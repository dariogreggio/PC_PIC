/******************************************************************************
 * FileName:        Serial.c
 *
 *******************************************************************************/

#include <xc.h>
#include <stdint.h>
#include "pc_pic_south.h"

static BYTE serialbits;

// -----------------------------------------------------------------------------
signed char InitUART(DWORD baudRate,BYTE bits,BYTE par,BYTE stop) {

// UART
	UART1TX_TRIS = 0;		// sembra cmq inutile qua
	UART1RX_TRIS = 1;

 	TRISB |=  0b0010000000000000;			// DSR
	TRISD |=  0b0000001100001010;			// UART; RI,DCD
	TRISD &= ~0b0000010000000101;			// UART; DTR
  LATD  &= ~0b0000010000000100;			// RTS & DTR inattivi
  
  // in effetti, se c'� il MAX232 questi si potrebbero evitare.. ma non c'� su tutti
#if defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
  CNPUBbits.CNPUB13=1;
  CNPUDbits.CNPUD8=CNPUDbits.CNPUD9=1;
#else
  //https://tldp.org/HOWTO/Serial-HOWTO-19.html
  CNPU2bits.CN31PUE=1;
  CNPU4bits.CN53PUE=CNPU4bits.CN54PUE=1;
#endif

  
#ifdef __PIC24FJ256GB206__
//  U1MODE=0b0000000010110000;    // TX,RX; 8bit async; BRGH=1
  
  U1MODE=0b0000000000001000;    // 8bit async; BRGH=1
  U1STA= 0b0000010000000000;    // TX
#endif
#if defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
  U1MODE=0b0000000000001000;    // 8bit async; BRGH=1
  U1STA= 0b0001010000000000;    // TX,RX
#endif
  uint32_t baudRateDivider = ((GetPeripheralClock()/(4*baudRate))-1);    //
  U1BRG=baudRateDivider;
// finire parita ecc
  U1MODEbits.PDSEL=0b00;     // 8 bit no parity
  //FINIR!
  U1MODEbits.STSEL=stop;     // stop bit
  // finire RTS CTS 
  //U1MODEbits.RTSMD
  //U1MODEbits.UEN
  U1MODEbits.UARTEN=1;
  U1STA= 0b0001010000000000;    // TX,RX DOPO riporcodio 30/10/21 (lascio anche per 206, 6/22...)
  
  serialbits=bits;
  
  IEC0bits.U1RXIE=1;
  
  __delay_ms(50);
  ClrWdt();

	return 1;
  }

char BusyUART(void) {
  
  return !U1STAbits.TRMT;
  }

char DataRdyUART(void) {
  
  return !U1STAbits.URXDA;
  }

unsigned char ReadUART(void) {    // diretto (v. anche IRQ)
  
  CommStatus.COMM_PERR=U1STAbits.PERR;
  return U1RXREG;
  }

int getcUART(void) {      // da buffer/IRQ
  BYTE ch;
  
  if(Buf232Ptr != Buf232Ptr2) {
    ch=Buf232[Buf232Ptr2++];
    Buf232Ptr2 &= (BUF_232_SIZE-1);
    return ch;
    }
  else
    return -1;
  }

void WriteUART(unsigned int data) {
  
  while(BusyUART())
    ClrWdt(); /* wait if the buffer is full */
  putcUART(data);
  }

void putcUART(unsigned int data) {
  
  switch(serialbits) {
    case 5:
      U1TXREG = data & 0x1f;
      break;
    case 6:
      U1TXREG = data & 0x3f;
      break;
    case 7:
      U1TXREG = data & 0x7f;
      break;
    case 8:
      U1TXREG = data & 0xff;
      break;
    case 9:
      U1TXREG = data & 0x1ff;
      break;
    }
  CommStatus.BUSY=!UART1CTS_IO;    // mah s� :) verificare polarit�
  }

void putsUART(const char *data) {
  
	while(*data)   // Transmit a byte
    WriteUART(*data++);
	}

BYTE getSerialFlags(void) {
  BYTE n;
  
  n = UART1DSR_IO;
  n |= UART1CTS_IO ? 2 : 0;
  n |= UART1RI_IO ? 4 : 0;
  n |= UART1DCD_IO ? 8 : 0;
  
  return n;
  }

WORD getSerialStatus(void) {
  WORD w=CommStatus.w;
  
  CommStatus.w=0;
  return w;
  }

uint8_t openSerial(DWORD baudrate,BYTE parity,BYTE bits,BYTE stop,BYTE flow) {

  if(baudrate==0 || baudrate>4000000 /* Fcy/4 */)
    return 0;
  uint32_t baudRateDivider = ((GetPeripheralClock()/(4*baudrate))-1);    //
  U1BRG=baudRateDivider;

  if(bits<5 || bits>9)
    return 0;
  serialbits=bits;
  U1MODEbits.PDSEL = bits <= 8 ? 
    (parity=='E' ? 0b01: (parity=='O' ? 0b10 : 0b00)) : 
    0b11 /*9 bit noparity*/;
  U1MODEbits.STSEL = stop == 1 ? 0 : 1;
  U1MODEbits.UEN = flow ? 0b11 : 0b00;      // verificare! e/o fare pure in software
  //U1MODEbits.RTSMD

  UART1RTS_IO=0;
  UART1DTR_IO=0;
  
  U1MODEbits.UARTEN=1;

  U1STA= 0b0001010000000000;    // TX,RX DOPO riporcodio 30/10/21

  return 1;
  }

void closeSerial(void) {

  U1MODEbits.UARTEN=0;
	}



