/*********************************************************************
 *
 *	Hardware specific definitions
 *
 *********************************************************************
 * FileName:        HardwareProfile.h
 * Dependencies:    None
 * Processor:       PIC24, dsPIC
 * Compiler:        Microchip XC16
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (c) 2011 Microchip Technology Inc.  All rights 
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and 
 * distribute: 
 * (i)  the Software when embedded on a Microchip microcontroller or 
 *      digital signal controller product ("Device") which is 
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c and 
 *      ENC28J60.h ported to a non-Microchip device used in 
 *      conjunction with a Microchip ethernet controller for the 
 *      sole purpose of interfacing with the ethernet controller. 
 *
 * You should refer to the license agreement accompanying this 
 * Software for additional information regarding your rights and 
 * obligations.
 *
 *
 * Date	                Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 10/03/06             Original, copied from Compiler.h
 * 06/25/09             dsPIC & PIC24H support 
 * 09/15/09             Added PIC24FJ256DA210 Development Board Support
 * 06/02/11             Added MPLAB X Support
 * 06/24/14				GD
 * 08/28/21				GK
 ********************************************************************/

#ifndef HARDWARE_PROFILE_H
#define HARDWARE_PROFILE_H

#define GetSystemClock() 32000000UL
#define GetPeripheralClock() (GetSystemClock()/2)
#define FCY (GetPeripheralClock())		// per LibPic30.h e delay


// Hardware I/O pin mappings


#define m_RXDataBit PORTFbits.RF4
#define m_RXClkBit PORTFbits.RF5
#define TXDataTris TRISFbits.TRISF4         //
#define TXClkTris TRISFbits.TRISF5         // 
#define m_RXDataBit2 PORTFbits.RF3
#define m_RXClkBit2 PORTFbits.RF1
#define TXDataTris2 TRISFbits.TRISF3         // 
#define TXClkTris2 TRISFbits.TRISF1         // 

#define m_IRQ   LATDbits.LATD7
#define m_ACK m_IRQ         // ev. usare poi BA5
#define SIRQ_MASK 0x0080


#define UART1TX_TRIS		(TRISDbits.TRISD0)
#define UART1TX_IO			(LATDbits.LATD0)
#define UART1RX_TRIS		(TRISDbits.TRISD1)
#define UART1RX_IO			(PORTDbits.RD1)
#define UART1DTR_TRIS		(TRISDbits.TRISD10)
#define UART1DTR_IO			(LATDbits.LATD10)
#define UART1DSR_TRIS		(TRISBbits.TRISB13)
#define UART1DSR_IO			(PORTBbits.RB13)
#define UART1CTS_TRIS		(TRISDbits.TRISD1)
#define UART1CTS_IO			(PORTDbits.RD1)
#define UART1RTS_TRIS		(TRISDbits.TRISD2)
#define UART1RTS_IO			(LATDbits.LATD2)
#define UART1RI_TRIS		(TRISDbits.TRISD9)      // CS1/RI errore datasheet 206, il 606 � giusto per entrambi @#$%& #leucemiapauley #supercancrokubler
#define UART1RI_IO			(PORTDbits.RD9)
#define UART1DCD_TRIS		(TRISDbits.TRISD8)
#define UART1DCD_IO			(PORTDbits.RD8)

// porta parallela su PORTB 0..7
#define m_PStrobeBit    LATFbits.LATF0          // pin 58
#define m_PLFBit        LATCbits.LATC13         // pin 47
#define m_PReset        LATCbits.LATC15         // pin 40
#define m_PSel          LATBbits.LATB11         // pin 24
#define m_PSelP         PORTCbits.RC14          // pin 48
#define m_PACK          PORTBbits.RB10          // pin 23
#define m_PPout         PORTBbits.RB9           // pin 22
#define m_PBusy         PORTBbits.RB8           // pin 21
#define m_PErr          PORTBbits.RB12          // pin 27


#define m_RD PORTDbits.RD5         // pin 53
#define m_WR PORTDbits.RD4         // pin 52


#define USB_USE_HID 1
    
#endif // #ifndef HARDWARE_PROFILE_H
