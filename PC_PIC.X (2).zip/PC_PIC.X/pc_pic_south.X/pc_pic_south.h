#ifndef _PC_PIC_SOUTHBRIDGE_H
#define _PC_PIC_SOUTHBRIDGE_H
    
    
#include "GenericTypeDefs.h"

#include "hardwareprofile.h"
#include "../pc_pic_cpu.X/pc_pic_bios.h"
#include "pc_pic_south_bios.h"
#include <libpic30.h>


/* check if build is for a real debug tool */
#if defined(__DEBUG) && !defined(__MPLAB_ICD2_) && !defined(__MPLAB_ICD3_) && \
   !defined(__MPLAB_PICKIT2__) && !defined(__MPLAB_PICKIT3__) && \
   !defined(__MPLAB_REALICE__) && \
   !defined(__MPLAB_DEBUGGER_REAL_ICE) && \
   !defined(__MPLAB_DEBUGGER_ICD3) && \
   !defined(__MPLAB_DEBUGGER_PK3) && \
   !defined(__MPLAB_DEBUGGER_PICKIT2) && \
   !defined(__MPLAB_DEBUGGER_PIC32MXSK)
    #warning Debug with broken MPLAB simulator
    #define USING_SIMULATOR
#endif


#define VERNUMH     1
#define VERNUML     2

//#define USA_SW_RTC 1
#define BUF_232_SIZE 512
#define BAUD_RATE 9600


union COMM_STATUS {			// 
	WORD w;
	struct {
// errori/flag in CommStatus Seriale, (LSB prima - right-aligned)
	unsigned int FRAME_2SEND:1;         // c'e' da mandare un frame
	unsigned int WAIT_4ACK  :1;
	unsigned int FRAME_REC  :1;         // c'e' un frame ricevuto
	unsigned int COMM_OVRERR:1;			// overrun seriale 
	unsigned int COMM_OVL   :1;         // errore di overflow buffer in ricezione 
	unsigned int COMM_TOUT  :1;         // errore di timeout in ricezione frame
	unsigned int COMM_FRERR :1;         // errore di framing (START/STOP) in ricezione 
	unsigned int COMM_PERR  :1;         // errore di parita' in ricezione  (0x80)
	unsigned int BUSY  :1;				// occupato
	unsigned int LINE_BUSY  :1;         // linea intasata, impossibile inviare
	unsigned int COMM_CRCERR  :1;       // errore di checksum in ricezione 
	};
	};

#define CR        0xd
#define LF        0xa
#define STX 2
#define ETX 3
#define EOT				4
#define ACK 6
#define XON 17
#define XOFF 19
#define DLE 16
#define NACK 21
#define ESC 27

extern volatile WORD Buf232Ptr,Buf232Ptr2;
extern volatile union COMM_STATUS CommStatus;
extern volatile BYTE Buf232[BUF_232_SIZE];
extern volatile BYTE second_10;
extern volatile WORD tick10;

void Timer_Init(unsigned int);
void PMP_Init(void);


signed char InitUART(DWORD,BYTE,BYTE,BYTE);
char BusyUART(void);
char DataRdyUART(void);
unsigned char ReadUART(void);
void putcUART(unsigned int);
void WriteUART(unsigned int);
void putsUART(const char *);
BYTE getSerialFlags(void);
void closeSerial(void);

signed char InitParallel(void);
void putcParallel(BYTE);
void writeParallel(BYTE);
BYTE getcParallel(void);
BYTE getParallelFlags(void);

signed char InitPS2(BYTE);
void WritePS2(BYTE,BYTE);

void syncPS2Leds(void);

// il Timer0 conta ogni 62.5nSec*prescaler=64... (@32MHz CPUCLK => 16MHz) su PIC24; fanno 4uS
#define TMR2BASE (((FCY/64)/10)-11)		//   100Hz per timer 
//#define TMR2BASE (20000-11)		//   10Hz per timer con ps=8


void bumpClock(void);
void notifyToCPU(BYTE,BYTE *,BYTE);


// *****************************************************************************
// *****************************************************************************
// Data Structures
// *****************************************************************************
// *****************************************************************************

typedef struct __attribute((packed)) _HID_REPORT_BUFFER {
  WORD  Report_ID;
  WORD  ReportSize;
  BYTE  ReportData[16];      // MESSO FISSO (come facemo in KUSmouse) anzich� malloc! (meglio per hot plug)
  WORD  ReportPollRate;
	}   HID_REPORT_BUFFER;

typedef union __attribute((packed)) _HID_LED_REPORT_BUFFER {
    BYTE b;
    struct {
        BYTE  NUM_LOCK      : 1;
        BYTE  CAPS_LOCK     : 1;
        BYTE  SCROLL_LOCK   : 1;
        BYTE  UNUSED        : 5;
        };
	} HID_LED_REPORT_BUFFER;
typedef union __attribute((packed)) _PS2_LED_REPORT_BUFFER {
    BYTE b;
    struct {
        BYTE  SCROLL_LOCK   : 1;
        BYTE  NUM_LOCK      : 1;
        BYTE  CAPS_LOCK     : 1;
        BYTE  UNUSED        : 5;
        };
	} PS2_LED_REPORT_BUFFER;

typedef enum __attribute((packed)) _APP_STATE {
  DEVICE_NOT_CONNECTED,
  DEVICE_CONNECTED, // Device Enumerated  - Report Descriptor Parsed 
  DEVICE_CONNECTED2, // post-init
  READY_TO_TX_RX_REPORT,
  GET_INPUT_REPORT, // perform operation on received report 
  INPUT_REPORT_PENDING,
  SEND_OUTPUT_REPORT, // Not needed in case of mouse 
  OUTPUT_REPORT_PENDING,
  ERROR_REPORTED 
	} APP_STATE;




#endif
    
