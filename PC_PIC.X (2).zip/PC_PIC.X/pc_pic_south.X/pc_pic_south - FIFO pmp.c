/******************************************************************************
 * FileName:        MainDemo.c
 * Dependencies:    see included files below
 * Processor:       PIC24F, dsPIC
 * Compiler:        XC16 
 * Company:         Microchip Technology, Inc.
 * Software License Agreement
 *
 * Copyright (c) 2011 Microchip Technology Inc.  All rights reserved.
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital
 * signal controller, which is integrated into your product or third party
 * product (pursuant to the sublicense terms in the accompanying license
 * agreement).  
 *
 * You should refer to the license agreement accompanying this Software
 * for additional information regarding your rights and obligations.
 *
 *******************************************************************************/

/************************************************************
 * Configuration Bits
 ************************************************************/

#ifdef __PIC24FJ256GB206__
// PIC24FJ256GB206 Configuration Bit Settings
// 'C' source line config statements

// CONFIG4

// CONFIG3
#pragma config WPFP = WPFP255           // Write Protection Flash Page Segment Boundary (Highest Page (same as page 170))
#pragma config SOSCSEL = SOSC           // Secondary Oscillator Power Mode Select (Secondary oscillator is in Default (high drive strength) Oscillator mode)
#pragma config WUTSEL = LEG             // Voltage Regulator Wake-up Time Select (Default regulator start-up time is used)
#pragma config ALTPMP = ALPMPDIS        // Alternate PMP Pin Mapping (EPMP pins are in default location mode)
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable (Segmented code protection is disabled)
#pragma config WPCFG = WPCFGDIS         // Write Protect Configuration Page Select (Last page (at the top of program memory) and Flash Configuration Words are not write-protected)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select (Protected code segment upper boundary is at the last page of program memory; the lower boundary is the code page specified by WPFP)

// CONFIG2
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary oscillator is disabled)
#pragma config IOL1WAY = ON             // IOLOCK One-Way Set Enable (The IOLOCK bit (OSCCON<6>) can be set once, provided the unlock sequence has been completed. Once set, the Peripheral Pin Select registers cannot be written to a second time.)
#pragma config OSCIOFNC = OFF           // OSCO Pin Configuration (OSCO/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Fail-Safe Clock Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = FRCDIV           // Initial Oscillator Select (Fast RC Oscillator with Postscaler (FRCDIV))
#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL is enabled automatically on start-up)
#pragma config PLLDIV = DIV12           // 96 MHz PLL Prescaler Select (Oscillator input is divided by 12 (48 MHz input))
#pragma config IESO = ON                // Internal External Switchover (IESO mode (Two-Speed Start-up) is enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Windowed WDT (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer (Watchdog Timer is enabled)
#pragma config ICS = PGx1               // Emulator Pin Placement Select bits (Emulator functions are shared with PGEC1/PGED1)
#pragma config GWRP = OFF               // General Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON              // JTAG Port Enable (JTAG port is enabled)

/* QUARZO
*/
//_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & ICS_PGx3 & FWDTEN_ON & WINDIS_OFF & FWPSA_PR32 & WDTPS_PS1024)
//_CONFIG2(IESO_OFF & FNOSC_PRIPLL & PLL_96MHZ_ON & OSCIOFNC_OFF & POSCMOD_HS & PLLDIV_DIV2 & FCKSM_CSDCMD & IOL1WAY_ON & DISUVREG_OFF )
//_CONFIG3(WPFP_WPFP0 &  WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM)

//USB Host
//        _CONFIG2(FNOSC_PRIPLL & POSCMOD_HS & PLL_96MHZ_ON & PLLDIV_DIV2 & IESO_OFF) // Primary HS OSC with PLL, USBPLL /2
//       _CONFIG1(JTAGEN_OFF & FWDTEN_OFF & ICS_PGx2)   // JTAG off, watchdog timer off

#elif defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
// PIC24FJ256GB606 Configuration Bit Settings
// 'C' source line config statements

#pragma config BTMODE = SINGLE          /* Boot Mode Configuration bits (Device is in Single Boot (legacy) mode) */
// FSEC
#pragma config BWRP = OFF               // Boot Segment Write-Protect bit (Boot Segment may be written)
#pragma config BSS = DISABLED           // Boot Segment Code-Protect Level bits (No Protection (other than BWRP))
#pragma config BSEN = OFF               // Boot Segment Control bit (No Boot Segment)
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GSS = DISABLED           // General Segment Code-Protect Level bits (No Protection (other than GWRP))
#pragma config CWRP = OFF               // Configuration Segment Write-Protect bit (Configuration Segment may be written)
#pragma config CSS = DISABLED           // Configuration Segment Code-Protect Level bits (No Protection (other than CWRP))
#pragma config AIVTDIS = OFF            // Alternate Interrupt Vector Table bit (Disabled AIVT)

// FBSLIM
#pragma config BSLIM = 0x1FFF           // Boot Segment Flash Page Address Limit bits (Enter Hexadecimal value)

// FOSCSEL
#pragma config FNOSC = FRCPLL           // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config PLLMODE = PLL96DIV2      // PLL Mode Selection (96 MHz PLL. (8 MHz input))
#pragma config IESO = OFF               // Two-speed Oscillator Start-up Enable bit (Start up with user-selected oscillator source)

// FOSC
#pragma config POSCMD = NONE            // Primary Oscillator Mode Select bits (Primary Oscillator disabled)
#pragma config OSCIOFCN = ON            // OSC2 Pin Function bit (OSC2 is general purpose digital I/O pin)
#pragma config SOSCSEL = OFF            // SOSC Power Selection Configuration bits (Digital (SCLKI) mode)
#pragma config PLLSS = PLL_FRC          // PLL Secondary Selection Configuration bit (PLL is fed by the on-chip Fast RC (FRC) oscillator)
#pragma config IOL1WAY = OFF            // Peripheral pin select configuration bit (Allow multiple reconfigurations)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)

// FWDT
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler bits (1:32,768)
#pragma config FWPSA = PR128            // Watchdog Timer Prescaler bit (1:128)
#pragma config FWDTEN = ON_SWDTEN       // Watchdog Timer Enable bits (WDT Enabled/Disabled (controlled using SWDTEN bit))
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config WDTWIN = WIN25           // Watchdog Timer Window Select bits (WDT Window is 25% of WDT period)
#pragma config WDTCMX = WDTCLK          // WDT MUX Source Select bits (WDT clock source is determined by the WDTCLK Configuration bits)
#pragma config WDTCLK = LPRC            // WDT Clock Source Select bits (WDT uses LPRC)

// FPOR
#pragma config BOREN = SBOREN           // Brown Out Enable bit (Controlled by SBOREN)
#pragma config LPCFG = OFF              // Low power regulator control (No Retention Sleep)
#pragma config DNVPEN = ENABLE          // Downside Voltage Protection Enable bit (Downside protection enabled using ZPBOR when BOR is inactive)

// FICD
#pragma config ICS = PGD2               // ICD Communication Channel Select bits (Communicate on PGEC2 and PGED2)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)
#pragma config BTSWP = OFF              // BOOTSWP Disable (BOOTSWP instruction disabled)

// FDEVOPT1
#pragma config ALTCMPI = DISABLE        // Alternate Comparator Input Enable bit (C1INC, C2INC, and C3INC are on their standard pin locations)
#pragma config TMPRPIN = OFF            // Tamper Pin Enable bit (TMPRN pin function is disabled)
#pragma config SOSCHP = OFF             // SOSC High Power Enable bit (valid only when SOSCSEL = 1 (Enable SOSC low power mode)
#pragma config ALTVREF = ALTVREFDIS       // Alternate Voltage Reference Location Enable bit (VREF+ and CVREF+ on RA10, VREF- and CVREF- on RA9)
    
#include <xc.h>
    
/* define map input pin numbers */ 
enum {   
    RPI_RB0  = 0,  /* RPI00 */ 
    RPI_RB1 ,      /* RPI01 */ 
    RPI_RD8 ,      /* RPI02 */ 
    RPI_RD10,      /* RPI03 */ 
    RPI_RD9 ,      /* RPI04 */ 
    RPI_RB6  = 6,  /* RPI06 */ 
    RPI_RB7 ,      /* RPI07 */ 
    RPI_RB8 ,      /* RPI08 */ 
    RPI_RB9 ,      /* RPI09 */ 
    RPI_RF4 ,      /* RPI10 */ 
    RPI_RD0 ,      /* RPI11 */ 
    RPI_RD11,      /* RPI12 */ 
    RPI_RB2 ,      /* RPI13 */ 
    RPI_RB14,      /* RPI14 */ 
    RPI_RF3  = 16, /* RPI16 */ 
    RPI_RF5 ,      /* RPI17 */ 
    RPI_RB5 ,      /* RPI18 */ 
    RPI_RG8 ,      /* RPI19 */ 
    RPI_RD5 ,      /* RPI20 */ 
    RPI_RG6 ,      /* RPI21 */ 
    RPI_RD3 ,      /* RPI22 */ 
    RPI_RD2 ,      /* RPI23 */ 
    RPI_RD1 ,      /* RPI24 */ 
    RPI_RD4 ,      /* RPI25 */ 
    RPI_RG7 ,      /* RPI26 */ 
    RPI_RG9 ,      /* RPI27 */ 
    RPI_RB4 ,      /* RPI28 */ 
    RPI_RB15,      /* RPI29 */ 
    RPI_RF2 ,      /* RPI30 */ 
    RPI_RC14 = 37, /* RPI37 */ 
    RPI_NONE = 0x3f 
};  
    
/* define map output function numbers */ 
enum {   
    RPO_NONE    = 0,    /* (Pin Disabled)            */
    RPO_C1OUT   = 1,    /* Comparator 1 Output       */
    RPO_C2OUT   = 2,    /* Comparator 2 Output       */
    RPO_C3OUT   = 26,   /* Comparator 3 Output       */
    RPO_SDO1    = 7,    /* SPI1 Data Output          */
    RPO_SCK1OUT = 8,    /* SPI1 Clock Output         */
    RPO_SS1OUT  = 9,    /* SPI1 Slave Select Output  */
    RPO_SDO2    = 10,   /* SPI2 Data Output          */
    RPO_SCK2OUT = 11,   /* SPI2 Clock Output         */
    RPO_SS2OUT  = 12,   /* SPI2 Slave Select Output  */
    RPO_SDO3    = 23,   /* SPI3 Data Output          */
    RPO_SCK3OUT = 24,   /* SPI3 Clock Output         */
    RPO_SS3OUT  = 25,   /* SPI3 Slave Select Output  */
    RPO_OC1     = 13,   /* Output Compare 1          */
    RPO_OC2     = 14,   /* Output Compare 2          */
    RPO_OC3     = 15,   /* Output Compare 3          */
    RPO_OCM4    = 16,   /* CCP4 Output Compare       */
    RPO_OCM5    = 17,   /* CCP5 Output Compare       */
    RPO_OCM6    = 18,   /* CCP6 Output Compare       */
    RPO_OCM7    = 27,   /* CCP7 Output Compare       */
    RPO_U1TX    = 3,    /* UART1 Transmit            */
    RPO_U1RTS   = 4,    /* UART1 Request-to-Send     */
    RPO_U2TX    = 5,    /* UART2 Transmit            */
    RPO_U2RTS   = 6,    /* UART2 Request-to-Send     */
    RPO_U3TX    = 19,   /* UART3 Transmit            */
    RPO_U3RTS   = 20,   /* UART3 Request-to-Send     */
    RPO_U4TX    = 21,   /* UART4 Transmit            */
    RPO_U4RTS   = 22,   /* UART4 Request-to-Send     */
    RPO_REFO    = 28,   /* Reference Clock Output    */
    RPO_CLC1OUT = 29,   /* CLC1 Output               */
    RPO_CLC2OUT = 30,   /* CLC2 Output               */
    RPO_RTCC    = 31,   /* RTCC Output               */
};  
#endif

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>




/************************************************************
 * Includes
 ************************************************************/
#include <ctype.h>
#include <stdlib.h>
#include "pc_pic_south.h"

#include <pps.h>


#include "usb_config.h"
#include "usb.h"
#include "usb_host_hid_parser.h"
#include "usb_host_hid.h"
#include "usb_host_local.h"
#include "ps2.h"

#define USBInitialize(f) USBHostInit(f)			// RIDEFINITA per poter avere returncode! v. main





#ifdef USA_BOOTLOADER 
//#define BL_ENTRY_BUTTON PORTEbits.RE0 //button 1...

//If defined, the reset vector pointer and boot mode entry delay
// value will be stored in the device's vector space at addresses 0x100 and 0x102
#define USE_VECTOR_SPACE
//****************************************

//Bootloader Vectors *********************
#ifdef USE_VECTOR_SPACE
	/*
		Store delay timeout value & user reset vector at 0x100 
		(can't be used with bootloader's vector protect mode).
		
		Value of userReset should match reset vector as defined in linker script.
		BLreset space must be defined in linker script.
	*/
	unsigned char timeout  __attribute__ ((space(prog),section(".BLreset"))) = 0x0A;
	unsigned int userReset  __attribute__ ((space(prog),section(".BLreset"))) = 0xC00; 
//cambiato ordine o le metteva a cazzo... 
#else
	/*
		Store delay timeout value & user reset vector at start of user space
	
		Value of userReset should be the start of actual program code since 
		these variables will be stored in the same area.
	*/
	unsigned int userReset  __attribute__ ((space(prog),section(".init"))) = 0xC04 ;
	unsigned char timeout  __attribute__ ((space(prog),section(".init"))) = 5 ;
#endif
#endif



static const char _PC_PIC_SOUTHBRIDGE_C[]= {"PIC24FJ256GB206 PC_PIC_SOUTHBRIDGE - 13/12/2021\r\n\r\n"};
#ifdef USA_BOOTLOADER 
	' ','B','L',
#endif
static const char Copyr1[]="(C) Dario's Automation 2021 - G.Dar\xd\xa\x0";
// MORTE AGLI UMANI FOREVER!!!

/************************************************************
 * Defines
 ************************************************************/

/************************************************************
 * Function Prototypes
 ************************************************************/



/************************************************************
 * Variables
 ************************************************************/

//Flags

extern volatile APP_STATE App_State_USB;
extern BOOL DisplayConnectOnce,DisplayDetachOnce;
extern HID_DATA_DETAILS Appl_ModifierKeysDetails;
extern HID_DATA_DETAILS Appl_NormalKeysDetails;
extern HID_REPORT_BUFFER     Appl_raw_report_buffer;
extern HID_LED_REPORT_BUFFER Appl_led_report_buffer;
extern BYTE ErrorDriver;
extern BYTE ErrorCounter;
extern HID_DATA_DETAILS Appl_LED_Indicator;
extern BOOL ReportBufferUpdated;
extern BYTE NumOfBytesRcvd;
void App_ProcessInputReport(void);
void App_PrepareOutputReport(void);
void App_Detect_Device(void);
void App_Clear_Data_Buffer(void);
void InitializeTimer(void);
#define MAX_ERROR_COUNTER 10

extern BYTE PS2Errors;
extern BYTE SlavePresent;

extern BYTE CAPS_Lock_Pressed;
extern BYTE NUM_Lock_Pressed;

BYTE keyToSend;

void PromptMouseConnesso(void);
void PromptMouseSconnesso(void);
void ReportDatiMouse(void);
BYTE mouseEvent[4];

extern BYTE TPLfound;

BYTE IRQCode,IRQParm;
extern volatile BYTE commandParms[128],commandReceived,commandParmCnt,commandOldReg;


/************************************************************
 * int main (void)
 ************************************************************/
int main(void) {
	char buffer[64];
	int i;

	ANSB=0x0000;
	ANSC=0x0000;
	ANSD=0x0000;
	ANSE=0x0000;
	ANSF=0x0000;
	ANSG=0x0000;

 

#if defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
  // v. anche https://www.microchip.com/forums/m1080639.aspx
//  OSCDIV=0;
//	CLKDIVbits.RCDIV = 0b001;		// 
//	CLKDIVbits.CPDIV = 0b00;		// 
  CLKDIVbits.PLLEN     = 1; //
  while(OSCCONbits.LOCK != 1);
#endif
  
#ifdef __PIC24FJ256GB206__
  CLKDIVbits.PLLEN     = 1; //
  while(OSCCONbits.LOCK != 1);
  
	CLKDIVbits.RCDIV = 0;		// Set 1:1 8MHz FRC postscaler pll
#endif


	LATB =  0b0011011100000000;			// BA; PACK, POUT, PBUSY, PERR; DSR
	// finire!
	LATC =  0b0101000000000000;			// PSEL; CLKIn
	LATD =  0b0000101110111010;			// CS; IRQ; UART; RI,DCD; WR,RD
	LATE =  0b0000000000000000;			// 
	LATF =  0b0000000000000000;			// 
	LATG =  0b0000000000000000;			// 

	TRISB = 0b1111011100000000;			// BA; PACK, POUT, PBUSY, PERR; DSR
	TRISC = 0b0101000000000000;			// PSEL; CLKIn
#if defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
	TRISD = 0b0000101100111010;			// CS; UART; RI,DCD; WR,RD. CS & RI invertiti cmq!
#else
	TRISD = 0b0000101100111010;			// CS; UART; RI,DCD; WR,RD
#endif
	TRISE = 0b0000000011111111;			// BD
	TRISF = 0b0000000000111010;			// PS/2
	TRISG = 0b0000001111000000;			// BA

  //https://en.wikipedia.org/wiki/Parallel_port secondo lui alcuni sono sia in che out...
  CNPUBbits.CNPUB8=CNPUBbits.CNPUB9=CNPUBbits.CNPUB10=CNPUCbits.CNPUC14=CNPUBbits.CNPUB12=1;
  //https://tldp.org/HOWTO/Serial-HOWTO-19.html
  CNPUBbits.CNPUB13=1;
#if defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
  CNPUDbits.CNPUD4=CNPUDbits.CNPUD5=CNPUDbits.CNPUD8=CNPUDbits.CNPUD9=1;
#else
  CNPUDbits.CNPUD4=CNPUDbits.CNPUD5=CNPUDbits.CNPUD8=CNPUDbits.CNPUD11=1;
#endif


//	while(1) {	/*LED1_IO ^= 1;*/ ClrWdt(); 		// test clock 606
//		LATB ^= 0xffff; }		// 30/10/21: 2MHz = 250nS per 4 istruzioni ASM (1+1+2), ok 32MHz


//#ifndef USA_BOOTLOADER mah e invece s� s� s�

// Unlock Registers
//	PPSUnLock;
//	PPSOutput(PPS_RP11, PPS_U1TX);      // TXD pin 46 RD0
//	PPSInput(PPS_U1RX, PPS_RP24);      // RXD pin 49 RD1
//  PPSOutput(PPS_RP23,PPS_U1RTS);      // RTS pin 50 RD2
//  PPSInput(PPS_U1CTS,PPS_RP22);      // CTS pin 51 RD3
//	PPSLock;
  __builtin_write_OSCCONL(OSCCON & 0xbf);
  RPINR18bits.U1RXR = 24;
  RPINR18bits.U1CTSR = 22;
  RPOR5bits.RP11R = 3;
  RPOR11bits.RP23R = 4;
  __builtin_write_OSCCONL(OSCCON | 0x40);


#ifndef USING_SIMULATOR
  __delay_ms(250);
#endif 
  
  Timer_Init(TMR2BASE);
  PMP_Init();

  
	InitUART(BAUD_RATE,8,0,1);

  putsUART("Booting...\r\n");

	ClrWdt();



//	LED0_IO ^= 1;

  InitParallel();


#ifndef USING_SIMULATOR
	USBInitialize(0);
#endif 
  
  InitPS2(0);



  while(1) {
		ClrWdt();

//		LATB ^= 0xffff;   //12.5uS 30/10/21
		switch(commandReceived) {
			case 0:
				break;
			case 4:
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
			case BIOS_SERIAL_INIT:
				InitUART(MAKELONG(MAKEWORD(commandParms[0],commandParms[1]),MAKEWORD(commandParms[2],commandParms[3])),commandParms[4],commandParms[5],commandParms[6]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
			case BIOS_SERIAL_WRITE:
				WriteUART(commandParms[0]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
			case BIOS_PARALLEL_INIT:
				InitParallel();
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
			case BIOS_PARALLEL_WRITE:
				putcParallel(commandParms[0]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
			case BIOS_PS2_INIT:
				InitPS2(commandParms[0]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
			case BIOS_PS2_WRITE:
	//        WritePS2(parms[0],parms[1]);
				if(commandParms[0])
					PS2out(commandParms[0]);     // finire...
				else
					PS2out(commandParms[0]);     // finire...
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
				break;
      case BIOS_KEYBOARD_SETLED:
        Appl_led_report_buffer.b=commandParms[0];
        App_State_USB = SEND_OUTPUT_REPORT;
        if(SlavePresent) {
          BYTE TEMP0;
        	i=PS2_slaveout(0xED);
          if(i != 0xff) {							// controllo ev. errore (piu' che altro x debug...)
            TEMP0=InputSlave();				// aspettare ACK?
            //		call PS2_slavein
            i=PS2_slaveout(Appl_led_report_buffer.b /*VERIFICARE!!*/);
            if(i != 0xff) {							// controllo ev. errore (piu' che altro x debug...)
              TEMP0=InputSlave();				// aspettare ACK?
              }
            }
          }
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
        break;
      case BIOS_INVALID:
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
        break;
      default:
        commandReceived=commandParmCnt=commandOldReg=0;
        m_ACK=1;
        break;
			}


    USBTasks();
    App_Detect_Device();
    switch(App_State_USB) {
	    case DEVICE_NOT_CONNECTED:
        if(TPLfound==TPL_MOUSE)
          PromptMouseSconnesso();
        else
          T3CONbits.TON = 0;                  // stop timer 
        if(DisplayDetachOnce == FALSE) {
          #ifdef DEBUG_MODE
          putsUART( "Device Detached \r\n" );
          #endif
          DisplayDetachOnce = TRUE;
          Appl_raw_report_buffer.Report_ID = 0;
          Appl_raw_report_buffer.ReportSize = 0;
          Appl_raw_report_buffer.ReportPollRate = 0;
          TPLfound=0;
      		}
        if(USBHostHID_ApiDeviceDetect()) {		// True if report descriptor is parsed with no error
          App_State_USB = DEVICE_CONNECTED;
          DisplayConnectOnce = FALSE;
          }
        break;
        
      case DEVICE_CONNECTED:
        App_State_USB = READY_TO_TX_RX_REPORT;
        if(DisplayConnectOnce == FALSE) {
          #ifdef DEBUG_MODE
          putsUART( "Explorer16 Board \r\n" );
          putsUART( "USB HIDHost Demo \r\n" );
          #endif
          DisplayConnectOnce = TRUE;
          DisplayDetachOnce = FALSE;
		      }
        if(TPLfound==TPL_MOUSE)
          PromptMouseConnesso();
          // per questioni di velocit� qua chiediamo sempre report (cos� era in consilium cancro ai vostri figli ecc)
          //  ma forse non � il massimo... vedere
        else
          InitializeTimer(); // start 10ms timer to schedule input reports
        break;
        
      case READY_TO_TX_RX_REPORT:
        if(!USBHostHID_ApiDeviceDetect()) {
          App_State_USB = DEVICE_NOT_CONNECTED;
//          deviceInfoHID[i].ID.deviceAddress=0;
          TPLfound=0;
          //                                DisplayOnce = FALSE;
          }
        else {
          if(TPLfound==TPL_MOUSE)
            App_State_USB = GET_INPUT_REPORT;
          }
        break;
        
      case GET_INPUT_REPORT:
        if(TPLfound==TPL_MOUSE) {
          if(USBHostHID_ApiGetReport(Appl_raw_report_buffer.Report_ID,0,
            Appl_raw_report_buffer.ReportSize, Appl_raw_report_buffer.ReportData)) {
            // Host may be busy/error -- keep trying 
            }
          else {
            App_State_USB = INPUT_REPORT_PENDING;
            }
          }
        else {
          if(USBHostHID_ApiGetReport(Appl_raw_report_buffer.Report_ID,Appl_ModifierKeysDetails.interfaceNum,
            Appl_raw_report_buffer.ReportSize, Appl_raw_report_buffer.ReportData)) {
            // Host may be busy/error -- keep trying 
            }
          else {
            App_State_USB = INPUT_REPORT_PENDING;
            }
          }
        break;
        
      case INPUT_REPORT_PENDING:
        if(USBHostHID_ApiTransferIsComplete(&ErrorDriver,&NumOfBytesRcvd)) {
          if(ErrorDriver || (NumOfBytesRcvd != Appl_raw_report_buffer.ReportSize)) {
	          ErrorCounter++;
	          if(MAX_ERROR_COUNTER <= ErrorDriver)
	            App_State_USB = ERROR_REPORTED;
	          else
	            App_State_USB = READY_TO_TX_RX_REPORT;
          	}
          else {
            ErrorCounter = 0; 
            ReportBufferUpdated = TRUE;
            App_State_USB = READY_TO_TX_RX_REPORT;

            if(DisplayConnectOnce == TRUE) {
							int i;
              for(i=0; i<Appl_raw_report_buffer.ReportSize; i++) {
                if(Appl_raw_report_buffer.ReportData[i] != 0) {
                  DisplayConnectOnce = FALSE;
                  }
              	}
          		}

            if(TPLfound==TPL_MOUSE) {
              ReportDatiMouse();
              }
            else {
              App_ProcessInputReport();
              App_PrepareOutputReport();
              }
        		}
          }
        break;

      case SEND_OUTPUT_REPORT: // Will be done while implementing Keyboard 
        if(USBHostHID_ApiSendReport(Appl_LED_Indicator.reportID,Appl_LED_Indicator.interfaceNum, 
          Appl_LED_Indicator.reportLength, (BYTE*)&Appl_led_report_buffer)) {
          // Host may be busy/error -- keep trying 
          }
        else {
          App_State_USB = OUTPUT_REPORT_PENDING;
	        }
        break;

      case OUTPUT_REPORT_PENDING:
        if(USBHostHID_ApiTransferIsComplete(&ErrorDriver,&NumOfBytesRcvd)) {
        	if(ErrorDriver) {
           ErrorCounter++ ; 
           if(MAX_ERROR_COUNTER <= ErrorDriver)
               App_State_USB = ERROR_REPORTED;

           //                                App_State_USB = READY_TO_TX_RX_REPORT;
          	}
          else {
            ErrorCounter = 0; 
            App_State_USB = READY_TO_TX_RX_REPORT;
            }
          }
        break;

      case ERROR_REPORTED:
        break;
        
      default:
        break;

      }



		if(!m_RXDataBit)	{		//Check for slave request-to-send
      BYTE TEMP0;
//			__builtin_disableinterrupts();					//Request-to-send detected
			TEMP0=PS2_slavein();
			if(!(PS2Errors & 8))
				// o fare RESEND_PS2_slaveout
				slaveKbHandler(TEMP0);
//			goto	Stream5;
//			__builtin_enableinterrupts();
			}

		if(!m_RXDataBit2)	{		//Check for slave request-to-send
      BYTE TEMP0;
//			__builtin_disableinterrupts();					//Request-to-send detected
			TEMP0=PS2_slavein();
			if(!(PS2Errors & 8))
				// o fare RESEND_PS2_slaveout
				slaveKbHandler(TEMP0);
//			goto	Stream5;
//			__builtin_enableinterrupts();
			}
    
    if(keyToSend) {
      notifyToCPU(EVENT_KEYBOARD,&keyToSend,1);
      
      WriteUART(keyToSend);//test vari..
//      putcParallel(keyToSend);//test vari..
      
      if(keyToSend == 0x53 /*KEY_NUMLOCK USB */) {
        ReportBufferUpdated=1;
        App_PrepareOutputReport();
        if(SlavePresent) {
          BYTE TEMP0;
        	i=PS2_slaveout(0xED);
          if(i != 0xff)	{						// controllo ev. errore (piu' che altro x debug...)
            TEMP0=InputSlave();				// aspettare ACK?
            //		call PS2_slavein
            i=PS2_slaveout(Appl_led_report_buffer.b /*VERIFICARE!!*/);
            if(i != 0xff) {							// controllo ev. errore (piu' che altro x debug...)
              TEMP0=InputSlave();				// aspettare ACK?
              }
            }
          }
        }
      if(keyToSend == 0x39 /*KEY_CAPSLOCK USB */) {
        ReportBufferUpdated=1;
        App_PrepareOutputReport();
        }
      
      if(keyToSend == 'a') {//test vari..
        TXClkTris2 ^= 1;
        TXDataTris ^= 1;
        }
      
      keyToSend=0;
      }
    
    if(mouseEvent[0] || mouseEvent[1] || mouseEvent[2]) {
      notifyToCPU(EVENT_MOUSE,mouseEvent,4);
      
      WriteUART(mouseEvent[1]);//test vari..
      
      mouseEvent[0]=mouseEvent[1]=mouseEvent[2]=mouseEvent[3]=0;
      }
    
    if(Buf232Ptr2 != Buf232Ptr) {
      notifyToCPU(EVENT_RS232,(BYTE*)&Buf232[Buf232Ptr2],1);   // v. anche IRQ UART... quale usare?
      Buf232Ptr2 = Buf232Ptr;
      }

    
		if(second_10) {

//      m_PReset ^= 1;    // test

//WriteUART('u');
//WriteUART(TPLfound);
//WriteUART(App_State_USB);
//WriteUART(Appl_raw_report_buffer.ReportSize);

      second_10=0;
				}				// 0.1 sec

		}			//main loop


  return (-1);
	}

void notifyToCPU(BYTE event,BYTE *parm,BYTE size) {
  
  IRQCode=event;  
  IRQParm=parm[0];
  
  m_IRQ=0;
  __delay_us(1);
  m_IRQ=1;
  
  }

// -----------------------------------------------------------------------------
void Timer_Init(unsigned int tim) {
  
  T2CON=0;
  T2CONbits.TCS = 0;                  // clock from peripheral clock
  T2CONbits.TCKPS = 0b10;             // 1:64 prescale
  T2CONbits.T32=0;
  PR2=TMR2BASE;                       // 
  T2CONbits.TON = 1;                  // start timer 
  
  IFS0bits.T2IF=0;
  IPC1bits.T2IP=4;
  IEC0bits.T2IE=1;
  
  }


void PMP_Init(void) {

  PMCON1= 0b0000000100000001;     // slave PSP mode buffered; no CS1 & 2; IRQ sempre
  PMCON2= 0b0000000000000000;     // 
  PMCON3= 0b0000000000000000;     // no WR & RD; byte mode; 0 wait state
  PMCS1CF=0b0010000000000000;     // CS1 abilitato NON CAMBIA UN CAZZO PORCODIO; 8bit; tutti segnali attivi low 
  PMCS2CF=0b1000000000000000;     // CS2 disabilitato
//  PMCS1BS=0b0000000000000000;     // base addresses VERIFICARE!
//  PMCS2BS=0b0000000000000000;     // mah lasciamo default, dice 0x80 e 0x8080
  PMCS1MD=0b0000000000000000;     // no ack; chip select modes; no delays
  PMCS2MD=0b0000000000000000;     // idem pare
//  PMCON4 =0b0000000000111111;     // BA0..7
  PMCON4 =0b0000000000000000;     // BA0..7

  

  
#ifdef __PIC24FJ256GB206__
  PADCFG1=0b0000000000000010;     // schmitt-trigger levels MA ANCHE RTCC OUTPUT seconds!
#elif defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
#endif
  
  PMCON1bits.PMPEN=1;
  IPC11bits.PMPIP=6;
  IFS2bits.PMPIF=0;
  IEC2bits.PMPIE=1;
	}


// ----------------------------------------------------------------------

