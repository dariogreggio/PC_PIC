// PS/2 routines comuni - 04/5/03 - 13/7/04 - 19/12/07 - 19/1/08
// versione C 1/3/2005
// (C) ADPM Synthesis sas 2001-2008 - G.Dar, Cyberdyne 2009-2012
//		(portions Copyright 2001, Adam Chapweske chap0179@tc.umn.edu)
// 2021 GD/K per PC_PIC motherboard

// PARAMETRIZZARE i BIT e le PORTE usate!!


#include <xc.h>
#include "ps2.h"
#include "pc_pic_south.h"



BYTE PS2Errors;			// b0..1=errori master, b2.3=errori slave - input..output

BYTE SlavePresent;
BYTE LedStatus;


// ----------------------------------------------------------------------
signed char InitPS2(BYTE q) {
  BYTE i;

  LATF  &= ~0b0000000000111010;     // 
  TRISF &= ~0b0000000000111010;     // tengo in reset
  ODCF  = 	0b0000000000111010;
  
  __delay_ms(200);
  TRISF |= 0b0000000000111010;
  ClrWdt();
  __delay_ms(100);
  
  PS2_slaveout(0xFF);   // la risposta qua arriva subito! v. main loop, dev'essere pronto!
  
  i=Input();    // 0xAA...
  slaveKbHandler(i);

//  PS2out(0xF2);   // Read ID?
  
  PS2_slaveout(0xED);   // SetLed
  i=PS2_slavein();
  slaveKbHandler(i);
  PS2_slaveout(0x1);   // FINIRE!
  i=PS2_slavein();
  slaveKbHandler(i);

  PS2_slaveout(0xF4);   // Enable
  i=PS2_slavein();
  slaveKbHandler(i);

  
// tutti e due..  PS2_slaveout2(0xFF);   // la risposta qua arriva subito! v. main loop, dev'essere pronto!

  }

//---------------------------------------------------------------------------------------------
//Wait for host to send data, then read one byte of data

BYTE Input(void) {
	BYTE masterInTimer;

	PS2Errors &= ~1;
	masterInTimer=255;
	while(m_RXDataBit && masterInTimer) {
		ClrWdt();
		__delay_us(5);
		masterInTimer--;
		}
	if(masterInTimer)
		return PS2in();
	else {
		PS2Errors |= 1;
		return 0;
		}
	}

BYTE InputSlave(void) {
	BYTE slaveInTimer;

	slaveInTimer=255;
	PS2Errors &= ~4;

	do {
		ClrWdt();
		if(!m_RXDataBit) {
			return PS2_slavein();
			}

		__delay_us(5);
		} while(--slaveInTimer);

	PS2Errors |= 4;
	return 0;
	}


//---------------------------------------------------------------------------------------------
//When this routine is called, CLOCK must have already been pulled low by the host
BYTE PS2in(void) {
	BYTE COUNTER,PARITY,i,TEMP0,masterInTimer;

	masterInTimer=255;
	while(!m_RXClkBit && masterInTimer) {
		ClrWdt();
		__delay_us(1);
		masterInTimer--;
		}
	if(!masterInTimer)
		return 0x00;

	__delay_us(1);
	if(m_RXDataBit)
		return 0x00;

	COUNTER=0x08;			//Setup a counter
	PARITY=0;
	TEMP0 = 0;	

	do {
		i=PS2inBit();
		if(!m_RXClkBit)		//Host abort?
			return	0x00;				//  Yes--return (00=errore)
		TEMP0 >>= 1;	
//			TEMP0 &= 0x7f;	
		TEMP0 |= i;	
		PARITY ^= i;
		} while(--COUNTER);

	i=PS2inBit();		//Parity Bit
	if(!m_RXClkBit)		//Host abort?
		return	0x00;				//  Yes--return (00=errore)
	PARITY ^= i;

	do {
		i=PS2inBit();		//Stop Bit
		if(!m_RXClkBit)			//Host abort?
			return	0x00;					//  Yes--return (00=errore)
		} while(!m_RXDataBit);		//Host released DATA?
		//  Nope--clock again

	__delay_us(33);			//Acknowledge
	TXDataTris=0;
	__delay_us(5);
	TXClkTris=0;
	__delay_us(40);
	TXClkTris=1;
	__delay_us(5);
	TXDataTris=1;
	__delay_us(40);			// NON C'ERA!! poi era 1 (e andava x il mouse...) poi portato a 20 con PC Siemens! 
									// In pratica, la PS2Out si sovrapponeva a PS2in (e il PC non riceveva gli ACK dalla tastiera) ************

	if(PARITY & 0x80)
		goto	noError;

	i=PS2InError();
// IN LARIMART NON C'ERA!!! PROVARE A TOGLIERLO!


	TEMP0=0;

noError:


#ifdef DEBUG_232
//	movfw	TEMP0					FARE!!! v. interlin.asm
//	call PutByte232_HW
#endif
//		call PutByte232	; ***** debug
//		movfw	TEMP0				; recupero


	return TEMP0;
	}

//---------------------------------------------------------------------------------------------
BYTE PS2inBit(void) {

	__delay_us(30);
	TXClkTris=0;
	__delay_us(40);
	TXClkTris=1;
	__delay_us(5);
	return m_RXDataBit ? 0x80 : 0x00;
	}


		
BYTE PS2out(BYTE n) {
	BYTE COUNTER,PARITY,i,TEMP0;
	BYTE timeout_timer;





	__delay_us(50);			//						luglio 2004



	PS2Errors |= 2;

	timeout_timer=255;
	while(!m_RXClkBit && timeout_timer) {
		ClrWdt();
		__delay_us(5);
		timeout_timer--;
		}
	if(!m_RXClkBit)
		return 0xFE;

	__delay_us(2);					// era 1 **************

	PS2Errors &= ~2;

	if(!m_RXDataBit)
		return	0xFF;

	PARITY=0x01;			// ODD parity (dis-parity!)
	COUNTER=0x08;
	TEMP0=n;
	__delay_us(10);					// era 18 in 2003
	PS2outBit(0);			// Start bit
	__delay_us(3);

	do {
		PARITY ^= TEMP0;
		PS2outBit(TEMP0);
		if(!m_RXClkBit) {
			PS2outEnd();
			return 0xFF;
			}
		TEMP0 >>= 1;
		} while(--COUNTER);

	__delay_us(5);
	PS2outBit(PARITY);
	__delay_us(5);
	PS2outBit(0x01);
	__delay_us(35);
	return	0x00;
	}

void PS2outBit(BYTE n) {
//https://retrocomputing.stackexchange.com/questions/15607/why-is-the-clock-frequency-of-the-ps-2-keyboard-protocol-so-high
//10-16KHz, siamo a 11~
	TXDataTris= n & 0x01;

	__delay_us(18);
	TXClkTris=0;
	__delay_us(40);
	TXClkTris=1;
	__delay_us(15);					//25 in 2003					; era 15 IN mOUSE lARIMART!!
	}


BYTE PS2outEnd(void) {

	TXClkTris=1;
	TXDataTris=1;


//		Delay	25					; prova luglio 2004

	return 0xFF;

	}

BYTE PS2InError(void) {
  }


BYTE PS2_slaveinBit(void) {
	BYTE i,slaveInTimer;

	slaveInTimer=250;					// ca. 1mS max (x2=5KHz min. acc.)

	do {
		ClrWdt();
		if(!m_RXClkBit)				// aspetto che CLK scenda...
			goto  PS2_slaveinBit2;

		__delay_us(2);
		} while(--slaveInTimer);
	return 0xff;

PS2_slaveinBit2:
	__delay_us(2);
	if(m_RXClkBit)					// CLK DEVE essere ancora basso!!
		return 0xff;

#ifdef DEBUG3
	LATCbits.LATC3 ^= 1;		// ***** debug
#endif

	i= m_RXDataBit ? 0x80 : 0x00;

	slaveInTimer=250;						// ca. 1mS max (x2=5KHz min. acc.)

	do {
		ClrWdt();
		if(m_RXClkBit)				// aspetto che CLK risalga...
			goto  PS2_slaveinBit4;

		__delay_us(2);
		} while(--slaveInTimer);
	return 0xff;

PS2_slaveinBit4:
	return i;

	}


BYTE PS2_slavein(void) {
	BYTE i,PARITY,TEMP0,COUNTER;

	i=PS2_slaveinBit();
	if(i == 0xff) {									// se errore...
//		clrf SlavePresent
//			LATCbits.LATC0 = 0;		// ***** debug
		PS2Errors |= 8;
		return 0xff;
		}

		
	COUNTER=0x08;		//Setup a counter
	PARITY=0;
	TEMP0=0;		// forse inutile...
	PS2Errors &= ~8;

	do {
		i=PS2_slaveinBit();
		if(i == 0xff)	{								// se errore...
			SlavePresent=0;
//			LATCbits.LATC0 = 0;		// ***** debug
			PS2Errors |= 8;
			return 0xff;
			}

		TEMP0 >>= 1;
		TEMP0 |= i;
		PARITY ^= i;
		} while(--COUNTER);


	i=PS2_slaveinBit();			//Parity Bit
	if(i == 0xff) {									// se errore...
//	clrf SlavePresent
//			LATCbits.LATC0 = 0;		// ***** debug
		PS2Errors |= 8;
		return 0xff;
		}

	PARITY ^= i;

	i=PS2_slaveinBit();			//Stop Bit
	if(i == 0xff)	{								// se errore...
//		clrf SlavePresent
//			LATCbits.LATC0 = 0;		// ***** debug
		PS2Errors |= 8;
		return 0xff;
		}

	if(i == 0x80) {														// dev'essere "1"!!
		if(PARITY & 0x80) {

#ifdef DEBUG1
	PutByte232(TEMP0)	;			//***** debug
#endif

#ifdef DEBUG_232
	//	movfw	TEMP0					FARE!!! v. interlin.asm
	//	call PutByte232_HW
#endif

			return TEMP0;
			}
		}


//		call	PS2InError
// NO!! COSA DEVO FARE??
	PS2Errors |= 8;


#ifdef DEBUG2
		PutByte232(TEMP0);		// ***** debug
#endif

#ifdef DEBUG_232
//	movfw	TEMP0					FARE!!! v. interlin.asm
//	call PutByte232_HW
#endif

	return 0;

	}


BYTE PS2_slaveout(BYTE n) {
	BYTE i,slaveInTimer,PARITY,COUNTER,TEMP0;


	TXClkTris2=0;				// blocco eventuali trasmissioni...
	__delay_us(100);
	TXDataTris2=0;				// inizio la trasmissione...
	__delay_us(2);
	TXClkTris2=1;
//		Delay 2


// il loop di ritardo che segue e' importante perche' (come da documentazione) se si cerca di scrivere alla slave mentre era inibita, questa puo' metterci fino a 10mS per iniziare a generare il clock...
	slaveInTimer=255;

	do {
		ClrWdt();
		if(!m_RXClkBit)				// aspetto che CLK scenda...
			goto PS2_slaveoutStart2;

		__delay_us(25);
		} while(--slaveInTimer);
	TXDataTris2=1;				// inizio la trasmissione...
	TXClkTris2=1;

	return 0xff;

PS2_slaveoutStart2:

//		clrw
//		call  PS2_slaveoutBit
		
	PARITY=0x01;
	COUNTER=0x08;
	TEMP0 =n;

	do {
		PARITY ^= TEMP0;
		i=PS2_slaveoutBit(TEMP0);
		if(i == 0xff) { 									// se errore...
			TXDataTris2=1;				// fine trasmissione...
//		clrf SlavePresent
//			LATCbits.LATC0 = 0;		// ***** debug
			return 0xff;
			}

		TEMP0 >>= 1;
		} while(--COUNTER);

	PS2_slaveoutBit(PARITY);
	PS2_slaveoutBit(0x01);

	TXDataTris2=1;				// fine trasmissione (forse inutile xche' lo fa il stop-bit)

// aspetto ACK dalla tastiera/mouse!!
	PS2_slaveinBit();
// controllare???
	return	0x00;


	}

BYTE PS2_slaveoutBit(BYTE n) {
	BYTE slaveInTimer;
		
	slaveInTimer=255;

	do {
		ClrWdt();
		if(!m_RXClkBit)				// aspetto che CLK scenda... NON DOVREBBE ESSERE il "2" ?? ! (2012)
			goto  PS2_slaveoutBit2;

		__delay_us(1);
		} while(--slaveInTimer);

	return 0xff;


PS2_slaveoutBit2:

#ifndef __18F4550
	TXDataTris2 = n & 1;
#endif





	slaveInTimer=255;

	do {
		ClrWdt();
		if(m_RXClkBit)				// aspetto che CLK salga...
			goto  PS2_slaveoutBit4;

		__delay_us(1);
		} while(--slaveInTimer);

	return 0xff;

PS2_slaveoutBit4:
	return 0;

	}


BYTE slaveKbHandler(BYTE cmd) {
	BYTE TEMP0;

	switch(cmd) {
		case 0xAA:

//0xAA - Power on self test passed - BAT complete
slaveKb_AA:

			SlavePresent |= 1;


//			LATCbits.LATC0 = 1;		// ***** debug


//mandare lo stato dei led??
//			slave_KB_ED();

			return 0x00;
			break;

		case 0xFA:
//0xFA - Acknowledge
slaveKb_FA:
			return 0x00;
			break;

		case 0xEE:
//0xEE - Set Echo
slaveKb_EE:
			return 0x00;
			break;

		case 0xFE:
//0xFE - Resend
slaveKb_FE:
//		call  ACK_PS2_slaveout			;Unbuffered output 0xFA (acknowledge)
//		goto	PS2_slaveOut					; ammesso che serva, forse bisogna rispedire l'intero ultimo blocchetto (che potrebbe in effetti essere un solo byte, sempre, per lo slave)
			return 0x00;
			break;

		case 0xFC:
//0xFC - Power on self test Failed !
slaveKb_FC:

// che fare??
//		movlw 0x0
//		movwf SlavePresent

			return 0x00;
			break;

		case 0x0:
		case 0xff:
//0x00 o 0xFF - Error or buffer overflow
slaveKb_00_FF:
			return 0x00;
			break;

		default:


			SlavePresent |= 1;			// se sono qua, la slave c'e'!
//			LATCbits.LATC0 = 1;		// ***** debug

			return 0;
//		goto slaveKbError		boh?? no, mai...
			break;



//Invalid Command
slaveKbError:
//		movlw	0xFC
//		call	PacketOut1Byte
			return 0xFF;

		}			// switch
	}			// slaveKBHandler


void slave_KB_ED(void) {
	BYTE i,TEMP0;

	i=PS2_slaveout(0xED);
	if(i == 0xff)							// controllo ev. errore (piu' che altro x debug...)
		goto Kb_ED_2;

	TEMP0=InputSlave();				// aspettare ACK?
//		call PS2_slavein

		// gli inoltra lo stato dei led
	i=PS2_slaveout(LedStatus);
	if(i == 0xff)							// controllo ev. errore (piu' che altro x debug...)
		goto Kb_ED_2;

	TEMP0=InputSlave();				// aspettare ACK?

Kb_ED_2:
				;
	}

