#include <xc.h>

#include "pc_pic_south.h"
#include "pc_pic_south.h"

	
volatile WORD Buf232Ptr=0,Buf232Ptr2=0;
volatile union COMM_STATUS CommStatus;
volatile BYTE Buf232[BUF_232_SIZE];

volatile WORD tick10=0;
volatile BYTE second_10=0;
volatile BYTE CommTimer;					// timeout in ricezione 

extern BYTE IRQCode,IRQParm;
//extern BYTE keyToSend;

//extern volatile __eds__ BYTE __attribute__((eds,noload)) epmp_data;
#define PMPWaitBusy()   while(PMCON2bits.BUSY); 

BYTE ByteRec;
void __attribute__ ((interrupt,/*shadow*/,no_auto_psv)) _U1RXInterrupt(void) {

//		ClrWdt();
 	
  if(U1STAbits.FERR) {
		U1STAbits.FERR=0;
	  CommStatus.COMM_FRERR=1;
//									kLED0_IO^=1;
    }
	if(U1STAbits.OERR) {			// non mi interessano i caratteri ev. in attesa...
		U1STAbits.OERR=0;
//									kLED1_IO^=1;

		CommStatus.COMM_OVRERR=1;
		}

//	while(DataRdyUART1()) {	// bah non si capisce se ha senso.. credo di no cmq
  CommStatus.COMM_PERR=U1STAbits.PERR;
  ByteRec = U1RXREG;


  Buf232[Buf232Ptr++]=ByteRec;				// max BUF_232_SIZE
  Buf232Ptr &= (BUF_232_SIZE-1);
  if(Buf232Ptr == Buf232Ptr2)
    CommStatus.COMM_OVL  =1;         // errore di overflow buffer in ricezione 

// mmm no, meglio da main...  notifyToCPU(EVENT_RS232,&ByteRec,1);
	

	IFS0bits.U1RXIF = 0;
	}



// ---------------------------------------------------------------------------------------

void __attribute__ (( interrupt, /*shadow*/,  no_auto_psv )) _T2Interrupt(void) {
	static BYTE divider1s=0;

//	LATC ^= 0xffff; 

	second_10=1;					// flag
	tick10++;
	divider1s++;

	if(divider1s==20) {		// finire se serve..
		if(CommTimer)
			CommTimer--;
		divider1s=0;
		}


	IFS0bits.T2IF = 0; 			//Clear the Timer2 interrupt status flag 
	}


volatile BYTE commandParms[128],commandReceived,commandOldReg,commandParmCnt;
void __attribute__ (( interrupt, shadow,  no_auto_psv)) _PMPInterrupt(void) {
  BYTE reg,dIO;
  int g=PORTG,b=PORTB;
  
// ?? DOV'�??  addr=PMADDR & 255; non in slave cmq

  if(PMSTAT & 0x000F /* patch pd && !(PMSTAT & 0x0F00)*/) {
//    TRISE &= ~0b0000000011111111;   // serve o � automatico?
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
    if(reg != commandOldReg) {
      commandOldReg=reg;
      commandParmCnt=0;
      }
    switch(reg) {
      case BIOS_GETID:
        dIO='S';
				commandOldReg=commandParmCnt=0;
        break;
      case BIOS_GETVERSION:
				switch(commandParmCnt) {
					case 0:
		        dIO=VERNUML;
						commandParmCnt++;
		        break;
					case 1:
		        dIO=VERNUMH;
  					commandOldReg=commandParmCnt=0;
		        break;
					}
        break;
      case BIOS_GETCONFIG:
				dIO=0;		// fare
				commandOldReg=commandParmCnt=0;
        break;
			case BIOS_IRQ_REQUEST:
				dIO=IRQCode;
        IRQCode=0;
				commandOldReg=commandParmCnt=0;
				break;
			case BIOS_SERIAL_READ:
//				dIO=ReadUART();
				dIO=ByteRec;
				commandOldReg=commandParmCnt=0;
				break;
			case BIOS_PARALLEL_READ:
//				dIO=getcParallel();
				dIO;    // finire!
				commandOldReg=commandParmCnt=0;
				break;
      case BIOS_KEYBOARD_READ:
				dIO=IRQParm;
				commandOldReg=commandParmCnt=0;
				break;
      default:
				dIO=reg;
				commandOldReg=commandParmCnt=0;
        break;
      }

    if(PMSTATbits.OB0E) {
      *((BYTE *)&PMDOUT1)=dIO;
      }
    else if(PMSTATbits.OB1E) {
      *(((BYTE *)&PMDOUT1)+1)=dIO;
      }
    else if(PMSTATbits.OB2E) {
      *((BYTE *)&PMDOUT2)=dIO;
      }
    else if(PMSTATbits.OB3E) {
      *(((BYTE *)&PMDOUT2)+1)=dIO;
      }
    
    if(PMSTATbits.OBUF) {
      commandOldReg=commandParmCnt=0;
      PMSTATbits.OBUF=0;
      }
    
		commandParmCnt &= 15;

//    TRISE |= 0b0000000011111111;   // serve o � automatico?
	  }
  
  
  if(PMSTATbits.IB0F) {
    dIO=*((BYTE *)&PMDIN1);
    goto is_read;
    }
  else if(PMSTATbits.IB1F) {
    dIO=*(((BYTE *)&PMDIN1)+1);
    goto is_read;
    }
  else if(PMSTATbits.IB2F) {
    dIO=*((BYTE *)&PMDIN2);
    goto is_read;
    }
  else if(PMSTATbits.IB3F) {
    dIO=*(((BYTE *)&PMDIN2)+1);
is_read:
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
    if(reg != commandOldReg) {
      commandOldReg=reg;
      commandParmCnt=0;
      }
    if(!commandReceived) {
      switch(reg) {
        case 0:
          commandReceived=BIOS_INVALID;
          commandParms[0]=dIO;
          commandOldReg=commandParmCnt=0;
          break;
  //			case 4:
  //				???
  //				break;
        case BIOS_SERIAL_INIT:
          commandParms[commandParmCnt++]=dIO;
          if(commandParmCnt>=7) {
            commandReceived=BIOS_SERIAL_INIT;
            commandOldReg=commandParmCnt=0;
            m_ACK=0;
            }
          break;
        case BIOS_SERIAL_WRITE:
          commandParms[0]=dIO;
          commandReceived=BIOS_SERIAL_WRITE;
          commandOldReg=commandParmCnt=0;
          m_ACK=0;
          break;
        case BIOS_PARALLEL_INIT:
          commandParms[commandParmCnt++]=dIO;
          if(commandParmCnt>=1) {
            commandOldReg=commandParmCnt=0;
            m_ACK=0;
            }
          break;
        case BIOS_PARALLEL_WRITE:
          commandParms[0]=dIO;
          commandReceived=BIOS_PARALLEL_WRITE;
          commandOldReg=commandParmCnt=0;
          m_ACK=0;
          break;
        case BIOS_PS2_INIT:
          commandParms[commandParmCnt++]=dIO;
          if(commandParmCnt>=7) {
            commandReceived=BIOS_PS2_INIT;
            commandOldReg=commandParmCnt=0;
            m_ACK=0;
            }
          break;
        case BIOS_PS2_WRITE:
          commandParms[commandParmCnt++]=dIO;
          commandReceived=BIOS_PS2_WRITE;
          commandOldReg=commandParmCnt=0;
          m_ACK=0;
          break;
        case BIOS_KEYBOARD_SETLED:
          commandParms[0]=dIO;
          commandReceived=BIOS_KEYBOARD_SETLED;     // ??
          commandOldReg=commandParmCnt=0;
          m_ACK=0;
          break;
        case BIOS_RESET:
            m_ACK=0;
          while(1);		// pu� servire!
          break;
        default:
          dIO;
          commandReceived=BIOS_INVALID;
          commandOldReg=commandParmCnt=0;
          break;

        }
      }
    if(PMSTATbits.IBOV) {
      commandOldReg=commandParmCnt=0;
      commandReceived=0;
      PMSTATbits.IBOV=0;
      m_ACK=1;
      }
    }
  

	IFS2bits.PMPIF = 0; 			//Clear the PSP interrupt status flag 
	}



void _ISR __attribute__((__no_auto_psv__)) _AddressError(void) {
	Nop();
	Nop();
	}

void _ISR __attribute__((__no_auto_psv__)) _StackError(void) {
	Nop();
	Nop();
	}
	
