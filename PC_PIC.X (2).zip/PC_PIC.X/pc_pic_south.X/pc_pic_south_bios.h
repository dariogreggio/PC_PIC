#ifndef _PC_PIC_SOUTHBRIDGEBIOS_H
#define _PC_PIC_SOUTHBRIDGEBIOS_H
    
    
#include "GenericTypeDefs.h"


enum __attribute((packed)) BIOS_SOUTHBRIDGE {
    BIOS_SERIAL_INIT=8,
    BIOS_SERIAL_CHAR=9,
    BIOS_PARALLEL_INIT=12,
    BIOS_PARALLEL_CHAR=13,
    BIOS_PS2_INIT=15,
    BIOS_PS2_WRITE=16,
    BIOS_KEYBOARD_READ=17,
    BIOS_KEYBOARD_LED=18
    };

enum __attribute((packed)) {
    EVENT_KEYBOARD=1,
    EVENT_MOUSE,
    EVENT_RS232,
    EVENT_CENTRONICS,
    EVENT_USB_IN,
    EVENT_USB_OUT,
	};


#endif
    
    