#include <xc.h>


#include "pc_pic_south.h"

	
volatile WORD Buf232Ptr=0,Buf232Ptr2=0;
volatile union COMM_STATUS CommStatus;
volatile BYTE Buf232[BUF_232_SIZE];

volatile WORD tick10=0;
volatile BYTE second_10=0;
volatile BYTE CommTimer;					// timeout in ricezione 

extern volatile BYTE IRQCode,IRQParm[4];
//extern BYTE keyToSend;
extern BYTE SlavePresent;

//extern volatile __eds__ BYTE __attribute__((eds,noload)) epmp_data;
//solo master...#define PMPWaitBusy()   while(PMCON2bits.BUSY); 

BYTE ByteRec;
void __attribute__ ((interrupt,/*shadow*/,no_auto_psv)) _U1RXInterrupt(void) {

//		ClrWdt();
 	
  if(U1STAbits.FERR) {
		U1STAbits.FERR=0;
	  CommStatus.COMM_FRERR=1;
//									kLED0_IO^=1;
    }
	if(U1STAbits.OERR) {			// non mi interessano i caratteri ev. in attesa...
		U1STAbits.OERR=0;
//									kLED1_IO^=1;

		CommStatus.COMM_OVRERR=1;
		}

//	while(DataRdyUART1()) {	// bah non si capisce se ha senso.. credo di no cmq
  CommStatus.COMM_PERR=U1STAbits.PERR;
  ByteRec = U1RXREG;


  Buf232[Buf232Ptr++]=ByteRec;				// max BUF_232_SIZE
  Buf232Ptr &= (BUF_232_SIZE-1);
  if(Buf232Ptr == Buf232Ptr2)
    CommStatus.COMM_OVL  =1;         // errore di overflow buffer in ricezione 

// mmm no, meglio da main...  notifyToCPU(EVENT_RS232,&ByteRec,1);
	

	IFS0bits.U1RXIF = 0;
	}



// ---------------------------------------------------------------------------------------

void __attribute__ (( interrupt, /*shadow*/,  no_auto_psv )) _T2Interrupt(void) {
	static BYTE divider1s=0;

//	LATC ^= 0xffff; 

	second_10=1;					// flag
	tick10++;
	divider1s++;

	if(divider1s==20) {		// finire se serve..
		if(CommTimer)
			CommTimer--;
		divider1s=0;
		}


	IFS0bits.T2IF = 0; 			//Clear the Timer2 interrupt status flag 
	}


volatile BYTE commandParms[128],commandReceived,commandOldRegR,commandParmCntR;
void __attribute__ (( interrupt, shadow, no_auto_psv)) _PMPInterrupt(void) {
  BYTE reg,dIO;
  WORD g=PORTG,b=PORTB;
  static BYTE commandParmCntW,commandOldRegW;
  
  if(PMSTATbits.IB0F) {
    dIO=*((BYTE *)&PMDIN1);
    goto is_read;
    }
  else if(PMSTATbits.IB1F) {
    dIO=*(((BYTE *)&PMDIN1)+1);
    goto is_read;
    }
  else if(PMSTATbits.IB2F) {
    dIO=*((BYTE *)&PMDIN2);
    goto is_read;
    }
  else if(PMSTATbits.IB3F) {
    dIO=*(((BYTE *)&PMDIN2)+1);
is_read:
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
    if(reg != commandOldRegR) {
      commandOldRegR=reg;
      commandParmCntR=0;
      }
    if(!commandReceived) {
      switch(reg) {
        case 0:
          commandReceived=BIOS_INVALID;
          commandParms[0]=dIO;
          commandOldRegR=commandParmCntR=0;
          break;
  //			case 4:
  //				???
  //				break;
        case BIOS_SERIAL_INIT:
          commandParms[commandParmCntR++]=dIO;
          if(commandParmCntR>=7) {
            commandReceived=BIOS_SERIAL_INIT;
            commandOldRegR=commandParmCntR=0;
            m_ACK=0;
            }
          break;
        case BIOS_SERIAL_WRITE:
          commandParms[0]=dIO;
          commandReceived=BIOS_SERIAL_WRITE;
          commandOldRegR=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_PARALLEL_INIT:
          commandParms[commandParmCntR++]=dIO;
          if(commandParmCntR>=1) {
            commandOldRegR=commandParmCntR=0;
            m_ACK=0;
            }
          break;
        case BIOS_PARALLEL_WRITE:
          commandParms[0]=dIO;
          commandReceived=BIOS_PARALLEL_WRITE;
          commandOldRegR=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_PS2_INIT:
          commandParms[commandParmCntR++]=dIO;
          if(commandParmCntR>=7) {
            commandReceived=BIOS_PS2_INIT;
            commandOldRegR=commandParmCntR=0;
            m_ACK=0;
            }
          break;
        case BIOS_PS2_WRITE:
          commandParms[commandParmCntR++]=dIO;
          commandReceived=BIOS_PS2_WRITE;
          commandOldRegR=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_KEYBOARD_SETLED:
          commandParms[0]=dIO;
          commandReceived=BIOS_KEYBOARD_SETLED;     // ??
          commandOldRegR=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_RESET:
          m_ACK=0;
          while(1);		// pu� servire!
          break;
        default:
          dIO;
          commandReceived=BIOS_INVALID;
          commandOldRegR=commandParmCntR=0;
          break;

        }
      }
    if(PMSTATbits.IBOV) {
      commandOldRegR=commandParmCntR=0;
      commandReceived=0;
      PMSTATbits.IBOV=0;
      m_ACK=1;
      }
    }
  
//  if(PMSTATbits.OB0E) { no, non va..
  if(PMSTAT & 0x000F) {
//    TRISE &= ~0b0000000011111111;   // serve o � automatico?
    
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
      
//      U1TXREG=reg;
    if(reg != commandOldRegW) {
      commandOldRegW=reg;
      commandParmCntW=0;
      }
      
    switch(reg) {
      case BIOS_GETID:
        dIO='S';
				commandOldRegW=commandParmCntW=0;
        break;
      case BIOS_GETVERSION:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
		        dIO=VERNUML;
						commandParmCntW++;
		        break;
					case 1:
		        dIO=VERNUMH;
     				commandOldRegW=commandParmCntW=0;
		        break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
					}
        break;
      case BIOS_GETCONFIG:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
		        dIO='S';
						commandParmCntW++;
		        break;
					case 1:
		        dIO='P';
						commandParmCntW++;
		        break;
					case 2:
		        dIO='2';
						commandParmCntW++;
		        break;
					case 3:
		        dIO='U';
						commandParmCntW++;
		        break;
					case 4:
		        dIO='U';
    				commandOldRegW=commandParmCntW=0;
		        break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
        break;
      case BIOS_GETSTATUS:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
		        dIO=SlavePresent;
						commandParmCntW++;
		        break;
					case 1:
		        // dIO=getParallelFlags(); ma NON posso usare funzioni! salvare da loop principale o boh..
            dIO=(PORTB >> 8) & 0b111;
            dIO ^= 0x100;
            dIO |= PORTB & 0b0001000000000000 ? 0b1000 : 0;
            dIO |= PORTC & 0b0100000000000000 ? 0b10000 : 0;
						commandParmCntW++;
		        break;
					case 2:
//            dIO=getSerialFlags(void)  idem..
            dIO=CommStatus.w;   // finire LO/HI

//            dIO=getSerialStatus(void)  idem
            dIO = UART1DSR_IO;
            dIO |= UART1CTS_IO ? 2 : 0;
            dIO |= UART1RI_IO ? 4 : 0;
            dIO |= UART1DCD_IO ? 8 : 0;
						commandParmCntW++;
		        break;
					case 3:
		        dIO='U';
  					commandOldRegW=commandParmCntW=0;
		        break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
        break;
			case BIOS_IRQ_REQUEST:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
    				dIO=IRQCode;
            IRQCode=0;
    				commandOldRegW=commandParmCntW=0;
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
				break;
			case BIOS_SERIAL_READ:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
//				dIO=ReadUART();
            dIO=IRQParm[0];
            IRQParm[0]=IRQParm[1]=0;
    				commandOldRegW=commandParmCntW=0;
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
				break;
			case BIOS_PARALLEL_READ:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
//				dIO=getcParallel();
            TRISB |= 0b0000000011111111;
            dIO = PORTB & 0b0000000011111111;
    				commandOldRegW=commandParmCntW=0;
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
				break;
      case BIOS_KEYBOARD_READ:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
            dIO=IRQParm[0];
            commandParmCntW++;
            break;
          case 1:
            dIO=IRQParm[1];
            IRQParm[0]=IRQParm[1]=0;
    				commandOldRegW=commandParmCntW=0;
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
				break;
      default:
				dIO=reg;
				commandOldRegW=commandParmCntW=0;
        break;
      }
    
    if(PMSTATbits.OB0E) {
      *((BYTE *)&PMDOUT1)=dIO;
      }
    else if(PMSTATbits.OB1E) {
      *(((BYTE *)&PMDOUT1)+1)=dIO;
      }
    else if(PMSTATbits.OB2E) {
      *((BYTE *)&PMDOUT2)=dIO;
      }
    else if(PMSTATbits.OB3E) {
      *(((BYTE *)&PMDOUT2)+1)=dIO;
      }
    if(PMSTATbits.OBUF) {
      commandOldRegW=commandParmCntW=0;
      PMSTATbits.OBUF=0;
      }
    
//      U1TXREG=dIO;


//    TRISE |= 0b0000000011111111;   // serve o � automatico?
	  }
  
  

	IFS2bits.PMPIF = 0; 			//Clear the PSP interrupt status flag 
	}



void _ISR __attribute__((__no_auto_psv__)) _AddressError(void) {
	Nop();
	Nop();
	}

void _ISR __attribute__((__no_auto_psv__)) _StackError(void) {
	Nop();
	Nop();
	}
	
