#include <xc.h>


#include "pc_pic_south.h"

	
volatile WORD Buf232Ptr=0,Buf232Ptr2=0;
volatile union COMM_STATUS CommStatus;
volatile BYTE Buf232[BUF_232_SIZE];

volatile WORD tick10=0;
volatile BYTE second_10=0;
volatile BYTE CommTimer;					// timeout in ricezione 

extern volatile BYTE IRQCode,IRQParm;
//extern BYTE keyToSend;

//extern volatile __eds__ BYTE __attribute__((eds,noload)) epmp_data;
#define PMPWaitBusy()   while(PMCON2bits.BUSY); 

BYTE ByteRec;
void __attribute__ ((interrupt,/*shadow*/,no_auto_psv)) _U1RXInterrupt(void) {

//		ClrWdt();
 	
  if(U1STAbits.FERR) {
		U1STAbits.FERR=0;
	  CommStatus.COMM_FRERR=1;
//									kLED0_IO^=1;
    }
	if(U1STAbits.OERR) {			// non mi interessano i caratteri ev. in attesa...
		U1STAbits.OERR=0;
//									kLED1_IO^=1;

		CommStatus.COMM_OVRERR=1;
		}

//	while(DataRdyUART1()) {	// bah non si capisce se ha senso.. credo di no cmq
  CommStatus.COMM_PERR=U1STAbits.PERR;
  ByteRec = U1RXREG;


  Buf232[Buf232Ptr++]=ByteRec;				// max BUF_232_SIZE
  Buf232Ptr &= (BUF_232_SIZE-1);
  if(Buf232Ptr == Buf232Ptr2)
    CommStatus.COMM_OVL  =1;         // errore di overflow buffer in ricezione 

// mmm no, meglio da main...  notifyToCPU(EVENT_RS232,&ByteRec,1);
	

	IFS0bits.U1RXIF = 0;
	}



// ---------------------------------------------------------------------------------------

void __attribute__ (( interrupt, /*shadow*/,  no_auto_psv )) _T2Interrupt(void) {
	static BYTE divider1s=0;

//	LATC ^= 0xffff; 

	second_10=1;					// flag
	tick10++;
	divider1s++;

	if(divider1s==20) {		// finire se serve..
		if(CommTimer)
			CommTimer--;
		divider1s=0;
		}


	IFS0bits.T2IF = 0; 			//Clear the Timer2 interrupt status flag 
	}


volatile BYTE commandParms[128],commandReceived,commandOldReg,commandParmCntR;
void __attribute__ (( interrupt, shadow, no_auto_psv)) _PMPInterrupt(void) {
  BYTE reg,dIO;
  int g=PORTG,b=PORTB;
  static BYTE commandParmCntW;
  
  if(PMSTATbits.IBF ) {   // se metto prima la Read, qua poi mi trovo sempre zero in PMDIN!! perch�?? (solo in non-buffered, pare)
    dIO=PMDIN1;
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
    if(reg != commandOldReg) {
      commandOldReg=reg;
      commandParmCntR=0;
      }
    if(!commandReceived) {
      switch(reg) {
        case 0:
          commandReceived=BIOS_INVALID;
          commandParms[0]=dIO;
          commandOldReg=commandParmCntR=0;
          break;
  //			case 4:
  //				???
  //				break;
        case BIOS_SERIAL_INIT:
          commandParms[commandParmCntR++]=dIO;
          if(commandParmCntR>=7) {
            commandReceived=BIOS_SERIAL_INIT;
            commandOldReg=commandParmCntR=0;
            m_ACK=0;
            }
          break;
        case BIOS_SERIAL_WRITE:
          commandParms[0]=dIO;
          commandReceived=BIOS_SERIAL_WRITE;
          commandOldReg=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_PARALLEL_INIT:
          commandParms[commandParmCntR++]=dIO;
          if(commandParmCntR>=1) {
            commandOldReg=commandParmCntR=0;
            m_ACK=0;
            }
          break;
        case BIOS_PARALLEL_WRITE:
          commandParms[0]=dIO;
          commandReceived=BIOS_PARALLEL_WRITE;
          commandOldReg=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_PS2_INIT:
          commandParms[commandParmCntR++]=dIO;
          if(commandParmCntR>=7) {
            commandReceived=BIOS_PS2_INIT;
            commandOldReg=commandParmCntR=0;
            m_ACK=0;
            }
          break;
        case BIOS_PS2_WRITE:
          commandParms[commandParmCntR++]=dIO;
          commandReceived=BIOS_PS2_WRITE;
          commandOldReg=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_KEYBOARD_SETLED:
          commandParms[0]=dIO;
          commandReceived=BIOS_KEYBOARD_SETLED;     // ??
          commandOldReg=commandParmCntR=0;
          m_ACK=0;
          break;
        case BIOS_RESET:
            m_ACK=0;
          while(1);		// pu� servire!
          break;
        default:
          dIO;
          commandReceived=BIOS_INVALID;
          commandOldReg=commandParmCntR=0;
          break;

        }
      }
    if(PMSTATbits.IBOV) {
      commandOldReg=commandParmCntR=0;
      commandReceived=0;
      PMSTATbits.IBOV=0;
      m_ACK=1;
      }
    }
  
  if(PMSTATbits.OBE) {
//    TRISE &= ~0b0000000011111111;   // serve o � automatico?
    
      reg=(g >> 4) & 0b00111100;
      reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
      
//      U1TXREG=reg;
    if(reg != commandOldReg) {
      commandOldReg=reg;
      commandParmCntW=0;
      }
      
    switch(reg) {
      case BIOS_GETID:
        dIO='S';
				commandOldReg=commandParmCntW=0;
        break;
      case BIOS_GETVERSION:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
		        dIO=VERNUML;
						commandParmCntW++;
		        break;
					case 2:
		        dIO=VERNUMH;
						commandParmCntW++;
		        break;
					case 3:
		        dIO=VERNUMH;
  					commandOldReg=commandParmCntW=0;
		        break;
					}
        break;
      case BIOS_GETCONFIG:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          }
				dIO=0;		// fare
				commandOldReg=commandParmCntW=0;
        break;
			case BIOS_IRQ_REQUEST:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
    				dIO=IRQCode;
            commandParmCntW++;
            break;
          case 1:
    				dIO=IRQCode;
            IRQCode=0;
    				commandOldReg=commandParmCntW=0;
            break;
          }
				break;
			case BIOS_SERIAL_READ:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
//				dIO=ReadUART();
            dIO=IRQParm;
            commandParmCntW++;
            break;
          case 1:
//				dIO=ReadUART();
            dIO=IRQParm;
            IRQParm=0;
    				commandOldReg=commandParmCntW=0;
            break;
          }
				break;
			case BIOS_PARALLEL_READ:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
//				dIO=getcParallel();
				dIO;    // finire!
            commandParmCntW++;
            break;
          case 1:
//				dIO=getcParallel();
				dIO;    // finire!
    				commandOldReg=commandParmCntW=0;
            break;
          }
				break;
      case BIOS_KEYBOARD_READ:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
            dIO=IRQParm;
            commandParmCntW++;
            break;
          case 1:
            dIO=IRQParm;
            IRQParm=0;
    				commandOldReg=commandParmCntW=0;
            break;
          }
				break;
      default:
				dIO=reg;
				commandOldReg=commandParmCntW=0;
        break;
      }
    
    PMDOUT1=commandParmCntW;
    if(PMSTATbits.OBUF) {
      commandOldReg=commandParmCntW=0;
      PMSTATbits.OBUF=0;
      }
    
      U1TXREG=dIO;

		commandParmCntW &= 15;

//    TRISE |= 0b0000000011111111;   // serve o � automatico?
	  }
  
  

	IFS2bits.PMPIF = 0; 			//Clear the PSP interrupt status flag 
	}



void _ISR __attribute__((__no_auto_psv__)) _AddressError(void) {
	Nop();
	Nop();
	}

void _ISR __attribute__((__no_auto_psv__)) _StackError(void) {
	Nop();
	Nop();
	}
	
