/******************************************************************************
 * FileName:        Parallel.c
 *
 *******************************************************************************/

#include <xc.h>
#include "pc_pic_south.h"

// ----------------------------------------------------------------------
signed char InitParallel(void) {
  
  TRISB &= ~0b0000100011111111;   // PD0..7; PSELP
  TRISB |=  0b0001011100000000;   // PACK, POUT, PBUSY, PERR
  TRISC &= ~0b1010000000000000;   // PRST, PLF
  TRISC |=  0b0100000000000000;   // PSEL
  TRISF &= ~0b0000000000000001;   // PSTRB
  
  //https://en.wikipedia.org/wiki/Parallel_port secondo lui alcuni sono sia in che out...
#ifdef __PIC24FJ256GB206__
  CNPU1bits.CN0PUE=CNPU2bits.CN26PUE=CNPU2bits.CN27PUE=CNPU2bits.CN28PUE=CNPU3bits.CN32PUE=CNPU2bits.CN30PUE=1;
#elif defined(__PIC24FJ256GB606__) || defined(__PIC24FJ512GB606__)
  /*manca su RC14..*/ CNPUBbits.CNPUB8=CNPUBbits.CNPUB9=CNPUBbits.CNPUB10=CNPUCbits.CNPUC14=CNPUBbits.CNPUB12=1;
#endif
  
  LATB &= ~0b0000100011111111;
  LATC &= ~0b1010000000000000;
  LATF &= ~0b0000000000000001;
  LATB |=  0b0000100000000000;      // tutti alti ossia inattivi; dati a 0
  LATC |=  0b1010000000000000;      // RESET attivo!
  LATF |=  0b0000000000000001;
  
  __delay_ms(250);    // di + :)
  m_PReset=0;     // NON invertito, dice

  return 1;
  }

void putcParallel(unsigned char data) {
  WORD i;

  TRISB &= ~0b0000000011111111;
  i= LATB & 0b1111111100000000;
  LATB = i | data;
  __delay_us(10);
  m_PStrobeBit=0;
  __delay_us(50);
  m_PStrobeBit=1;
  }

void writeParallel(unsigned char data) {
  
  while(!m_PBusy)     // attivo basso
    ClrWdt();
  putcParallel(data);
  while(!m_PACK)     // attivo alto
    ClrWdt();
//  return 1;
  }

BYTE getcParallel(void) {
  
  TRISB |= 0b0000000011111111;
  __delay_us(5);
  return PORTB & 0b0000000011111111;
  }

BYTE getParallelFlags(void) {
  BYTE n;
  
  n=(PORTB >> 8) & 0b111;
  n ^= 0x100; // BUSY � invertito, dice...
  n |= PORTB & 0b0001000000000000 ? 0b1000 : 0;
  //ev. mappare i bit come su PC vero o boh :)
  n |= PORTC & 0b0100000000000000 ? 0b10000 : 0;
  
  return n;
  }

void resetPrinter(void) {
  
  m_PReset=1;   // NON invertito, dice
  __delay_ms(200);
  m_PReset=0;
  }

uint8_t openPrinter(void) {

  m_PSel=0;
  return 1;
  }

uint8_t closePrinter(void) {

  m_PSel=1;
  return 1;
  }

