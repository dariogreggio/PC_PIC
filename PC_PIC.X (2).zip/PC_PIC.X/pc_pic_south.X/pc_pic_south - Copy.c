/******************************************************************************
 * FileName:        MainDemo.c
 * Dependencies:    see included files below
 * Processor:       PIC24F, dsPIC
 * Compiler:        XC16 
 * Company:         Microchip Technology, Inc.
 * Software License Agreement
 *
 * Copyright (c) 2011 Microchip Technology Inc.  All rights reserved.
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital
 * signal controller, which is integrated into your product or third party
 * product (pursuant to the sublicense terms in the accompanying license
 * agreement).  
 *
 * You should refer to the license agreement accompanying this Software
 * for additional information regarding your rights and obligations.
 *
 *******************************************************************************/

/************************************************************
 * Configuration Bits
 ************************************************************/

#ifdef __PIC24FJ256GB206__
// PIC24FJ256GB206 Configuration Bit Settings
// 'C' source line config statements

// CONFIG4

// CONFIG3
#pragma config WPFP = WPFP255           // Write Protection Flash Page Segment Boundary (Highest Page (same as page 170))
#pragma config SOSCSEL = SOSC           // Secondary Oscillator Power Mode Select (Secondary oscillator is in Default (high drive strength) Oscillator mode)
#pragma config WUTSEL = LEG             // Voltage Regulator Wake-up Time Select (Default regulator start-up time is used)
#pragma config ALTPMP = ALPMPDIS        // Alternate PMP Pin Mapping (EPMP pins are in default location mode)
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable (Segmented code protection is disabled)
#pragma config WPCFG = WPCFGDIS         // Write Protect Configuration Page Select (Last page (at the top of program memory) and Flash Configuration Words are not write-protected)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select (Protected code segment upper boundary is at the last page of program memory; the lower boundary is the code page specified by WPFP)

// CONFIG2
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary oscillator is disabled)
#pragma config IOL1WAY = ON             // IOLOCK One-Way Set Enable (The IOLOCK bit (OSCCON<6>) can be set once, provided the unlock sequence has been completed. Once set, the Peripheral Pin Select registers cannot be written to a second time.)
#pragma config OSCIOFNC = OFF           // OSCO Pin Configuration (OSCO/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Fail-Safe Clock Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = FRCDIV           // Initial Oscillator Select (Fast RC Oscillator with Postscaler (FRCDIV))
#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL is enabled automatically on start-up)
#pragma config PLLDIV = DIV12           // 96 MHz PLL Prescaler Select (Oscillator input is divided by 12 (48 MHz input))
#pragma config IESO = ON                // Internal External Switchover (IESO mode (Two-Speed Start-up) is enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Windowed WDT (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer (Watchdog Timer is enabled)
#pragma config ICS = PGx1               // Emulator Pin Placement Select bits (Emulator functions are shared with PGEC1/PGED1)
#pragma config GWRP = OFF               // General Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON              // JTAG Port Enable (JTAG port is enabled)

/* QUARZO
*/
//_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & ICS_PGx3 & FWDTEN_ON & WINDIS_OFF & FWPSA_PR32 & WDTPS_PS1024)
//_CONFIG2(IESO_OFF & FNOSC_PRIPLL & PLL_96MHZ_ON & OSCIOFNC_OFF & POSCMOD_HS & PLLDIV_DIV2 & FCKSM_CSDCMD & IOL1WAY_ON & DISUVREG_OFF )
//_CONFIG3(WPFP_WPFP0 &  WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM)

//USB Host
//        _CONFIG2(FNOSC_PRIPLL & POSCMOD_HS & PLL_96MHZ_ON & PLLDIV_DIV2 & IESO_OFF) // Primary HS OSC with PLL, USBPLL /2
//       _CONFIG1(JTAGEN_OFF & FWDTEN_OFF & ICS_PGx2)   // JTAG off, watchdog timer off

#elif __PIC24FJ256GB606__
// PIC24FJ256GB606 Configuration Bit Settings
// 'C' source line config statements

// FSEC
#pragma config BWRP = OFF               // Boot Segment Write-Protect bit (Boot Segment may be written)
#pragma config BSS = DISABLED           // Boot Segment Code-Protect Level bits (No Protection (other than BWRP))
#pragma config BSEN = OFF               // Boot Segment Control bit (No Boot Segment)
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GSS = DISABLED           // General Segment Code-Protect Level bits (No Protection (other than GWRP))
#pragma config CWRP = OFF               // Configuration Segment Write-Protect bit (Configuration Segment may be written)
#pragma config CSS = DISABLED           // Configuration Segment Code-Protect Level bits (No Protection (other than CWRP))
#pragma config AIVTDIS = OFF            // Alternate Interrupt Vector Table bit (Disabled AIVT)

// FBSLIM
#pragma config BSLIM = 0x1FFF           // Boot Segment Flash Page Address Limit bits (Enter Hexadecimal value)

// FOSCSEL
#pragma config FNOSC = FRC          // Oscillator Source Selection (Oscillator with Frequency Divider)
#pragma config PLLMODE = PLL4X          // PLL Mode Selection (4x PLL selected)
#pragma config IESO = ON                // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)

// FOSC
#pragma config POSCMD = NONE            // Primary Oscillator Mode Select bits (Primary Oscillator disabled)
#pragma config OSCIOFCN = ON            // OSC2 Pin Function bit (OSC2 is general purpose digital I/O pin)
#pragma config SOSCSEL = OFF            // SOSC Power Selection Configuration bits (Digital (SCLKI) mode)
#pragma config PLLSS = PLL_FRC          // PLL Secondary Selection Configuration bit (PLL is fed by the Primary oscillator)
#pragma config IOL1WAY = ON             // Peripheral pin select configuration bit (Allow only one reconfiguration)
#pragma config FCKSM = CSDCMD           // Clock Switching Mode bits (Both Clock switching and Fail-safe Clock Monitor are disabled)

// FWDT
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler bits (1:32,768)
#pragma config FWPSA = PR128            // Watchdog Timer Prescaler bit (1:128)
#pragma config FWDTEN = ON              // Watchdog Timer Enable bits (WDT Enabled)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config WDTWIN = WIN25           // Watchdog Timer Window Select bits (WDT Window is 25% of WDT period)
#pragma config WDTCMX = WDTCLK          // WDT MUX Source Select bits (WDT clock source is determined by the WDTCLK Configuration bits)
#pragma config WDTCLK = LPRC            // WDT Clock Source Select bits (WDT uses LPRC)

// FPOR
#pragma config BOREN = ON               // Brown Out Enable bit (Brown Out Enable Bit)
#pragma config LPCFG = OFF              // Low power regulator control (No Retention Sleep)
#pragma config DNVPEN = ENABLE          // Downside Voltage Protection Enable bit (Downside protection enabled using ZPBOR when BOR is inactive)

// FICD
#pragma config ICS = PGD2               // ICD Communication Channel Select bits (Communicate on PGEC2 and PGED2)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)
#pragma config BTSWP = OFF              // BOOTSWP Disable (BOOTSWP instruction disabled)

// FDEVOPT1
#pragma config ALTCMPI = DISABLE        // Alternate Comparator Input Enable bit (C1INC, C2INC, and C3INC are on their standard pin locations)
#pragma config TMPRPIN = OFF            // Tamper Pin Enable bit (TMPRN pin function is disabled)
#pragma config SOSCHP = ON              // SOSC High Power Enable bit (valid only when SOSCSEL = 1 (Enable SOSC high power mode (default))
#pragma config ALTVREF = ALTREFEN       // Alternate Voltage Reference Location Enable bit (VREF+ and CVREF+ on RA10, VREF- and CVREF- on RA9)

#endif

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>




/************************************************************
 * Includes
 ************************************************************/
#include <ctype.h>
#include <stdlib.h>
#include "pc_pic_south.h"

#include <pps.h>


#include "usb_config.h"
#include "usb.h"
#include "usb_host_hid_parser.h"
#include "usb_host_hid.h"
#include "usb_host_local.h"
#include "ps2.h"

#define USBInitialize(f) USBHostInit(f)			// RIDEFINITA per poter avere returncode! v. main





#ifdef USA_BOOTLOADER 
//#define BL_ENTRY_BUTTON PORTEbits.RE0 //button 1...

//If defined, the reset vector pointer and boot mode entry delay
// value will be stored in the device's vector space at addresses 0x100 and 0x102
#define USE_VECTOR_SPACE
//****************************************

//Bootloader Vectors *********************
#ifdef USE_VECTOR_SPACE
	/*
		Store delay timeout value & user reset vector at 0x100 
		(can't be used with bootloader's vector protect mode).
		
		Value of userReset should match reset vector as defined in linker script.
		BLreset space must be defined in linker script.
	*/
	unsigned char timeout  __attribute__ ((space(prog),section(".BLreset"))) = 0x0A;
	unsigned int userReset  __attribute__ ((space(prog),section(".BLreset"))) = 0xC00; 
//cambiato ordine o le metteva a cazzo... 
#else
	/*
		Store delay timeout value & user reset vector at start of user space
	
		Value of userReset should be the start of actual program code since 
		these variables will be stored in the same area.
	*/
	unsigned int userReset  __attribute__ ((space(prog),section(".init"))) = 0xC04 ;
	unsigned char timeout  __attribute__ ((space(prog),section(".init"))) = 5 ;
#endif
#endif



static const char _PC_PIC_SOUTHBRIDGE_C[]= {"PIC24FJ256GB206 PC_PIC_SOUTHBRIDGE - 30/10/2021\r\n\r\n"};
#ifdef USA_BOOTLOADER 
	' ','B','L',
#endif
static const char Copyr1[]="(C) Dario's Automation 2021 - G.Dar\xd\xa\x0";
// MORTE AGLI UMANI FOREVER!!!

/************************************************************
 * Defines
 ************************************************************/

/************************************************************
 * Function Prototypes
 ************************************************************/



/************************************************************
 * Variables
 ************************************************************/

//Flags

extern volatile APP_STATE App_State_Keyboard;
extern BOOL DisplayConnectOnce;
extern BOOL DisplayDetachOnce;
extern HID_DATA_DETAILS Appl_ModifierKeysDetails;
extern HID_DATA_DETAILS Appl_NormalKeysDetails;
extern HID_REPORT_BUFFER     Appl_raw_report_buffer;
extern HID_LED_REPORT_BUFFER Appl_led_report_buffer;
extern BYTE ErrorDriver;
extern BYTE ErrorCounter;
extern HID_DATA_DETAILS Appl_LED_Indicator;
extern BOOL ReportBufferUpdated;
extern BYTE NumOfBytesRcvd;
void App_ProcessInputReport(void);
void App_PrepareOutputReport(void);
void App_Detect_Device(void);
void InitializeTimer(void);
#define MAX_ERROR_COUNTER 10

extern BYTE PS2Errors;
extern BYTE SlavePresent;

extern BYTE CAPS_Lock_Pressed;
extern BYTE NUM_Lock_Pressed;

BYTE keyToSend;
BYTE mouseEvent;

BYTE IRQCode;


/************************************************************
 * int main (void)
 ************************************************************/
int main(void) {
	char ByteRec;
	char buffer[64];
	int i;


	ANSB=0x0000;
	ANSC=0x0000;
	ANSD=0x0000;
	ANSF=0x0000;
	ANSG=0x0000;

  
  
	while(1) {	/*LED1_IO ^= 1;*/ ClrWdt(); 		// test clock 606
		LATB ^= 0xffff; }		// 30/10/21: dovrebbe andare a 8MHz (sono 8 cicli v. asm ossia 4 + 4); ok

  CLKDIVbits.PLLEN     = 1; //
  while(OSCCONbits.LOCK != 1);
  
	CLKDIVbits.RCDIV = 0;		// Set 1:1 8MHz FRC postscaler pll


	TRISB = 0b1111011100000000;			// BA; PACK, POUT, PBUSY, PERR; DSR
	TRISC = 0b0100000000000000;			// PSEL
	TRISD = 0b0000101100111010;			// CS; UART; RI,DCD; WR,RD
	TRISE = 0b0000000011111111;			// BD
	TRISF = 0b0000000000111010;			// PS/2
	TRISG = 0b0000001111000000;			// BA

  //https://en.wikipedia.org/wiki/Parallel_port secondo lui alcuni sono sia in che out...
  CNPUBbits.CNPUB8=CNPUBbits.CNPUB9=CNPUBbits.CNPUB10=CNPUCbits.CNPUC14=CNPUBbits.CNPUB12=1;
  //https://tldp.org/HOWTO/Serial-HOWTO-19.html
  CNPUBbits.CNPUB13=1;
  CNPUDbits.CNPUD8=CNPUDbits.CNPUD11=1;


//	LED0_IO = 0;

//	while(1) {	/*LED1_IO ^= 1;*/ ClrWdt(); 		// test clock 210
//		__builtin_btg((unsigned int *)&LATC,13); }		// 15/11/14: dovrebbe andare a 8MHz (sono 8 cicli v. asm ossia 4 + 4); ok



//#ifndef USA_BOOTLOADER mah e invece s� s� s�

// Unlock Registers
	PPSUnLock;
	PPSOutput(PPS_RP11, PPS_U1TX);      // TXD pin 46 RD0
	PPSInput(PPS_U1RX, PPS_RP24);      // RXD pin 49 RD1
  PPSOutput(PPS_RP23,PPS_U1RTS);      // RTS pin 50 RD2
  PPSInput(PPS_U1CTS,PPS_RP22);      // CTS pin 51 RD3

	PPSLock;

  
	InitUART(BAUD_RATE);

  putsUART("Booting...\r\n");

	ClrWdt();



//	LED0_IO ^= 1;

  InitParallel();


	USBInitialize(0);			
  
  InitPS2(0);



  while(1) {
		ClrWdt();


    USBTasks();
    App_Detect_Device();
    switch(App_State_Keyboard) {
	    case DEVICE_NOT_CONNECTED:
        USBTasks();
        if(DisplayDetachOnce == FALSE) {
//					operationalState=WAITING; no!
          #ifdef DEBUG_MODE
          putsUART( "Device Detached \r\n" );
          #endif
          DisplayDetachOnce = TRUE;
      		}
        if(USBHostHID_ApiDeviceDetect()) {		/* True if report descriptor is parsed with no error */
          App_State_Keyboard = DEVICE_CONNECTED;
          DisplayConnectOnce = FALSE;
          }
        break;
      case DEVICE_CONNECTED:
        App_State_Keyboard = READY_TO_TX_RX_REPORT;
        if(DisplayConnectOnce == FALSE) {
// 

          #ifdef DEBUG_MODE
          putsUART( "Explorer16 Board \r\n" );
          putsUART( "USB HIDHost Demo \r\n" );
          #endif
          DisplayConnectOnce = TRUE;
          DisplayDetachOnce = FALSE;
		      }
        InitializeTimer(); // start 10ms timer to schedule input reports
        break;
      case READY_TO_TX_RX_REPORT:
        if(!USBHostHID_ApiDeviceDetect()) {
          App_State_Keyboard = DEVICE_NOT_CONNECTED;
          //                                DisplayOnce = FALSE;
          }
        break;
      case GET_INPUT_REPORT:
        if(USBHostHID_ApiGetReport(Appl_raw_report_buffer.Report_ID,Appl_ModifierKeysDetails.interfaceNum,
          Appl_raw_report_buffer.ReportSize, Appl_raw_report_buffer.ReportData)) {
          // Host may be busy/error -- keep trying 
          }
        else {
          App_State_Keyboard = INPUT_REPORT_PENDING;
      		}
        USBTasks();
        break;
      case INPUT_REPORT_PENDING:
        if(USBHostHID_ApiTransferIsComplete(&ErrorDriver,&NumOfBytesRcvd)) {
          if(ErrorDriver ||(NumOfBytesRcvd != Appl_raw_report_buffer.ReportSize)) {
	          ErrorCounter++ ; 
	          if(MAX_ERROR_COUNTER <= ErrorDriver)
	            App_State_Keyboard = ERROR_REPORTED;
	          else
	            App_State_Keyboard = READY_TO_TX_RX_REPORT;
          	}
          else {
            ErrorCounter = 0; 
            ReportBufferUpdated = TRUE;
            App_State_Keyboard = READY_TO_TX_RX_REPORT;

            if(DisplayConnectOnce == TRUE) {
							int i;
              for(i=0; i<Appl_raw_report_buffer.ReportSize; i++) {
                if(Appl_raw_report_buffer.ReportData[i] != 0) {
                  DisplayConnectOnce = FALSE;
                  }
              	}
          		}

            App_ProcessInputReport();
            App_PrepareOutputReport();
        		}
          }
        break;

      case SEND_OUTPUT_REPORT: // Will be done while implementing Keyboard 
        if(USBHostHID_ApiSendReport(Appl_LED_Indicator.reportID,Appl_LED_Indicator.interfaceNum, Appl_LED_Indicator.reportLength,
          (BYTE*)&Appl_led_report_buffer)) {
          // Host may be busy/error -- keep trying 
          }
        else {
          App_State_Keyboard = OUTPUT_REPORT_PENDING;
	        }
        USBTasks();
        break;

      case OUTPUT_REPORT_PENDING:
        if(USBHostHID_ApiTransferIsComplete(&ErrorDriver,&NumOfBytesRcvd)) {
        	if(ErrorDriver) {
           ErrorCounter++ ; 
           if(MAX_ERROR_COUNTER <= ErrorDriver)
               App_State_Keyboard = ERROR_REPORTED;

           //                                App_State_Keyboard = READY_TO_TX_RX_REPORT;
          	}
          else {
            ErrorCounter = 0; 
            App_State_Keyboard = READY_TO_TX_RX_REPORT;
            }
          }
        break;

      case ERROR_REPORTED:
        break;
      default:
        break;

      }


		if(!m_RXDataBit)	{		//Check for slave request-to-send
      BYTE TEMP0;
//			__builtin_disableinterrupts();					//Request-to-send detected
			TEMP0=PS2_slavein();
			if(!(PS2Errors & 8))
				// o fare RESEND_PS2_slaveout
				slaveKbHandler(TEMP0);
//			goto	Stream5;
//			__builtin_enableinterrupts();
			}

		if(!m_RXDataBit2)	{		//Check for slave request-to-send
      BYTE TEMP0;
//			__builtin_disableinterrupts();					//Request-to-send detected
			TEMP0=PS2_slavein();
			if(!(PS2Errors & 8))
				// o fare RESEND_PS2_slaveout
				slaveKbHandler(TEMP0);
//			goto	Stream5;
//			__builtin_enableinterrupts();
			}
    
    if(keyToSend) {
      notifyToCPU(EVENT_KEYBOARD,&keyToSend,1);
      
      WriteUART(keyToSend);
      
      if(keyToSend == 0x53 /*KEY_NUMLOCK USB */) {
// gi� fatto di l�        NUM_Lock_Pressed ^= 1;        
//        Appl_led_report_buffer.NUM_LOCK=NUM_Lock_Pressed;
//        App_State_Keyboard=SEND_OUTPUT_REPORT;
        ReportBufferUpdated=1;
        App_PrepareOutputReport();
        if(SlavePresent) {
          BYTE TEMP0;
        	i=PS2_slaveout(0xED);
          if(i == 0xff)							// controllo ev. errore (piu' che altro x debug...)
            goto Kb_ED_2;
        	TEMP0=InputSlave();				// aspettare ACK?
          //		call PS2_slavein
        	i=PS2_slaveout(Appl_led_report_buffer.b /*VERIFICARE!!*/);
          if(i == 0xff)							// controllo ev. errore (piu' che altro x debug...)
            goto Kb_ED_2;
        	TEMP0=InputSlave();				// aspettare ACK?
Kb_ED_2: ;
          }
        }
      if(keyToSend == 0x39 /*KEY_CAPSLOCK USB */) {
//        CAPS_Lock_Pressed ^= 1;        
//        Appl_led_report_buffer.CAPS_LOCK=CAPS_Lock_Pressed;
//        App_State_Keyboard=SEND_OUTPUT_REPORT;
        ReportBufferUpdated=1;
        App_PrepareOutputReport();
        }
      
      keyToSend=0;
      }
    
    if(mouseEvent) {
      notifyToCPU(EVENT_KEYBOARD,&mouseEvent,1);
      mouseEvent=0;
      }
    
    if(Buf232Ptr2 != Buf232Ptr) {
      notifyToCPU(EVENT_RS232,&Buf232[Buf232Ptr2],1);
      Buf232Ptr2 = Buf232Ptr;
      }

    
		if(second_10) {

      m_PReset ^= 1;    // test
      
      second_10=0;
				}				// 0.1 sec

		}			//main loop


  return (-1);
	}

void notifyToCPU(BYTE event,BYTE *parm,BYTE size) {
  
  IRQCode=event;  
  
  m_IRQ=0;
  __delay_us(5);
  m_IRQ=1;
  
  }

// -----------------------------------------------------------------------------
void Timer_Init(unsigned int tim) {
  
  T2CONbits.TCS = 0;                  // clock from peripheral clock
  T2CONbits.TCKPS = 0b10;             // 1:64 prescale
  T2CONbits.T32=0;
  PR2=TMR2BASE;                       // 
  T2CONbits.TON = 1;                  // start timer 
  
  IFS0bits.T2IF=0;
  IEC0bits.T2IE=1;
  IPC1bits.T2IP=4;

  
  }


void PMP_Init(void) {

  PMCON1= 0b0000000000000001;     // slave PSP mode; no CS1 & 2 ?????; IRQ sempre
  PMCON2= 0b0000000000000000;     // 
  PMCON3= 0b1100011100000000;     // WR & RD; byte mode; wait state
  PMCS1CF=0b0100000111111111;     // CS1 & 2; 8bit; tutti segnali attivi low BOH COSA FA??
  PMCS1BS=0b0000000000000000;     // base addresses VERIFICARE!
  PMCS1MD=0b0000000011111111;     // chip select modes; delays
  PMCON4 =0b0000000000111111;     // BA0..7
  
#ifdef __PIC24FJ256GB206__
  PADCFG1=0b0000000000000010;     // schmitt-trigger levels MA ANCHE RTCC OUTPUT seconds!
#elif __PIC24FJ256GB606__
#endif
  
  PMCON1bits.PMPEN=1;
  
  IEC2bits.PMPIE=1;
  IPC11bits.PMPIP=3;
	}


// ----------------------------------------------------------------------

