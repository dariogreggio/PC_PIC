#include "sys_common.h"
#include "harmony_app.h"
#include "system_definitions.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************

 
void __ISR(_USB_VECTOR, IPL5SRS) _IntHandler_USB_stub(void) {
  
  DRV_USBHS_Tasks_ISR(sysObj.drvUSBObject);
  }

void __ISR(_USB_DMA_VECTOR, IPL5SRS) _IntHandlerUSBInstance0_USBDMA(void) {
  
  DRV_USBHS_Tasks_ISR_USBDMA(sysObj.drvUSBObject);
  }


