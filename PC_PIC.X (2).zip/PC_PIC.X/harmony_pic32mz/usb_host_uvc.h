/* 
 * File:   usb_host_uvc.h
 * Author: dario
 *
 * Created on 13 luglio 2021, 19.58
 */

#ifndef USB_HOST_UVC_H
#define	USB_HOST_UVC_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "usb_host.h"
#include "usb_host_local.h"
#include "usb_host_client_driver.h"
#include "../pc_pic_cpu.X/pc_pic_cpu.h"

#define USB_AUDIO_CLASS_CODE 0x01
#define USB_UVC_CLASS_CODE 0x0E
#define USB_VENDOR_SPECIFIC_CLASS_CODE 0xFF
    // https://www.usb.org/defined-class-codes
    // https://github.com/iliasam/STM32F4_UVC_Camera/blob/master/iar_uvc_nv12/Libraries/STM32_USB_Device_Library/Class/video/inc/uvc.h
    // https://github.com/groupgets/purethermal1-firmware/blob/master/Middlewares/ST/STM32_USB_Device_Library/Class/video/Inc/uvc.h
    typedef enum {
    USB_UVC_SUBCLASS_UNDEFINED  = 0x00,
    USB_UVC_SUBCLASS_VIDEOCONTROL = 0x01,
    USB_UVC_SUBCLASS_VIDEOSTREAMING = 0x02,
    USB_UVC_SUBCLASS_INTERFACE_COLLECTION = 0x03,
            
    USB_AUDIO_SUBCLASS_AUDIOCONTROL      = 0x01,
//    USB_AUDIO_AUDIOSTREAMING        = 0x02,
//    USB_AUDIO_MIDISTREAMING         = 0x03
    } USB_UVC_SUBCLASS_CODE; 
typedef enum {
    USB_UVC_PR_PROTOCOL_UNDEFINED    = 0x0
    } USB_UVC_PROTOCOL_CODE;

typedef uintptr_t USB_HOST_UVC_OBJ;
typedef uintptr_t USB_HOST_UVC_STREAMING_INTERFACE_OBJ;
typedef uintptr_t USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ;
typedef uintptr_t USB_HOST_UVC_REQUEST_HANDLE;
#define USB_HOST_UVC_REQUEST_HANDLE_INVALID ((USB_HOST_UVC_REQUEST_HANDLE)(-1))
typedef uintptr_t USB_HOST_UVC_STREAM_TRANSFER_HANDLE;
#define USB_HOST_UVC_STREAM_TRANSFER_HANDLE_INVALID ((USB_HOST_UVC_STREAM_TRANSFER_HANDLE)(-1))
typedef uintptr_t USB_HOST_UVC_STREAM_HANDLE;
#define USB_HOST_UVC_STREAM_HANDLE_INVALID ((USB_HOST_UVC_STREAM_HANDLE)(-1))
typedef uintptr_t USB_HOST_UVC_STREAM_OBJ;
typedef enum {
    USB_HOST_UVC_EVENT_ATTACH, 
    USB_HOST_UVC_EVENT_DETACH,
  } USB_HOST_UVC_EVENT;

typedef enum {
    USB_UVC_CS_REQUEST_CODE_UNDEFINED = 0x00,
    USB_UVC_CS_SET_CUR   = 0x01,
    USB_UVC_CS_GET_CUR   = 0x81,
    USB_UVC_CS_SET_MIN   = 0x02,
    USB_UVC_CS_GET_MIN   = 0x82,
    USB_UVC_CS_SET_MAX   = 0x03,
    USB_UVC_CS_GET_MAX   = 0x83,
    USB_UVC_CS_SET_RES   = 0x04,
    USB_UVC_CS_GET_RES   = 0x84,
    USB_UVC_CS_SET_MEM   = 0x05,
    USB_UVC_CS_GET_MEM   = 0x85,
    USB_UVC_CS_GET_INFO  = 0x86,
    USB_UVC_CS_GET_DEF   = 0x87,
    USB_UVC_CS_GET_STAT  = 0xFF
    } USB_UVC_CS_REQUEST_CODE;

typedef enum {
    USB_UVC_EP_CONTROL_UNDEFINED  = 0x00,
    USB_UVC_SAMPLING_FREQ_CONTROL = 0x01,
    USB_UVC_PITCH_CONTROL         = 0x02
} USB_UVC_ENDPOINT_CONTROL_SELECTORS;

typedef enum {
    USB_UVC_FU_CONTROL_UNDEFINED        = 0x00,
    USB_UVC_MUTE_CONTROL                = 0x01,
    USB_UVC_VOLUME_CONTROL              = 0x02,
    USB_UVC_BASS_CONTROL                = 0x03,
    USB_UVC_MID_CONTROL                 = 0x04,
    USB_UVC_TREBLE_CONTROL              = 0x05,
    USB_UVC_GRAPHIC_EQUALIZER_CONTROL   = 0x06,
    USB_UVC_AUTOMATIC_GAIN_CONTROL      = 0x07,
    USB_UVC_DELAY_CONTROL               = 0x08,
    USB_UVC_BASS_BOOST_CONTROL          = 0x09,
    USB_UVC_LOUDNESS_CONTROL            = 0x0A,
            
    USB_UVC_PROBE_CONTROL=1,
    USB_UVC_COMMIT_CONTROL=2,

} USB_UVC_FEATURE_UNIT_CONTROL_SELECTORS;    

/*DOM-IGNORE-BEGIN*/
#define USB_HOST_UVC_RESULT_MIN -100

typedef enum {
    /* An unknown failure has occurred */
    USB_HOST_UVC_RESULT_FAILURE /*DOM-IGNORE-BEGIN*/ = USB_HOST_UVC_RESULT_MIN /*DOM-IGNORE-END*/,

    /* The transfer or request could not be scheduled because internal queues
       are full. The request or transfer should be retried */
    USB_HOST_UVC_RESULT_BUSY,

    /* The request was stalled */
    USB_HOST_UVC_RESULT_REQUEST_STALLED,

    /* A required parameter was invalid */
    USB_HOST_UVC_RESULT_INVALID_PARAMETER,

    /* The associated device does not exist in the system. */
    USB_HOST_UVC_RESULT_DEVICE_UNKNOWN,

    /* The specified handle is not valid */
    USB_HOST_UVC_RESULT_HANDLE_INVALID,

    /* The transfer or requested was aborted */
    USB_HOST_UVC_RESULT_TRANSFER_ABORTED,

    /* The specified Audio v1.0 object is invalid */ 
    USB_HOST_UVC_RESULT_OBJ_INVALID,

    /* No more audio control entity */ 
    USB_HOST_UVC_RESULT_END_OF_CONTROL_ENTITY, 
    
    /* No more streaming interface settings present in the audio device */ 
    USB_HOST_UVC_RESULT_END_OF_STREAMING_INTERFACE, 

    /* No more interface alternate settings are present in the audio streaming 
       interface */
    USB_HOST_UVC_RESULT_END_OF_INTERFACE_SETTINGS,

    /* Indicates that the operation succeeded or the request was accepted and
       will be processed. */ 
    USB_HOST_UVC_RESULT_SUCCESS
    
    /*DOM-IGNORE-BEGIN*/ = 1 /*DOM-IGNORE-END*/,
  } USB_HOST_UVC_RESULT;
  
typedef enum {
	
	/* The transfer or request could not be scheduled because internal
     * queues are full. The request or transfer should be retried */
    USB_HOST_UVC_0_RESULT_BUSY  = /*  DOM-IGNORE-BEGIN */ USB_HOST_RESULT_REQUEST_BUSY, /* DOM-IGNORE-END*/

	/* The transfer or requested was aborted */
    USB_HOST_UVC_0_RESULT_TRANSFER_ABORTED,
    
	/* The request was stalled */    
    USB_HOST_UVC_0_RESULT_REQUEST_STALLED,

	/* The specified Audio v1.0 Object is Invalid */ 
    USB_HOST_UVC_0_RESULT_OBJ_INVALID,

    /* No more audio stream present in the Device */       
    USB_HOST_UVC_0_RESULT_END_OF_STREAM_LIST,
    
	/* DOM-IGNORE-BEGIN */
    USB_HOST_UVC_0_RESULT_ERROR_INTERFACE_UNKNOWN, 
    /* DOM-IGNORE-END*/
	
	/* A required parameter was invalid */
    USB_HOST_UVC_0_RESULT_PARAMETER_INVALID, 
    
	/* DOM-IGNORE-BEGIN */
    USB_HOST_UVC_0_RESULT_CONFIGURATION_UNKNOWN, 

    USB_HOST_UVC_0_RESULT_BUS_NOT_ENABLED,

    USB_HOST_UVC_0_RESULT_BUS_UNKNOWN,
	/* DOM-IGNORE-END*/
	
    /* The specified device does not exist in the system */
    USB_HOST_UVC_0_RESULT_DEVICE_UNKNOWN,

    /* An unknown failure has occurred */
    USB_HOST_UVC_0_RESULT_FAILURE,

    // Indicates a false condition
    USB_HOST_UVC_0_RESULT_FALSE = 0,

    // Indicate a true condition
    USB_HOST_UVC_0_RESULT_TRUE = 1,

    /* Indicates that the operation succeeded or the request was accepted and
       will be processed. */
    USB_HOST_UVC_0_RESULT_SUCCESS = USB_HOST_RESULT_TRUE
} USB_HOST_UVC_0_RESULT;
  
typedef enum {
    /* The transfer or request could not be scheduled because internal
     * queues are full. The request or transfer should be retried */
    USB_HOST_UVC_STREAM_RESULT_REQUEST_BUSY =  USB_HOST_RESULT_REQUEST_BUSY,
            
    /* Request was aborted */
    USB_HOST_UVC_STREAM_RESULT_TRANSFER_ABORTED,
            
    /* Request was stalled */
    USB_HOST_UVC_STREAM_RESULT_REQUEST_STALLED,

    /* The specified Stream Handle is not valid */
    USB_HOST_UVC_STREAM_RESULT_HANDLE_INVALID,
 
    /* The end of the device list was reached.*/
    USB_HOST_UVC_STREAM_RESULT_END_OF_DEVICE_LIST,
    
    /* The specified interface is not available */
    USB_HOST_UVC_STREAM_RESULT_INTERFACE_UNKNOWN,
   
    /* A NULL parameter was passed to the function */
    USB_HOST_UVC_STREAM_RESULT_PARAMETER_INVALID,

    /* The specified configuration does not exist on this device.*/
    USB_HOST_UVC_STREAM_RESULT_CONFIGURATION_UNKNOWN, 

    /* A bus operation was requested but the bus was not operated */
    USB_HOST_UVC_STREAM_RESULT_BUS_NOT_ENABLED,

    /* The specified bus does not exist in the system */
    USB_HOST_UVC_STREAM_RESULT_BUS_UNKNOWN,
 
    // The specified audio stream does not exist in the system
    USB_HOST_UVC_STREAM_RESULT_UNKNOWN,

    // An unknown failure has occurred
    USB_HOST_UVC_STREAM_RESULT_FAILURE,

    // Indicates a false condition
    USB_HOST_UVC_STREAM_RESULT_FALSE = 0,

    // Indicate a true condition
    USB_HOST_UVC_STREAM_RESULT_TRUE = 1,

    /* Indicates that the operation succeeded or the request was accepted and
       will be processed. */
    USB_HOST_UVC_STREAM_SUCCESS = USB_HOST_RESULT_TRUE
    
} USB_HOST_UVC_STREAM_RESULT;

typedef enum {
    USB_HOST_UVC_STREAM_EVENT_READ_COMPLETE,
    USB_HOST_UVC_STREAM_EVENT_WRITE_COMPLETE,
    USB_HOST_UVC_STREAM_EVENT_INTERFACE_SET_COMPLETE, 
//    USB_HOST_UVC_STREAM_EVENT_SAMPLING_FREQUENCY_SET_COMPLETE,  
//    USB_HOST_UVC_STREAM_EVENT_SAMPLING_FREQUENCY_GET_COMPLETE,
    USB_HOST_UVC_0_STREAM_EVENT_ENABLE_COMPLETE, 
    USB_HOST_UVC_0_STREAM_EVENT_DISABLE_COMPLETE,
    USB_HOST_UVC_STREAM_EVENT_DETACH
} USB_HOST_UVC_STREAM_EVENT;

/*typedef enum {
    USB_HOST_UVC_0_STREAM_EVENT_READ_COMPLETE,
    USB_HOST_UVC_0_STREAM_EVENT_WRITE_COMPLETE,
    USB_HOST_UVC_0_STREAM_EVENT_ENABLE_COMPLETE, 
    USB_HOST_UVC_0_STREAM_EVENT_DISABLE_COMPLETE,
    USB_HOST_UVC_0_STREAM_EVENT_SAMPLING_RATE_SET_COMPLETE,       
} USB_HOST_UVC_0_STREAM_EVENT;*/

typedef struct {
    // Transfer handle of this transfer
    USB_HOST_UVC_STREAM_TRANSFER_HANDLE transferHandle;

    // Amount of data transferred
    size_t length;
    
    // Transfer termination status
    USB_HOST_UVC_RESULT result;

    } USB_HOST_UVC_STREAM_EVENT_READ_COMPLETE_DATA,
    USB_HOST_UVC_STREAM_EVENT_WRITE_COMPLETE_DATA;

typedef struct {
    uint32_t event;
    
    USB_HOST_DEVICE_INTERFACE_EVENT_SET_INTERFACE_COMPLETE_DATA eventData; 

    uintptr_t context;
} USB_HOST_UVC_STREAM_STATE_DATA; 

typedef struct {
    /* Transfer handle of this transfer */
    USB_HOST_UVC_REQUEST_HANDLE  requestHandle; 

    /* Transfer termination status */
    USB_HOST_UVC_RESULT requestStatus;

} USB_HOST_UVC_STREAM_EVENT_INTERFACE_SET_COMPLETE_DATA,
USB_HOST_UVC_STREAM_EVENT_SAMPLING_RATE_SET_COMPLETE_DATA,
USB_HOST_UVC_STREAM_EVENT_SAMPLING_RATE_GET_COMPLETE_DATA;

typedef enum {
    /* Error state */
    USB_HOST_UVC_STREAM_STATE_ERROR = -1,

    /* The instance is not ready */
    USB_HOST_UVC_STREAM_STATE_NOT_READY = 0,

    /* The instance should set the configuration */
    USB_HOST_UVC_STREAM_STATE_SET_CONFIGURATION,

    /* Wait for configuration set */
    USB_HOST_UVC_STREAM_STATE_WAIT_FOR_CONFIGURATION_SET,

    /* Wait for interfaces to get ready */
    USB_HOST_UVC_STREAM_STATE_WAIT_FOR_INTERFACES,

    /* The instance is ready */
    USB_HOST_UVC_STREAM_STATE_READY,
            
    /* Pipe Open or Close is pending on this the stream */ 
    USB_HOST_UVC_STREAM_STATE_PIPE_ACTION_PENDING, 
    
    /* Pipe is opened on the stream. Data can be transferred on this stream now */ 
    USB_HOST_UVC_STREAM_STATE_PIPE_OPEN_SUCCESS, 
            
    // Pipe Open failed
    USB_HOST_UVC_STREAM_PIPE_OPEN_FAILED,         
            
    /*  Pipe is closed on the stream */        
    USB_HOST_UVC_STREAM_STATE_PIPE_CLOSE_SUCCESS,         
    
    /* Pipe Close failed */         
    USB_HOST_UVC_STREAM_PIPE_CLOSE_FAILED     
            
} USB_HOST_UVC_STREAM_STATE;

typedef enum {
    USB_HOST_UVC_DIRECTION_OUT  /*DOM-IGNORE-BEGIN*/= 0 /*DOM-IGNORE-END*/,
    USB_HOST_UVC_DIRECTION_IN  /*DOM-IGNORE-BEGIN*/= 1 /*DOM-IGNORE-END*/,
} USB_HOST_UVC_STREAM_DIRECTION;

typedef enum {
    USB_HOST_UVC_STREAM_EVENT_RESPONSE_NONE /*DOM-IGNORE-BEGIN*/= 0 /*DOM-IGNORE-END*/
    } USB_HOST_UVC_STREAM_EVENT_RESPONSE;
    
typedef USB_HOST_UVC_STREAM_EVENT_RESPONSE (* USB_HOST_UVC_STREAM_EVENT_HANDLER) (  
    USB_HOST_UVC_STREAM_HANDLE handle,
    USB_HOST_UVC_STREAM_EVENT event,
    void * eventData, uintptr_t context);

typedef void (* USB_HOST_UVC_ENTITY_REQUEST_CALLBACK) (USB_HOST_UVC_OBJ videoObj, 
    USB_HOST_UVC_REQUEST_HANDLE requestHandle,
    USB_HOST_UVC_RESULT result,
    size_t size, uintptr_t context); 

typedef void (* USB_HOST_UVC_CONTROL_CALLBACK) (USB_HOST_UVC_OBJ videoObj, 
    USB_HOST_UVC_REQUEST_HANDLE requestHandle,
    USB_HOST_UVC_RESULT result,
    size_t size, uintptr_t context); 

typedef enum {
    USB_HOST_UVC_API_VERSION_FLAG_STREAM_INTERFACE_SET = 0, 
    USB_HOST_UVC_API_VERSION_FLAG_STREAM_DISABLE = 1, 
    USB_HOST_UVC_API_VERSION_FLAG_STREAM_ENABLE = 2,
    USB_HOST_UVC_API_VERSION_FLAG_V1 = 3, 
    USB_HOST_UVC_API_VERSION_FLAG_V1_DEPRECIATED = 4
} USB_HOST_UVC_API_VERSION_FLAGS; 

typedef struct {
    // True if this object is allocated
    bool inUse;
    
    // Transfer context
    uintptr_t context;

    // Type of control request
    USB_HOST_CONTROL_REQUEST_TYPE requestType;

    // Callback to invoke when control transfer is complete
    USB_HOST_UVC_ENTITY_REQUEST_CALLBACK callback;

} USB_HOST_UVC_CONTROL_TRANSFER_OBJ;

typedef union  __attribute__((packed)) {
    /* Value */
	uint16_t value; 
	
	struct {
		unsigned leftFront:1; 
		unsigned rightFront:1; 
		unsigned centerFront:1; 	
		unsigned LFE:1; 
		unsigned leftSurround:1; 
		unsigned rightSurround:1; 
		unsigned leftOfCenter:1; 
		unsigned rightOfCenter:1; 
		unsigned surround:1; 
		unsigned sideLeft:1; 
		unsigned sideRight:1; 
		unsigned top:1; 
		unsigned :4; 
	};

} USB_VIDEO_CHANNEL_CONFIG; 



typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VC_HEADER descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint16_t bcdUVC;

    uint16_t wTotalLength;
    
    uint32_t dwClockFrequency;
    
    uint8_t bInCollection;

    uint8_t baInterfaceNr1;
    
    uint8_t baInterfaceNrN[];

} USB_UVC_VC_INTERFACE_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Type of this descriptor
    uint8_t bDescriptorType;

    // Subtype of this descriptor
    uint8_t bDescriptorSubtype; 
    
    // Entity ID
    uint8_t entityID; 

} USB_HOST_UVC_CONTROL_ENTITY_DESCRIPTOR_HEADER;

typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Type of this descriptor
    uint8_t bDescriptorType;

    // Subtype of this descriptor
    uint8_t bDescriptorSubtype; 
    
    // Unique ID of the Terminal
    uint8_t bTerminalID; 
    
    // Characterizes the type of Terminal. See USB Audio Terminal Types.
    uint8_t wTerminalType; 
    
    // Identifies the Terminal to which this Terminal is associated.
    uint8_t bAssocTerminal; 
} USB_HOST_UVC_TERMINAL_HEADER_DESCRIPTOR;      // boh non � chiaro a cosa serva, � incluso in INPUT e OUTPUT TERMINAL

typedef struct __attribute__((packed)) {
    // Request type SET or GET
    uint8_t bmRequestType;
    
    // Identifies the attribute to be accessed
    uint8_t bRequest;

    union {
        struct {        // v. usb_protocol.h https://github.com/arduino/ArduinoCore-samd/blob/master/bootloaders/mzero/Bootloader_D21/src/ASF/common/services/usb/usb_protocol.h
            // Identifies the channel number
            uint8_t channelNumber;
            // Identifies the control selector
            uint8_t controlSelector;
        };
        uint16_t wValue;
    };
    union {
        struct {
            // Identifies the interface number
            uint8_t interfaceNumber;
            // Identifies the feature unit ID
            uint8_t featureUnitId;
        };
        uint16_t wIndex;
    };
    

    // Length of the parameter block
    uint16_t wLength;

} USB_UVC_FEATURE_UNIT_CONTROL_REQUEST;

typedef struct __attribute__((packed)) {
    // Request type SET or GET
    uint8_t bmRequestType;

    // Identifies the attribute to be accessed
    uint8_t bRequest;

    // This field is always Zero
    unsigned :8;

    // Identifies the control selector
    uint8_t controlSelector;

    // Identifies the Endpoint number
    uint8_t endpointNumber;
    
    // This field is always Zer0
    unsigned :8;

    // Length of the parameter block
    uint16_t wLength;

} USB_UVC_ENDPOINT_CONTROL_REQUEST;

typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Interface descriptor type
    uint8_t bDescriptorType;

    // Interface Descriptor Subtype
    uint8_t bDescriptorSubtype;

    // 
    uint8_t bNumFormats;

    uint16_t wTotalLength;

    uint8_t bEndpointAddress;
    
    uint8_t bmInfo;
    
    // 
    uint8_t bTerminalLink;
    
    uint8_t bStillCaptureMethod;
    
    uint8_t bTriggerSupport;
    
    uint8_t bTriggerUsage;
    
    uint8_t bControlSize;
    
    // 
    uint8_t bmaControls1[2 /* N */];

    // 
    uint8_t bmaControlsP[2 /* N */];

    } USB_UVC_VS_INPUT_HEADER_DESCRIPTOR;

#define USB_HOST_UVC_CONTROL_TRANSFER_OBJ USB_HOST_UVC_CONTROL_TRANSFER_OBJ
typedef struct {         
    // Streaming Interface Number
    uint8_t vsInterfaceId; 

    // Interface Alternate Setting Number
    uint8_t interfaceAlternateSetting;

    // Number of Endpoints
    uint8_t nEndpoints;

    uint8_t bTerminalLink;

     // The number of bytes occupied by one video subframe.
    uint32_t bSubframeSize[USB_HOST_UVC_VIDEO_FORMAT_NUMBER];
    
    SIZE wSize[USB_HOST_UVC_VIDEO_FORMAT_NUMBER];
    uint8_t bBitsPerPixel[USB_HOST_UVC_VIDEO_FORMAT_NUMBER];
    uint8_t /*USB_UVC_FORMAT_TAG*/ format;
     
    // Flag indicates if Feedback supported
    bool isFeebackSupported;
    
    // Stream Direction
    USB_HOST_UVC_STREAM_DIRECTION direction;
   
    USB_INTERFACE_DESCRIPTOR descVSInterface; 
    
    USB_UVC_VS_INPUT_HEADER_DESCRIPTOR descVSClassSpecific;
    
    USB_ENDPOINT_DESCRIPTOR isoDataEndpointDesc; 
    
    USB_ENDPOINT_DESCRIPTOR isoFeedbackaEndpointDesc;
    
    USB_HOST_UVC_STREAM_EVENT_HANDLER streamEventHandler; 
    
    // Application defined context
    uintptr_t context;
    
} USB_HOST_UVC_STREAM_SETTING;

typedef struct {
    
    // Stream state
    USB_HOST_UVC_STREAM_STATE state; 
    
    USB_HOST_UVC_STREAM_STATE_DATA stateData; 
    
    // Audio Streaming Interface Handle
    USB_HOST_DEVICE_INTERFACE_HANDLE vsInterfaceHandle;

    // Interface Type
    USB_UVC_SUBCLASS_CODE infType;
    
    // Interface number
    uint8_t interfaceId;

    // Number of Interface Alternate Settings
    uint8_t nInterfaceSetting; 

    // Interface alternate setting that is active currently
    uint8_t activeInterfaceSetting;

    // Temporary storage of requested Interface Alternate Setting
    uint8_t requestedInterfaceSetting;
    
    // Video Stream Info
    USB_HOST_UVC_STREAM_SETTING videoStreamSetting[USB_HOST_UVC_STREAMING_INTERFACE_ALTERNATE_SETTINGS_NUMBER]; 
    
    // Pipe status
    bool isIsoDataPipeSet;
    
    // Pipe status
    bool isIsoFeedbackPipeSet;

    // Pipe Handle for Isochronous Data Endpoint
    USB_HOST_PIPE_HANDLE isoDataPipeHandle;

    // Pipe Handle for Isochronous Feedback Endpoint
    USB_HOST_PIPE_HANDLE isochronousFeedbackPipeHandle;
    
    USB_SETUP_PACKET setupPacket; 
    
    USB_HOST_UVC_CONTROL_TRANSFER_OBJ videoControlObj;
    
    USB_HOST_UVC_STREAM_EVENT_HANDLER streamEventHandler; 
    
    // Application defined context
    uintptr_t context;

} USB_HOST_UVC_STREAMING_INTERFACE;
    
typedef struct {

    // Indicates if the instance is in use or not
    bool assigned;
    
    // Index of this Video/UVC Client driver instance
    uint8_t index; 
    
    // Device Object Handle
    USB_HOST_DEVICE_OBJ_HANDLE deviceObjHandle;

    // Video Control Interface Handle
    USB_HOST_DEVICE_INTERFACE_HANDLE acInterfaceHandle;
    
    // Video Control Descriptor pointer
    uint8_t *pVideoControlDescriptor; 

    // Total number of Video Streaming ecc Interfaces
    uint8_t nVSInterfaces;
    
    /* This is Video Streaming interface counter. This is incremented whenever 
       a new interface is assigned by Host Layer */
    uint8_t countVSInterfaces;
    
    // Pipe for Video Control Endpoint
    USB_HOST_PIPE_HANDLE controlPipeHandle;

    // A collection Video Streaming interfaces
    USB_HOST_UVC_STREAMING_INTERFACE streamInf[USB_HOST_UVC_STREAMING_INTERFACES_NUMBER];
    
    USB_SETUP_PACKET setupPacket; 
    
    USB_HOST_UVC_CONTROL_TRANSFER_OBJ videoControlObj; 
       
} USB_HOST_UVC_INSTANCE;

typedef void (* USB_HOST_UVC_ATTACH_EVENT_HANDLER) (
                 USB_HOST_UVC_OBJ videoObj, 
                 USB_HOST_UVC_EVENT event, uintptr_t context
              );

// USB Host Video Common object
typedef struct {    
    USB_HOST_UVC_ATTACH_EVENT_HANDLER attachEventHandler; 
    USB_HOST_UVC_INSTANCE *prevVideoInstance; 
    uintptr_t context; 
    }  USB_HOST_UVC_COMMON_OBJ;
    
    
        
    
typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Interface descriptor type
    uint8_t bDescriptorType;

    // Interface Descriptor Subtype
    uint8_t bDescriptorSubtype;

    // Unique Terminal Identifier Constant
    uint8_t bTerminalID;

    // Terminal Type
    uint16_t wTerminalType;     // 0x0201 ITT_CAMERA; 0x0401 COMPOSITE_CONNECTOR

    // ID of the associated Output Terminal
    uint8_t bAssocTerminal;

    // Input Terminal String Descriptor Index
    uint8_t iTerminal;

    // (opzionali)
    uint16_t wObjectiveFocalLengthMin;
    uint16_t wObjectiveFocalLengthMax;
    
    //
    uint16_t wOcularFocalLength;
    
    //
    uint8_t bControSize;

    uint8_t bmControls[];

    } USB_UVC_INPUT_TERMINAL_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Interface descriptor type
    uint8_t bDescriptorType;

    // Interface Descriptor Subtype
    uint8_t bDescriptorSubtype;

    // Unique Terminal Identifier Constant
    uint8_t bTerminalID;

    // Terminal Type
    uint16_t wTerminalType;     // 0x0101 TT_STREAMING

    // ID of the associated Input Terminal
    uint8_t bAssocTerminal;

    // Source Unit or Terminal ID
    uint8_t bSourceID;

    // Output Terminal String Descriptor Index
    uint8_t iTerminal;

    } USB_UVC_OUTPUT_TERMINAL_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Interface descriptor type
    uint8_t bDescriptorType;

    // Interface Descriptor Subtype
    uint8_t bDescriptorSubtype;

    // Unique Terminal Identifier Constant
    uint8_t bUnitID;

    // Source Unit or Terminal ID
    uint8_t bSourceID;
    
    // 
    uint16_t wMaxMultiplier;

    // 
    uint8_t bmControls[2 /* N */];

    // Processing Unit String Descriptor Index
    uint8_t iProcessing;

// 1.1    uint8_t bmVideoStandards;
    
    } USB_UVC_PROCESSING_UNIT_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Interface descriptor type
    uint8_t bDescriptorType;

    // Interface Descriptor Subtype
    uint8_t bDescriptorSubtype;

    // Unique Terminal Identifier Constant
    uint8_t bUnitID;

    uint8_t guidExtensionCode[16];

    uint8_t bNumControls;
    
    uint8_t bNrInPins;
    
    // Source Unit or Terminal ID
    uint8_t baSourceID1[0];
    
//    uint8_t baSourceIDP;
    
    uint8_t bControlSize;
    
    // 
    uint8_t bmControls[0 /* N */];

    // Extension Unit String Descriptor Index
    uint8_t iExtension;

    } USB_UVC_EXTENSION_UNIT_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VS_FORMAT_UNCOMPRESSED descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint8_t bFormatIndex;

    uint8_t bNumFrameDescriptors;
    
    uint8_t guidFormat[16];
    
    uint8_t bBitsPerPixel;

    uint8_t bDefaultFrameIndex;
    
    uint8_t bAspectRatioX;
    uint8_t bAspectRatioY;

    uint8_t bmInterlaceFlags;
    
    uint8_t bCopyProtect;
    
} USB_UVC_VS_FORMAT_UNCOMPRESSED_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VS_FRAME_UNCOMPRESSED descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint8_t bFrameIndex;

    uint8_t bmCapabilities;
    
    SIZE wSize;
    
    uint32_t dwMinBitRate;
    uint32_t dwMaxBitRate;
    
    uint32_t dwMaxVideoFrameBufferSize;
    
    uint32_t dwDefaultFrameInterval;
    
    uint8_t bFrameIntervalType;

    uint32_t dwFrameInterval[];
    
} USB_UVC_VS_FRAME_UNCOMPRESSED_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VS_FORMAT_MJPEG descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint8_t bFormatIndex;

    uint8_t bNumFrameDescriptors;
    
    uint8_t bmFlags;

    uint8_t bDefaultFrameIndex;
    
    uint8_t bAspectRatioX;
    uint8_t bAspectRatioY;

    uint8_t bmInterlaceFlags;
    
    uint8_t bCopyProtect;
    
} USB_UVC_VS_FORMAT_MJPEG_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VS_FRAME_MJPEG descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint8_t bFrameIndex;

    uint8_t bmCapabilities;
    
    SIZE wSize;
    
    uint32_t dwMinBitRate;
    uint32_t dwMaxBitRate;
    
    uint32_t dwMaxVideoFrameBufferSize;
    
    uint32_t dwDefaultFrameInterval;
    
    uint8_t bFrameIntervalType;

    uint32_t dwFrameInterval[];
    
} USB_UVC_VS_FRAME_MJPEG_DESCRIPTOR;

typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VS_FRAME_UNCOMPRESSED descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint8_t bEndpointAddress;

    uint8_t bNumImageSizePatterns;
    
//SIZE
    uint16_t wWidth1;
    uint16_t wHeight1;
    
    uint16_t wWidthN;
    uint16_t wHeightN;
    
    uint8_t bNumCompressionPattern;
    
    uint8_t bCompression1;
    
    uint8_t bCompressionN;
    
} USB_UVC_VS_STILL_IMAGE_FRAME_DESCRIPTOR;
    
typedef struct __attribute__((packed)) {
    // Size of the descriptor in bytes
    uint8_t bLength;

    // CS_INTERFACE descriptor type
    uint8_t bDescriptorType;

    // VS_FRAME_UNCOMPRESSED descriptor subtype
    uint8_t bDescriptorSubtype;
    
    uint8_t bColorPrimaries;

    uint8_t bTransferCharacteristics;
    
    uint8_t bMatrixCoefficients;
    
} USB_UVC_VS_COLOR_FORMAT_DESCRIPTOR;
    
    

typedef uintptr_t USB_HOST_UVC_CONTROL_ENTITY_OBJ; 

typedef enum {
    /* USB Terminal Types */ 
    USB_UVC_TERMINAL_TYPE_USB_UNDEFINED = 0x0100,
    USB_UVC_TERMINAL_TYPE_USB_STREAMING = 0x0101,
    USB_UVC_TERMINAL_TYPE_USB_VENDOR_SPECIFIC = 0x01FF,
         
    /* Input Terminal types */ 
    USB_UVC_TERMINAL_TYPE_INPUT_UNDEFINED = 0x0200, 
    USB_UVC_TERMINAL_TYPE_INPUT_MICROPHONE = 0x0201,
    USB_UVC_TERMINAL_TYPE_INPUT_MICROPHONE_DESKTOP = 0x0202,
    USB_UVC_TERMINAL_TYPE_INPUT_MICROPHONE_PERSONAL = 0x0203,
    USB_UVC_TERMINAL_TYPE_INPUT_MICROPHONE_OMNI = 0x0204,
    USB_UVC_TERMINAL_TYPE_INPUT_MICROPHONE_ARRAY = 0x0205,
    USB_UVC_TERMINAL_TYPE_INPUT_MICROPHONE_ARRAY_PROCESSING = 0x0206,
       
    /* Output Terminal types */         
    USB_UVC_TERMINAL_TYPE_OUTPUT_UNDEFINED = 0x0300,
    USB_UVC_TERMINAL_TYPE_OUTPUT_SPEAKER = 0x0301,
    USB_UVC_TERMINAL_TYPE_OUTPUT_HEADPHONES = 0x0302,
    USB_UVC_TERMINAL_TYPE_OUTPUT_HMD = 0x0303,
    USB_UVC_TERMINAL_TYPE_OUTPUT_SPEAKER_DESKTOP = 0x0304,
    USB_UVC_TERMINAL_TYPE_OUTPUT_SPEAKER_ROOM = 0x0305,
    USB_UVC_TERMINAL_TYPE_OUTPUT_SPEAKER_COMM = 0x0306,
    USB_UVC_TERMINAL_TYPE_OUTPUT_SPEAKER_LFE = 0x0307
            
  } USB_UVC_TERMINAL_TYPE; 
  
typedef enum {
  USB_UVC_FORMAT_TYPE_UNDEFINED = 0,
  USB_UVC_FORMAT_RGB,
  USB_UVC_FORMAT_YUV,
  USB_UVC_FORMAT_MJPG
  } USB_UVC_FORMAT_CODE, USB_UVC_FORMAT_TAG;

  
typedef struct {
    /* Video Stream Object. Clients need to pass this object when opening this 
       video stream using USB_HOST_UVC_StreamOpen function. */ 
    USB_HOST_UVC_STREAM_OBJ streamObj;

    // Video Format code for this Stream
    USB_UVC_FORMAT_CODE format;

    // Stream direction
    USB_HOST_UVC_STREAM_DIRECTION streamDirection;

    // Number of bytes occupied by one video sub-frame
    uint32_t subFrameSize[USB_HOST_UVC_VIDEO_FORMAT_NUMBER];
    SIZE videoSize[USB_HOST_UVC_VIDEO_FORMAT_NUMBER];
    
    uint8_t bpp[USB_HOST_UVC_VIDEO_FORMAT_NUMBER];

} USB_HOST_UVC_STREAM_INFO;


#define USB_HOST_UVC_STREAM_TRANSFER_HANDLE_INVALID ((USB_HOST_UVC_STREAM_TRANSFER_HANDLE)(-1))

typedef enum {
    USB_UVC_DESCRIPTOR_UNDEFINED    = 0x00,
    USB_UVC_HEADER                     = 0x01,
    USB_UVC_INPUT_TERMINAL             = 0x02,
    USB_UVC_OUTPUT_TERMINAL            = 0x03,
    USB_UVC_MIXER_UNIT                 = 0x04,
    USB_UVC_SELECTOR_UNIT              = 0x05,
    USB_UVC_FEATURE_UNIT               = 0x06,
    USB_UVC_PROCESSING_UNIT            = 0x05 /*0x07*/,
    USB_UVC_EXTENSION_UNIT             = 0x06 /*0x08*/,

    USB_UVC_VS_STILL_IMAGE_FRAME=0x03,
    USB_UVC_VS_FORMAT_UNCOMPRESSED=0x04,
    USB_UVC_VS_FRAME_UNCOMPRESSED=0x05,
    USB_UVC_VS_FORMAT_MJPEG=0x06,
    USB_UVC_VS_FRAME_MJPEG=0x07,
    USB_UVC_VS_FORMAT_MPEG2TS = 0x0a, 
    USB_UVC_VS_FORMAT_DV = 0x0c, 
    USB_UVC_VS_COLORFORMAT = 0x0d, 
    USB_UVC_VS_FORMAT_FRAME_BASED = 0x10,
    USB_UVC_VS_FRAME_FRAME_BASED = 0x11, 
    USB_UVC_VS_FORMAT_STREAM_BASED = 0x12,
    USB_UVC_VS_COLOR_MATCHING=  0x0D,

    USB_UVC_CS_ENDPOINT=0x25,
    USB_UVC_CS_INTERFACE=0x24,
           
  } USB_UVC_INTERFACE_DESCRIPTOR_SUBTYPE, USB_UVC_ENTITY_TYPE; 
  
#define USB_VIDEO_CLASS_SPECIFIC_DESCRIPTOR 0x24
#define USB_VIDEO_CLASS_SPECIFIC_INTERRUPT_ENDPOINT 0x25

  
typedef struct __attribute__((packed)) {
    // Size of this descriptor
    uint8_t bLength;

    // Interface descriptor type
    uint8_t bDescriptorType;

    // Interface Descriptor Subtype
    uint8_t bDescriptorSubtype;

    // Constant uniquely identifying the Unit within the video function.
    uint8_t bUnitID;

    // Source Unit or Terminal ID
    uint8_t bSourceID;

    // Size in Bytes of an element in the Control array
    uint8_t bControlSize;

} USB_UVC_FEATURE_UNIT_DESCRIPTOR_HEADER;


typedef struct __attribute__((packed)) {
    uint16_t bmHint;
    uint8_t bFormatIndex;
    uint8_t bFrameIndex;
    uint32_t dwFrameInterval;
    uint16_t wKeyFrameRate;
    uint16_t wPFrameRate;
    uint16_t wCompQuality;
    uint16_t wCompQualitySize;
    uint16_t wDelay;
//    uint16_t Padding;
    uint32_t dwMaxVideoFrameSize;
    uint32_t dwMaxPayloadTransferSize;
    //uint32_t dwClockFrequency;        // da v1.1 in poi...
    //uint8_t bmFramingInfo;
    //uint8_t bPreferedVersion;
    //uint8_t bMinVersion;
    //uint8_t bMaxVersion;
    } USB_UVC_VIDEO_PROBE_AND_COMMIT_CONTROLS;
  
/*DOM-IGNORE-BEGIN*/extern const USB_HOST_CLIENT_DRIVER gUSBHostUVCDriver; /*DOM-IGNORE-END*/
#define USB_HOST_UVC_INTERFACE  /*DOM-IGNORE-BEGIN*/&gUSBHostUVCDriver /*DOM-IGNORE-END*/

                    

    
void App_USBHostUVCAttachHandler(USB_HOST_UVC_OBJ, USB_HOST_UVC_EVENT, uintptr_t);
void App_USBVideoControlRequestCallback(USB_HOST_UVC_OBJ, USB_HOST_UVC_REQUEST_HANDLE,
  USB_HOST_UVC_RESULT, size_t, uintptr_t);
USB_HOST_UVC_STREAM_EVENT_RESPONSE APP_USBHostUVCStreamEventHandler(
    USB_HOST_UVC_STREAM_HANDLE, USB_HOST_UVC_STREAM_EVENT,
    void *, uintptr_t);
void APP_VideoDataSetDefault(void);


USB_HOST_UVC_STREAM_RESULT USB_HOST_UVC_SetVideoProbeControl(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_CONTROL_ENTITY_OBJ, USB_HOST_UVC_REQUEST_HANDLE *, uint8_t,
  uint32_t,uint32_t,uint32_t);
USB_HOST_UVC_STREAM_RESULT USB_HOST_UVC_GetVideoControl(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_CONTROL_ENTITY_OBJ, USB_HOST_UVC_REQUEST_HANDLE *, uint8_t);
USB_HOST_UVC_STREAM_RESULT USB_HOST_UVC_SetVideoCommitControl(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_CONTROL_ENTITY_OBJ, USB_HOST_UVC_REQUEST_HANDLE *, uint8_t);
USB_HOST_UVC_STREAM_HANDLE USB_HOST_UVC_StreamOpen(USB_HOST_UVC_STREAM_OBJ);
uint8_t USB_HOST_UVC_StreamingInterfaceTerminalLinkGet(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ, USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ);
USB_HOST_UVC_RESULT USB_HOST_UVC_StreamEventHandlerSet(USB_HOST_UVC_STREAM_HANDLE,
  USB_HOST_UVC_STREAM_EVENT_HANDLER, uintptr_t);
USB_HOST_UVC_RESULT _USB_HOST_UVC_StreamWrite(USB_HOST_UVC_STREAM_HANDLE,
  USB_HOST_UVC_STREAM_TRANSFER_HANDLE *, void *, size_t , uint8_t);
USB_HOST_UVC_RESULT _USB_HOST_UVC_StreamRead(USB_HOST_UVC_STREAM_HANDLE,
  USB_HOST_UVC_STREAM_TRANSFER_HANDLE *, void *, size_t , uint8_t);
USB_HOST_UVC_RESULT USB_HOST_UVC_EntityRequestCallbackSet(USB_HOST_UVC_OBJ, 
  USB_HOST_UVC_ENTITY_REQUEST_CALLBACK, uintptr_t);
USB_HOST_UVC_RESULT USB_HOST_UVC_StreamingInterfaceSet(USB_HOST_UVC_STREAM_HANDLE,
  USB_HOST_UVC_REQUEST_HANDLE *, USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ);
USB_HOST_UVC_RESULT USB_HOST_UVC_StreamingInterfaceGetFirst(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ *);
USB_HOST_UVC_RESULT USB_HOST_UVC_StreamingInterfaceSettingGetFirst(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ *);
USB_HOST_UVC_RESULT USB_HOST_UVC_StreamingInterfaceSettingGetNext(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ *);
USB_UVC_FORMAT_TAG USB_HOST_UVC_StreamingInterfaceFormatTagGet(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ);
USB_HOST_UVC_STREAM_DIRECTION USB_HOST_UVC_StreamingInterfaceDirectionGet(
  USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ);
uint32_t USB_HOST_UVC_StreamingInterfaceSubFrameSizeGet(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ, unsigned char);
uint16_t USB_HOST_UVC_StreamingInterfaceWidthGet(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ, unsigned char);
uint16_t USB_HOST_UVC_StreamingInterfaceHeightGet(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ, unsigned char);
uint8_t USB_HOST_UVC_StreamingInterfaceBitsPerPixelGet(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_OBJ,
  USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ, unsigned char);
USB_HOST_UVC_RESULT USB_HOST_UVC_EntityObjectGet(USB_HOST_UVC_OBJ,
  uint8_t, USB_HOST_UVC_CONTROL_ENTITY_OBJ *);
USB_HOST_UVC_RESULT USB_HOST_UVC_ControlEntityGetNext(USB_HOST_UVC_OBJ,
  USB_HOST_UVC_CONTROL_ENTITY_OBJ, USB_HOST_UVC_CONTROL_ENTITY_OBJ *);      
USB_UVC_ENTITY_TYPE USB_HOST_UVC_EntityTypeGet(USB_HOST_UVC_OBJ, 
  USB_HOST_UVC_CONTROL_ENTITY_OBJ); 


extern USB_HOST_UVC_COMMON_OBJ gUSBHostUVCCommonObj;


#ifdef	__cplusplus
}
#endif

#endif	/* USB_HOST_UVC_H */

