/*******************************************************************************
  USB Host Hub Driver interface names mapping

  Company:
    Microchip Technology Inc.

  File Name:
    usb_hub_mapping.h

  Summary:
    USB Device Layer Interface names mapping

  Description:
    This file contain mapppings required for the hub driver.
*******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2012 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

*******************************************************************************/
//DOM-IGNORE-END

#ifndef _USB_HOST_HUB_MAPPING_H
#define _USB_HOST_HUB_MAPPING_H

#include "system_config.h"

#if (USB_HOST_HUB_SUPPORT == true)
    #include "usb/usb_host_hub_interface.h"
    extern USB_HUB_INTERFACE externalHubInterface;
    #define USB_HOST_HUB_INTERFACE &externalHubInterface;
#else
    #define USB_HOST_HUB_INTERFACE (NULL)
#endif


#endif
