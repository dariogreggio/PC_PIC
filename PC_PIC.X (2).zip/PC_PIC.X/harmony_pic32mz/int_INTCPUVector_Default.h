/*******************************************************************************
  INT Peripheral Library Template Implementation

  File Name:
    int_INTCPUVector_Default.h

  Summary:
    INT PLIB Template Implementation

  Description:
    This header file contains template implementations
    For Feature : INTCPUVector
    and its Variant : Default
    For following APIs :
        PLIB_INT_ExistsINTCPUVector
        PLIB_INT_VectorGet

*******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2012 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

*******************************************************************************/

//DOM-IGNORE-END

#ifndef _INT_INTCPUVECTOR_DEFAULT_H
#define _INT_INTCPUVECTOR_DEFAULT_H

//******************************************************************************
/* Function :  INT_ExistsINTCPUVector_Default

  Summary:
    Implements Default variant of PLIB_INT_ExistsINTCPUVector

  Description:
    This template implements the Default variant of the PLIB_INT_ExistsINTCPUVector function.
*/
#define PLIB_INT_ExistsINTCPUVector PLIB_INT_ExistsINTCPUVector
PLIB_TEMPLATE bool INT_ExistsINTCPUVector_Default(INT_MODULE_ID index) {
    return true;
}

//******************************************************************************
/* Function :  INT_VectorGet_Default

  Summary:
    Implements Default variant of PLIB_INT_VectorGet 

  Description:
    This template implements the Default variant of the PLIB_INT_VectorGet function.
*/
PLIB_TEMPLATE INT_VECTOR INT_VectorGet_Default(INT_MODULE_ID index)
{
    return (INT_VECTOR) INTSTATbits.SIRQ;
}

#endif /*_INT_INTCPUVECTOR_DEFAULT_H*/

/******************************************************************************
 End of File
*/

