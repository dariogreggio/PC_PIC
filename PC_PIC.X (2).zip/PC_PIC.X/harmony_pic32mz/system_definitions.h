/*******************************************************************************
  System Definitions

  File Name:
    system_definitions.h

  Summary:
    MPLAB Harmony project system definitions.

  Description:
    This file contains the system-wide prototypes and definitions for an MPLAB
    Harmony project.
 *******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

 orcufaus
 *******************************************************************************/
//DOM-IGNORE-END
#ifndef _SYS_DEFINITIONS_H
#define _SYS_DEFINITIONS_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "sys_common.h"
#include "sys_module.h"
#include "sys_devcon.h"
//#include "system/clk/sys_clk.h"
//#include "system/int/sys_int.h"
#include "sys_tmr.h"
#include "drv_tmr.h"
//#include "system/ports/sys_ports.h"

#ifdef USA_USB_HOST
#include "drv_usbhs.h"
//#include "drv_usbfs.h"
#include "usb_host.h"
#include "usb_host_hub.h"
#include "usb_host_hub_interface.h"

#if defined(USA_USB_HOST_MSD)
#include "sys_fs.h"
#include "sys_fs_media_manager.h"
#include "fatfs_ff.h"
#include "fatfs_ffconf.h"
#include "fatfs_diskio.h"
#endif

//#include "usb_host_audio_v1_0.h"
#if defined(USA_USB_HOST_UVC)
#include "usb_host_uvc.h"
#endif
#endif

#ifdef USA_USB_SLAVE_CDC
#include "drv_usbhs.h"
#include "usb_device.h"
#include "usb_cdc.h"
#include "usb_device_cdc.h"
#endif

//#include "app.h"


// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* System Objects

  Summary:
    Structure holding the system's object handles

  Description:
    This structure contains the object handles for all objects in the
    MPLAB Harmony project's system configuration.

  Remarks:
    These handles are returned from the "Initialize" functions for each module
    and must be passed into the "Tasks" function for each module.
*/

typedef struct {
    SYS_MODULE_OBJ  sysTmr;
    SYS_MODULE_OBJ  drvTmr0;
    SYS_MODULE_OBJ  drvUSBObject;
    
#if defined(USA_USB_HOST)
    SYS_MODULE_OBJ  usbHostObject0;
#endif
#if defined(USA_USB_SLAVE_CDC)
    SYS_MODULE_OBJ  usbDevObject0;
#endif

} SYSTEM_OBJECTS;


// *****************************************************************************
// *****************************************************************************
// Section: extern declarations
// *****************************************************************************
// *****************************************************************************

extern SYSTEM_OBJECTS sysObj;



//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* _SYS_DEFINITIONS_H */
/*******************************************************************************
 End of File
*/

