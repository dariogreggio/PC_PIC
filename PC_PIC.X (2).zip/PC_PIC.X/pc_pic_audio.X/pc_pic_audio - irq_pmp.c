/********************************************************************
 FileName:     main.c
 Dependencies: See INCLUDES section
 Processor:		PIC32MZ
 Hardware:		The code is natively intended to be used on the following
              hardware platforms: PC_PIC_MOTHERBOARD
 Compiler:  	Microchip XC32
 Company:		Microchip Technology, Inc.

 Software License Agreement:
 * ma fatevi le seghe umani demmerda!!!
 * 
********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  1.0   11/19/2004   Initial release
  2.1   02/26/2007   Updated for simplicity and to use common
                     coding style
  2021  pc_pic_audio
********************************************************************/


// PIC32MZ1024EFE064 Configuration Bit Settings

// 'C' source line config statements
#pragma config USERID =     0x4B47

// DEVCFG3
#pragma config FMIIEN = OFF             // Ethernet RMII/MII Enable (RMII Enabled)
#pragma config FETHIO = OFF             // Ethernet I/O Pin Select (Alternate Ethernet I/O)
#pragma config PGL1WAY = ON             // Permission Group Lock One Way Configuration (Allow only one reconfiguration)
#pragma config PMDL1WAY = ON            // Peripheral Module Disable Configuration (Allow only one reconfiguration)
#pragma config IOL1WAY = ON             // Peripheral Pin Select Configuration (Allow only one reconfiguration)
#pragma config FUSBIDIO = OFF            // USB USBID Selection 

// DEVCFG2
/* Default SYSCLK = 200 MHz (8MHz FRC / FPLLIDIV * FPLLMUL / FPLLODIV) */
//#pragma config FPLLIDIV = DIV_1, FPLLMULT = MUL_50, FPLLODIV = DIV_2
#pragma config FPLLIDIV = DIV_1         // System PLL Input Divider (1x Divider)
#pragma config FPLLRNG = RANGE_5_10_MHZ// System PLL Input Range (5-10 MHz Input)
#pragma config FPLLICLK = PLL_FRC       // System PLL Input Clock Selection (FRC is input to the System PLL)
#pragma config FPLLMULT = MUL_52       // System PLL Multiplier (PLL Multiply by 54)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (2x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)

// DEVCFG1
#pragma config FNOSC = FRCDIV           // Oscillator Selection Bits (Fast RC Osc w/Div-by-N (FRCDIV))
#pragma config DMTINTV = WIN_127_128    // DMT Count Window Interval (Window/Interval value is 127/128 counter value)
#pragma config FSOSCEN = ON             // Secondary Oscillator Enable (Enable SOSC)
#pragma config IESO = ON                // Internal/External Switch Over (Enabled)
#pragma config POSCMOD = OFF            // Primary Oscillator Configuration (Primary osc disabled)
#pragma config OSCIOFNC = OFF           // CLKO Output Signal Active on the OSCO Pin (Disabled)
#pragma config FCKSM = CSECME           // Clock Switching and Monitor Selection (Clock Switch Enabled, FSCM Enabled)
#pragma config WDTPS = PS16384          // Watchdog Timer Postscaler (1:16384)
  // circa 6-7 secondi, 24.7.19
#pragma config WDTSPGM = STOP           // Watchdog Timer Stop During Flash Programming (WDT stops during Flash programming)
#pragma config WINDIS = NORMAL          // Watchdog Timer Window Mode (Watchdog Timer is in non-Window mode)
#pragma config FWDTEN = ON             // Watchdog Timer Enable (WDT Enabled)
#pragma config FWDTWINSZ = WINSZ_25     // Watchdog Timer Window Size (Window size is 25%)
#pragma config DMTCNT = DMT31           // Deadman Timer Count Selection (2^31 (2147483648))
#pragma config FDMTEN = OFF             // Deadman Timer Enable (Deadman Timer is disabled)

// DEVCFG0
#pragma config DEBUG = OFF              // Background Debugger Enable (Debugger is disabled)
#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
#pragma config ICESEL = ICS_PGx1        // ICE/ICD Comm Channel Select (Communicate on PGEC1/PGED1)
#pragma config TRCEN = OFF              // Trace Enable (Trace features in the CPU are disabled)
#pragma config BOOTISA = MIPS32         // Boot ISA Selection (Boot code and Exception code is MIPS32)
#pragma config FECCCON = OFF_UNLOCKED   // Dynamic Flash ECC Configuration (ECC and Dynamic ECC are disabled (ECCCON bits are writable))
#pragma config FSLEEP = OFF             // Flash Sleep Mode (Flash is powered down when the device is in Sleep mode)
#pragma config DBGPER = PG_ALL          // Debug Mode CPU Access Permission (Allow CPU access to all permission regions)
#pragma config SMCLR = MCLR_NORM        // Soft Master Clear Enable bit (MCLR pin generates a normal system Reset)
#pragma config SOSCGAIN = GAIN_2X       // Secondary Oscillator Gain Control bits (2x gain setting)
#pragma config SOSCBOOST = ON           // Secondary Oscillator Boost Kick Start Enable bit (Boost the kick start of the oscillator)
#pragma config POSCGAIN = GAIN_2X       // Primary Oscillator Gain Control bits (2x gain setting)
#pragma config POSCBOOST = ON           // Primary Oscillator Boost Kick Start Enable bit (Boost the kick start of the oscillator)
#pragma config EJTAGBEN = NORMAL        // EJTAG Boot (Normal EJTAG functionality)

// DEVCP0
#pragma config CP = OFF                 // Code Protect (Protection Disabled)

// SEQ3

// DEVADC0

// DEVADC1

// DEVADC2

// DEVADC3

// DEVADC4

// DEVADC7

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include <xc.h>  
                

/** I N C L U D E S **********************************************************/

#include "../Compiler.h"
#include "../GenericTypeDefs.h"

#include "pc_pic_audio.h"
#include "pc_pic_audio_bios.h"
#include "io_cfg.h"
#include <sys/attribs.h>
#include <sys/kmem.h>


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


/** V A R I A B L E S ********************************************************/


extern volatile BYTE Sec10_1,ADCdone;
WORD Seconds;
BYTE Sec10;
extern volatile BYTE commandParms[128],commandReceived,commandParmCnt,commandOldReg;


WORD DMA_READY samplesOut[22050],samplesIn[22050];
// https://daycounter.com/Calculators/Sine-Generator-Calculator.phtml
const int16_t SQUARE_WAVE_TABLE[NUM_SAMPLES]=  { 0x07ff,0x07ff,0x07ff,0x07ff, 0x07ff,0x07ff,0x07ff,0x07ff,
	0xf800,0xf800,0xf800,0xf800, 0xf800,0xf800,0xf800,0xf800 };
const int16_t TRIANGLE_WAVE_TABLE[NUM_SAMPLES]={ 0xf800,0xfa00,0xfc00,0xfe00, 0x0000,0x0200,0x0400,0x0600,
	0x07ff,0x0600,0x0400,0x0200, 0x0000,0xfe00,0xfc00,0xfa00 };
const int16_t SINE_WAVE_TABLE[NUM_SAMPLES]=    { 0x0000,0x030f,0x05a7,0x0763, 0x07ff,0x0763,0x05a7,0x030f,
	0x0000,0xfcf0,0xfa58,0xf89c, 0xf800,0xf89c,0xfa58,0xfcf0 };
const int16_t SAWTOOTH_WAVE_TABLE[NUM_SAMPLES]={ 0xf900,0xfa00,0xfb00,0xfc00, 0xfd00,0xfe00,0xff00,0x0000,
	0x00ff,0x01ff,0x02ff,0x03ff, 0x04ff,0x05ff,0x06ff,0x07ff };

BYTE IRQCode;

/** P R I V A T E  P R O T O T Y P E S ***************************************/
static void InitializeSystem(void);
void UserInit(void);


/** DECLARATIONS ***************************************************/

static const char _PC_PIC_AUDIO_C[]= {"PIC32MZ2048EFG100 PC_PIC_AUDIO - 8/12/2021\r\n\r\n"};
static const char Copyr1[]="(C) Dario's Automation 2021 - G.Dar\xd\xa\x0";
// MORTE... AGLI... UMANI... 30/8/21.


volatile struct AUDIO_WAVE canaliAudio[3];
enum TIPO_OUTPUT outputMode;		// 0=analog, 1=SPDIF
enum TIPO_WAVE waveMode=NONE;			// 1=synth, 2=samples


/********************************************************************
 * Function:        static void InitializeSystem(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        InitializeSystem is a centralized initialization routine. 
 *
 *                  User application initialization routine should also be called from here.                  
 *
 * Note:            None
 *******************************************************************/
static void InitializeSystem(void) {

  ClrWdt();
  
  // disable JTAG port
//  DDPCONbits.JTAGEN = 0;

   // Disable all Interrupts
  __builtin_disable_interrupts();
  
//  SPLLCONbits.PLLMULT=10;
  
  OSCTUN=0;
  OSCCONbits.FRCDIV=0;
  
  // Switch to FRCDIV, SYSCLK=8MHz
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  OSCCONbits.NOSC=0x00; // FRC
  OSCCONbits.OSWEN=1;
  SYSKEY=0x33333333;
  while(OSCCONbits.OSWEN) {
    Nop();
    }
    // At this point, SYSCLK is ~8MHz derived directly from FRC
 //http://www.microchip.com/forums/m840347.aspx
  // Switch back to FRCPLL, SYSCLK=200MHz
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  OSCCONbits.NOSC=0x01; // SPLL
  OSCCONbits.OSWEN=1;
  SYSKEY=0x33333333;
  while(OSCCONbits.OSWEN) {
    Nop();
    }
  // At this point, SYSCLK is ~200MHz derived from FRC+PLL
  
//***
  mySYSTEMConfigPerformance();

  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  CFGCONbits.IOLOCK = 0;      // PPS Unlock
  SYSKEY=0x33333333;

/*
  RPB8Rbits.RPB8R = 15;        // Assign RPB8 as REFO3, pin 21
	REFO3CONbits.RSLP=1;
	REFO3CONbits.OE =1;
	REFO3CONbits.RODIV=1;
	REFO3CONbits.ON=1;
	TRISBbits.TRISB8=1;
*/
/*  RPD5Rbits.RPD5R = 12;        // Assign RPD5 as OC1, pin 53
 */
  RPD3Rbits.RPD3R = 5;        // Assign RPD3 as SDO1, pin 51
  SDI1Rbits.SDI1R = 0;        // Assign RPD2 as SDI1, pin 50
  RPF5Rbits.RPF5R = 1;        // Assign RPF5 as U1TX
  U1RXRbits.U1RXR = 2;        // Assign RPF4 as U1RX

  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  CFGCONbits.IOLOCK = 1;      // PPS Lock
  SYSKEY=0x33333333;

  ANSELB=0b0000000000000000;      // 
  ANSELE=0b0000000000000000;
  ANSELG=0b0000000000000000;
//  ODCDbits.ODCD9=ODCDbits.ODCD10=ODCFbits.ODCF4=ODCFbits.ODCF5=1;  // i led che vanno a 5V e i possibili I2C :)



    /*
    while(1) {
  TRISB=0;
    LATB^=0xffff;
    __delay_us(100);    //100uS test timing 23/6/2020
    ClrWdt();
    }*/
    
    UserInit();
    
    
	}	//end InitializeSystem



/******************************************************************************
 * Function:        void UserInit(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This routine should take care of all of the demo code
 *                  initialization that is required.
 *
 * Note:            
 *
 *****************************************************************************/
void UserInit(void) {
	unsigned char i;

  ClrWdt();

  TRISB=0b1111111111000000;   // BA; joy+joy ana + micin
  TRISC=0b0001000000000000;		// CLKIn
  TRISD=0b0000100000110000;   // CS; WR,RD
  TRISE=0b0000000011111111;		// BD
  TRISF=0b0000000000001000;   // joy
  TRISG=0b0000001111000000;   // joy; BA

  LATB=0b0000000000100000;    // IRQ
  LATC=0b1000000000000000;    // TCS
  LATD=0b0000000000000000;      // 
  LATE=0b0000000000000000;
  LATF=0b0000000000000010;    // ASCS, LDAC
  LATG=0b0000000000000000;
  

  CNPUDbits.CNPUD4=CNPUDbits.CNPUD5=CNPUDbits.CNPUD11=1;

  myINTEnableSystemMultiVectoredInt();

  Timer_Init(TMR1BASE);
  PWM_Init();
  ADC_Init();
  SPI_Init(0);
//  DMA_Init();
  PMP_Init();
  
  OpenUART(9600);    // Midi...


  

   #define DEFAULT_YEARS               0x0021
   #define DEFAULT_MONTH_DAY           0x0830
   #define DEFAULT_WEEKDAY_HOURS       0x0121
   #define DEFAULT_MINUTES_SECONDS     0x3900


#ifndef USA_SW_RTC
	RTCC_Init();
  
	PIC32RTCCSetDate( DEFAULT_YEARS, DEFAULT_MONTH_DAY );
	PIC32RTCCSetTime( DEFAULT_WEEKDAY_HOURS, DEFAULT_MINUTES_SECONDS );

#else
	currentDate.mday=1;
	currentDate.mon=1;
	currentDate.year=11;
#endif


  }	//end UserInit




/******************************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *****************************************************************************/
int main(void) {
  int i;
  static WORD divider;
  DWORD n;


  
  InitializeSystem();
  

//  mLED_1=1;

        
        
#ifndef USING_SIMULATOR
  __delay_ms(250);
#endif
//  mLED_2=1;
  
  ClrWdt();




//  IEC0bits.AD1IE = 1;

	SetOutput(ANALOGIC);
  SetMode(SYNTH);
//  SetWave(0,/*TRIANGOLARE*/ SINUSOIDALE,1000,1,8,60,1,0);
//  SetWave(1,QUADRA,100,1,8,30,0,0);
  SetWave(0,TRIANGOLARE,2000,2,8,80,1,0);

  
//  mLED_1=0;


  while(1) {

  	ClrWdt();



//		mLED_1 ^= 1;		// CHECK Timing!		~4uS 24/7/21
    
    
    
  	if(ADCdone) {
//		mLED_4 ^= 1;		// CHECK Timing!		6400uSec (25 * 256), @140MHz, 27/7/21

      divider++;


      ADCdone=0;
      }
//		m_Led1Bit ^= 1;		// CHECK Timing!		ca.  ??mSec, @200MHz, ??/?/21
    
    
    switch(commandReceived) {
      case BIOS_AUDIO_SETMODE:
        SetMode(commandParms[0]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_SETWAVE:
//        SetMode(SYNTH);
        SetWave(commandParms[0],commandParms[1],MAKEWORD(commandParms[2],commandParms[3]),commandParms[4],commandParms[5],commandParms[6],commandParms[7],commandParms[8]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_SETFREQUENCY:
        SetFrequency(commandParms[0],MAKEWORD(commandParms[1],commandParms[2]));
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_SETOUTPUT:
        SetOutput(commandParms[0]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_SETRECORD:
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_PUTSAMPLES:
        SetMode(SAMPLES);
        samplesOut[0];
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_WRITEMIDI:
        while(BusyUART())
          ClrWdt();
        WriteUART(commandParms[0]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_AUDIO_SETCLOCK:
        SetClock(commandParms[0],commandParms[1],commandParms[2],commandParms[3],commandParms[4],commandParms[5]);
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      case BIOS_INVALID:
// no!      default:
        commandReceived=commandParmCnt=commandOldReg=0;
        m_IRQ=1;
        break;
      }
    

    if(Sec10_1) {
      Sec10++;
      
#ifndef USA_SW_RTC
      currentTime.l=PIC32RTCCGetTime();   // BCD ma ok qua!
#endif      
      n=currentTime.sec % 10;
//      SetFrequency(0,950+10*(n));
      
      
      Sec10_1=0;
      }
    
#ifndef USING_SIMULATOR
//    __delay_ms(1);
#endif

    }	//end while
	}	//end main


void SetWave(BYTE channel,enum TIPO_ONDA type,WORD freq,BYTE chan,BYTE bits,BYTE volume,BYTE mode,BYTE effect) {
  
  if(channel<3) {
    IEC0bits.T2IE=0;
    canaliAudio[channel].tipo=type;
    canaliAudio[channel].freq=freq;
    canaliAudio[channel].channels=chan;
    canaliAudio[channel].bits=bits;
    canaliAudio[channel].volume=volume;
    canaliAudio[channel].mode=mode;
    canaliAudio[channel].effects=effect;
    canaliAudio[channel].counter=0;
    IEC0bits.T2IE=1;
    }
  }

void SetMode(enum TIPO_WAVE mode) {
  
  IEC0bits.T2IE=0;
  
  m_SPIASCSBit=0;
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = 0b0011100000000000;     // channel A, unbuffered, gain=1, no shutdown; PRESET 1/2 Vcc
  while(SPI1STATbits.SPIBUSY)
    ClrWdt();
  SPI1BUF;
  m_SPIASCSBit=1;
  Nop(); Nop(); Nop();
  m_SPIASCSBit=0;
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = 0b1011100000000000;     // channel B, unbuffered, gain=1, no shutdown; PRESET 1/2 Vcc
  while(SPI1STATbits.SPIBUSY)
    ClrWdt();
  SPI1BUF;
  m_SPIASCSBit=1;
  
  waveMode=mode;
  switch(mode) {
    case SYNTH:
      canaliAudio[0].tipo=canaliAudio[1].tipo=canaliAudio[2].tipo=NESSUNA;
      canaliAudio[0].counter=canaliAudio[1].counter=canaliAudio[2].counter=0;
      PR2=(GetPeripheralClock()/(Fsynth*NUM_SAMPLES)) /*-1*/;    // freq-synth-sample time;  312.5uS = 320KHz
      IEC0bits.T2IE=1;
      break;
    case SAMPLES:
      canaliAudio[0].tipo=canaliAudio[1].tipo=canaliAudio[2].tipo=NESSUNA;
      canaliAudio[0].counter=canaliAudio[1].counter=canaliAudio[2].counter=0;
      PR2=(GetPeripheralClock()/Fs) /*-1*/;    // freq-sample time;  22050
      IEC0bits.T2IE=1;
      break;
    case NONE:
      canaliAudio[0].tipo=canaliAudio[1].tipo=canaliAudio[2].tipo=NESSUNA;
      canaliAudio[0].counter=canaliAudio[1].counter=canaliAudio[2].counter=0;
      PR2=32768;    // tanto per :)
      IEC0bits.T2IE=0;
      break;
    }
  }

void SetFrequency(BYTE channel,WORD freq) {
  
//  IEC0bits.T2IE=0; direi no qua...
  if(channel<3) {
    canaliAudio[channel].freq=freq;
    canaliAudio[channel].counter=0;   // ma occhio ai glitch cmq..
    }
  }

void SetOutput(enum TIPO_OUTPUT m) {
  
  IEC0bits.T2IE=0;
  switch(m) {
    case ANALOGIC:
      outputMode=ANALOGIC;
      m_LDACBit=0;
      canaliAudio[0].counter=canaliAudio[1].counter=canaliAudio[2].counter=0;
  
      m_SPIASCSBit=0;
      SPI1STATbits.SPIROV = 0;  // Reset overflow bit
      SPI1BUF = 0b0011100000000000;     // channel A, unbuffered, gain=1, no shutdown; PRESET 1/2 Vcc
      while(SPI1STATbits.SPIBUSY)
        ClrWdt();
      SPI1BUF;
      m_SPIASCSBit=1;
      Nop(); Nop(); Nop();
      m_SPIASCSBit=0;
      SPI1STATbits.SPIROV = 0;  // Reset overflow bit
      SPI1BUF = 0b1011100000000000;     // channel B, unbuffered, gain=1, no shutdown; PRESET 1/2 Vcc
      while(SPI1STATbits.SPIBUSY)
        ClrWdt();
      SPI1BUF;
      m_SPIASCSBit=1;
  
      T2CONbits.TON = 1;                  // start timer 
      IEC0bits.T2IE=1;
      break;
    case SPDIF:
      outputMode=SPDIF;
      m_LDACBit=1;
      canaliAudio[0].counter=canaliAudio[1].counter=canaliAudio[2].counter=0;
      T2CONbits.TON = 1;                  // start timer 
      IEC0bits.T2IE=1;
      //preparare SPI1 o qual �, a 32bit
      break;
    }
  }

void SetClock(BYTE d,BYTE m,WORD y,BYTE H,BYTE M,BYTE S) {
  
#ifndef USA_SW_RTC 
  PIC32RTCCSetDate(MAKEWORD(to_bcd(y % 100),0), MAKEWORD(to_bcd(d),to_bcd(m)));
  PIC32RTCCSetTime(MAKEWORD(to_bcd(H),0 /*weekday*/), MAKEWORD(to_bcd(S),to_bcd(M)));
#else
  currentTime.sec=S;
  currentTime.min=M;
  currentTime.hour=H;
  currentDate.mday=d;
  currentDate.mon=m;
  currentDate.year=y;
#endif

  }



// --------------------------------------------------------------------------
// Joystick
signed char InitJoystick(void) {
  
  TRISB |= 0b0001111111000000;   // joy+joy ana 
  TRISF |= 0b0000000000001000;   // joy
  // le ANSEL le lascio in ConvertADC, in caso li si volesse usare come digitali!
  
  CNPUFbits.CNPUF3=1;
  CNPUBbits.CNPUB6=1;
  CNPUBbits.CNPUB9=1;
  CNPUBbits.CNPUB12=1;
  
  return 1;
  }

signed char InitMIDI(void) {
  
  TRISFbits.TRISF4=1;
  TRISFbits.TRISF5=0;
  
  return 1;
  }

WORD ReadJoystick(BYTE c) {
  
  switch(c) {
    case 0:
      return ConvertADC(47);
      break;
    case 1:
      return ConvertADC(48);
      break;
    case 2:
      return ConvertADC(5);
      break;
    case 3:
      return ConvertADC(6);
      break;
    default:
      return -1;
      break;
    }
  }

WORD ReadPulsanti(BYTE c) {
  
  switch(c) {
    case 0:
      return PORTBbits.RB6;
      break;
    case 1:
      return PORTBbits.RB9;
      break;
    case 2:
      return PORTBbits.RB12;
      break;
    case 3:
      return PORTFbits.RF3;
      break;
    default:
      return -1;
      break;
    }
  }

// --------------------------------------------------------------------------
void mySYSTEMConfigPerformance(void) {
  unsigned int PLLIDIV;
  unsigned int PLLMUL;
  unsigned int PLLODIV;
  double CLK2USEC;
  unsigned int SYSCLK;
  unsigned char PLLODIVVAL[]={
    2,2,4,8,16,32,32,32
    };
	unsigned int cp0;

  PLLIDIV=SPLLCONbits.PLLIDIV+1;
  PLLMUL=SPLLCONbits.PLLMULT+1;
  PLLODIV=PLLODIVVAL[SPLLCONbits.PLLODIV];

  SYSCLK=(FOSC*PLLMUL)/(PLLIDIV*PLLODIV);
  CLK2USEC=SYSCLK/1000000.0f;

  SYSKEY = 0x00000000;
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;

  if(SYSCLK<=60000000)
    PRECONbits.PFMWS=0;
  else if(SYSCLK<=120000000)
    PRECONbits.PFMWS=1;
  else if(SYSCLK<=210000000)
    PRECONbits.PFMWS=2;
  else if(SYSCLK<=252000000)
    PRECONbits.PFMWS=4;
  else
    PRECONbits.PFMWS=7;


  PRECONbits.PFMSECEN=0;    // non c'� nella versione "2019" ...
  PRECONbits.PREFEN=0b01;   // anche 11 non cambia nulla qua

  SYSKEY = 0x00000000;

  // Set up caching
#warning VERIFICARE CACHING trovato in giro!
  cp0 = _mfc0(16, 0);
  cp0 &= ~0x07;
  cp0 |= 0b011; // K0 = Cacheable, non-coherent, write-back, write allocate
  _mtc0(16, 0, cp0);  
  }

void myINTEnableSystemMultiVectoredInt(void) {

  PRISS = 0x76543210;
  INTCONSET = _INTCON_MVEC_MASK;    //MVEC
  __builtin_enable_interrupts();
  }

/* CP0.Count counts at half the CPU rate */
#define TICK_HZ (CPU_HZ / 2)

void __attribute__((used)) __delay_us(unsigned int usec) {
  unsigned int tWait, tStart;

  tWait=(GetSystemClock()/2000000)*usec;
  tStart=_mfc0(9,0);
  while((_mfc0(9,0)-tStart)<tWait)
    ClrWdt();        // wait for the time to pass
  }

void __attribute__((used)) __delay_ms(unsigned int ms) {
  
  for(;ms;ms--)
    __delay_us(1000);
  }



void __delay_us_hw(WORD t) {
  
  PR5=GetPeripheralClock()/8/t;   //
  IFS0bits.T5IF=0;
  TMR5=0;
  while(!IFS0bits.T5IF) ClrWdt();   // meglio, causa IRQ!
  }

// --------------------------------------------------------------------------
void Timer_Init(unsigned int tim) {
  
  T1CONbits.TCS = 0;                  // clock from peripheral clock
  T1CONbits.TCKPS = 0b11;             // 1:256 prescale
  PR1 = tim /*27000*/;                // rollover every n clocks; 
  T1CONbits.TON = 1;                  // start timer 
  
  IFS0bits.T1IF=0;
  IPC1bits.T1IP=2;
  IEC0bits.T1IE=1;
  
  T2CONbits.TCS = 0;                  // clock from peripheral clock
  T2CONbits.TCKPS = 0b000;            // 1:1 prescale
  T2CONbits.T32=0;
  PR2=32768;      // tanto per
  T2CONbits.TON = 1;                  // timer prepared
  
  IFS0bits.T2IF=0;
  IPC2bits.T2IP=4;
  IEC0bits.T2IE=0;

  T3CONbits.TCS = 0;                  // clock from peripheral clock
  T3CONbits.TCKPS = 0b000;            // 1:1 prescale
#ifdef SLIDING_WINDOW
  PR3=GetPeripheralClock()/(Fs);      // ADC timebase = 
#else
  PR3=GetPeripheralClock()/Fs;        // ADC timebase = 25uS @40000
#endif
  T3CONbits.TON = 1;                  // start timer 
  
  }

void SPI_Init(BYTE spiMode) {
  
  SPI1CONbits.ON=0;
	TRISDbits.TRISD2=1;				// SDI � input
	TRISDbits.TRISD3=0;				// SDO � output
	TRISDbits.TRISD1=0;			// SCK � output 
  TRISFbits.TRISF1=0;     // ACS � output
  TRISCbits.TRISC15=0;     // TCS � output
  CNPUDbits.CNPUD2=1;     // serve sempre!
  
  switch(spiMode) {		// CKP=b6=CPOL=0 se idle basso/1 se idle alto; CKE=b8=0 se DOut cambia quando idle->active, 1 se viceversa
/*Mode CPOL CPHA
    0   0   0
    1   0   1
    2   1   0
    3   1   1 */
		// ci sarebbe pure il b9 che � sample a met� o alla fine...
    case 0:
      SPI1CON= 0b00000000000000000000000100100000;    // master, mode 0 (v tcpip stack: 0x0120)
      break;
    case 1:
      SPI1CON= 0b00000000000000000000000000100000;    //no fancy stuff
      break;
    case 2:
      SPI1CON= 0b00000000000000000000000101100000;    //
      break;
    case 3:
      SPI1CON= 0b00000000000000000000000001100000;    //
      break;
    }
  
  SPI1CONbits.MODE16=1;     // sempre, qua: sia DAC che temperatura
  SPI1CONbits.STXISEL=0b00;     // interrupt su buffer vuoto
  SPI1CON2= 0b00000000000000000000000000000000;    // no special length; SPITUREN irq per dma?
  SPI1STAT= 0b00000000000000000000000000000000;    // 
	SPI1BRG = ((GetPeripheralClock()/SPI1_FREQUENCY)/2)-1;			// 12=3.3MHz; 27/9/21 (100 : (2*(12+1)))
  
  IPC27bits.SPI1TXIP=5;
//  IEC3bits.SPI1TXIE=1;    fatto al volo!
  IFS3bits.SPI1TXIF=0;
    
  SPI1CONbits.ON=1;

  
  SPI4CONbits.ON=0;
// FINIRE	TRISDbits.TRISD10=0;				// SDO � output
	TRISDbits.TRISD10=0;			// SCK � output 
  
  SPI4CON= 0b00000000000000000000110100100000;    // master, mode 11 24bit data/64bit frame
  SPI4CON2= 0b00000000000000000000000010000000;    // AUDEN; AUDMOD=00 (PCM); MONO; SPITUREN irq per dma?
  SPI4STAT= 0b00000000000000000000000000000000;    // 
	SPI4BRG = ((GetPeripheralClock()/SPDIF_FREQUENCY)/2)-1;			// 12=3.3MHz; 27/9/21 (100 : (2*(12+1)))
//  SPI4CONbits.ON=1;
  
  }

void DMA_Init(void) {
  
//  const unsigned int* sourceAddr = (void*) ((unsigned int) &ADCDATA4 & 0x1FFFFFFF);
  // usare VirtToPhys() ?? ma non lo trova, ecco KVA_TO_PA(
//  const unsigned int* sourceAddr = KVA_TO_PA(&ADCDATA4);
//https://www.microchip.com/forums/m951559.aspx

  
  IFS4CLR=_IFS4_DMA0IF_MASK; //clear any pending DMA channel 0 interrupt  
  
  DCH0CON = 0x0013;   // channel off, priority 3, no chaining, continuous
  DCH0ECON = 0;    // no start or stop IRQs, no pattern match
  DCH0SSA = KVA_TO_PA(&samplesOut);  // transfer source physical address
  DCH0SSIZ = NUM_SAMPLES;     // source size 4 * 
  DCH0DSA = KVA_TO_PA(&SPI1BUF);     // transfer destination physical address
  // mi pare che IL MERDOSO SIMULATORE desse DMA-address-error con KVA.. e ok senza, mentre invece SERVE!!
  DCH0DSIZ = 1;    // destination size 
  DCH0CSIZ = 1;                   // 1 bytes transferred per event
  DCH0INT = 0;                    // clear all interrupts
  //DCH0ECONSET = _ADC_DATA4_VECTOR << _DCH0ECON_CHSIRQ_POSITION;
  //DCH0ECONSET = _DCH0ECON_SIRQEN_MASK;
  DCH0ECONbits.CHSIRQ = _TIMER_1_VECTOR;
  DCH0ECONbits.SIRQEN = 1;  // enable DMA 0 for IRQ trigger
  
  //DCH0CONbits.CHCHNS=1;        // Channel 0 chained to start from channel with lower natural priority (channel 1)
  //DCH0CONbits.CHCHN=1;        // enable chaining     
  
  DCH0INTbits.CHSDIE = 1;      // Interrupt when the fill is done.
//  DCH0INTbits.CHDDIE = 1;      // Interrupt when the fill is done.
//  DCH0INT=0xff0000;
  
  IPC33bits.DMA0IP=5;            // set IPL 5, sub-priority 2??
  IPC33bits.DMA0IS=0;
//  IPC33SET = 5 << _IPC33_DMA0IP_POSITION; // 
//  IPC33SET = 0 << _IPC33_DMA0IS_POSITION; // 
  IEC4bits.DMA0IE=0;             // enable DMA channel 0 interrupt NO!
  //IEC4SET = _IEC4_DMA0IE_MASK; // enable DMA channel 0 interrupts

  
  // Set Peripheral Bus 3 Clock to SYSCLK/1
  SYSKEY = 0x00000000; // Start unlock sequence
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;
  while(PB3DIVbits.PBDIVRDY == 0);
  PB3DIVbits.PBDIV = 0;
  PB3DIVbits.ON = 1;
  SYSKEY = 0x33333333;
   
  T1CON=0;
  T1CONbits.TCS = 0;            // clock from peripheral clock
  T1CONbits.TCKPS = 0;          // 1:1 prescaler (DIVERSO dagli altri timer!))
  PR1 = 400; //GetPeripheralClock2()/GENERATOR_RATE;
//  IPC1bits.T1IP=3;            // set IPL 3, sub-priority 0
//  IPC1bits.T1IS=0;
//  IEC0bits.T1IE=1;
  T1CONbits.TON = 1;    // start timer to generate triggers
  //https://www.aidanmocke.com/blog/2019/01/08/DMA-Intro/

  
  
  DCH0CONbits.CHEN = 1; // turn on DMA channel 0
  DMACONbits.ON = 1;  // enable global DMA controller
    
  // https://www.microchip.com/forums/m698095.aspx
  // per chaining / pingpong..

  }  
  
void PMP_Init(void) {

  PMCON= 0b000000000000000000000000;     // tutti segnali attivi low; 
//  PMCON= 0b000000100000001100000000;     // tutti segnali attivi low; no CS ; WR & RD FORSE NON SERVONO; 
  // enhanced/dual buffer funzia solo in Master...
  PMMODE=0b0011100000000000;             // 0 wait state; 8bit; irq sempre; slave mode
  PMAEN =0b0000000000000000;             // idem solo per Master
  //PMAEN =0b0000000000111111;             // BA0..5, (no CS1-CS2)
  
  IPC32bits.PMPIP=3;
  IPC32bits.PMPIS=3;
  
  PMCONbits.ON=1;
  
	// meglio dopo, v.errata:
	Nop();
  PMSTAT=0;
	Nop();
//  PMDOUT=PMDIN;     // al primo giro pare arrivino entrambi, non so se per settling dei pin o errata o boh
  PMDIN;

  IEC4bits.PMPIE=1;
  }

void PWM_Init(void) {

  
  CFGCONbits.OCACLK=0;      // sceglie timer per PWM
  //ma SERVE SYSLOCK! in caso
  
  OC1CON = 0x0006;      // TimerX ossia Timer2; PWM mode no fault; Timer 16bit, TimerX
//  OC1R    = PWM_MAX/2;      // su PIC32 � read-only!
//  OC1RS   = PWM_MAX/2;      // 50%, relativo a PR2 del Timer2
//  OC1CONbits.ON = 1;   // on

//  OC5CON = 0x0006;      // TimerX ossia Timer2; PWM mode no fault; Timer 16bit, TimerX
//  OC5R    = 128;      // su PIC32 � read-only!
//  OC5RS   = 128;      // 50%, relativo a PR2 del Timer2
         // 274KHz~ per uscita analogica MODEM ev.
//  OC5CONbits.ON = 1;   // on
  
  }

void RTCC_Init(void) {
  
  RTCCON=0;
  
	UnlockRTCC();
  
  RTCCONbits.CAL=0;
  RTCCONbits.RTCCLKSEL=0b01;      // ext xtal
  RTCCONbits.RTCOUTSEL=0b01;      // seconds clock su RTCC pin out
  RTCCONbits.RTCOE=1;      // idem

  RTCALRM=0;
  
  RTCCONbits.ON=1;
  
	LockRTCC();
  }
  
// --------------------------------------------------------------------------
	

//Functions:
//ADC_Init() is used to configure A/D to convert 16 samples of 1 input
//channel per interrupt. The A/D is set up for a sampling rate of 1MSPS
//Timer3 is used to provide sampling time delay.
//The input pin being acquired and converted is AN7.
void ADC_Init(void) {
  // https://www.microchip.com/forums/m878246-p2.aspx
  // o anche https://forum.mikroe.com/viewtopic.php?f=164&t=69452

  // PB3DIV=0x800a;    // boh divido per 10 NO! sono gi� attivi di default e impostati a 1/2 = 100MHz
  // e cmq ci vuole una sequenza di sblocco...
  // Set Peripheral Bus 2 Clock to SYSCLK/DIV_4
  /*SYSKEY = 0x00000000; // Start unlock sequence
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;
  while(PB2DIVbits.PBDIVRDY == 0)  ;
  PB2DIVbits.PBDIV = GetSystemClock() / GetPeripheral2Clock() - 1;
  PB2DIVbits.ON = 1;
  SYSKEY = 0x33333333;*/
 
  ADCCON1=0;    // AICPMPEN=0, siamo sopra 2.5V
  CFGCONbits.IOANCPEN=0;    // idem; questo credo voglia SYSLOCK
  ADCTRGMODEbits.SH0ALT = 1; // AN47 = AN3, AN48=AN4
  ADCCON2=0;
  ADCCON3=0;
  
  //Configure Analog Ports
  ADCCON3bits.VREFSEL = 0; //Set Vref to VREF+/-

  ADCCMPEN1=0x00000000;
  ADCCMPEN2=0x00000000;
  ADCCMPEN3=0x00000000;
  ADCCMPEN4=0x00000000;
  ADCCMPEN5=0x00000000;
  ADCCMPEN6=0x00000000;
  ADCFLTR1=0x00000000;
  ADCFLTR2=0x00000000;
  ADCFLTR3=0x00000000;
  ADCFLTR4=0x00000000;
  ADCFLTR5=0x00000000;
  ADCFLTR6=0x00000000;
  
  ADCFSTAT=0;
  
  ADCTRGMODE=0;
  ADCTRGSNS=0;

  ADCTRG1=0;
  ADCTRG2=0;
  ADCTRG3=0;
  ADCTRG2bits.TRGSRC5 = 0b00011; // Set AN5 to trigger from scan trigger
  ADCTRG2bits.TRGSRC6 = 0b00011; // Set AN6 to trigger from scan trigger
  // 46 e 47 usano SEMPRE scan implicito, mentre per AN8 vedere che fare
  
  // I PRIMI 12 POSSONO OVVERO DEVONO USARE gli ADC dedicati! e anche se si usano
  // poi gli SCAN, per quelli >12, bisogna usarli entrambi (e quindi TRGSRC passa a STRIG ossia "common")

  ADCIMCON1bits.DIFF5 = 0; // single ended, unsigned
  ADCIMCON1bits.SIGN5 = 0; // 
  ADCIMCON1bits.DIFF6 = 0; // 
  ADCIMCON1bits.SIGN6 = 0; // 
  ADCIMCON1bits.DIFF2 = 0; // =47 (PD x sempre)
  ADCIMCON1bits.SIGN2 = 0; // 
  ADCIMCON1bits.DIFF3 = 0; // =48
  ADCIMCON1bits.SIGN3 = 0; // 
  ADCIMCON1bits.DIFF8 = 0; // questo forse no??
  ADCIMCON1bits.SIGN8 = 0; // 
  ADCCON1bits.SELRES = 0b11; // ADC7 resolution is 12 bits
  ADCCON1bits.STRGSRC = 1; // Select scan trigger.

  // Initialize warm up time register
  ADCANCON = 0;
  ADCANCONbits.WKUPCLKCNT = 5; // Wakeup exponent = 32 * TADx

  ADCEIEN1 = 0;
    
  ADCCON2bits.ADCDIV = 64; // per SHARED: 2 TQ * (ADCDIV<6:0>) = 64 * TQ = TAD
  ADCCON2bits.SAMC = 5;
    
  ADCCON3bits.ADCSEL = 0;   //0=periph clock 3; 1=SYSCLK
  ADCCON3bits.CONCLKDIV = 4; // 25MHz, sotto � poi diviso 2 per il canale, = max 50MHz come da doc

  ADC2TIMEbits.SELRES=0b11;        // 12 bits
  ADC2TIMEbits.ADCDIV=4;       // 
  ADC2TIMEbits.SAMC=5;        // 
  ADC3TIMEbits.SELRES=0b11;        // 12 bits
  ADC3TIMEbits.ADCDIV=4;       // 
  ADC3TIMEbits.SAMC=5;        //   
  
  ADCCSS1 = 0; // Clear all bits
  ADCCSS2 = 0;
  ADCCSS1bits.CSS5 = 1; // AN5 (Class 2) set for scan
  ADCCSS1bits.CSS6 = 1; // AN6 (Class 2) set for scan
  ADCCSS1bits.CSS2 = 1; // AN47=AN2 (Class 1) set for scan
  ADCCSS1bits.CSS3 = 1; // AN48=AN3 (Class 1) set for scan
  ADCCSS1bits.CSS8 = 1; // AN8 (Class 2) set for scan

  ADC0CFG=DEVADC0;
  ADC1CFG=DEVADC1;
  ADC2CFG=DEVADC2;
  ADC3CFG=DEVADC3;
  ADC4CFG=DEVADC4;
  ADC7CFG=DEVADC7;

  ADCCON1bits.ON = 1;   //Enable AD
  ClrWdt();
  
  // Wait for voltage reference to be stable 
#ifndef USING_SIMULATOR
  while(!ADCCON2bits.BGVRRDY); // Wait until the reference voltage is ready
  //while(ADCCON2bits.REFFLT); // Wait if there is a fault with the reference voltage
#endif

  // Enable clock to the module.
  
  ADCANCONbits.ANEN7 = 1;
  ADCCON3bits.DIGEN7 = 1;
  ADCANCONbits.ANEN2 = 1;
  ADCCON3bits.DIGEN2 = 1;
  ADCANCONbits.ANEN3 = 1;
  ADCCON3bits.DIGEN3 = 1;
  
  ANSELBbits.ANSB13 = 1;    // MICIN = RB13, AN8
    
#ifndef USING_SIMULATOR
  while(!ADCANCONbits.WKRDY2); // Wait until ADC is ready
  while(!ADCANCONbits.WKRDY3); // 
  while(!ADCANCONbits.WKRDY7); // 
#endif
  
  // ADCGIRQEN1bits.AGIEN7=1;     // IRQ (anche ev. per DMA))


          
    //Turn on the Timer Interrupt
//    asm volatile("ei");
#if 0
  T1CON=0;
  T1CONbits.TCS = 0;            // clock from peripheral clock
  T1CONbits.TCKPS = 0;          // 1:1 prescaler (DIVERSO dagli altri timer!))
//  PR1=100;        // ~25mS 24.7.19, con 10000 e PRE=256 e timer_clock=periph1_clock=100MHz, farebbe 39.6Hz=25mS
                  // 25.7.19, con 100 e PRE=64 e timer_clock=periph1_clock=100MHz, => 16KHz=64uS
                  // 25.7.19, con 50 e PRE=1 e timer_clock=periph1_clock=100MHz, => 2MHz
//  PR1=5000;     // test per audio, campiono a 20KHz!
//  con 50 pare fare 2Msamples, SAMC=3 e 8-10bits
  PR1 = Fcy/SAMPLING_RATE;

  
  T1CONbits.TON = 1;    // start timer to generate ADC triggers
//            ADCCON3bits.GSWTRG = 1;
#endif    
      
	}


WORD ConvertADC(BYTE n) { // http://ww1.microchip.com/downloads/en/DeviceDoc/70005213f.pdf
  WORD retval;
    // v. minibasic/breakthrough
  
  ANSELBbits.ANSB7 = 0;
  ANSELBbits.ANSB8 = 0;
  ANSELBbits.ANSB10 = 0;
  ANSELBbits.ANSB11 = 0;
  switch(n) {
    case 47:
      ANSELBbits.ANSB7 = 1;
      break;
    case 48:
      ANSELBbits.ANSB8 = 1;
      break;
    case 5:
      ANSELBbits.ANSB10 = 1;
      break;
    case 6:
      ANSELBbits.ANSB11 = 1;
      break;
    default:    // MIC...
      ANSELBbits.ANSB13 = 1;
      break;
    }

	__delay_us(30);
  
  ADCCON3bits.GSWTRG = 1; // Start software trigger

  switch(n) {
    case 47:
      ANSELBbits.ANSB7 = 1;
      while(ADCDSTAT1bits.ARDY2 == 0) // Wait until the measurement run
        ClrWdt();
      ADCDATA3;
      ADCDATA5;
      ADCDATA6;
      ADCDATA8;
      retval=ADCDATA2;
      break;
    case 48:
      ANSELBbits.ANSB8 = 1;
      while(ADCDSTAT1bits.ARDY3 == 0) // Wait until the measurement run
        ClrWdt();
      ADCDATA2;
      ADCDATA5;
      ADCDATA6;
      ADCDATA8;
      retval=ADCDATA3;
      break;
    case 5:
      ANSELBbits.ANSB10 = 1;
      while(! ADCDSTAT1bits.ARDY7)    // Wait for the conversion to complete
        ClrWdt();
      ADCDATA2;
      ADCDATA3;
      ADCDATA6;
      ADCDATA8;
      retval=ADCDATA5;
      break;
    case 6:
      ANSELBbits.ANSB11 = 1;
      while(! ADCDSTAT1bits.ARDY7)    // Wait for the conversion to complete
        ClrWdt();
      ADCDATA2;
      ADCDATA3;
      ADCDATA5;
      ADCDATA8;
      retval=ADCDATA6;
    // PARE che quando mandi il trigger, lui converte TUTTI i canali abilitati,
    // per cui se non pulisco "l'altro" mi becco un RDY e una lettura precedente...
    // forse COSI' funzionerebbe, PROVARE      while(ADCCON2bits.EOSRDY == 0) // Wait until the measurement run
      break;
    default:
      ANSELBbits.ANSB13 = 1;
      while(! ADCDSTAT1bits.ARDY7)    // Wait for the conversion to complete
        ClrWdt();
      ADCDATA2;
      ADCDATA3;
      ADCDATA5;
      ADCDATA6;
      retval=ADCDATA8;
      break;
    }
  
  ANSELBbits.ANSB7 = 0;
  ANSELBbits.ANSB8 = 0;
  ANSELBbits.ANSB10 = 0;
  ANSELBbits.ANSB11 = 0;
  
//    IFS0bits.AD1IF=0;
    
  return retval;
  
  }

        
// UART
void OpenUART(uint32_t baudRate) {
  
  U1MODE=0b0000000000001000;    // BRGH=1
  U1STA= 0b0000010000000000;    // TXEN
  DWORD baudRateDivider = ((GetPeripheralClock()/(4*baudRate))-1);
  U1BRG=baudRateDivider;
  U1MODEbits.ON=1;
  
    // UART Rx interrupt configuration.
  IFS3bits.U1RXIF = 0;  // Clear the interrupt flag
  IFS3bits.U1TXIF = 0;  // Clear the interrupt flag

//  IEC1bits.U1RXIE = 1;  // Rx interrupt enable
//  IEC1bits.U1EIE = 1;
  IPC28bits.U1RXIP = 2;    // Rx Interrupt priority level
  IPC28bits.U1RXIS = 3;    // Rx Interrupt sub priority level
  
  }

char BusyUART(void) {
  
  return !U1STAbits.TRMT;
  }

char DataRdyUART(void) {
  
  return U1STAbits.URXDA;
  }

void putsUART(unsigned char *buffer) {
  
  while(*buffer) {
    while(U1STAbits.UTXBF);  /* wait if the buffer is full */
    U1TXREG = *buffer++;   /* transfer data byte to TX reg */
    }
  }

unsigned char ReadUART(void) {
  
  return U1RXREG;
  }

void WriteUART(unsigned char data) {
  
  U1TXREG = data;
  }



#ifndef USA_SW_RTC 
/****************************************************************************
  Function:
    DWORD   PIC32RTCCGetDate( void )

  Description:
    This routine reads the date from the RTCC module.

  Precondition:
    The RTCC module has been initialized.

  Parameters:
    None

  Returns:
    DWORD in the format <xx><YY><MM><DD>

  Remarks:
    To catch roll-over, we do two reads.  If the readings match, we return
    that value.  If the two do not match, we read again until we get two
    matching values.

  ***************************************************************************/
DWORD PIC32RTCCGetDate(void) {
  unsigned int timeCopy1, timeCopy2;
  
  if(RTCCONbits.RTCSYNC == 0)  {
    return RTCDATE; // return time
    }
  else  {
    // read time twice and compare result, retry until a match occurs
    while( (timeCopy1 = RTCDATE) != (timeCopy2 = RTCDATE) )
      ClrWdt();
    return timeCopy1; // return time when both reads matched
    }
  }


/****************************************************************************
  Function:
    DWORD   PIC32RTCCGetTime( void )

  Description:
    This routine reads the time from the RTCC module.

  Precondition:
    The RTCC module has been initialized.

  Parameters:
    None

  Returns:
    DWORD in the format <xx><HH><MM><SS>

  Remarks:
    To catch roll-over, we do two reads.  If the readings match, we return
    that value.  If the two do not match, we read again until we get two
    matching values.

  ***************************************************************************/

DWORD PIC32RTCCGetTime(void) {
  unsigned int timeCopy1, timeCopy2;
  
  if(RTCCONbits.RTCSYNC == 0) {
    return RTCTIME; // return time
    }
  else {
    // read time twice and compare result, retry until a match occurs
    while( (timeCopy1 = RTCTIME) != (timeCopy2 = RTCTIME) )
      ClrWdt();
    return timeCopy1; // return time when both reads matched
    }
	}


/****************************************************************************
  Function:
    void PIC32RTCCSetDate( WORD xx_year, WORD month_day )

  Description:
    This routine sets the RTCC date to the specified value.


  Precondition:
    The RTCC module has been initialized.

  Parameters:
    WORD xx_year    - BCD year in the lower byte
    WORD month_day  - BCD month in the upper byte, BCD day in the lower byte

  Returns:
    None

  Remarks:

  ***************************************************************************/
void PIC32RTCCSetDate(WORD xx_year, WORD month_day) {

	UnlockRTCC();
  RTCDATEbits.YEAR10 = LOBYTE(xx_year) / 10;
  RTCDATEbits.YEAR01 = LOBYTE(xx_year) % 10;
  RTCDATEbits.MONTH10=from_bcd(HIBYTE(month_day)) / 10;
  RTCDATEbits.MONTH01=from_bcd(HIBYTE(month_day)) % 10;
  RTCDATEbits.DAY10=from_bcd(LOBYTE(month_day)) / 10;
  RTCDATEbits.DAY01=from_bcd(LOBYTE(month_day)) % 10;
	LockRTCC();
  
	}


/****************************************************************************
  Function:
    void PIC32RTCCSetTime( WORD weekDay_hours, WORD minutes_seconds )

  Description:
    This routine sets the RTCC time to the specified value.

  Precondition:
    The RTCC module has been initialized.

  Parameters:
    WORD weekDay_hours      - BCD weekday in the upper byte, BCD hours in the
                                lower byte
    WORD minutes_seconds    - BCD minutes in the upper byte, BCD seconds in
                                the lower byte

  Returns:
    None

  Remarks:

  ***************************************************************************/
void PIC32RTCCSetTime(WORD weekDay_hours, WORD minutes_seconds) {

  UnlockRTCC();
  RTCDATEbits.WDAY01=HIBYTE(weekDay_hours);
  RTCTIMEbits.HR10 = from_bcd(LOBYTE(weekDay_hours)) / 10;
  RTCTIMEbits.HR01 = from_bcd(LOBYTE(weekDay_hours)) % 10;
  RTCTIMEbits.MIN10 = from_bcd(HIBYTE(minutes_seconds)) / 10;
  RTCTIMEbits.MIN01 = from_bcd(HIBYTE(minutes_seconds)) % 10;
  RTCTIMEbits.SEC10 = from_bcd(LOBYTE(minutes_seconds)) / 10;
  RTCTIMEbits.SEC01 = from_bcd(LOBYTE(minutes_seconds)) % 10;
	LockRTCC();

	}

/****************************************************************************
  Function:
    void UnlockRTCC( void )

  Description:
    This function unlocks the RTCC so we can write a value to it.

  Precondition:
    None

  Parameters:
    None

  Return Values:
    None

  Remarks:
    
  ***************************************************************************/

#define RTCC_INTERRUPT_REGISTER IEC5
#define RTCC_INTERRUPT_VALUE    0x0040

void UnlockRTCC(void) {
  BOOL interruptsWereOn;

  interruptsWereOn = FALSE;
  // sta roba arriva da PIC24, non so serve ancora qua...
  if((RTCC_INTERRUPT_REGISTER & RTCC_INTERRUPT_VALUE) == RTCC_INTERRUPT_VALUE) {
    interruptsWereOn = TRUE;
    RTCC_INTERRUPT_REGISTER &= ~RTCC_INTERRUPT_VALUE;
    }
  
  SYSKEY = 0xaa996655; // write first unlock key to SYSKEY
  SYSKEY = 0x556699aa;
  RTCCONbits.RTCWREN=1;      // 
  SYSKEY = 0x00000000;
  
  if(interruptsWereOn) {
    RTCC_INTERRUPT_REGISTER |= RTCC_INTERRUPT_VALUE;
    }
  
	}
void LockRTCC(void) {

  SYSKEY = 0xaa996655; // write first unlock key to SYSKEY
  SYSKEY = 0x556699aa;
  RTCCONbits.RTCWREN=0;      // 
  SYSKEY = 0x00000000;
	}
#endif


BYTE to_bcd(BYTE n) {
	
	return (n % 10) | ((n / 10) << 4);
	}

BYTE from_bcd(BYTE n) {
	
	return (n & 15) + (10*(n >> 4));
	}

WORD SPI_EXCH(uint16_t w) {
  
  SPI1CONbits.MODE16=1;     // 
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = w;     // Write character to SPI buffer
  while(SPI1STATbits.SPIBUSY == 1 /*(SPI2STATLbits.SPITBF == 1)*/ /* || (SPI2STATLbits.SPIRBF == 0) */ )
    ClrWdt();
  SPI1BUF;
// sempre e cmq qua  SPI1CONbits.MODE16=0;

  }

int16_t ReadTemperature(void) {
  int16_t t;
  
  m_SPITCSBit=0;
  t=SPI_EXCH(0b0000000000000000);
  SPI_EXCH(0b0000000000000000);     // config: continuous, FARE SOLO AL BOOT?
	// AZZ c'� un solo pin per I e O !! farla in sw? o provare a disattivare SDI e scriverlo a 0? o sbattersene e sperare nel power-on state??
	// per riconfigurare PPS, occhio a IOL1WAY!

  m_SPITCSBit=1;
  return t >> 3;      // b0..2 unused; dividere poi per 16 (precisione di 0.0625)
  }


void notifyToCPU(BYTE event,BYTE *parm,BYTE size) {

  IRQCode=event;  
  
  m_IRQ=0;
  __delay_us(5);
  m_IRQ=1;
  
  }


/** EOF main.c *************************************************/


