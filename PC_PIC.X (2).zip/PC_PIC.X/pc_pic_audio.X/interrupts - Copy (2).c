/********************************************************************
 FileName:     interrupt.c

 ********************************************************************
 File Description:

 Change History:
  2021  pc_pic_audio
********************************************************************/

#include "../Compiler.h"
#include "../GenericTypeDefs.h"
#include "pc_pic_audio.h"
#include "io_cfg.h"
#include <sys/attribs.h>
#include <sys/kmem.h>

volatile BYTE Sec10_1,ADCdone;
extern WORD samplesOut[22050],samplesIn[22050];
extern const int16_t TRIANGLE_WAVE_TABLE[NUM_SAMPLES];
extern const int16_t SINE_WAVE_TABLE[NUM_SAMPLES];
extern const int16_t SAWTOOTH_WAVE_TABLE[NUM_SAMPLES];
extern const int16_t SQUARE_WAVE_TABLE[NUM_SAMPLES];
const WORD adsrTimes[16]={ 2,8,16,24, 38,56,68,80, 100,250,500,800, 1000,3000,5000,8000 }; //mS

extern volatile struct AUDIO_WAVE canaliAudio[3];
extern enum TIPO_OUTPUT outputMode;		// 
extern enum TIPO_WAVE waveMode;			// 

extern BYTE IRQCode;

volatile BYTE MidiIn;
extern volatile WORD joystickAnaValues[4];
extern volatile BYTE joystickButtons[5];
extern volatile WORD temperature;

#ifdef USA_SW_RTC 
volatile PIC32_RTCC_DATE currentDate;
volatile PIC32_RTCC_TIME currentTime;
#else
PIC32_RTCC_DATE currentDate;
PIC32_RTCC_TIME currentTime;
#endif

//#define PMPWaitBusy()   //while(!PMSTATbits.OBE);     // VERIFICARE, credo non serva su slave...


void __ISR(_TIMER_1_VECTOR,ipl2SRS) TMR1_ISR(void) {
	
//		mLED_3 ^= 1;		// CHECK Timing!		100mS 26/10/21

  Sec10_1=1;
  
#ifdef USA_SW_RTC 
  static BYTE second_10;
  
  second_10++;
  if(second_10>=10) {
    second_10=0;
    currentTime.sec++;
    if(currentTime.sec >= 60) {
      currentTime.sec=0;
      currentTime.min++;
      if(currentTime.min >= 60) {
        currentTime.min=0;
        currentTime.hour++;
        if(currentTime.hour >= 24) {
          currentTime.hour=0;
          currentDate.mday++;
          if(currentDate.mday >= 30) {		// finire...
            currentDate.mday=0;
            currentDate.mon++;
            if(currentDate.mon >= 12) {		// 
              currentDate.mon=0;
              currentDate.year++;
              }
            }
          }
        }
      } 
    } 

#endif

 	//Clear the Interrupt flag bit or else the CPU will keep vectoring back to the ISR
  IFS0CLR = _IFS0_T1IF_MASK;
	}

void __ISR(_TIMER_2_VECTOR,ipl5SRS) TMR2_ISR(void) {
#warning PROVARE IPL7!!
  WORD value[2]={MAX_DAC_VALUE/2,MAX_DAC_VALUE/2};
  static WORD oldvalue[2];
  static BYTE cnt[3];
	int32_t temp;
	static WORD lfsr = 0xACE1u,oldlfsr=0;
  WORD b;


  // � stranamente lento di un po'... 28/10/21
  //  spostare clear flag su?
  IFS0CLR = _IFS0_T2IF_MASK;
  
  //		mLED_4 ^= 1;		// CHECK Timing!		
  // SERVE USARE bits??
  
  switch(waveMode) {
    case SYNTH:
  // come tempi siamo un po' al pelo: abbiamo campionamento a 320KHz (20K x 16)
  // e con la SPI @16MHz una transazione dura 1uS, per cui se mandiamo entrambi i canali fanno oltre 2uS su 3 totali...
  
      if(canaliAudio[0].tipo != NESSUNA) {
        canaliAudio[0].counter += canaliAudio[0].freq;
        if(canaliAudio[0].counter >= Fsynth) {
          canaliAudio[0].counter -= Fsynth;
          cnt[0]++;
          cnt[0] &= NUM_SAMPLES-1;
          }
        switch(canaliAudio[0].tipo) {
          case QUADRA:
            temp = SQUARE_WAVE_TABLE[cnt[0]];
            break;
          case TRIANGOLARE:
            temp = TRIANGLE_WAVE_TABLE[cnt[0]];
            break;
          case SAWTOOTH:
            temp = SAWTOOTH_WAVE_TABLE[cnt[0]];
            break;
          case SINUSOIDALE:
            temp = SINE_WAVE_TABLE[cnt[0]];
            break;
          case IMPULSI:
            temp = cnt[0] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
            break;
          case RUMORE_BIANCO:
//            temp = rand() & MAX_DAC_VALUE; NON USARE FUNZIONI!
            b = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
            lfsr =  (lfsr >> 1) | (b << 15);
            temp = (MAX_DAC_VALUE/2) - (lfsr >> 4);		// basato su 4096
            break;
          case RUMORE_ROSA:
/*          { static WORD r;
            temp = r;      // bah...
//            r = rand() & MAX_DAC_VALUE;
            temp += r;
          }*/
            b = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
            lfsr =  (lfsr >> 1) | (b << 15);
            lfsr+=oldlfsr;
            lfsr/=2;
            oldlfsr=lfsr;
            temp = (MAX_DAC_VALUE/2) - (lfsr >> 4);		// basato su 4096
            break;
          }
        temp = (temp*canaliAudio[0].volume)/100;
        value[0] += temp;
        if(value[0]>=0x8000)   // negativo :)
          value[0]=0;
        else if(value[0]>MAX_DAC_VALUE)
          value[0]=MAX_DAC_VALUE;
        if(canaliAudio[0].mode == 1) {      // finire
          value[1]+=temp;
          }
        if(canaliAudio[0].effects == 1) {      // finire
          value[1] += temp;
          }
        if(value[1]>=0x8000)   // negativo :)
          value[1]=0;
        else if(value[1]>MAX_DAC_VALUE)
          value[1]=MAX_DAC_VALUE;
        }

      if(canaliAudio[1].tipo != NESSUNA) {
        canaliAudio[1].counter += canaliAudio[1].freq;
        if(canaliAudio[1].counter >= Fsynth) {
          canaliAudio[1].counter -= Fsynth;
          cnt[1]++;
          cnt[1] &= NUM_SAMPLES-1;
          }
        switch(canaliAudio[1].tipo) {
          case QUADRA:
            temp = SQUARE_WAVE_TABLE[cnt[1]];
            break;
          case TRIANGOLARE:
            temp = TRIANGLE_WAVE_TABLE[cnt[1]];
            break;
          case SAWTOOTH:
            temp = SAWTOOTH_WAVE_TABLE[cnt[1]];
            break;
          case SINUSOIDALE:
            temp = SINE_WAVE_TABLE[cnt[1]];
            break;
          case IMPULSI:
            temp = cnt[1] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
            break;
          case RUMORE_BIANCO:
            b = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
            lfsr =  (lfsr >> 1) | (b << 15);
            temp = (MAX_DAC_VALUE/2) - (lfsr >> 4);		// basato su 4096
            break;
          case RUMORE_ROSA:
            b = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
            lfsr =  (lfsr >> 1) | (b << 15);
            lfsr+=oldlfsr;
            lfsr/=2;
            oldlfsr=lfsr;
            temp = (MAX_DAC_VALUE/2) - (lfsr >> 4);		// basato su 4096
            break;
          }
        temp = (temp*canaliAudio[1].volume)/100;
        value[0] += temp;
        if(value[0]>=0x8000)   // negativo :)
          value[0]=0;
        else if(value[0]>MAX_DAC_VALUE)
          value[0]=MAX_DAC_VALUE;
        if(canaliAudio[1].mode == 1) {      // finire
          value[1]+=temp;
          }
        if(canaliAudio[1].effects == 1) {      // finire
          value[1] += -temp;
          }
        if(value[1]>=0x8000)   // negativo :)
          value[1]=0;
        else if(value[1]>MAX_DAC_VALUE)
          value[1]=MAX_DAC_VALUE;
        }

      if(canaliAudio[2].tipo != NESSUNA) {
        canaliAudio[2].counter += canaliAudio[2].freq;
        if(canaliAudio[2].counter >= Fsynth) {
          canaliAudio[2].counter -= Fsynth;
          cnt[2]++;
          cnt[2] &= NUM_SAMPLES-1;
          }
        switch(canaliAudio[2].tipo) {
          case QUADRA:
            temp = SQUARE_WAVE_TABLE[cnt[2]];
            break;
          case TRIANGOLARE:
            temp = TRIANGLE_WAVE_TABLE[cnt[2]];
            break;
          case SAWTOOTH:
            temp = SAWTOOTH_WAVE_TABLE[cnt[2]];
            break;
          case SINUSOIDALE:
            temp = SINE_WAVE_TABLE[cnt[2]];
            break;
          case IMPULSI:
            temp = cnt[2] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
            break;
          case RUMORE_BIANCO:
            b = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
            lfsr =  (lfsr >> 1) | (b << 15);
            temp = (MAX_DAC_VALUE/2) - (lfsr >> 4);		// basato su 4096
            break;
          case RUMORE_ROSA:
            b = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
            lfsr =  (lfsr >> 1) | (b << 15);
            lfsr+=oldlfsr;
            lfsr/=2;
            oldlfsr=lfsr;
            temp = (MAX_DAC_VALUE/2) - (lfsr >> 4);		// basato su 4096
            break;
          }
        temp = (temp*canaliAudio[2].volume)/100;
        value[0] += temp;
        if(value[0]>=0x8000)   // negativo :)
          value[0]=0;
        else if(value[0]>MAX_DAC_VALUE)
          value[0]=MAX_DAC_VALUE;
        if(canaliAudio[2].mode == 1) {      // finire
          value[1] += temp;
          }
        if(canaliAudio[2].effects == 1) {      // finire
          value[1] += -temp;
          }
        if(value[1]>=0x8000)   // negativo :)
          value[1]=0;
        else if(value[1]>MAX_DAC_VALUE)
          value[1]=MAX_DAC_VALUE;
        }
  

//  if(canaliAudio[0].tipo != NESSUNA || canaliAudio[1].tipo != NESSUNA || canaliAudio[2].tipo != NESSUNA) {
      switch(outputMode) {
        case ANALOGIC:
  //      m_LDACBit=1;    // 
          if(oldvalue[0] != value[0]) {
            oldvalue[0] = value[0];
            m_SPIASCSBit=0;
            SPI1STATbits.SPIROV = 0;  // Reset overflow bit
            value[0] &= 0b0000111111111111;     //MAX_DAC_VALUE
            value[0] |= 0b0011000000000000;     // channel A, unbuffered, gain=1, no shutdown
            SPI1BUF = value[0];     // Write to SPI buffer
            while(SPI1STATbits.SPIBUSY)
              ClrWdt();
            SPI1BUF;
            // FARE cos�: inviare 1 word qua, attivare IRQ TX SPI, e poi da l� inviare 2� word e disattivare IRQ
            // ...forse c'� una FIFO e si possono scrivere subito entrambe?? no, va alzato CS ogni volta!
            m_SPIASCSBit=1;
            }
  //        Nop(); Nop(); Nop(); Nop();  //~40nS
          if(oldvalue[1] != value[1]) {
            oldvalue[1] = value[1];
            m_SPIASCSBit=0;
            SPI1STATbits.SPIROV = 0;  // Reset overflow bit
            value[1] &= 0b0000111111111111;     //
            value[1] |= 0b1011000000000000;     // channel B, unbuffered, gain=1, no shutdown
            SPI1BUF = value[1];     // Write to SPI buffer
            while(SPI1STATbits.SPIBUSY)
              ClrWdt();
            SPI1BUF;
            m_SPIASCSBit=1;
            }
  //      m_LDACBit=0;    // non lo usiamo, v.doc
          break;
        
        case SPDIF:      // https://it.wikipedia.org/wiki/S/PDIF#Il_channel_status_bit_nel_protocollo_S/PDIF
        {
          DWORD tempL;
          BYTE preamble;
          static BYTE frame=0;
          SPI4STATbits.SPIROV = 0;  // Reset overflow bit
          value[0] &= 0b0000111111111111;     //MAX_DAC_VALUE
          if(!frame)
            preamble=0b11100010;
          else
            preamble=0b11101000;
          /// mmm mi sa che sta roba funzia solo in Manchester encoding... il che complica le cose qua..
          // vedere I2S o boh!
          tempL=((DWORD)value[0]) << (16-4);    // ma LSB first... FARE
          tempL |= 0b00000000000000000000000000000000;    // preamble
          tempL |= 0b1000;      // VUCP
          SPI4BUF = tempL;     // Write to SPI buffer
          while(SPI4STATbits.SPIBUSY == 1 /*(SPI2STATLbits.SPITBF == 1)*/ /* || (SPI2STATLbits.SPIRBF == 0) */ )
            ClrWdt();
          SPI4BUF;
          // FARE cos�: inviare 1 word qua, attivare IRQ TX SPI, e poi da l� inviare 2� word e disattivare IRQ
          // ...forse c'� una FIFO e si possono scrivere subito entrambe??
      //  IEC3SET = _IEC3_SPI1TXIE_MASK;
          preamble=0b11100100;
          tempL=((DWORD)value[1]) << (16-4);    // ma LSB first... FARE
          tempL |= 0b00000000000000000000000000000000;    // preamble
          tempL |= 0b1000;      // VUCP
          SPI4BUF = tempL;     // Write to SPI buffer
          while(SPI4STATbits.SPIBUSY == 1 /*(SPI4STATLbits.SPITBF == 1)*/ /* || (SPI4STATLbits.SPIRBF == 0) */ )
            ClrWdt();
          SPI4BUF;

          frame++;
          frame &= 0xc0;
          }
   // FINIRE!!
          break;
        }
      break;
    
    case SAMPLES:
      temp = samplesOut[canaliAudio[0].counter];
      temp = (temp*canaliAudio[0].volume)/100;
      value[0] = temp;
      if(value[0]>=0x8000)   // negativo :)
        value[0]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[0]=MAX_DAC_VALUE;
      if(canaliAudio[0].mode == 1) {      // finire
        value[1]=temp;
        }
      if(canaliAudio[0].effects == 1) {      // finire
        value[1] += -temp;
        }
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[1]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      canaliAudio[0].counter++;
      if(canaliAudio[0].counter == canaliAudio[0].length) {
        canaliAudio[0].counter=0;
        m_IRQ ^= 1;
        }
      break;
    }    
  
	}

void __ISR(_TIMER_4_VECTOR,ipl2SRS) TMR4_ISR(void) {    // 1mS per ADSR
  BYTE i;
  
  for(i=0; i<3; i++) {
    switch(canaliAudio[i].ADSRstate) {
      case 0:
        break;
      case 1:
        canaliAudio[i].ADSRcounter++;
//        canaliAudio[i].volume=canaliAudio[i].savedVolume *  // finire!
        if(canaliAudio[i].ADSRcounter >= adsrTimes[canaliAudio[i].attack]) {
          canaliAudio[i].ADSRstate++;
          canaliAudio[i].ADSRcounter=0;
          }
        break;
      case 2:
        canaliAudio[i].ADSRcounter++;
//        canaliAudio[i].volume=canaliAudio[i].savedVolume canaliAudio[i].sustain *  // finire!
        if(canaliAudio[i].ADSRcounter >= adsrTimes[canaliAudio[i].decay]*3) {
          canaliAudio[i].ADSRstate++;
          canaliAudio[i].ADSRcounter=0;
          }
        break;
      case 3:
        canaliAudio[i].ADSRcounter++;
//        canaliAudio[i].volume=canaliAudio[i].savedVolume *  // finire!
        if(canaliAudio[i].ADSRcounter >= adsrTimes[canaliAudio[i].release]*3) {
          canaliAudio[i].ADSRstate++;
          canaliAudio[i].ADSRcounter=0;
          }
        break;
      case 4:
        break;
      }
    }
  
  IFS0CLR = _IFS0_T4IF_MASK;
  }

void __ISR(_SPI1_TX_VECTOR,ipl5SRS) SPI_ISR(void) { // STESSO SRS, v. sopra se si usa!
  // il porcodio di simulatore non simula questo irq...
  static BYTE phase;
  
  switch(phase) {
    case 0:
      m_SPIASCSBit=1;
      Nop(); Nop(); Nop(); Nop(); Nop(); Nop();  //~70nS
      SPI1BUF;
      m_SPIASCSBit=0;
      // fare globali se si usa...
//      value[1] &= 0b0000111111111111;     //
//      value[1] |= 0b1011000000000000;     // channel B, unbuffered, gain=1, no shutdown
//      SPI1BUF = value[1];     // Write to SPI buffer
      phase=1;
      break;
    default:
      SPI1BUF;
      IEC3CLR = _IEC3_SPI1TXIE_MASK;
      m_SPIASCSBit=1;
//      value[0]=value[1]=MAX_DAC_VALUE/2;
      phase=0;
      break;
    }
  IFS3CLR = _IFS3_SPI1TXIF_MASK;
  }

void __ISR(_ADC_VECTOR,ipl4SRS) ADC_ISR(void) {
//    https://www.microchip.com/forums/m1118492.aspx#1119761
	// usare NAKED per irq...

	static WORD counter;

//  ADTRIG0Lbits.TRGSRC0=0;
    
//		mLED_2 ^= 1;		// CHECK Timing!		200uSec (12.5uS * 16), @140MHz, 25/7/21
  
  IFS1CLR = _IFS1_ADCIF_MASK;
  IFS6bits.ADC0EIF = 0;
	}


void __ISR(_DMA0_VECTOR,ipl5SRS) DMA_ISR(void) { // v. SRS SOPRA!

        
//  DCH0SSA = KVA_TO_PA(&testSine);  // transfer source physical address
  DCH0INTCLR = _DCH0INT_CHSDIF_MASK /*DCH0INTbits.CHDDIF=0*/;
  
  IFS4CLR = _IFS4_DMA0IF_MASK /*IFS4bits.DMA0IF=0*/;  // Clear the interrupt flag!
  }

  
volatile BYTE commandParms[128],commandReceived,commandOldRegR,commandParmCntR;
void __ISR(_PMP_VECTOR,ipl6SRS) PMP_ISR(void) {
  BYTE reg,dIO;
	static BYTE commandOldRegW,commandParmCntW;
  int g=PORTG,b=PORTB;

//  addr=PMADDR & 63; no come slave non va
  if(PMSTATbits.IB0F) {
    dIO=*((BYTE *)&PMDIN);
    goto is_read;
    }
  else if(PMSTATbits.IB1F) {
    dIO=*(((BYTE *)&PMDIN)+1);
    goto is_read;
    }
  else if(PMSTATbits.IB2F) {
    dIO=*(((BYTE *)&PMDIN)+2);
    goto is_read;
    }
  else if(PMSTATbits.IB3F) {
    dIO=*(((BYTE *)&PMDIN)+3);
is_read:
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
    if(reg != commandOldRegR) {
      commandOldRegR=reg;
      commandParmCntR=0;
      }
		if(!commandReceived) {
			switch(reg) {
				case 0:
					commandReceived=BIOS_INVALID;
					commandParms[commandParmCntR]=dIO;
					commandOldRegR=commandParmCntR=0;
					break;
				case BIOS_AUDIO_SETMODE:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=1) {
						commandReceived=BIOS_AUDIO_SETMODE;
						commandOldRegR=commandParmCntR=0;
            LATBCLR=AACK_MASK;
//						m_ACK=0;
						}
					break;
				case BIOS_AUDIO_SETWAVE:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=9) {
						commandReceived=BIOS_AUDIO_SETWAVE;
						commandOldRegR=commandParmCntR=0;
            LATBCLR=AACK_MASK;
						}
					break;
				case BIOS_AUDIO_SETFREQUENCY:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=3) {
						commandReceived=BIOS_AUDIO_SETFREQUENCY;
						commandOldRegR=commandParmCntR=0;
            LATBCLR=AACK_MASK;
						}
					break;
				case BIOS_AUDIO_SETOUTPUT:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=1) {
						commandReceived=BIOS_AUDIO_SETOUTPUT;
						commandOldRegR=commandParmCntR=0;
            LATBCLR=AACK_MASK;
						}
					break;
				case BIOS_AUDIO_SETRECORD:
					dIO;
					commandReceived=BIOS_AUDIO_SETRECORD;
					commandOldRegR=commandParmCntR=0;
          LATBCLR=AACK_MASK;
					break;
				case BIOS_AUDIO_SETADSR:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=6) {		// channel,A,D,S,R,gate.. https://www.c64-wiki.com/wiki/ADSR ; https://www.c64-wiki.com/wiki/SID
						commandReceived=BIOS_AUDIO_SETADSR;
						commandOldRegR=commandParmCntR=0;
			      LATBCLR=AACK_MASK;
						}
					break;

				case BIOS_AUDIO_PUTSAMPLES:
					dIO;
					commandReceived=BIOS_AUDIO_PUTSAMPLES;
					commandOldRegR=commandParmCntR=0;
          LATBCLR=AACK_MASK;
					break;
          
				case BIOS_AUDIO_INITMIDI:
					commandParms[0]=dIO;
					commandReceived=BIOS_AUDIO_INITMIDI;
					commandOldRegR=commandParmCntR=0;
          LATBCLR=AACK_MASK;
					break;
				case BIOS_AUDIO_WRITEMIDI:
					commandParms[0]=dIO;
					commandReceived=BIOS_AUDIO_WRITEMIDI;
					commandOldRegR=commandParmCntR=0;
          LATBCLR=AACK_MASK;
					break;
          
				case BIOS_AUDIO_SETCLOCK:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=6) {
						commandReceived=BIOS_AUDIO_SETCLOCK;
						commandOldRegR=commandParmCntR=0;
            LATBCLR=AACK_MASK;
						}
					break;
				case BIOS_AUDIO_SETALARM:
					commandParms[commandParmCntR++]=dIO;
					if(commandParmCntR>=5) {
						commandReceived=BIOS_AUDIO_SETALARM;
						commandOldRegR=commandParmCntR=0;
            LATBCLR=AACK_MASK;
						}
					break;
          
				case BIOS_AUDIO_SETJOYSTICK:
					commandParms[0]=dIO;
					commandReceived=BIOS_AUDIO_SETJOYSTICK;
					commandOldRegR=commandParmCntR=0;
          LATBCLR=AACK_MASK;
					break;
          
				case BIOS_RESET:
          switch(dIO) {
            case 0:
              while(1);		// pu� servire! fatto cos� scatta wd e ok
              break;
            case 1:     // warm reset, specie per WINC...
    					commandReceived=BIOS_RESET;
    					commandOldRegR=commandParmCntR=0;
              LATBCLR=AACK_MASK;
              break;
            }
					break;
				default:
					commandReceived=BIOS_INVALID;
					commandOldRegR=commandParmCntR=0;
					break;
				}
			}
    if(PMSTATbits.IBOV) {
      commandOldRegR=commandParmCntR=0;
      commandReceived=0;
      PMSTATbits.IBOV=0;
      LATBSET=AACK_MASK;
      }
		}



  if(PMSTAT & 0x000F) {
//    TRISE &= ~0b0000000011111111;   // serve o � automatico?
    
    reg=(g >> 4) & 0b00111100;
    reg |= (b >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
    if(reg != commandOldRegW) {
      commandOldRegW=reg;
      commandParmCntW=0;
      }
    
		switch(reg) {
      case BIOS_GETID:
        dIO='A';
				commandOldRegW=commandParmCntW=0;
        break;
      case BIOS_GETVERSION:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
		        dIO=VERNUML;
						commandParmCntW++;
		        break;
					case 2:
		        dIO=VERNUMH;
						commandParmCntW++;
		        break;
					case 3:
		        dIO=VERNUMH;
  					commandOldRegW=commandParmCntW=0;
		        break;
					}
        break;
      case BIOS_GETCONFIG:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
		        dIO=waveMode;
						commandParmCntW++;
		        break;
					case 2:
					case 3:
		        dIO=outputMode;
						commandParmCntW++;
		        break;
					case 4:
					case 5:
		        dIO='M';
						commandParmCntW++;
		        break;
					case 6:
		        dIO='J';
						commandParmCntW++;
		        break;
					case 7:
		        dIO='J';
  					commandOldRegW=commandParmCntW=0;
		        break;
          }
        break;
			case BIOS_IRQ_REQUEST:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
          case 0:
    				dIO=IRQCode;
            commandParmCntW++;
            break;
          case 1:
    				dIO=IRQCode;
            IRQCode=0;
    				commandOldRegW=commandParmCntW=0;
            break;
          }
				break;
			case BIOS_AUDIO_GETSAMPLES:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
				samplesIn[0];
				// FINIRE!
				commandOldRegW=commandParmCntW=0;
				break;
			case BIOS_AUDIO_READMIDI:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
						dIO=MidiIn;
            commandParmCntW++;
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
/*				while(!DataRdyUART())
					ClrWdt();
				dIO=ReadUART();*/
				dIO= 0 ;   // FINIRE!
				commandOldRegW=commandParmCntW=0;
				break;
			case BIOS_AUDIO_READJOYSTICK:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
						dIO=joystickButtons[0];
            commandParmCntW++;
            break;
					case 2:
					case 3:
						dIO=joystickButtons[1];
            commandParmCntW++;
            break;
					case 4:
					case 5:
						dIO=joystickButtons[2];
            commandParmCntW++;
            break;
					case 6:
					case 7:
						dIO=joystickButtons[3];
            commandParmCntW++;
            break;
					case 8:
					case 9:
						dIO=joystickButtons[4];
            commandParmCntW++;
            break;
					case 10:
					case 11:
						dIO=LOBYTE(joystickAnaValues[0]);
            commandParmCntW++;
            break;
					case 12:
					case 13:
						dIO=HIBYTE(joystickAnaValues[0]);
            commandParmCntW++;
            break;
					case 14:
					case 15:
						dIO=LOBYTE(joystickAnaValues[1]);
            commandParmCntW++;
            break;
					case 16:
					case 17:
						dIO=HIBYTE(joystickAnaValues[1]);
            commandParmCntW++;
            break;
					case 18:
					case 19:
						dIO=LOBYTE(joystickAnaValues[2]);
            commandParmCntW++;
            break;
					case 20:
					case 21:
						dIO=HIBYTE(joystickAnaValues[2]);
            commandParmCntW++;
            break;
					case 22:
					case 23:
						dIO=LOBYTE(joystickAnaValues[3]);
            commandParmCntW++;
            break;
					case 24:
						dIO=HIBYTE(joystickAnaValues[3]);
            commandParmCntW++;
            break;
					case 25:
						dIO=HIBYTE(joystickAnaValues[3]);
    				commandOldRegW=commandParmCntW=0;
            break;
					default:
						dIO=-1;
    				commandOldRegW=commandParmCntW=0;
						break;
          }
				break;
			case BIOS_AUDIO_GETCLOCK:
			{
#define FROM_BCD(n) 	((n & 15) + (10*(n >> 4)))    // per funzioni in irq...
        
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
	#ifndef USA_SW_RTC 
//				currentDate.l=PIC32RTCCGetDate();
    				dIO=FROM_BCD(currentDate.mday);
	#else
    				dIO=currentDate.mday;
	#endif
						commandParmCntW++;
						break;
					case 2:
					case 3:
	#ifndef USA_SW_RTC 
    				dIO=FROM_BCD(currentDate.mon);
	#else
            dIO=currentDate.mon;
	#endif
						commandParmCntW++;
						break;
					case 4:
					case 5:
	#ifndef USA_SW_RTC 
    				dIO=FROM_BCD(currentDate.year);
	#else
            dIO=currentDate.year;
	#endif
						commandParmCntW++;
						break;
					case 6:
					case 7:
	#ifndef USA_SW_RTC 
  //				currentTime.l=PIC32RTCCGetTime();
    				dIO=FROM_BCD(currentTime.hour);
	#else
        		dIO=currentTime.hour;
	#endif
						commandParmCntW++;
						break;
					case 8:
					case 9:
	#ifndef USA_SW_RTC 
    				dIO=FROM_BCD(currentTime.min);
	#else
    				dIO=currentTime.min;
	#endif
						commandParmCntW++;
						break;
					case 10:
	#ifndef USA_SW_RTC 
    				dIO=FROM_BCD(currentTime.sec);
	#else
            dIO=currentTime.sec;
	#endif
						commandParmCntW++;
						break;
					case 11:
	#ifndef USA_SW_RTC 
    				dIO=FROM_BCD(currentTime.sec);
	#else
            dIO=currentTime.sec;
	#endif
    				commandOldRegW=commandParmCntW=0;
						break;
					default:
    				commandOldRegW=commandParmCntW=0;
						break;
					}
				// FINIRE!
				}
				commandOldRegW=commandParmCntW=0;
				break;
			case BIOS_AUDIO_READTEMPERATURE:
				switch(commandParmCntW) {    // credo sia giusto cos�, visto che facciamo sempre 2 letture di seguito
					case 0:
					case 1:
						dIO=LOBYTE(temperature);
						commandParmCntW++;
						break;
					case 2:
						dIO=HIBYTE(temperature);
						commandParmCntW++;
						break;
					case 3:
						dIO=HIBYTE(temperature);
    				commandOldRegW=commandParmCntW=0;
						break;
					default:
    				commandOldRegW=commandParmCntW=0;
						break;
          }
//				dIO=ReadTemperature() >> 4;
				dIO= 0 ;   // FINIRE!
				commandOldRegW=commandParmCntW=0;
				break;
			default:
				dIO=reg;
        commandOldRegW=commandParmCntW=0;
				break;
			}

    if(PMSTATbits.OB0E) {
      *((BYTE *)&PMDOUT)=dIO;
      }
    else if(PMSTATbits.OB1E) {
      *(((BYTE *)&PMDOUT)+1)=dIO;
      }
    else if(PMSTATbits.OB2E) {
      *(((BYTE *)&PMDOUT)+2)=dIO;
      }
    else if(PMSTATbits.OB3E) {
      *(((BYTE *)&PMDOUT)+3)=dIO;
      }

//			TRISE |= 0b0000000011111111;   // serve o � automatico?
    if(PMSTATbits.OBUF) {
      commandOldRegW=commandParmCntW=0;
      PMSTATbits.OBUF=0;
      }
		}
  
  IFS4CLR = _IFS4_PMPIF_MASK;
  }

void __ISR(_UART1_RX_VECTOR,ipl2SRS) UART1_ISR(void) {
  
//  LATDbits.LATD4 ^= 1;    // LED to indicate the ISR.
  MidiIn = U1RXREG;
  notifyToCPU(EVENT_MIDI,(BYTE *)&MidiIn,1);
  
  IFS3bits.U1RXIF = 0;  // Clear the interrupt flag!
  }


// ---------------------------------------------------------------------------------------
// declared static in case exception condition would prevent
// auto variable being created
static enum {
	EXCEP_IRQ = 0,			// interrupt
	EXCEP_AdEL = 4,			// address error exception (load or ifetch)
	EXCEP_AdES,				// address error exception (store)
	EXCEP_IBE,				// bus error (ifetch)
	EXCEP_DBE,				// bus error (load/store)
	EXCEP_Sys,				// syscall
	EXCEP_Bp,				// breakpoint
	EXCEP_RI,				// reserved instruction
	EXCEP_CpU,				// coprocessor unusable
	EXCEP_Overflow,			// arithmetic overflow
	EXCEP_Trap,				// trap (possible divide by zero)
	EXCEP_IS1 = 16,			// implementation specfic 1
	EXCEP_CEU,				// CorExtend Unuseable
	EXCEP_C2E				// coprocessor 2
  } _excep_code;

static unsigned int _epc_code;
static unsigned int _excep_addr;

void __attribute__((weak)) _general_exception_handler(uint32_t __attribute__((unused)) code, uint32_t __attribute__((unused)) address) {
  
  Nop();
  }

void __attribute__((nomips16,used)) _general_exception_handler_entry(void) {
  
	asm volatile("mfc0 %0,$13" : "=r" (_epc_code));
	asm volatile("mfc0 %0,$14" : "=r" (_excep_addr));

	_excep_code = (_epc_code & 0x0000007C) >> 2;

  _general_exception_handler(_excep_code, _excep_addr);

	while (1)	{
		// Examine _excep_code to identify the type of exception
		// Examine _excep_addr to find the address that caused the exception
    }
  }


