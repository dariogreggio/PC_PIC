/********************************************************************
 FileName:     interrupt.c

 ********************************************************************
 File Description:

 Change History:
  2021  pc_pic_audio
********************************************************************/

#include "Compiler.h"
#include "GenericTypeDefs.h"
#include "pc_pic_audio.h"
#include "HardwareProfile - dsPIC33E.h"
#include "io_cfg.h"

volatile BYTE Sec10_1,ADCdone;
extern const WORD sineTable[NUM_SAMPLES];
extern const WORD TRIANGLE_WAVE_TABLE[NUM_SAMPLES];
extern const WORD SINE_WAVE_TABLE[NUM_SAMPLES];
extern const WORD SAWTOOTH_WAVE_TABLE[NUM_SAMPLES];

extern struct AUDIO_WAVE canaliAudio[3];

#ifdef USA_SW_RTC 
volatile PIC24_RTCC_DATE currentDate;
volatile PIC24_RTCC_TIME currentTime;
#else
PIC24_RTCC_DATE currentDate;
PIC24_RTCC_TIME currentTime;
#endif

#define PMPWaitBusy()   while(!PMSTATbits.OBE);     // VERIFICARE


void /*_ISRFAST usare */ __attribute__((interrupt, /* shadow, */ no_auto_psv)) _T1Interrupt(void) {
	
//		mLED_3 ^= 1;		// CHECK Timing!		100mS 24/7/21

  Sec10_1=1;
  
#ifdef USA_SW_RTC 
  
  currentTime.sec++;
  if(currentTime.sec >= 60) {
    currentTime.sec=0;
    currentTime.min++;
    if(currentTime.min >= 60) {
      currentTime.min=0;
      currentTime.hour++;
      if(currentTime.hour >= 24) {
        currentTime.hour=0;
        currentDate.mday++;
        if(currentDate.mday >= 30) {		// finire...
          currentDate.mday=0;
          currentDate.mon++;
          if(currentDate.mon >= 12) {		// 
            currentDate.mon=0;
            currentDate.year++;
            }
          }
        }
      }
    } 

#endif

 	//Clear the Interrupt flag bit or else the CPU will keep vectoring back to the ISR
 	IFS0bits.T1IF = 0;
	}

void __attribute__((interrupt, shadow, auto_psv)) _T2Interrupt(void) {    // v. ADC, shadow anche lui ma pty diversa MA NON VA, ADC ha bisogno di max pty!
  static BYTE cnt[3];
  BYTE doWrite=0;
  WORD value[2]={MAX_DAC_VALUE/2,MAX_DAC_VALUE/2};
	static WORD lfsr = 0xACE1u,oldlfsr=0;
	BYTE b;

//		mLED_4 ^= 1;		// CHECK Timing!		
  
  if(canaliAudio[0].tipo != NESSUNA) {
    canaliAudio[0].counter += canaliAudio[0].freq;
    if(canaliAudio[0].counter >= Fsynth) {
      switch(canaliAudio[0].tipo) {
        case QUADRA:
          value[0] += cnt[0] >= (NUM_SAMPLES/2) ? MAX_DAC_VALUE : 0;
          break;
        case TRIANGOLARE:
          value[0] += TRIANGLE_WAVE_TABLE[cnt[0]];
          break;
        case SAWTOOTH:
          value[0] += SAWTOOTH_WAVE_TABLE[cnt[0]];
          break;
        case SINUSOIDALE:
          value[0] += SINE_WAVE_TABLE[cnt[0]];
          break;
        case IMPULSI:
          value[0] += cnt[0] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
          break;
        case RUMORE_BIANCO:
          value[0] += rand() & MAX_DAC_VALUE;
	    /*b  = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
          lfsr =  (lfsr >> 1) | (b << 15);
          OC1R = lfsr >> 10;		// basato su 64
          */
          break;
        case RUMORE_ROSA:
        { WORD r;
          r = rand() & MAX_DAC_VALUE;
          value[0] += r;      // bah...
          value[0] += r;
        }
/*	    b  = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
  	  lfsr =  (lfsr >> 1) | (b << 15);
			lfsr+=oldlfsr;
			lfsr/=2;
			oldlfsr=lfsr;
			OC1R = lfsr >> 10;		// basato su 64
  filtrare...
      */
          break;
        }
      cnt[0]++;
      cnt[0] &= NUM_SAMPLES-1;
      }
    if(canaliAudio[0].mode == 1) {      // finire
      value[1]=value[0];
      }
    if(canaliAudio[0].effects == 1) {      // finire
      value[1] += -value[0];
      }
    }
  
  if(canaliAudio[1].tipo != NESSUNA) {
    canaliAudio[1].counter += canaliAudio[1].freq;
    if(canaliAudio[1].counter >= Fsynth) {
      switch(canaliAudio[1].tipo) {
        case QUADRA:
          value[0] += cnt[1] >= (NUM_SAMPLES/2) ? MAX_DAC_VALUE : 0;
          break;
        case TRIANGOLARE:
          value[0] += TRIANGLE_WAVE_TABLE[cnt[1]];
          break;
        case SAWTOOTH:
          value[0] += SAWTOOTH_WAVE_TABLE[cnt[1]];
          break;
        case SINUSOIDALE:
          value[0] += SINE_WAVE_TABLE[cnt[1]];
          break;
        case IMPULSI:
          value[0] += cnt[1] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
          break;
        case RUMORE_BIANCO:
          value[0] += rand() & MAX_DAC_VALUE;
          break;
        case RUMORE_ROSA:
          value[0] += rand() & MAX_DAC_VALUE;
          break;
        }
      cnt[1]++;
      cnt[1] &= NUM_SAMPLES-1;
      }
    if(canaliAudio[1].mode == 1) {      // finire
      value[1]=value[0];
      }
    if(canaliAudio[1].effects == 1) {      // finire
      value[1] += -value[0];
      }
    }
  if(canaliAudio[2].tipo != NESSUNA) {
    canaliAudio[2].counter += canaliAudio[2].freq;
    if(canaliAudio[2].counter >= Fsynth) {
      switch(canaliAudio[2].tipo) {
        case QUADRA:
          value[0] += cnt[2] >= (NUM_SAMPLES/2) ? MAX_DAC_VALUE : 0;
          break;
        case TRIANGOLARE:
          value[0] += TRIANGLE_WAVE_TABLE[cnt[2]];
          break;
        case SAWTOOTH:
          value[0] += SAWTOOTH_WAVE_TABLE[cnt[2]];
          break;
        case SINUSOIDALE:
          value[0] += SINE_WAVE_TABLE[cnt[2]];
          break;
        case IMPULSI:
          value[0] += cnt[2] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
          break;
        case RUMORE_BIANCO:
          value[0] += rand() & MAX_DAC_VALUE;
          break;
        case RUMORE_ROSA:
          value[0] += rand() & MAX_DAC_VALUE;
          break;
        }
      cnt[2]++;
      cnt[2] &= NUM_SAMPLES-1;
      }
    if(canaliAudio[2].mode == 1) {      // finire
      value[1]=value[0];
      }
    if(canaliAudio[2].effects == 1) {      // finire
      value[1] += -value[0];
      }
    }
  

  if(doWrite) {
    value[0] &= 0b0000111111111111;     //MAX_DAC_VALUE
    value[0] |= 0b0011000000000000;     // channel A, unbuffered, gain=1, no shutdown
    SPI1BUF=value[0];
    value[1] &= 0b0000111111111111;     //
    value[1] |= 0b1011000000000000;     // channel B, unbuffered, gain=1, no shutdown
    SPI1BUF=value[1];
    }
   // FINIRE!!
  
  

 	IFS0bits.T2IF = 0;
	}

void /*_ISRFAST usare */ __attribute__((interrupt, /* shadow, */ no_auto_psv)) _T4Interrupt(void) {
	
    //mLED_4 ^= 1;		// CHECK TIMER! 35uS prova con 312 24/7/21; anche 300Hz ok
  

 	IFS1bits.T4IF = 0;
	}

void __attribute__((__interrupt__, shadow, no_auto_psv)) _AD1Interrupt(void) {    // shadow come T2 ma diversa pty
//    https://www.microchip.com/forums/m1118492.aspx#1119761
	// usare NAKED per irq...

	static WORD counter;

//  ADTRIG0Lbits.TRGSRC0=0;
    
//		mLED_2 ^= 1;		// CHECK Timing!		200uSec (12.5uS * 16), @140MHz, 25/7/21
  
  IFS0bits.AD1IF=0;
	}


void __attribute__((__interrupt__, shadow, no_auto_psv)) _DMA0Interrupt(void) {   // shadow ma diversa pty

        
  IFS0bits.DMA0IF=0;
	}

void __attribute__((__interrupt__, shadow, __auto_psv__)) PMP_ISR(void) {   // shadow ma diversa pty
  BYTE addr,reg;
  static WORD parms[16];
  static BYTE parmN=0,oldReg=0;
  
  // verificare se � una buona idea scrivere dentro IRQ; inoltre credo si generi IRQ anche su WRite, che per� non importa tanto va perso
  addr=PMADDR & 63;
  reg=addr;
  if(reg != oldReg) {
    oldReg=reg;
    parmN=0;
    }
  if(1 /*WR*/) {
  switch(reg) {
    case 0:
      parms[parmN++]=PMDIN1;
        oldReg=parmN=0;
      break;
    case BIOS_GETCONFIG:
      break;
    case BIOS_AUDIO_SETWAVE:
      parms[parmN++]=PMDIN1;
      if(parmN>=4) {
        SetMode(parms[0],parms[1],MAKEWORD(parms[2],parms[3]),parms[4],parms[5],parms[6],parms[7]);
        oldReg=parmN=0;
        }
      break;
    case BIOS_AUDIO_SETCLOCK:
      parms[parmN++]=PMDIN1;
      if(parmN>=6) {
        SetClock(parms[0],parms[1],parms[2],parms[3],parms[4],parms[5]);
        oldReg=parmN=0;
        }
      break;
   }
  }
  else {        // RD
  switch(reg) {
    case BIOS_GETID:
      PMDOUT1='A';
      PMPWaitBusy();
      break;
    case BIOS_GETCONFIG:
      PMDOUT1=VERNUML;
      PMPWaitBusy();
      break;
    case 2:
      PMDOUT1=VERNUMH;
      PMPWaitBusy();
      break;
    case BIOS_IRQ_REQUEST:
      break;
    }
  }
  
  IFS2bits.PMPIF = 0;
  }


void _ISR __attribute__((__no_auto_psv__)) _AddressError(void) {
//https://www.microchip.com/forums/tm.aspx?m=313878&high=where_was_i
//https://www.microchip.com/forums/tm.aspx?m=295657&high=where_was_i
	Nop();
	Nop();
	}

void _ISR __attribute__((__no_auto_psv__)) _StackError(void) {

	Nop();
	Nop();
	}


