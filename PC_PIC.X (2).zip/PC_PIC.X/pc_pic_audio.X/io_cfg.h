/*********************************************************************
 *
 *                Microchip XC32 Firmware Version 1.0
 *
 *********************************************************************
 * FileName:        io_cfg.h
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC32
 * Compiler:        XC32 1.36+
 * Company:         Microchip Technology, Inc.
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Rawin Rojvanit       21/07/04    Original.
 * Dario Greggio        30/08/21    pc_pic_audio
 ********************************************************************/

#ifndef IO_CFG_H
#define IO_CFG_H



/** I N C L U D E S *************************************************/


	
#define Delay_1uS() __delay_us(1)
void Delay_uS(unsigned char);
void Delay_S_(unsigned char);
void Delay_mS_free(unsigned int);
#define Delay_1mS() __delay_mS(1)
#define Delay_mS(n) __delay_ms(n)




/** I N P U T / O U T P U T *****************************************************/
// port A  			// 

// port B

/** T R I S *********************************************************/


// joystick
#define Puls1Bit			6
#define m_Puls1Bit	PORT6bits.RB6
#define Puls2Bit			9
#define m_Puls2Bit	PORTBbits.RB9
#define Puls3Bit			12
#define m_Puls3Bit	PORTBbits.RD12
#define Puls4Bit			3
#define m_Puls4Bit	PORTFbits.RF3


#define m_IRQ  LATBbits.LATB5          // pin 11
#define m_ACK m_IRQ     // magari in futuro usare altro, tipo BA5
#define AIRQ_MASK 0x0020
#define AACK_MASK 0x0020
#define m_RD PORTDbits.RD5         // pin 53
#define m_WR PORTDbits.RD4         // pin 52

#define	SPISDITris TRISDbits.TRISD2				// SDI
#define	SPISDOTris TRISDbits.TRISD3				// SDO
#define	SPISCKTris TRISDbits.TRISD1				// SCK
#define	SPITCSTris  TRISCbits.TRISC15			// CS
#define	SPIASCSTris  TRISFbits.TRISF1			// CS
	
#define	m_SPISCKBit LATDbits.LATD1		// pin 49
#define	m_SPISDOBit LATDbits.LATD3		// pin 51
#define	m_SPISDIBit PORTDbits.RD2       // pin 50
#define	m_SPISDIOBit LATDbits.LATD2       // pin 50
#define	m_SPITCSBit  LATCbits.LATC15		// pin 32
#define	m_SPIASCSBit  LATFbits.LATF1		// pin 57
#define	m_LDACBit  LATFbits.LATF0		// pin 56


#define	m_Modem    LATDbits.LATD9		// pin 43
#define	m_SPDIF    LATDbits.LATD10		// pin 44

#define	m_AUXRESET   LATBbits.LATB2		// pin 14, per WINC e/o EIDE (ev.)

#define	m_MicIn    PORTBbits.RB13		// pin 28
#define	m_Ana1     PORTBbits.RB7		// pin 18
#define	m_Ana2     PORTBbits.RB8		// pin 21
#define	m_Ana3     PORTBbits.RB10		// pin 23
#define	m_Ana4     PORTBbits.RB11		// pin 24


// port F
#define	m_MidiOut  LATFbits.LATF5		// pin 42
#define	m_MidiIn   PORTFbits.RF4		// pin 41



#define Puls1Val  (1 << Puls1Bit)



#endif //IO_CFG_H


