/***
	pc_pic_audio.h

 * DarioG/Katia ;)  30/8/2021 
    dario.greggio@outlook.it

***/
#ifndef _PC_PIC_AUDIO_H
#define _PC_PIC_AUDIO_H

#include <xc.h>

#include "../pc_pic_cpu.X/pc_pic_bios.h"
#include "pc_pic_audio_bios.h"

/* check if build is for a real debug tool */
#if defined(__DEBUG) && !defined(__MPLAB_ICD2_) && !defined(__MPLAB_ICD3_) && \
   !defined(__MPLAB_PICKIT2__) && !defined(__MPLAB_PICKIT3__) && \
   !defined(__MPLAB_REALICE__) && \
   !defined(__MPLAB_DEBUGGER_REAL_ICE) && \
   !defined(__MPLAB_DEBUGGER_ICD3) && \
   !defined(__MPLAB_DEBUGGER_PK3) && \
   !defined(__MPLAB_DEBUGGER_PICKIT2) && \
   !defined(__MPLAB_DEBUGGER_PIC32MXSK)
    #warning Debug with broken MPLAB simulator
    #define USING_SIMULATOR
#endif


#ifndef FCY
#define FCY 208000000UL    //CPU clock; ricontrollato con baud rate, pare giusto cos�! (v. anche PLL)
    // overclock confermato 216 21/8/21 v.MUL_54
// tolto rimettere ev.
#define FOSC 8000000UL    //Oscillator frequency

#define CPU_CLOCK_HZ             (FCY)    // CPU Clock Speed in Hz
#define CPU_CT_HZ            (CPU_CLOCK_HZ/2)    // CPU CoreTimer   in Hz
#define PERIPHERAL_CLOCK_HZ      (FCY/2 /*100000000UL*/)    // Peripheral Bus  in Hz
#define GetSystemClock()         (FCY)    // CPU Clock Speed in Hz
#define GetPeripheralClock()     (PERIPHERAL_CLOCK_HZ)    // Peripheral Bus  in Hz
#define GetPeripheralClock2()     (FCY)    // Peripheral Bus per Timers in Hz

#define US_TO_CT_TICKS  (CPU_CT_HZ/1000000UL)    // uS to CoreTimer Ticks
    
#define SPI1_FREQUENCY 16000000UL
#define SPDIF_FREQUENCY (44100UL*192)           // boh

#define VERNUML 7
#define VERNUMH 0
#endif


#define DMA_READY __attribute__((coherent)) __attribute__((aligned(16)))    // 
//__attribute__((coherent,aligned(4)))


void mySYSTEMConfigPerformance(void);
void myINTEnableSystemMultiVectoredInt(void);

#define ReadCoreTimer()           _CP0_GET_COUNT()           // Read the MIPS Core Timer
void __delay_us(unsigned int);
void __delay_ms(unsigned int);



#define Fs 22050            // per mic in
#define Fsynth 20000        // per audio out (16x oversample, v.irq)
#define NUM_SAMPLES 16      // da usb_gen_funz; teoricamente 32 andrebbe, max=44100*32 x2 ~2.5Msamples, fattibile, spero!
#define MAX_DAC_VALUE 4095      // TC4921
    

struct __attribute((packed)) AUDIO_WAVE {
    DWORD freq;
//#warning usare DWORD per efficienza!
    DWORD counter;
    enum __attribute((packed)) TIPO_ONDA tipo;
    BYTE channels;
    BYTE bits;
    BYTE volume,savedVolume;
    BYTE mode;          // 1 canale solo, 2 canali mono, 2 canali stereo...
    BYTE effects;       // sfasa 180� i canali...
    
    BYTE attack,decay,sustain,release;
    BYTE ADSRstate;     // 0..4
    BYTE ADSRcounter;
    
    DWORD length;
    };




// il Timer0 conta ogni 10nSec*prescaler... (@200MHz CPUCLK => 100MHz) su PIC32
#define TMR1BASE (GetPeripheralClock() /256/10 /*39062*/)		//   10Hz per timer

//#define USA_SW_RTC 1

// PIC32 RTCC Structure
typedef union {
  struct {
    unsigned char   weekday;    // BCD codification for day of the week, 00-06
    unsigned char   mday;       // BCD codification for day of the month, 01-31
    unsigned char   mon;        // BCD codification for month, 01-12
    unsigned char   year;       // BCD codification for years, 00-99
  	};                              // field access	
  unsigned char       b[4];       // byte access
  unsigned short      w[2];       // 16 bits access
  unsigned long       l;          // 32 bits access
	} PIC32_RTCC_DATE;

// PIC32 RTCC Structure
typedef union {
  struct {
    unsigned char   reserved;   // reserved for future use. should be 0
    unsigned char   sec;        // BCD codification for seconds, 00-59
    unsigned char   min;        // BCD codification for minutes, 00-59
    unsigned char   hour;       // BCD codification for hours, 00-24
  	};                              // field access
  unsigned char       b[4];       // byte access
  unsigned short      w[2];       // 16 bits access
  unsigned long       l;          // 32 bits access
	} PIC32_RTCC_TIME;



DWORD   PIC32RTCCGetTime(void);
DWORD   PIC32RTCCGetDate(void);
void    PIC32RTCCSetTime(WORD weekDay_hours, WORD minutes_seconds);
void    PIC32RTCCSetDate(WORD xx_year, WORD month_day);
void    PIC32RTCCSetAlarm(BYTE month, BYTE day, BYTE hours, BYTE minutes, BYTE seconds);
void    UnlockRTCC(void);
void    LockRTCC(void);

#ifdef USA_SW_RTC 
extern volatile PIC32_RTCC_DATE currentDate;
extern volatile PIC32_RTCC_TIME currentTime;
#else
extern PIC32_RTCC_DATE currentDate;
extern PIC32_RTCC_TIME currentTime;
#endif


BYTE to_bcd(BYTE);
BYTE from_bcd(BYTE);



void Timer_Init(unsigned int);
void ADC_Init(void);
void PWM_Init(void);
void SPI_Init(BYTE);
void DMA_Init(void);
void RTCC_Init(void);
void PMP_Init(void);
uint16_t ConvertADC(BYTE n);
int16_t ReadTemperature(void);

void SetWave(BYTE,enum TIPO_ONDA,WORD,BYTE,BYTE,BYTE,BYTE,BYTE);
void SetMode(enum TIPO_WAVE);
void SetFrequency(BYTE,WORD);
void SetADSR(BYTE,BYTE,BYTE,BYTE,BYTE,BYTE);
void SetOutput(enum TIPO_OUTPUT);
void SetClock(BYTE,BYTE,WORD,BYTE,BYTE,BYTE);
void SetAlarm(BYTE,BYTE,BYTE,BYTE,BYTE);

void UserInit(void);
void notifyToCPU(BYTE ,BYTE *,BYTE);

void OpenUART(uint32_t);
char BusyUART(void);
char DataRdyUART(void);
unsigned char ReadUART(void);
void WriteUART(unsigned char);

signed char InitJoystick(BYTE);
signed char InitMIDI(void);
WORD ReadJoystick(BYTE c);
int8_t ReadPulsanti(BYTE c);

#define WriteMIDI(c) WriteUART(c)
#define ReadMIDI() ReadUART()

#endif	// defined _PC_PIC_AUDIO

