/********************************************************************
 FileName:     main.c
 Dependencies: See INCLUDES section
 Processor:		dsPIC33E
 Hardware:		The code is natively intended to be used on the following
 				hardware platforms: PC_PIC_MOTHERBOARD
 Compiler:  	Microchip C30 (for PIC24), XC16
 Company:		Microchip Technology, Inc.

 Software License Agreement:
 * ma fatevi le seghe umani dimemmerda!!!
 * 
********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  1.0   11/19/2004   Initial release
  2.1   02/26/2007   Updated for simplicity and to use common
                     coding style
  2021  pc_pic_audio
********************************************************************/


/** CONFIGURATION **************************************************/
// DSPIC33EP256MU806 Configuration Bit Settings

// FGS
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GSS = OFF                // General Segment Code-Protect bit (General Segment Code protect is disabled)
#pragma config GSSK = OFF               // General Segment Key bits (General Segment Write Protection and Code Protection is Disabled)

// FOSCSEL
#pragma config FNOSC = FRCPLL          // Initial Oscillator Source Selection bits (Internal Fast RC (FRC) Oscillator with postscaler)
#pragma config IESO = ON                // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)

// FOSC
#pragma config POSCMD = NONE            // Primary Oscillator Mode Select bits (Primary Oscillator disabled)
#pragma config OSCIOFNC = OFF           // OSC2 Pin Function bit (OSC2 is clock output)
#pragma config IOL1WAY = OFF             // Peripheral pin select configuration (Allow only one reconfiguration)
#pragma config FCKSM = CSDCMD           // Clock Switching Mode bits (Both Clock switching and Fail-safe Clock Monitor are disabled)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler bits (1:32,768)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config PLLKEN = ON              // PLL Lock Wait Enable bit (Clock switch to PLL source will wait until the PLL lock signal is valid.)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (Watchdog timer always disabled)

// FPOR
#pragma config FPWRT = PWR128           // Power-on Reset Timer Value Select bits (128ms)
#pragma config BOREN = ON               // Brown-out Reset (BOR) Detection Enable bit (BOR is enabled)
#pragma config ALTI2C1 = OFF //ON            // Alternate I2C pins for I2C1 (ASDA1/ASCK1 pins are selected as the I/O pins for I2C1)

// FICD
#pragma config ICS = PGD2               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config RSTPRI = PF              // Reset Target Vector Select bit (Device will obtain reset instruction from Primary flash)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)

// FAS
#pragma config AWRP = OFF               // Auxiliary Segment Write-protect bit (Aux Flash may be written)
#pragma config APL = OFF                // Auxiliary Segment Code-protect bit (Aux Flash Code protect is disabled)
#pragma config APLK = OFF               // Auxiliary Segment Key bits (Aux Flash Write Protection and Code Protection is Disabled)

// Use project enums instead of #define for ON and OFF.

#include <xc.h>  
                

/** I N C L U D E S **********************************************************/

#include "Compiler.h"
#include "GenericTypeDefs.h"

#include "pc_pic_audio.h"
#include "pc_pic_audio_bios.h"
#include "HardwareProfile - dsPIC33E.h"
#include "io_cfg.h"


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


/** V A R I A B L E S ********************************************************/


extern volatile BYTE Sec10_1,ADCdone;
WORD Seconds;
BYTE Sec10;

// https://daycounter.com/Calculators/Sine-Generator-Calculator.phtml
const WORD sineTable[NUM_SAMPLES] = {0x8000,0xb0fb,0xda82,0xf641,0xffff,0xf641,0xda82,0xb0fb,
  0x8000,0x4f04,0x257d,0x9be,0x0,0x9be,0x257d,0x4f04};
const WORD TRIANGLE_WAVE_TABLE[NUM_SAMPLES]={0x2222,0x4444,0x6666,0x8888, 0xaaaa,0xcccc,0xeeee,0xffff,
	0xeeee,0xcccc,0xaaaa,0x8888, 0x6666,0x4444,0x2222,0x0000};
const WORD SINE_WAVE_TABLE[NUM_SAMPLES]={0x8000,0xb0fb,0xda82,0xf641, 0xffff,0xf641,0xda82,0xb0fb,
	0x8000,0x4f04,0x257d,0x09be, 0x0000,0x09be,0x257d,0x4f04};
const WORD SAWTOOTH_WAVE_TABLE[NUM_SAMPLES]={0x1000,0x2000,0x3000,0x4000, 0x5000,0x6000,0x7000,0x8000,
	0x8fff,0x9fff,0xafff,0xbfff, 0xcfff,0xdfff,0xefff,0xffff};


/** P R I V A T E  P R O T O T Y P E S ***************************************/
static void InitializeSystem(void);
void UserInit(void);

/** VECTOR REMAPPING ***********************************************/

#if defined(__C30__)
    #if defined(PROGRAMMABLE_WITH_USB_HID_BOOTLOADER)
        /*
         *	ISR JUMP TABLE
         *
         *	It is necessary to define jump table as a function because C30 will
         *	not store 24-bit wide values in program memory as variables.
         *
         *	This function should be stored at an address where the goto instructions 
         *	line up with the remapped vectors from the bootloader's linker script.
         *  
         *  For more information about how to remap the interrupt vectors,
         *  please refer to AN1157.  An example is provided below for the T2
         *  interrupt with a bootloader ending at address 0x1400
         */
//        void __attribute__ ((address(0x1404))) ISRTable(){
//        
//        	asm("reset"); //reset instruction to prevent runaway code
//        	asm("goto %0"::"i"(&_T2Interrupt));  //T2Interrupt's address
//        }


//#define BL_ENTRY_BUTTON PORTEbits.RE0 //button 1...

//If defined, the reset vector pointer and boot mode entry delay
// value will be stored in the device's vector space at addresses 0x100 and 0x102
#define USE_VECTOR_SPACE
//****************************************

//Bootloader Vectors *********************
#ifdef USE_VECTOR_SPACE
	/*
		Store delay timeout value & user reset vector at 0x100 
		(can't be used with bootloader's vector protect mode).
		
		Value of userReset should match reset vector as defined in linker script.
		BLreset space must be defined in linker script.
	*/
	unsigned char timeout  __attribute__ ((space(prog),section(".BLreset"))) = 0x0A;
	unsigned int userReset  __attribute__ ((space(prog),section(".BLreset"))) = 0x1400; 
//cambiato ordine o le metteva a cazzo... 
#else
	/*
		Store delay timeout value & user reset vector at start of user space
	
		Value of userReset should be the start of actual program code since 
		these variables will be stored in the same area.
	*/
	unsigned int userReset  __attribute__ ((space(prog),section(".init"))) = 0xC04 ;
	unsigned char timeout  __attribute__ ((space(prog),section(".init"))) = 5 ;
#endif

#endif
#endif


/** DECLARATIONS ***************************************************/

static const char _PC_PIC_CPU_C[]= {"dsPIC33E512MU806 PC_PIC_AUDIO - 4/09/2021\r\n\r\n"};
static const char Copyr1[]="(C) Dario's Automation 2021 - G.Dar\xd\xa\x0";
// MORTE... AGLI... UMANI... 30/8/21.


struct AUDIO_WAVE canaliAudio[3];


/********************************************************************
 * Function:        static void InitializeSystem(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        InitializeSystem is a centralize initialization
 *                  routine. All required USB initialization routines
 *                  are called from here.
 *
 *                  User application initialization routine should also be called from here.                  
 *
 * Note:            None
 *******************************************************************/
static void InitializeSystem(void) {

  ClrWdt();
  
//	_PLLDIV=278 /*205*/;						// M = _PLLDIV+2, 2..513
//	_PLLPRE=6;						// N1 = _PLLPRE+2, 2..33
//	_PLLPOST=0;						// N2 = _PLLPOST, 2 (0), 4 (1), 8 (3)
  OSCTUNbits.TUN=23;			//(per andare a 8Mhz per USB!) (7.37+(23*.375)%)
// (280*8)/(8*2) = 140

  PLLFBD = 68; // M = PLLFBD + 2 = 80   // @8, v. OSCTUN
//    PLLFBD = 74; // M = PLLFBD + 2 = 76   // @7.37
  CLKDIVbits.PLLPOST = 0; // N2 = 2
  CLKDIVbits.PLLPRE = 0; // N1 = 2
//#warning OCCHIO qua � 7.37 non 8!
  /*	
  Fosc= Fin*M/(N1*N2)
	0.8MHz<(Fin/N1)<8MHz
	100MHz<(Fin*M/N1)<340MHz
	M=2,3,4,...513
	N1=2...33
	N2=2,4,8
	
	PLLFBD    = M -2;
	CLKDIVbits.PLLPRE = N1 -2;
	CLKDIVbits.PLLPOST = 0b00; //N2={2,4,R,8} */

//OSCCONbits.CLKLOCK=1;OSCCONbits.NOSC=1;OSCCONbits.OSWEN=1;
//  while (OSCCONbits.COSC != 0x7)LATB ^= 1;; 
  
  	//Wait for the Primary PLL to lock and then
       // configure the auxiliary PLL to provide 48MHz needed for USB Operation.
    while(OSCCONbits.LOCK != 1)  {
//      mLED_1 ^= 1;
      ClrWdt();			// boh?
    }



  ANSELB=0x0000;      // ana in, ana out...
  ANSELC=0x0000;
  ANSELD=0x0000;
  ANSELE=0x0000;
  ANSELG=0x0000;
//  ODCDbits.ODCD9=ODCDbits.ODCD10=ODCFbits.ODCF4=ODCFbits.ODCF5=1;  // i led che vanno a 5V e i possibili I2C :)
//  CNPUDbits.CNPUD9=CNPUDbits.CNPUD10=1;




    __builtin_write_OSCCONL(OSCCON & 0xbf);
//    RPOR6bits.RP87R = 17;   // OC2 => 
    __builtin_write_OSCCONL(OSCCON | 0x40);
   

    /*
    while(1) {
  TRISB=0;
    LATB^=0xffff;
    __delay_us(100);    //100uS test timing 23/6/2020
    ClrWdt();
    }*/
    
    UserInit();
    
    
	}	//end InitializeSystem



/******************************************************************************
 * Function:        void UserInit(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This routine should take care of all of the demo code
 *                  initialization that is required.
 *
 * Note:            
 *
 *****************************************************************************/
void UserInit(void) {
	unsigned char i;

  ClrWdt();

  TRISB=0b0011110010000000;   // joy ana + micin
  TRISC=0b0000000000000000;
  TRISD=0b0000001000000000;   // joy
  TRISE=0b0000000000000000;
  TRISF=0b0000000000000001;   // joy
  TRISG=0b0000000000001100;   // joy

 
  LATB=0b0000000000000000;
  LATC=0b0000000000000000;
  LATD=0b0000000000000000;      // 
  LATE=0b0000000000000000;
  LATF=0b0000000000000000;
  LATG=0b0000000000000000;
  
	mInitAllLEDs();
  mInitAllSwitches();

  Timer_Init(TMR1BASE);
  PWM_Init();
  ADC_Init();
  SPI_Init(0);
  DMA_Init();

  

   #define DEFAULT_YEARS               0x0021
   #define DEFAULT_MONTH_DAY           0x0830
   #define DEFAULT_WEEKDAY_HOURS       0x0121
   #define DEFAULT_MINUTES_SECONDS     0x3900

   #define INDEX_HOURS                 2
   #define INDEX_MINUTES               1
   #define INDEX_SECONDS               0
   #define INDEX_YEAR                  2
   #define INDEX_MONTH                 1
   #define INDEX_DAY                   0

#ifndef USA_SW_RTC
   OSCCON = 0x3300;    // Enable secondary oscillator TOLTO (x prova) lo 0x0002; uso PWM per dargli input!
   CLKDIV = 0x0000;    // Set PLL prescaler (1:1)
       // Initialize the RTCC
       // Turn on the secondary oscillator
	__asm__ ("MOV #OSCCON,w1");
	__asm__ ("MOV.b #0x02, w0");
	__asm__ ("MOV #0x46, w2");
	__asm__ ("MOV #0x57, w3");
	__asm__ ("MOV.b w2, [w1]");
	__asm__ ("MOV.b w3, [w1]");
	__asm__ ("MOV.b w0, [w1]");
	
	PIC24RTCCSetDate( DEFAULT_YEARS, DEFAULT_MONTH_DAY );
	PIC24RTCCSetTime( DEFAULT_WEEKDAY_HOURS, DEFAULT_MINUTES_SECONDS );
//	__builtin_write_OSCCONL(OSCCON | 0x0002); 		//DAL FORUM... MA CREDO CI SIA GIA'...
	RCFGCAL = 0x8000;
#else
	currentDate.mday=1;
	currentDate.mon=1;
	currentDate.year=11;
#endif


  }	//end UserInit




/******************************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *****************************************************************************/
int main(void) {
  int i;
  static WORD divider;


  
  InitializeSystem();
  

//  mLED_1=1;

        
        
#ifndef USING_SIMULATOR
  __delay_ms(250);
#endif
//  mLED_2=1;
  
  ClrWdt();


#ifndef USING_SIMULATOR
  __delay_ms(250);
#endif



//  IEC0bits.AD1IE = 1;

	
  
//  mLED_1=0;


  while(1) {

  	ClrWdt();



//		mLED_1 ^= 1;		// CHECK Timing!		~4uS 24/7/21
    
    
    
  	if(ADCdone) {
//		mLED_4 ^= 1;		// CHECK Timing!		6400uSec (25 * 256), @140MHz, 27/7/21

    divider++;


		ADCdone=0;
    }
//		m_Led1Bit ^= 1;		// CHECK Timing!		ca.  12mSec, @140MHz, 11/8/17
    


    if(Sec10_1) {
      Sec10++;
      
      
      
      Sec10_1=0;
      }
    
    }	//end while
	}	//end main


void SetMode(BYTE channel,enum TIPO_ONDA type,WORD freq,BYTE chan,BYTE bits,BYTE mode,BYTE effect) {
  
  if(channel<3) {
    canaliAudio[channel].tipo=type;
    canaliAudio[channel].freq=freq;
    canaliAudio[channel].channels=chan;
    canaliAudio[channel].bits=bits;
    canaliAudio[channel].mode=mode;
    canaliAudio[channel].effects=effect;
    }
  }

void SetClock(BYTE d,BYTE m,WORD y,BYTE H,BYTE M,BYTE S) {
  
#ifndef USA_SW_RTC 
  PIC24RTCCSetDate(MAKEWORD(to_bcd(y % 100),0), MAKEWORD(to_bcd(d),to_bcd(m)));
  PIC24RTCCSetTime(MAKEWORD(to_bcd(H),0 /*weekday*/), MAKEWORD(to_bcd(S),to_bcd(M)));
#else
  
#endif

  }



// --------------------------------------------------------------------------
// Joystick
signed char InitJoystick(void) {
  
  TRISB |= 0b0011110010000000;   // joy ana + micin
  TRISD |= 0b0000001000000000;   // joy
  TRISF |= 0b0000000000000001;   // joy
  TRISG |= 0b0000000000001100;   // joy
  
  return 1;
  }

signed char InitMidi(void) {
  
  TRISFbits.TRISF4=1;
  TRISFbits.TRISF5=0;
  
  return 1;
  }

// --------------------------------------------------------------------------
// UART


void __delay_us_hw(WORD t) {
  
  PR4=GetPeripheralClock()/8/t;   //
  IFS1bits.T4IF=0;
  TMR4=0;
  while(!IFS1bits.T4IF) ClrWdt();   // meglio, causa IRQ!
  }

// --------------------------------------------------------------------------
void Timer_Init(unsigned int tim) {
  
  T1CONbits.TCS = 0;                  // clock from peripheral clock
  T1CONbits.TCKPS = 0b11;             // 1:256 prescale
  PR1 = tim /*27000*/;                // rollover every n clocks; 
  T1CONbits.TON = 1;                  // start timer 
  
  IFS0bits.T1IF=0;
  IEC0bits.T1IE=1;
  IPC0bits.T1IP=2;
  
  T2CONbits.TCS = 0;                  // clock from peripheral clock
  T2CONbits.TCKPS = 0b00;             // 1:1 prescale
  T2CONbits.T32=0;
  PR2=GetPeripheralClock()/(Fsynth*NUM_SAMPLES);    // freq-synth-sample time;  312.5uS = 320KHz
  T2CONbits.TON = 1;                  // start timer 
  
  IFS0bits.T2IF=0;
  IEC0bits.T2IE=1;
  IPC1bits.T2IP=4;

  T3CONbits.TCS = 0;                  // clock from peripheral clock
  T3CONbits.TCKPS = 0b00;             // 1:1 prescale
#ifdef SLIDING_WINDOW
  PR3=GetPeripheralClock()/(Fs);      // ADC timebase = 
#else
  PR3=GetPeripheralClock()/Fs;        // ADC timebase = 25uS @40000
#endif
  T3CONbits.TON = 1;                  // start timer 
  
  }

void SPI_Init(BYTE spiMode) {
  
  SPI1STATbits.SPIEN=0;
//	TRISDbits.TRISD=1;				// SDI � input
	TRISDbits.TRISD2=0;				// SDO � output
	TRISDbits.TRISD1=0;			// SCK � output 
  LATDbits.LATD3=1;     //
  TRISDbits.TRISD3=0;		// CS � output

  
  switch(spiMode) {		// CKP=b6=CPOL=0 se idle basso/1 se idle alto; CKE=b8=0 se DOut cambia quando idle->active, 1 se viceversa
/*Mode CPOL CPHA
    0   0   0
    1   0   1
    2   1   0
    3   1   1 */
		// ci sarebbe pure il b9 che � sample a met� o alla fine...
    case 0:
      SPI1CON1= 0b0000000100100000;    // master, mode 0 (AT WINC 1500 vuole questo, https://www.avrfreaks.net/sites/default/files/forum_attachments/Atmel-XXXXX-WINC1500-SPI_Porting_Guide.pdf )
      // parrebbero invertiti, v. SD spi.. ma invece no, boh 2021
      break;
    case 1:
      SPI1CON1= 0b0000000000100000;    //no fancy stuff
      break;
    case 2:
      SPI1CON1= 0b0000000101100000;    //
      break;
    case 3:
      SPI1CON1= 0b0000000001100000;    // CKP = 1, CKE = 0
      break;
    }
  
  SPI1CON1bits.PPRE=0;      // FINIRE
  SPI1CON1bits.SPRE=0;
  SPI1CON2= 0b0000000000000000;    // no special length; no frame 
  SPI1STAT= 0b0000000000000000;    // 
    
  SPI1STATbits.SPIEN=1;

  }

void DMA_Init(void) {
  
  DMA0CON=0;
	DMA0CONbits.AMODE = 2; // Configure DMA for Peripheral indirect mode
  DMA0CONbits.MODE = 0 /*2*/; // Configure DMA for Continuous Ping-Pong mode
  DMA0PAD = (int)&SPI1BUF;
  DMA0CNT = 1024; //
  DMA0REQ = 13;     // Select Timer2 as DMA Request source 
  DMA0CONbits.DIR=0;
  DMA0STAL = (WORD)&sineTable;
  DMA0STAH = (WORD)0;
  DMA0STBL = (WORD)&sineTable;
  DMA0STBH = (WORD)0;
  
  IFS0bits.DMA0IF = 0; //Clear the DMA interrupt flag bit
  IEC0bits.DMA0IE = 1; //Set the DMA interrupt enable bit
  IPC1bits.DMA0IP = 5;
  
  DMA0CONbits.CHEN = 1; // Enable DMA

  }  
  
void PMP_Init(void) {

  PMCON= 0b0000001100000000;     // tutti segnali attivi low; no CS1 & 2 ???????; WR & RD;
  PMMODE=0b0010000011111111;             // max wait state; 8bit; irq sempre; slave mode
  PMAEN =0b1100000011111111;             // BA0..7, CS1-CS2 
  
  PMCONbits.PMPEN=1;
  
  IEC2bits.PMPIE=1;
  IPC11bits.PMPIP=3;
	}

void PWM_Init(void) {

  
  OC2CON1 = 0x0000;   // time-base=70MHz,
  OC2CON2 = 0x0000;
  OC2RS  = 256;       // 274KHz~ per uscita analogica
  OC2R   = 128;
  OC2CON1 = 0x1c00;
  OC2CON2 = 0x001f;
  
  OC2CON1 |= 0x0006;   // Mode 6, Edge-aligned PWM Mode
  }

// --------------------------------------------------------------------------
	

WORD ReadADC1(uint8_t n) {
    

  return ADC1BUF0;       // Read the ADC conversion result
  }




//Functions:
//ADC_Init() is used to configure A/D to convert 16 samples of 1 input
//channel per interrupt. The A/D is set up for a sampling rate of 1MSPS
//Timer3 is used to provide sampling time delay.
//The input pin being acquired and converted is AN7.
void ADC_Init(void) {


  AD1CON1 = 0b0001011101000000;   // src=timer3, 12bits, dma in order, signed fractional
  AD1CON1bits.AD12B=0;     // 10 bits
//  AD1CON1bits.FORM=0b01;              // signed integer => fc00-03ff (integer => 0000-07ff)
//  AD1CON1bits.FORM=0b11;              // signed fractional => 8000-7ff0
  AD1CON1bits.FORM=0b01;              // signed integer eqv. fractional Q6.10
  
  AD1CON1bits.SSRC=0b010;             // timer 3
  AD1CON1bits.ASAM=1;
  
  AD1CON2 = 0b0000000000000000;       // no scan. no alternate, convert CH0
  AD1CON2bits.SMPI=15;                // irq every 16 samples
  AD1CON3 = 0b0001000000000000;       // clock system, 16 sample,
  AD1CON3bits.ADCS=8;                 // clock = 50MHz/8
  AD1CON4 = 0b0000000000000000;       // DMA
  AD1CHS123 = 0b0000000000000000;     // ch. 123 non usati
  AD1CHS0 = 0b0000000000000000;       // ch. 1 AN1 RB1
  AD1CHS0bits.CH0SA=1;
  AD1CHS0bits.CH0SB=1;
  AD1CHS0bits.CH0NA=0;
  AD1CHS0bits.CH0NB=0;
    
  ANSELB=0b0011110010000000;        // joy ana + micin
        
  AD1CON1bits.ADON=1;
 
  IFS0bits.AD1IF = 0;
  IPC3bits.AD1IP = 5;
  IEC0bits.AD1IE = 0;
  
    
	}


void ConvertADC1(void) {
  
  AD1CON1bits.SAMP=1;   // PROVARE se serve!
  }

        
#ifdef USA_232
BYTE OpenUART(uint32_t baudRate) {
  
  U1MODE=0b0000000010110000;    // TX,RX; 8bit async; BRGH=1
  U1STA= 0b0000000000000000;    // 
  uint32_t baudRateDivider = ((GetPeripheralClock()/(2*baudRate))-1);    //v. anche BCLKSEL in U1MODEH
  U1BRG=baudRateDivider;
  U1MODEbits.UARTEN=1;
  
//  IEC0bits.U1RXIE=1;
  return 1;
  }

char BusyUART(void) {
  
  return !U1STAbits.TRMT;
  }

char DataRdyUART(void) {
  
  return(!U1STAbits.URXDA);
  }

unsigned char ReadUART(void) {
  
  return U1RXREG;
  }

void WriteUART(unsigned char data) {
  
  while(BusyUART())
    ClrWdt(); /* wait if the buffer is full */
  U1TXREG = data;
  }
#endif


#ifndef USA_SW_RTC 
/****************************************************************************
  Function:
    DWORD   PIC24RTCCGetDate( void )

  Description:
    This routine reads the date from the RTCC module.

  Precondition:
    The RTCC module has been initialized.


  Parameters:
    None

  Returns:
    DWORD in the format <xx><YY><MM><DD>

  Remarks:
    To catch roll-over, we do two reads.  If the readings match, we return
    that value.  If the two do not match, we read again until we get two
    matching values.

    For the PIC32MX, we use library routines, which return the date in the
    PIC32MX format.
  ***************************************************************************/
DWORD PIC24RTCCGetDate(void) {
  DWORD_VAL   date1;
  DWORD_VAL   date2;

  do {
    while (RCFGCALbits.RTCSYNC);

    RCFGCALbits.RTCPTR0 = 1;
    RCFGCALbits.RTCPTR1 = 1;
    date1.w[1] = RTCVAL;
    date1.w[0] = RTCVAL;

    RCFGCALbits.RTCPTR0 = 1;
    RCFGCALbits.RTCPTR1 = 1;
    date2.w[1] = RTCVAL;
    date2.w[0] = RTCVAL;

    } while (date1.Val != date2.Val);

  return date1.Val;
	}


/****************************************************************************
  Function:
    DWORD   PIC24RTCCGetTime( void )

  Description:
    This routine reads the time from the RTCC module.

  Precondition:
    The RTCC module has been initialized.

  Parameters:
    None

  Returns:
    DWORD in the format <xx><HH><MM><SS>

  Remarks:
    To catch roll-over, we do two reads.  If the readings match, we return
    that value.  If the two do not match, we read again until we get two
    matching values.

    For the PIC32MX, we use library routines, which return the time in the
    PIC32MX format.
  ***************************************************************************/

DWORD PIC24RTCCGetTime(void) {
  DWORD_VAL   time1;
  DWORD_VAL   time2;

  do {
    while (RCFGCALbits.RTCSYNC);

    RCFGCALbits.RTCPTR0 = 1;
    RCFGCALbits.RTCPTR1 = 0;
    time1.w[1] = RTCVAL;
    time1.w[0] = RTCVAL;

    RCFGCALbits.RTCPTR0 = 1;
    RCFGCALbits.RTCPTR1 = 0;
    time2.w[1] = RTCVAL;
    time2.w[0] = RTCVAL;

    } while (time1.Val != time2.Val);

    return time1.Val;
	}


/****************************************************************************
  Function:
    void PIC24RTCCSetDate( WORD xx_year, WORD month_day )

  Description:
    This routine sets the RTCC date to the specified value.


  Precondition:
    The RTCC module has been initialized.

  Parameters:
    WORD xx_year    - BCD year in the lower byte
    WORD month_day  - BCD month in the upper byte, BCD day in the lower byte

  Returns:
    None

  Remarks:
    For the PIC32MX, we use library routines.
  ***************************************************************************/
void PIC24RTCCSetDate(WORD xx_year, WORD month_day) {
  
	UnlockRTCC();
  RCFGCALbits.RTCPTR0 = 1;
  RCFGCALbits.RTCPTR1 = 1;
  RTCVAL = xx_year;
  RTCVAL = month_day;
	}


/****************************************************************************
  Function:
    void PIC24RTCCSetTime( WORD weekDay_hours, WORD minutes_seconds )

  Description:
    This routine sets the RTCC time to the specified value.

  Precondition:
    The RTCC module has been initialized.

  Parameters:
    WORD weekDay_hours      - BCD weekday in the upper byte, BCD hours in the
                                lower byte
    WORD minutes_seconds    - BCD minutes in the upper byte, BCD seconds in
                                the lower byte

  Returns:
    None

  Remarks:
    For the PIC32MX, we use library routines.
  ***************************************************************************/
void PIC24RTCCSetTime(WORD weekDay_hours, WORD minutes_seconds) {

  UnlockRTCC();
  RCFGCALbits.RTCPTR0 = 1;
  RCFGCALbits.RTCPTR1 = 0;
  RTCVAL = weekDay_hours;
  RTCVAL = minutes_seconds;
	}

/****************************************************************************
  Function:
    void UnlockRTCC( void )

  Description:
    This function unlocks the RTCC so we can write a value to it.

  Precondition:
    None

  Parameters:
    None

  Return Values:
    None

  Remarks:
    For the PIC32MX, we use library routines.
  ***************************************************************************/

#define RTCC_INTERRUPT_REGISTER IEC3
#define RTCC_INTERRUPT_VALUE    0x2000

void UnlockRTCC( void ) {
  BOOL interruptsWereOn;

  interruptsWereOn = FALSE;
  if((RTCC_INTERRUPT_REGISTER & RTCC_INTERRUPT_VALUE) == RTCC_INTERRUPT_VALUE) {
    interruptsWereOn = TRUE;
    RTCC_INTERRUPT_REGISTER &= ~RTCC_INTERRUPT_VALUE;
    }

  // Unlock the RTCC module
  __asm__ ("mov #NVMKEY,W0");
  __asm__ ("mov #0x55,W1");
  __asm__ ("mov #0xAA,W2");
  __asm__ ("mov W1,[W0]");
  __asm__ ("nop");
  __asm__ ("mov W2,[W0]");
  __asm__ ("bset RCFGCAL,#13");
  __asm__ ("nop");
  __asm__ ("nop");

  if(interruptsWereOn) {
    RTCC_INTERRUPT_REGISTER |= RTCC_INTERRUPT_VALUE;
    }
	}
#endif


BYTE to_bcd(BYTE n) {
	
	return (n % 10) | ((n / 10) << 4);
	}

BYTE from_bcd(BYTE n) {
	
	return (n & 15) + (10*(n >> 4));
	}


/** EOF main.c *************************************************/


