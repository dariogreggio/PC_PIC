/********************************************************************
 FileName:     interrupt.c

 ********************************************************************
 File Description:

 Change History:
  2021  pc_pic_audio
********************************************************************/

#include "../Compiler.h"
#include "../GenericTypeDefs.h"
#include "pc_pic_audio.h"
#include "io_cfg.h"
#include <sys/attribs.h>
#include <sys/kmem.h>

volatile BYTE Sec10_1,ADCdone;
extern WORD samplesOut[22050],samplesIn[22050];
extern const int16_t TRIANGLE_WAVE_TABLE[NUM_SAMPLES];
extern const int16_t SINE_WAVE_TABLE[NUM_SAMPLES];
extern const int16_t SAWTOOTH_WAVE_TABLE[NUM_SAMPLES];
extern const int16_t SQUARE_WAVE_TABLE[NUM_SAMPLES];

extern struct AUDIO_WAVE canaliAudio[3];
extern BYTE outputMode;		// 
extern BYTE waveMode;			// 

extern BYTE IRQCode;

#ifdef USA_SW_RTC 
volatile PIC32_RTCC_DATE currentDate;
volatile PIC32_RTCC_TIME currentTime;
#else
PIC32_RTCC_DATE currentDate;
PIC32_RTCC_TIME currentTime;
#endif

#define PMPWaitBusy()   while(!PMSTATbits.OBE);     // VERIFICARE


void __ISR(_TIMER_1_VECTOR,ipl2AUTO) TMR1_ISR(void) {
	
//		mLED_3 ^= 1;		// CHECK Timing!		100mS 26/10/21

  Sec10_1=1;
  
#ifdef USA_SW_RTC 
  static BYTE second_10;
  
  second_10++;
  if(second_10>=10) {
    second_10=0;
    currentTime.sec++;
    if(currentTime.sec >= 60) {
      currentTime.sec=0;
      currentTime.min++;
      if(currentTime.min >= 60) {
        currentTime.min=0;
        currentTime.hour++;
        if(currentTime.hour >= 24) {
          currentTime.hour=0;
          currentDate.mday++;
          if(currentDate.mday >= 30) {		// finire...
            currentDate.mday=0;
            currentDate.mon++;
            if(currentDate.mon >= 12) {		// 
              currentDate.mon=0;
              currentDate.year++;
              }
            }
          }
        }
      } 
    } 

#endif

 	//Clear the Interrupt flag bit or else the CPU will keep vectoring back to the ISR
  IFS0CLR = _IFS0_T1IF_MASK;
	}

void __ISR(_TIMER_2_VECTOR,ipl5AUTO) TMR2_ISR(void) {
  WORD value[2]={MAX_DAC_VALUE/2,MAX_DAC_VALUE/2};
  static BYTE cnt[3];
  BYTE doWrite=0;
	int32_t temp;
	static WORD lfsr = 0xACE1u,oldlfsr=0;
	BYTE b;

//		mLED_4 ^= 1;		// CHECK Timing!		
  // SERVE USARE bits??
  
  if(canaliAudio[0].tipo != NESSUNA) {
    canaliAudio[0].counter += canaliAudio[0].freq;
    if(canaliAudio[0].counter >= Fsynth) {
      canaliAudio[0].counter -= Fsynth;
      switch(canaliAudio[0].tipo) {
        case QUADRA:
          temp = SQUARE_WAVE_TABLE[cnt[0]];
          break;
        case TRIANGOLARE:
          temp = TRIANGLE_WAVE_TABLE[cnt[0]];
          break;
        case SAWTOOTH:
          temp = SAWTOOTH_WAVE_TABLE[cnt[0]];
          break;
        case SINUSOIDALE:
          temp = SINE_WAVE_TABLE[cnt[0]];
          break;
        case IMPULSI:
          temp = cnt[0] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
          break;
        case RUMORE_BIANCO:
          temp = rand() & MAX_DAC_VALUE;
	    /*b  = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
          lfsr =  (lfsr >> 1) | (b << 15);
          OC1R = lfsr >> 10;		// basato su 64
          */
          break;
        case RUMORE_ROSA:
        { static WORD r;
          temp = r;      // bah...
          r = rand() & MAX_DAC_VALUE;
          temp += r;
        }
/*	    b  = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5) ) & 1;
  	  lfsr =  (lfsr >> 1) | (b << 15);
			lfsr+=oldlfsr;
			lfsr/=2;
			oldlfsr=lfsr;
			OC1R = lfsr >> 10;		// basato su 64
  filtrare...
      */
          break;
        }
			temp = (temp*canaliAudio[0].volume)/100;
      value[0] += temp;
      if(value[0]>=0x8000)   // negativo :)
        value[0]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[0]=MAX_DAC_VALUE;
      cnt[0]++;
      cnt[0] &= NUM_SAMPLES-1;
      doWrite=1;
      }
    if(canaliAudio[0].mode == 1) {      // finire
      value[1]+=temp;
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      }
    if(canaliAudio[0].effects == 1) {      // finire
      value[1] += temp;
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      }
    }
  
  if(canaliAudio[1].tipo != NESSUNA) {
    canaliAudio[1].counter += canaliAudio[1].freq;
    if(canaliAudio[1].counter >= Fsynth) {
      canaliAudio[1].counter -= Fsynth;
      switch(canaliAudio[1].tipo) {
        case QUADRA:
          temp = SQUARE_WAVE_TABLE[cnt[1]];
          break;
        case TRIANGOLARE:
          temp = TRIANGLE_WAVE_TABLE[cnt[1]];
          break;
        case SAWTOOTH:
          temp = SAWTOOTH_WAVE_TABLE[cnt[1]];
          break;
        case SINUSOIDALE:
          temp = SINE_WAVE_TABLE[cnt[1]];
          break;
        case IMPULSI:
          temp = cnt[1] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
          break;
        case RUMORE_BIANCO:
          temp = rand() & MAX_DAC_VALUE;
          break;
        case RUMORE_ROSA:
        { static WORD r;
          temp = r;      // bah...
          r = rand() & MAX_DAC_VALUE;
          temp += r;
        }
          break;
        }
			temp = (temp*canaliAudio[1].volume)/100;
      value[0] += temp;
      if(value[0]>=0x8000)   // negativo :)
        value[0]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[0]=MAX_DAC_VALUE;
      cnt[1]++;
      cnt[1] &= NUM_SAMPLES-1;
      doWrite=1;
      }
    if(canaliAudio[1].mode == 1) {      // finire
      value[1]+=temp;
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      }
    if(canaliAudio[1].effects == 1) {      // finire
      value[1] += -temp;
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      }
    }
  if(canaliAudio[2].tipo != NESSUNA) {
    canaliAudio[2].counter += canaliAudio[2].freq;
    if(canaliAudio[2].counter >= Fsynth) {
      canaliAudio[2].counter -= Fsynth;
      switch(canaliAudio[2].tipo) {
        case QUADRA:
          temp = SQUARE_WAVE_TABLE[cnt[2]];
          break;
        case TRIANGOLARE:
          temp = TRIANGLE_WAVE_TABLE[cnt[2]];
          break;
        case SAWTOOTH:
          temp = SAWTOOTH_WAVE_TABLE[cnt[2]];
          break;
        case SINUSOIDALE:
          temp = SINE_WAVE_TABLE[cnt[2]];
          break;
        case IMPULSI:
          temp = cnt[2] >= (NUM_SAMPLES-1) ? MAX_DAC_VALUE : 0;
          break;
        case RUMORE_BIANCO:
          temp = rand() & MAX_DAC_VALUE;
          break;
        case RUMORE_ROSA:
        { static WORD r;
          temp = r;      // bah...
          r = rand() & MAX_DAC_VALUE;
          temp += r;
        }
          break;
        }
			temp = (temp*canaliAudio[2].volume)/100;
      value[0] += temp;
      if(value[0]>=0x8000)   // negativo :)
        value[0]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[0]=MAX_DAC_VALUE;
      cnt[2]++;
      cnt[2] &= NUM_SAMPLES-1;
      doWrite=1;
      }
    if(canaliAudio[2].mode == 1) {      // finire
      value[1] += temp;
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      }
    if(canaliAudio[2].effects == 1) {      // finire
      value[1] += -temp;
      if(value[1]>=0x8000)   // negativo :)
        value[1]=0;
      else if(value[0]>MAX_DAC_VALUE)
        value[1]=MAX_DAC_VALUE;
      }
    }
  

  if(doWrite) {   // se SPDIF, si potrebbe/dovrebbe inviare word vuote e con V=0...
    switch(outputMode) {
      case ANALOGIC:
//      m_LDACBit=1;    // 
        m_SPIASCSBit=0;
        SPI1STATbits.SPIROV = 0;  // Reset overflow bit
        value[0] &= 0b0000111111111111;     //MAX_DAC_VALUE
        value[0] |= 0b0011000000000000;     // channel A, unbuffered, gain=1, no shutdown
#if 1
        SPI1BUF = value[0];     // Write to SPI buffer
        while(SPI1STATbits.SPIBUSY)
          ClrWdt();
        SPI1BUF;
        // FARE cos�: inviare 1 word qua, attivare IRQ TX SPI, e poi da l� inviare 2� word e disattivare IRQ
        // ...forse c'� una FIFO e si possono scrivere subito entrambe?? no, va alzato CS ogni volta!
        m_SPIASCSBit=1;
        Nop(); Nop(); Nop(); Nop(); Nop(); Nop();  //~70nS
        m_SPIASCSBit=0;
        SPI1STATbits.SPIROV = 0;  // Reset overflow bit
        value[1] &= 0b0000111111111111;     //
        value[1] |= 0b1011000000000000;     // channel B, unbuffered, gain=1, no shutdown
        SPI1BUF = value[1];     // Write to SPI buffer
        while(SPI1STATbits.SPIBUSY)
          ClrWdt();
        SPI1BUF;
        m_SPIASCSBit=1;
#else   // mah non va... gli irq arrivano dopo 1 byte o boh...
        IEC3SET = _IEC3_SPI1TXIE_MASK;
//        IEC3bits.SPI1TXIE=1;
        SPI1BUF = value[0];     // Write to SPI buffer
#endif
//      m_LDACBit=0;    // non lo usiamo, v.doc
        break;
        
      case SPDIF:      // https://it.wikipedia.org/wiki/S/PDIF#Il_channel_status_bit_nel_protocollo_S/PDIF
      {
      DWORD tempL;
      BYTE preamble;
      static BYTE frame=0;
        SPI2STATbits.SPIROV = 0;  // Reset overflow bit
        value[0] &= 0b0000111111111111;     //MAX_DAC_VALUE
        if(!frame)
          preamble=0b11100010;
        else
          preamble=0b11101000;
        /// mmm mi sa che sta roba funzia solo in Manchester encoding... il che complica le cose qua..
        // vedere I2S o boh!
        tempL=((DWORD)value[0]) << (16-4);    // ma LSB first... FARE
        tempL |= 0b00000000000000000000000000000000;    // preamble
        tempL |= 0b1000;      // VUCP
        SPI2BUF = tempL;     // Write to SPI buffer
        while(SPI2STATbits.SPIBUSY == 1 /*(SPI2STATLbits.SPITBF == 1)*/ /* || (SPI2STATLbits.SPIRBF == 0) */ )
          ClrWdt();
        SPI2BUF;
        // FARE cos�: inviare 1 word qua, attivare IRQ TX SPI, e poi da l� inviare 2� word e disattivare IRQ
        // ...forse c'� una FIFO e si possono scrivere subito entrambe??
    //  IEC3SET = _IEC3_SPI1TXIE_MASK;
        preamble=0b11100100;
        tempL=((DWORD)value[1]) << (16-4);    // ma LSB first... FARE
        tempL |= 0b00000000000000000000000000000000;    // preamble
        tempL |= 0b1000;      // VUCP
        SPI2BUF = tempL;     // Write to SPI buffer
        while(SPI2STATbits.SPIBUSY == 1 /*(SPI2STATLbits.SPITBF == 1)*/ /* || (SPI2STATLbits.SPIRBF == 0) */ )
          ClrWdt();
        SPI2BUF;
        
        frame++;
        frame &= 0xc0;
      }
        break;
      }
    doWrite=0;
    }
   // FINIRE!!
  
  

  IFS0CLR = _IFS0_T2IF_MASK;
	}

void __ISR(_TIMER_4_VECTOR,ipl2AUTO) TMR4_ISR(void) {
  
  IFS0CLR = _IFS0_T4IF_MASK;
  }

void __ISR(_SPI1_TX_VECTOR,ipl5AUTO) SPI_ISR(void) {
  // il porcodio di simulatore non simula questo irq...
  static BYTE phase;
  
  switch(phase) {
    case 0:
      m_SPIASCSBit=1;
      Nop(); Nop(); Nop(); Nop(); Nop(); Nop();  //~70nS
      SPI1BUF;
      m_SPIASCSBit=0;
      // fare globali se si usa...
//      value[1] &= 0b0000111111111111;     //
//      value[1] |= 0b1011000000000000;     // channel B, unbuffered, gain=1, no shutdown
//      SPI1BUF = value[1];     // Write to SPI buffer
      phase=1;
      break;
    default:
      SPI1BUF;
      IEC3CLR = _IEC3_SPI1TXIE_MASK;
      m_SPIASCSBit=1;
//      value[0]=value[1]=MAX_DAC_VALUE/2;
      phase=0;
      break;
    }
  IFS3CLR = _IFS3_SPI1TXIF_MASK;
  }

void __ISR(_ADC_VECTOR,ipl2AUTO) ADC_ISR(void) {
//    https://www.microchip.com/forums/m1118492.aspx#1119761
	// usare NAKED per irq...

	static WORD counter;

//  ADTRIG0Lbits.TRGSRC0=0;
    
//		mLED_2 ^= 1;		// CHECK Timing!		200uSec (12.5uS * 16), @140MHz, 25/7/21
  
  IFS1CLR = _IFS1_ADCIF_MASK;
  IFS6bits.ADC0EIF = 0;
	}


void __ISR(_DMA0_VECTOR,ipl5AUTO) DMA_ISR(void) {

        
//  DCH0SSA = KVA_TO_PA(&testSine);  // transfer source physical address
  DCH0INTCLR = _DCH0INT_CHSDIF_MASK /*DCH0INTbits.CHDDIF=0*/;
  
  IFS4CLR = _IFS4_DMA0IF_MASK /*IFS4bits.DMA0IF=0*/;  // Clear the interrupt flag!
  }

void __ISR(_PMP_VECTOR,ipl3AUTO) PMP_ISR(void) {
  BYTE addr,reg;
  static WORD parms[16];
  static BYTE parmN=0,oldReg=0;
  
  // verificare se � una buona idea scrivere dentro IRQ; inoltre credo si generi IRQ anche su WRite, che per� non importa tanto va perso
//  addr=PMADDR & 63;
  addr=(PORTG >> 4) & 0b00111100;
  addr |= (PORTB >> 14);    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!

  reg=addr;
  if(reg != oldReg) {
    oldReg=reg;
    parmN=0;
    }
  if(1 /*WR*/) {
  switch(reg) {
    case 0:
      parms[parmN++]=PMRDIN;
        oldReg=parmN=0;
      break;
    case BIOS_AUDIO_SETWAVE:
      parms[parmN++]=PMRDIN;
      if(parmN>=4) {
        SetMode(parms[0],parms[1],MAKEWORD(parms[2],parms[3]),parms[4],parms[5],parms[6],parms[7],parms[8]);
        oldReg=parmN=0;
        }
      break;
    case BIOS_AUDIO_SETOUTPUT:
      parms[parmN++]=PMRDIN;
      if(parmN>=1) {
        SetOutput(parms[0]);
        oldReg=parmN=0;
        }
      break;
    case BIOS_AUDIO_SETRECORD:
      break;
    case BIOS_AUDIO_PUTSAMPLES:
      samplesOut[0];
			break;
    case BIOS_AUDIO_WRITEMIDI:
      while(BusyUART())
        ClrWdt();
      WriteUART(parms[0]);
      break;
    case BIOS_AUDIO_SETCLOCK:
      parms[parmN++]=PMRDIN;
      if(parmN>=6) {
        SetClock(parms[0],parms[1],parms[2],parms[3],parms[4],parms[5]);
        oldReg=parmN=0;
        }
      break;
   }
  }
  else {        // RD
  switch(reg) {
    case BIOS_GETID:
      PMDOUT='A';
      PMPWaitBusy();
      break;
    case BIOS_GETCONFIG:
      PMDOUT=VERNUML;
      PMPWaitBusy();
      break;
    case 2:
      PMDOUT=VERNUMH;
      PMPWaitBusy();
      break;
    case BIOS_IRQ_REQUEST:
      PMDOUT=IRQCode;
      PMPWaitBusy();
      break;
    case BIOS_AUDIO_GETSAMPLES:
      samplesIn[0];
      PMPWaitBusy();
      // FINIRE!
      break;
    case BIOS_AUDIO_READMIDI:
      while(!DataRdyUART())
        ClrWdt();
      PMDOUT=ReadUART();
      PMPWaitBusy();
      break;
    case BIOS_AUDIO_READJOYSTICK:
      switch(0) {
        case 0:
          PMDOUT=PORTBbits.RB6 ? 1 : 0 |
                 PORTBbits.RB9 ? 2 : 0 |
                 PORTBbits.RB12 ? 4 : 0 |
                 PORTFbits.RF3 ? 8 : 0;
          break;
        case 1:
          ConvertADC1(47);    // JA1=pin18
          PMDOUT=ADCDATA7;
          break;
        case 2:
          ConvertADC1(48);    // JA2=pin21
          PMDOUT=ADCDATA7;
          break;
        case 3:
          ConvertADC1(5);     // JA3=pin23
          PMDOUT=ADCDATA7;
          break;
        case 4:
          ConvertADC1(6);     // JA4=pin24
          PMDOUT=ADCDATA7;
          break;
        }
      PMPWaitBusy();
      // FINIRE!
      break;
    case BIOS_AUDIO_GETCLOCK:
    {
#ifndef USA_SW_RTC 
      currentTime.l=PIC32RTCCGetTime();
      currentDate.l=PIC32RTCCGetDate();
      PMDOUT=from_bcd(currentTime.sec);
#else
      PMDOUT=currentTime.sec;
#endif
      PMPWaitBusy();
      // FINIRE!
      }
      break;
    case BIOS_AUDIO_READTEMPERATURE:
      PMDOUT=ReadTemperature() >> 4;
      PMPWaitBusy();
      break;
    }
  }
  
  IFS4CLR = _IFS4_PMPIF_MASK;
  }

void __ISR(_UART1_RX_VECTOR,ipl2AUTO) UART1_ISR(void) {
  
//  LATDbits.LATD4 ^= 1;    // LED to indicate the ISR.
  char curChar = U1RXREG;
  notifyToCPU(EVENT_MIDI,&curChar,1);
  
  IFS3bits.U1RXIF = 0;  // Clear the interrupt flag!
  }


// ---------------------------------------------------------------------------------------
// declared static in case exception condition would prevent
// auto variable being created
static enum {
	EXCEP_IRQ = 0,			// interrupt
	EXCEP_AdEL = 4,			// address error exception (load or ifetch)
	EXCEP_AdES,				// address error exception (store)
	EXCEP_IBE,				// bus error (ifetch)
	EXCEP_DBE,				// bus error (load/store)
	EXCEP_Sys,				// syscall
	EXCEP_Bp,				// breakpoint
	EXCEP_RI,				// reserved instruction
	EXCEP_CpU,				// coprocessor unusable
	EXCEP_Overflow,			// arithmetic overflow
	EXCEP_Trap,				// trap (possible divide by zero)
	EXCEP_IS1 = 16,			// implementation specfic 1
	EXCEP_CEU,				// CorExtend Unuseable
	EXCEP_C2E				// coprocessor 2
  } _excep_code;

static unsigned int _epc_code;
static unsigned int _excep_addr;

void __attribute__((weak)) _general_exception_handler(uint32_t __attribute__((unused)) code, uint32_t __attribute__((unused)) address) {
  }

void __attribute__((nomips16,used)) _general_exception_handler_entry(void) {
  
	asm volatile("mfc0 %0,$13" : "=r" (_epc_code));
	asm volatile("mfc0 %0,$14" : "=r" (_excep_addr));

	_excep_code = (_epc_code & 0x0000007C) >> 2;

  _general_exception_handler(_excep_code, _excep_addr);

	while (1)	{
		// Examine _excep_code to identify the type of exception
		// Examine _excep_addr to find the address that caused the exception
    }
  }


