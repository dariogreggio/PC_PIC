/* 
 * File:   PC_PIC_CPU.h
 * Author: dario/katia
 *
 * Created on 3 settembre 2021, 11.17
 */

#ifndef PC_PIC_BIOS_H
#define	PC_PIC_BIOS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
#include <stdint.h>
#include "../genericTypedefs.h"


enum __attribute((packed)) {
    BIOS_GETID=1,
    BIOS_GETVERSION=2,
    BIOS_GETCONFIG=3,
    BIOS_GETSTATUS=4,
    BIOS_IRQ_REQUEST=8,
    BIOS_RESET=62 /*254*/,
    BIOS_INVALID=63 /*255*/
    };

#define MAKE_PMP_ADDRESS(g,b) ((g >> 4) & 0b00111100) | ((b >> 14) & 0b00000011);    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!

#ifdef	__cplusplus
}
#endif

#endif	/* PC_PIC_CPU_H */


/* protocollo PMP / bus periferiche
abbiamo 256 indirizzi (tranne il video solo 64) e 2 bit CS
(la RAM � a parte, EBI)

0..3 per ID e configurazione generica, in particolare la lettura a 0 restituisce versione ecc

A 4 (in lettura), quando le slave creano un interrupt, si trova "CHI" lo ha generato ossia il sottogruppo

Da 8 in poi ci sono le cose specifiche:
Per la VGA, a 8 metterei risoluzione x,y; VGA/composito
da 16 le primitive video, punto linea rettangolo cerchio
da 32 un bit-blit raw

Per l'audio, a 8 metterei qualit� audio, Hz bit canali
da 16 generazione forme d'onda, rettangolo sinusoide triangolare rumore
da 24 audio raw
da 32 il joystick
da 40 la Midi

Per il south bridge, a 8 metterei la tastiera
da 9 la RS232
a 16 la parallela
a 24 le PS/2



*/

