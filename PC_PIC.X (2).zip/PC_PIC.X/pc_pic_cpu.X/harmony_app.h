/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_Initialize" and "APP_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_STATES" definition).  Both
    are defined here for convenience.

	GD improved 19.12.18; 13/7/21
*******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

 *******************************************************************************/
//DOM-IGNORE-END

#ifndef _APP_H
#define _APP_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application States

  Summary:
    Application states enumeration

  Description:
    This enumeration defines the valid application states.  These states
    determine the behavior of the application at various times.
*/

typedef enum {
  
    // Application's state machine's initial state.
    APP_STATE_INIT=0,
            
    APP_STATE_IDLE,

#if defined(USA_USB_HOST)
    // Application opens host layer
    APP_STATE_BUS_ENABLE,

    // Wait for Bus enable complete
    APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE, // 3

    // Application waits for Video Device Attach
    APP_STATE_WAIT_FOR_DEVICE_ATTACH,
    APP_STATE_DEVICE_CONNECTED,

    // Set Interface
    APP_STATE_ZERO_BANDWIDTH_INTERFACE_SET,
            
    // Video Device is Attached
    APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ZERO,
            
    // Waiting for the initial setting of video data
    APP_STATE_WAIT_FOR_SET_PROBE_VIDEO,           // 7
            
    APP_STATE_WAIT_FOR_GET_PROBE_VIDEO,
            
    // Application waits for Set Video parm
    APP_STATE_WAIT_FOR_SET_COMMIT_VIDEO,           // 9
            
    // Start Scheduling Audio Stream Enable
    APP_STATE_ENABLE_VIDEO_STREAM,      //
            
    // Application waits for Zero Bandwidth Set to complete
    APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ONE,  // 11
            
    // Setting of correct alternate setting for the Audio Streaming Interface is completed
    APP_STATE_START_STREAM_DATA,

    // Wait for Write Complete
    APP_STATE_WAIT_FOR_WRITE_COMPLETE,
    APP_STATE_WAIT_FOR_READ_COMPLETE,       // 14
            
#if defined(USA_USB_HOST_MSD)
    APP_STATE_MOUNT_DISK,
    APP_STATE_UNMOUNT_DISK,
    APP_STATE_OPEN_FILE,
    APP_STATE_WRITE_TO_FILE,
    APP_STATE_CLOSE_FILE,
#endif

#endif

#if defined(USA_USB_SLAVE_CDC)
    // Application waits for device configuration
    APP_STATE_WAIT_FOR_CONFIGURATION,
    // Wait for a character receive
    APP_STATE_SCHEDULE_READ,
    // A character is received from host
    APP_STATE_WAIT_FOR_READ_COMPLETE,
            // Wait for the TX to get completed
    APP_STATE_SCHEDULE_WRITE,
    // Wait for the write to complete
    APP_STATE_WAIT_FOR_WRITE_COMPLETE,
#endif
            
    // Error
    APP_STATE_ERROR
            
  } APP_STATES;

#if defined(USA_USB_HOST)
#if defined(USA_USB_HOST_UVC)
typedef enum {
    APP_USB_AUDIO_CHANNEL_MASTER = 0,
    APP_USB_AUDIO_CHANNEL_LEFT,
    APP_USB_AUDIO_CHANNEL_RIGHT
  } APP_USB_AUDIO_CHANNEL;
  

typedef struct {
    USB_UVC_FORMAT_CODE format; 
    USB_HOST_UVC_STREAM_DIRECTION streamDirection; 
    uint16_t wWidth; 
    uint16_t wHeight; 
    uint8_t bitPerPixel; 
    uint8_t subFrameSize; 
  } APP_USB_HOST_UVC_STREAM_FORMAT;

typedef enum {
    APP_USB_AUDIO_MASTER_MUTE_SET,
    APP_USB_AUDIO_MASTER_UNMUTE_SET,
    APP_USB_AUDIO_MASTER_VOLUME_SET,
    APP_USB_AUDIO_LEFT_VOLUME_SET,
    APP_USB_AUDIO_RIGHT_VOLUME_SET,  
  } APP_USB_UVC_CONTROL_TRANSFER_ACTION;
#endif
#endif
  
// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct {
    // The application's current state
    APP_STATES state;

    // Saved Application State
    APP_STATES savedState;
    
#if defined(USA_USB_HOST)
#if defined(USA_USB_HOST_MSD)
//    v. breakthrough
//    SYS_FS_HANDLE fileHandle;
#endif
#if defined(USA_USB_HOST_UVC)
    // Video Device attached flag
    volatile bool isVideoDeviceAttached;

    // USB Host layer Handle
    USB_HOST_DEVICE_OBJ_HANDLE hostHandle;

    // Object Handle of this Video Device
    volatile USB_HOST_UVC_OBJ videoDeviceObj;
    
    // Video/Audio IN Stream Object
    USB_HOST_UVC_STREAMING_INTERFACE_OBJ inStreamObj;
    USB_HOST_UVC_STREAMING_INTERFACE_OBJ inStreamObj2;
    
    // Handle to the IN Video/Audio Stream
    USB_HOST_UVC_STREAM_HANDLE inStreamHandle;
    USB_HOST_UVC_STREAM_HANDLE inStreamHandle2;
    
    // Video/Audio IN Streaming Interface Objects
    USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ videoStreamInterfaceSettingObj;
    USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ audioStreamInterfaceSettingObj;
    
    // Video IN Streaming Interface Object
    USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ videoStreamInterfaceSettingObjZeroBandwidth;
    USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ audioStreamInterfaceSettingObjZeroBandwidth;
    
    // Flag indicates if Video IN stream has been Found
    bool isVideoInStreamFound;

    // Transfer handle for Audio Write
    USB_HOST_UVC_STREAM_TRANSFER_HANDLE transferHandleVideoWrite;
    USB_HOST_UVC_STREAM_TRANSFER_HANDLE transferHandleVideoRead;

    // Stream Enable/Disable
    USB_HOST_UVC_REQUEST_HANDLE requestHandle;

    // Video read completed
    volatile bool isVideoWriteCompleted;
    volatile bool isVideoReadCompleted;
    volatile uint16_t wLenVideoRead;

    // Pointer to Input Terminal Descriptor
    USB_UVC_INPUT_TERMINAL_DESCRIPTOR *inputTerminaDescriptor;
    
    // Pointer to Feature Unit Descriptor
    USB_UVC_FEATURE_UNIT_DESCRIPTOR_HEADER *featureUnitDescriptor;

    uint16_t width,height;
    
    uint8_t bitsPerPixel;
    
    uint16_t packetSize;
    
    // Stream Has been enabled
    volatile bool isStreamEnabled;

    // Flag to indicate progress Stream Disable request
    volatile bool isStreamInterfaceSetZeroComplete;

    // Flag to indicate progress Stream Enable request
    volatile bool isStreamInterfaceSetOneComplete;
    
    USB_HOST_UVC_CONTROL_ENTITY_OBJ videoFeatureUnitObj; 
//    USB_HOST_UVC_CONTROL_ENTITY_OBJ audioFeatureUnitObj; 
    uint8_t videoTerminalLink; 
//    uint8_t audioTerminalLink; 
    volatile bool isControlRequestCompleted;
    volatile bool isStreamInterfaceSetComplete; 

   
    uint32_t switchDebounceTimer; 
    bool isMuteSwitchPressed; 
    bool ignoreSwitchPress; 
#endif
    
    bool deviceIsConnected;
#endif
    
    // Flag determines SOF event occurrence
    bool sofEventHasOccurred;

#ifdef USA_USB_SLAVE_CDC    
        // Device layer handle returned by device layer open function
    USB_DEVICE_HANDLE deviceHandle;
    // Set Line Coding Data
    USB_CDC_LINE_CODING setLineCodingData;
    // Device configured state
    bool isConfigured;
    // Get Line Coding Data
    USB_CDC_LINE_CODING getLineCodingData;
    // Control Line State
    USB_CDC_CONTROL_LINE_STATE controlLineStateData;
    // Read transfer handle
    USB_DEVICE_CDC_TRANSFER_HANDLE readTransferHandle;
    // Write transfer handle
    USB_DEVICE_CDC_TRANSFER_HANDLE writeTransferHandle;
    // True if a character was read
    volatile bool isReadComplete;
    // True if a character was written
    volatile bool isWriteComplete;
    /* Break data */
    uint16_t breakData;
    // Number of bytes read from Host 
    uint32_t numBytesRead; 
#endif

    } APP_DATA;


// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Routines
// *****************************************************************************
// *****************************************************************************
/* These routines are called by drivers when certain events occur.
*/

	
// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Summary:
     MPLAB Harmony application initialization routine.

  Description:
    This function initializes the Harmony application.  It places the 
    application in its initial state and prepares it to run so that its 
    APP_Tasks function can be called.

  Precondition:
    All other system initialization routines should be called before calling
    this routine (in "SYS_Initialize").

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Initialize();
    </code>

  Remarks:
    This routine must be called from the SYS_Initialize function.
*/
void APP_Initialize(void);

#if defined(USA_USB_HOST_UVC)
/*******************************************************************************
  Function:
    void APP_AudioDataSetDefault (void)

  Summary:
    Set Audio Host application data to default values.

  Description:
    
  Precondition:
    
  Parameters:
    None.

  Returns:
    None.
*/
void APP_AudioDataSetDefault (void);

void APP_FindAudioControls(void);

void APP_SendAudioMuteControl( 
    APP_USB_UVC_CONTROL_TRANSFER_ACTION, uint32_t *);

void APP_SendAudioVolumeControl( 
    APP_USB_UVC_CONTROL_TRANSFER_ACTION, uint16_t *); 
#endif

/*******************************************************************************
  Function:
    void APP_Tasks ( void )

  Summary:
    MPLAB Harmony Demo application tasks function

  Description:
    This routine is the Harmony Demo application's tasks function.  It
    defines the application's state machine and core logic.

  Precondition:
    The system and application initialization ("SYS_Initialize") should be
    called before calling this.

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Tasks();
    </code>

  Remarks:
    This routine must be called from SYS_Tasks() routine.
 */

void APP_Tasks(void);

#if defined(USA_USB_HOST_UVC)
USB_HOST_UVC_STREAM_EVENT_RESPONSE APP_USBHostAudioStreamEventHandler(
    USB_HOST_UVC_STREAM_HANDLE,
    USB_HOST_UVC_STREAM_EVENT,
    void *, uintptr_t);

void App_USBHostUVCAttachHandler(
    USB_HOST_UVC_OBJ, USB_HOST_UVC_EVENT,
    uintptr_t);
USB_HOST_EVENT_RESPONSE APP_USBHostEventHandler(USB_HOST_EVENT, void *, uintptr_t);

bool App_USBHostVideoStreamFind(
    USB_HOST_UVC_OBJ,
    APP_USB_HOST_UVC_STREAM_FORMAT,
    USB_HOST_UVC_STREAMING_INTERFACE_OBJ *,
    USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ *,
    USB_HOST_UVC_STREAMING_INTERFACE_SETTING_OBJ *); 

void App_USBUVCControlRequestCallback(
    USB_HOST_UVC_OBJ,
    USB_HOST_UVC_REQUEST_HANDLE,
    USB_HOST_UVC_RESULT,
    size_t, uintptr_t context); 

void APP_ProcessSwitchPress(void); 
bool APP_VideoFeatureUnitObjectGet(uint8_t, USB_HOST_UVC_CONTROL_ENTITY_OBJ *); 
#endif

/*******************************************************************************
  Function:
    void APP_Tasks(void)

  Summary:
    MPLAB Harmony Demo application tasks function

  Description:
    This routine is the Harmony Demo application's tasks function.  It
    defines the application's state machine and core logic.

  Precondition:
    The system and application initialization ("SYS_Initialize") should be
    called before calling this.

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Tasks();
    </code>

  Remarks:
    This routine must be called from SYS_Tasks() routine.
 */
void APP_Tasks(void);

#if defined(USA_USB_HOST_UVC)
typedef struct __attribute__((packed)) {    //https://docs.microsoft.com/en-us/windows-hardware/drivers/stream/uvc-extensions-1-5
  uint8_t HeaderSize; // in effetti � il primo... = 12 (v. codeproject)
  union {
    struct {
      unsigned int FID:1;   // Frame Identifier
      unsigned int isEOF:1;   // End of Frame
      unsigned int PTS:1;   // Presentation Time Stamp
      unsigned int SCR:1;   // Source Clock Reference
      unsigned int RES:1;   // Reserved.
      unsigned int STI:1;   // Still Image
      unsigned int ERR:1;   // Error Bit
      unsigned int EOH:1;   // End of Header
      };
    uint8_t HeaderBitfield;   // e questo il secondo...
    };
  uint16_t TotalSize;   // uint32_t PTS;
  uint32_t Frame;       // uint48_t SCR;
  uint32_t CurrentBank;
} VP_HeaderInfoType;      
#endif

#endif /* _APP_H */
