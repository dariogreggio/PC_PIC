#include <xc.h>
#include <ctype.h>
#include "Pc_pic_cpu.h"
#ifdef USA_WIFI
#include "at_winc1500.h"
#endif

extern SIZE Screen,ScreenText;
extern struct KEYPRESS keypress;
extern volatile unsigned long now;
extern BYTE myRSSI;
extern const char _PC_PIC_CPU_C[];
extern const char Copyr1[];

#define PRIMA_SCHERMATA_BIOS 0
#define ULTIMA_SCHERMATA_BIOS (PRIMA_SCHERMATA_BIOS+35)		// 

const char *string_disable="DISABLED",*string_enable="ENABLED ";
const char *string_on="ON ",*string_off="OFF";

typedef struct __attribute((packed)) _MENU_ITEM {
	char *name;
	BYTE x,y;
	DWORD *var;
	WORD valMin,valMax;
	BYTE type;
  BYTE extra;
  BYTE enabled;
	} MENU_ITEM;

const MENU_ITEM menuItems[ULTIMA_SCHERMATA_BIOS-PRIMA_SCHERMATA_BIOS] = 
{
//size=0 e val min/max 0..1 indicano ON/OFF!
  // tarato su LCD 480x320 ossia 60x40char
	{ "Date:",         2, 7,(DWORD *)&BiosArea.dateTime,0,0,17,0,1 },   // 
	{ "Time:",         30,7,(DWORD *)&BiosArea.dateTime,0,0,18,0,1 },   // 
  
	{ "NumLock:",      2, 9,(DWORD *)&BiosArea.flags,   0,1,0,1,1 },
	{ "Ignore Errors:",30,9,(DWORD *)&BiosArea.flags,   0,1,0,2,1 },
	{ "UseExtRAM:",    2,10,(DWORD *)&BiosArea.flags,   0,1,0,4,1 },
	{ "DebugMode:",    19,10,(DWORD *)&BiosArea.flags,   0,1,0,8,1 },
	{ "ConfigMode:",   40,10,(DWORD *)&BiosArea.flags,   0,1,0,16,1 },
//	{ "Verbose:",			40,10,(DWORD *)&BiosArea.flags,   0,1,0,32,1 },
#warning AGGIUNGERE VERBOSE!
	{ "Cpu Speed:",    2, 12,(DWORD *)&BiosArea.cpuSpeed,0,2,1,0,1 },
	{ "Cpu Cache:",    30,12,(DWORD *)&BiosArea.cpuCache,0,2,1,0,1 },
	{ "Video Mode:",   2 ,13,(DWORD *)&BiosArea.videoMode,0,3,1,0,1 },		//
#if defined(USA_USB_HOST_UVC)
	{ "VideoCapture:", 30,13,(DWORD *)&BiosArea.videoCapture,0,1,0,0,1 },		//
#else
	{ "VideoCapture:", 30,13,(DWORD *)&BiosArea.videoCapture,0,1,0,0,0 },		//
#endif
	{ "Disc 1:",       2, 14,(DWORD *)&BiosArea.disc[0], 0,1,0 /*1*/,0,1 },
#if defined(USA_USB_HOST_MSD)
	{ "Disc 2:",       30,14,(DWORD *)&BiosArea.disc[1], 0,1,0 /*1*/,0,1 },
#else
	{ "Disc 2:",       30,14,(DWORD *)&BiosArea.disc[1], 0,1,0 /*1*/,0,0 },
#endif
	{ "Boot disc:",    2, 15,(DWORD *)&BiosArea.bootDisc,1,5,1,0,1 },
	{ "Serial port:",  2, 16,(DWORD *)&BiosArea.serial,  0,1,0 /*1*/,0,1 },
	{ "Parallel port:",30,16,(DWORD *)&BiosArea.parallel,0,1,0 /*1*/,0,1 },
	{ "Audio:",        2, 17,(DWORD *)&BiosArea.audio,   0,1,0 /*1*/,0,1 },
	{ "Joystick:",     30,17,(DWORD *)&BiosArea.joystick,0,1,0 /*1*/,0,1 },
#ifdef USA_WIFI
	{ "WiFi:",         2, 18,(DWORD *)&BiosArea.wifi,    0,1,0 /*1*/,0,1 },
#else
	{ "WiFi:",         2, 18,(DWORD *)&BiosArea.wifi,    0,1,0 /*1*/,0,0 },
#endif
#ifdef USA_ETHERNET
	{ "Ethernet:",     30,18,(DWORD *)&BiosArea.ethernet,0,1,0 /*1*/,0,1 },
#else
	{ "Ethernet:",     30,18,(DWORD *)&BiosArea.ethernet,0,1,0 /*1*/,0,0 },
#endif
// beh andrebbe tolto tutto :)
	{ "MAC Address:",  2, 20,(DWORD *)&BiosArea.MyMACAddr,0,17,255,0,1 },	//20
  
	{ "IP Address:",   2, 21,(DWORD *)&BiosArea.MyIPAddr,0,0,16,0,1 },	//gestire IP dotted!
	{ "Subnet mask:",  30,21,(DWORD *)&BiosArea.MyMask,  0,0,16,0,1 },
	{ "Gateway:",      2, 22,(DWORD *)&BiosArea.MyGateway,0,0,16,0,1 },
	{ "DNS Server 1:", 2, 23,(DWORD *)&BiosArea.PrimaryDNSServer,0,0,16,0,1 },
	{ "DNS Server 2:", 30,23,(DWORD *)&BiosArea.SecondaryDNSServer,0,0,16,0,1 },
	{ "NetBios name:", 2, 24,(DWORD *)&BiosArea.NetBIOSName,0,16-1,255,0,1 },
  
#ifdef USA_WIFI
	{ "Wifi name:",    2, 25,(DWORD *)&BiosArea.wifiName, 0,16-1,255,0,1 },
	{ "Wifi password:",30,25,(DWORD *)&BiosArea.wifiPasw, 0,16-1,255,0,1 },
	{ "RSSI:",4,26,(DWORD *)&myRSSI, 0,0,1,0,0 },    //29
#else
	{ "Wifi name:",    2, 25,(DWORD *)&BiosArea.wifiName, 0,16-1,255,0,0 },
	{ "Wifi password:",30,25,(DWORD *)&BiosArea.wifiPasw, 0,16-1,255,0,0 },
	{ "RSSI:",4,26,(DWORD *)NULL, 0,0,1,0,0 },    //29
#endif

	{ "HTTP port:",    2, 27,(DWORD *)&BiosArea.httpPort, 1,65534,2,0,1 },
	{ "Telnet port:",  30,27,(DWORD *)&BiosArea.telnetPort,1,65534,2,0,1 },

	{ "Admin name:",   2, 28,(DWORD *)&BiosArea.nome_admin,0,16-1,255,0,1 },
	{ "Admin password:",30,28,(DWORD *)&BiosArea.pasw_admin,0,16-1,255,0,1 },
  
	{ "Bios password:",2, 30,(DWORD *)&BiosArea.password,  0,8,255,0,1 }

	};

const MENU_ITEM *menuItems1[36] = {
  &menuItems[0],
  &menuItems[1],
  &menuItems[2],
  &menuItems[3],
  &menuItems[4],
  &menuItems[5],
  &menuItems[6],
  &menuItems[7],
  &menuItems[8],
  &menuItems[9],
  &menuItems[10],
  &menuItems[11],
  &menuItems[12],
  &menuItems[13],
  &menuItems[14],
  &menuItems[15],
  &menuItems[16],
  &menuItems[17],
  &menuItems[18],
  &menuItems[19],
  &menuItems[20],
  &menuItems[21],
  &menuItems[22],
  &menuItems[23],
  &menuItems[24],
  &menuItems[25],
  &menuItems[26],
  &menuItems[27],
  &menuItems[28],
  &menuItems[29],
  &menuItems[30],
  &menuItems[31],
  &menuItems[32],
  &menuItems[33],
  &menuItems[34],
  &menuItems[35],
  };
const MENU_ITEM *menuItems4[4][9] = {
  //in effetti non va, perch� vanno cambiate le coordinate...
  {
    &menuItems[0],
    &menuItems[1],
    &menuItems[2],
    &menuItems[3],
    &menuItems[4],
    &menuItems[5],
    &menuItems[6],
    &menuItems[7],
    &menuItems[8],
    },
  {
    &menuItems[9],
    &menuItems[10],
    &menuItems[11],
    &menuItems[12],
    &menuItems[13],
    &menuItems[14],
    &menuItems[15],
    &menuItems[16],
    &menuItems[17],
    },
  {
    &menuItems[18],
    &menuItems[19],
    &menuItems[20],
    &menuItems[21],
    &menuItems[22],
    &menuItems[23],
    &menuItems[24],
    &menuItems[25],
    &menuItems[26],
    },
  {
    &menuItems[27],
    &menuItems[28],
    &menuItems[29],
    &menuItems[30],
    &menuItems[31],
    &menuItems[32],
    &menuItems[33],
    &menuItems[34],
    &menuItems[35],
    },
  };

int showAParm(BYTE,char *,BYTE);
int parseAParm(BYTE,const char *);

void SaveBios(BYTE m);

void LCDPutStringXY(BYTE x,BYTE y,const char *s) {

  SetXYText(x,y);
  print(s);
  }

void LCDPutStringCenter(BYTE y,const char *text) {
  SHORT  width;

//	SetFont((void *)font);
//  width = GetTextWidth(text, (void *)font);
  width = strlen(text);

  LCDPutStringXY(((ScreenText.cx) - width) / 2, y, text);
	}

int MostraSiNo(const char *title) {
	int n=-1;
	
//  SetColor(BLUE);
//  ClearDevice();
//  SetColor(WHITE);
//	Cls();
//ev.  DrawRectangle(0,0,Screen.cx-1,Screen.cy-1,GREEN);

	LCDPutStringCenter(33,(char *)(title ? title : "ARE YOU SURE (Y/N)?"));

	do {
		handle_events(); 
		__delay_ms(100);
		ClrWdt();
		if(tolower(keypress.key)=='y')
			n=1;
		else if(tolower(keypress.key)=='n')
			n=0;
		} while(n==-1);	
  KBClear();

	return n;
	}

int handleBIOS(void) {
	BYTE currItem=0,oldItem;
  BYTE currPage=0;
  BYTE currX;
	char buffer[64];
	struct __attribute__((__packed__)) BIOS_AREA newBiosArea;
	BYTE n;

	memcpy(&newBiosArea,&BiosArea,sizeof(newBiosArea));

reprint_menu:
	oldItem=0;
  currX=0;

  SetColors(WHITE,BLUE);
  Cls();
  
  showBIOS();
	showAParm(0,buffer,TRUE);
  SetCursorMode(1,3);

  KBClear();
	for(;;) {
		ClrWdt();
		if(currItem!=oldItem) {
			showAParm(oldItem,buffer,FALSE);
			showAParm(currItem,buffer,TRUE);
//			LCDPutStringXY(menuItems[currItem].size+1,0,buffer);
			oldItem=currItem;
      currX=0;    // dovrei andare al fondo, dei numeri e delle stringhe...
      SetXYText(menuItems[currItem].x+strlen(menuItems[currItem].name)+1,menuItems[currItem].y);
			}
		if(now != BiosArea.dateTime) {
//			if(currItem != 0)
        showAParm(0,buffer,currItem==0);    // no questo lo lascio se no al primo giro non si aggiorna..
			if(currItem != 1)
  			showAParm(1,buffer,currItem==1);    // beh vabbe' :)
			if(/*currItem != 0 && */ currItem != 1)
        BiosArea.dateTime=now;
      
      if(!(now % 10)) {
        if(BiosArea.wifi) {
#ifdef USA_WIFI
          m2m_wifi_get_connection_info();
#endif
          showAParm(29,buffer,FALSE);
          }
        }
      SetXYText(menuItems[currItem].x+strlen(menuItems[currItem].name)+1+currX,menuItems[currItem].y);
      }

	  __delay_ms(50);
		handle_events();
    
#ifdef USA_WIFI
        m2m_wifi_handle_events(NULL);   //boh s� almeno per debug
#endif
    
    if((keypress.key==0x9a) && 
      keypress.modifier==0b00000101) { // CTRL-ALT-CANC!
			//anche qua??
			}

		switch(keypress.key) {
			case '+':			// 
				if(!menuItems[currItem].enabled)			// se � disattivata, salto (v. sotto)
					break;
				switch(menuItems[currItem].type) {
					case 0:
            if(menuItems[currItem].extra) {
              (*((BYTE *)menuItems[currItem].var)) ^= menuItems[currItem].extra;
              }
            else {
              (*((BYTE *)menuItems[currItem].var))++;
              (*((BYTE *)menuItems[currItem].var)) &= 1;
              }
						break;
					case 1:
						if((*((BYTE *)menuItems[currItem].var)) < menuItems[currItem].valMax)
  						(*((BYTE *)menuItems[currItem].var))++;
						break;
					case 2:
						if((*((WORD *)menuItems[currItem].var)) < menuItems[currItem].valMax)
  						(*((WORD *)menuItems[currItem].var))++;
						break;
					case 4:
						if((*((DWORD *)menuItems[currItem].var)) < menuItems[currItem].valMax)
  						(*((DWORD *)menuItems[currItem].var))++;
						break;
          default:
						break;
					}
      	goto show_and_redraw;
				break;
			case '-':			// 
				if(!menuItems[currItem].enabled)			// se � disattivata, salto (v. sotto)
					break;
				switch(menuItems[currItem].type) {
					case 0:
            if(menuItems[currItem].extra) {
              (*((BYTE *)menuItems[currItem].var)) ^= menuItems[currItem].extra;
              }
            else {
              (*((BYTE *)menuItems[currItem].var))++;
              (*((BYTE *)menuItems[currItem].var)) &= 1;
              }
						break;
					case 1:
						if((*((BYTE *)menuItems[currItem].var)) > menuItems[currItem].valMin)
  						(*((BYTE *)menuItems[currItem].var))--;
						break;
					case 2:
						if((*((WORD *)menuItems[currItem].var)) > menuItems[currItem].valMin)
  						(*((WORD *)menuItems[currItem].var))--;
						break;
					case 4:
						if((*((DWORD *)menuItems[currItem].var)) > menuItems[currItem].valMin)
  						(*((DWORD *)menuItems[currItem].var))--;
						break;
          default:
						break;
					}
      	goto show_and_redraw;
				break;
			case 0x91:		// right
			case 0x92:		// left
				break;
			case '\x8':			// 
				if(!menuItems[currItem].enabled)			// 
					break;
  			showAParm(currItem,buffer,TRUE);
				switch(menuItems[currItem].type) {
					case 1:
					case 2:
					case 4:
					case 16:
					case 17:
					case 18:
            {
            char *p=buffer;
            int i=strlen(p);
            if(i>0)
              p[--i]=0;
            currX=i;
            }
            parseAParm(currItem,buffer);
						break;
					case 255:
            {
            // gestire mac address...
            char *p=(char *)menuItems[currItem].var;
            int i=strlen(p);
            if(i>0)
              p[--i]=0;
            currX=i;
            }
            parseAParm(currItem,buffer);    // qua nulla ma magari mac address...
    				break;
          }
      	goto show_and_redraw;
				break;
      default:
				if(keypress.key<' ' || keypress.key>0x7e || !menuItems[currItem].enabled)			// 
					break;
  			showAParm(currItem,buffer,TRUE);
				switch(menuItems[currItem].type) {
					case 0:
        		if(keypress.key == ' ') {
              if(menuItems[currItem].extra) {
                (*((BYTE *)menuItems[currItem].var)) ^= menuItems[currItem].extra;
                }
              else {
                (*((BYTE *)menuItems[currItem].var))++;
                (*((BYTE *)menuItems[currItem].var)) &= 1;
                }
              parseAParm(currItem,buffer);    // beh nulla :)
              currX=0;
              }
						break;
					case 1:
        		if(isdigit(keypress.key)) {
              char *p=buffer;
              int i=strlen(p);
              if(i < 3)
                p[i++]=keypress.key; p[i]=0;
              parseAParm(currItem,buffer);
              currX=i;
              }
						break;
					case 2:
        		if(isdigit(keypress.key)) {
              char *p=buffer;
              int i=strlen(p);
              if(i < 5)
                p[i++]=keypress.key; p[i]=0;
              parseAParm(currItem,buffer);
              currX=i;
              }
						break;
					case 4:
        		if(isdigit(keypress.key)) {
              char *p=buffer;
              int i=strlen(p);
              if(i < 10)
                p[i++]=keypress.key; p[i]=0;
              parseAParm(currItem,buffer);
              currX=i;
              }
						break;
					case 16:
        		if(isdigit(keypress.key) || keypress.key=='.') {
              char *p=buffer;
              int i=strlen(p);
              if(i < 15)
                p[i++]=keypress.key; p[i]=0;
              parseAParm(currItem,buffer);
              currX=i;
              }
						break;
					case 17:
        		if(isdigit(keypress.key) || keypress.key=='-' || keypress.key=='/') {
              char *p=buffer;
              int i=strlen(p);
              if(i < 10)
                p[i++]=keypress.key; p[i]=0;
              parseAParm(currItem,buffer);
              currX=i;
              }
						break;
					case 18:
        		if(isdigit(keypress.key) || keypress.key=='-' || keypress.key==':') {
              char *p=buffer;
              int i=strlen(p);
              if(i < 8)
                p[i++]=keypress.key; p[i]=0;
              parseAParm(currItem,buffer);
              currX=i;
              }
						break;
					case 255:
            {
            // gestire mac address...
            char *p=(char *)menuItems[currItem].var;
            int i=strlen(p);
            if(i < menuItems[currItem].valMax)
              p[i++]=keypress.key; p[i]=0;
            parseAParm(currItem,buffer);    // qua nulla ma magari mac address...
              currX=i;
            }
    				break;
          }
show_and_redraw:
        {
        int i;
        switch(currItem) {
          case 9: // caso particolare videoMode
            i=10;
            break;
          case 7:
            i=6;
            break;
          default:
            switch(menuItems[currItem].type) {
              case 0:     // diciam che non serve
                i=0;
                break;
              case 1:
                i=3;
                break;
              case 2:
                i=5;
                break;
              case 4:
                i=10;
                break;
              case 16:
                i=10;
                break;
              case 17:
                i=8;
                break;
              case 18:
                i=15;
                break;
              case 255:
                i=menuItems[currItem].valMax;
                break;
              default:
                i=0;    // per sicurezza :)
                break;
              }
            break;
          }
force_blank:
        memset(buffer,' ',i);
        buffer[i]=0;
        SetColors(WHITE,BLUE);
        LCDPutStringXY(menuItems[currItem].x+strlen(menuItems[currItem].name)+1,menuItems[currItem].y,
                buffer);
        }
      	showAParm(currItem,buffer,TRUE);
        
        
// serve??      SetXYText(menuItems[currItem].x+strlen(menuItems[currItem].name)+1+currX,menuItems[currItem].y);
      
      
        break;
        
			case 0x94:		// up
skip_up:
				if(currItem>0) {
					currItem--;
          if(!menuItems[currItem].enabled)			// 
            goto skip_up;
          }
				break;
			case 0x93:		// down
skip_down:
				if(currItem<(ULTIMA_SCHERMATA_BIOS-PRIMA_SCHERMATA_BIOS-1)) {
          currItem++;
          if(!menuItems[currItem].enabled)			// 
            goto skip_down;
          }
				break;
      case '\t':		// tab=down
      case '\n':		// CR=down
        if(currItem<(ULTIMA_SCHERMATA_BIOS-PRIMA_SCHERMATA_BIOS-1)) {
          currItem++;
          }
        break;
        
			case 0x97:		// home, mah s�
				currItem=0;
        break;
			case 0x98:		// end
        currItem=ULTIMA_SCHERMATA_BIOS-PRIMA_SCHERMATA_BIOS-1;
        break;
			case 0x96:		// FINIRE PgUp/Dn per pagine (v. display piccoli)
        if(currPage>0)
          currPage--;
        break;
			case 0x95:
        if(currPage<4)
          currPage++;
        break;
        
			case '\x1b':		// ESC no save
				if(MostraSiNo("Exit without saving (Y/N)?")) {
					memcpy(&BiosArea,&newBiosArea,sizeof(BiosArea));
					n=0;
					goto fine;
					}
				else {
			  	goto reprint_menu;
					}
				break;
			case 0xaa:		// F10      fare! 
				if(MostraSiNo("Save settings and exit (Y/N)?")) {
					SaveBios(0);
					n=1;
					goto fine;
					}
				else {
			  	goto reprint_menu;
					}
				break;
			case 0xa9:		// F9      fare! 
				if(MostraSiNo("Save settings (Y/N)?")) {
					SaveBios(0);
			  	goto reprint_menu;
					}
				else {
			  	goto reprint_menu;
					}
				break;
			}
    KBClear();
    mLED_1 ^= 1;     //  
		} 
  
fine:
	return n;
	}

int showBIOS(void) {
	BYTE i,n;
	char buffer[64];

	n=1;
//  SetColors(WHITE,BLUE);
//  Cls();
  
  DrawRectangle(0,0,Screen.cx-1,Screen.cy-1,LIGHTGREEN);
  DrawRectangle(2,2,Screen.cx-3,Screen.cy-3,GREEN);
  DrawRectangle(10,48,Screen.cx-11,256,WHITE);
  DrawLine(10,68,Screen.cx-11,68,WHITE);
  DrawLine(10,92,Screen.cx-11,92,WHITE);
  DrawLine(238,48,238,68,WHITE);
  DrawLine(238,92,238,256,WHITE);

  SetXYText(1,1);
	printf("BIOS %u.%02u",VERNUMH,VERNUML);
	LCDPutStringXY(12,1,_PC_PIC_CPU_C /*"PC_PIC BIOS information"*/);
	LCDPutStringXY(12,2,Copyr1 /*"CPU/RAM/PERIPHERALS/NETWORK"*/);
	LCDPutStringXY(3,38,"F9=SAVE");
	LCDPutStringXY(14,38,"ESC=QUIT WITHOUT SAVING");
	LCDPutStringXY(41,38,"F10=SAVE & EXIT");

	for(i=0; i<(ULTIMA_SCHERMATA_BIOS-PRIMA_SCHERMATA_BIOS); i++) {
		showAParm(i,buffer,FALSE);
		}

	return n;
	}

int parseAParm(BYTE n,const char *buf) {
  int i;
  uint32_t temp;
  
	switch(menuItems[n].type) {
		case 0:
			break;
		case 1:       // byte
			switch(n) {
				case 7:		// caso particolare CPU speed
				case 8:		// caso particolare CPU cache
				case 9:		// video mode
				case 13:		// boot
					break;	
				default:
					i=sscanf(buf,"%u",&temp);
          if(i==EOF)
            temp=0;
          *((BYTE *)menuItems[n].var)=LOBYTE(LOWORD(temp));
					break;	
				}	
			break;
		case 2:       // word
  		i=sscanf(buf,"%u",&temp);
      if(i==EOF)
        temp=0;
      *((WORD *)menuItems[n].var)=LOWORD(temp);
			break;
		case 4:       // dword
  		i=sscanf(buf,"%u",&temp);
      if(i==EOF)
        temp=0;
      *((DWORD *)menuItems[n].var)=temp;      // sprecato ma ok :)
			break;
		case 16:      // IP address
      {
#if defined(USA_WIFI) || defined(USA_ETHERNET)
      *((DWORD *)menuItems[n].var)=nmi_inet_addr(buf);
#endif
      }
			break;
		case 17:      // date da unix-time
    {
      PIC32_DATE date;
      PIC32_TIME time;
      uint32_t c1,c2,c3;
      
      SetTimeFromNow(now,&date,&time);
			i=sscanf(buf,"%u/%u/%u",&c1,&c2,&c3);
      // gestire meglio... lo 0 ecc
      date.mon=c2; date.mday=c1; date.year=c3;
      SetNowFromTime(date,time);
    }
			break;
		case 18:      // time da unix-time
    {
      PIC32_DATE date;
      PIC32_TIME time;
      uint32_t c1,c2,c3;
      
      SetTimeFromNow(now,&date,&time);
			i=sscanf(buf,"%u:%u:%u",&c1,&c2,&c3);
      // gestire meglio... lo 0 ecc
      time.hour=c1; time.min=c2; time.sec=c3;
      SetNowFromTime(date,time);
    }
			break;
		case 255:     // stringa
      i=strlen(buf);
			break;
		}
  return i;
  }

int showAParm(BYTE n,char *buf,BYTE state) {
	int i=0;

  SetColors(WHITE,BLUE);
  LCDPutStringXY(menuItems[n].x,menuItems[n].y,menuItems[n].name);
  if(!menuItems[n].var)
    return 0;
  
	switch(menuItems[n].type) {
		case 0:
      if(menuItems[n].extra) {
        i=sprintf(buf,"%s",*((BYTE *)menuItems[n].var) & menuItems[n].extra  ? 
          string_on : string_off);
        }
      else {
        i=sprintf(buf,"%s",*((BYTE *)menuItems[n].var) ? string_enable : string_disable);
        }
			break;
		case 1:       // byte
  		i=*((BYTE *)menuItems[n].var);
			switch(n) {
				case 7:		// caso particolare CPU speed
					i=sprintf(buf,"%uMHz",i==0 ? 200 : (i==1 ? 100 : 50));
					break;	
				case 8:		// caso particolare CPU cache
					i=sprintf(buf,"%s",i==0 ? "WB" : (i==1 ? "WT" : "NONE"));
					break;	
				case 9:		// video mode
					i=sprintf(buf,"%s",i==0 ? "LCD" : (i==1 ? "VGA" : (i==2 ? "COMPOSITE" : "LCD/DMA")));
					break;	
				case 13:		// boot
					i=sprintf(buf,"%c",i+'A'-1);
					break;	
				default:
					i=sprintf(buf,"%u",i);
					break;	
				}	
			break;
		case 2:       // word
			i=sprintf(buf,"%u",*((WORD *)menuItems[n].var));
			break;
		case 4:       // dword
			i=sprintf(buf,"%u",*((DWORD *)menuItems[n].var));
			break;
		case 16:      // IP address
    {
      DWORD d=*((DWORD *)menuItems[n].var);
			i=sprintf(buf,"%u.%u.%u.%u",LOBYTE(LOWORD(d)),HIBYTE(LOWORD(d)),
              LOBYTE(HIWORD(d)),HIBYTE(HIWORD(d)));
    }
			break;
		case 17:      // date da unix-time
    {
      PIC32_DATE date;
      PIC32_TIME time;

      SetTimeFromNow(now,&date,&time);
      i=sprintf(buf,"%02u/%02u/%02u",		// no BCD!
        date.mday,date.mon,date.year);
    }
			break;
		case 18:      // time da unix-time
    {
      PIC32_DATE date;
      PIC32_TIME time;

      SetTimeFromNow(now,&date,&time);
      i=sprintf(buf,"%02u:%02u:%02u",		// no BCD!
        time.hour,time.min,time.sec);
    }
			break;
		case 255:     // stringa
			switch(n) {
				case 20:		// caso particolare mac address
        {
					BYTE *p=(BYTE *)menuItems[n].var;
					i=sprintf(buf,"%02X:%02X:%02X:%02X:%02X:%02X",p[0],p[1],p[2],p[3],p[4],p[5]);
        }
					break;	
				default:
    			i=sprintf(buf,"%s",(char *)menuItems[n].var);
          break;
        }
			break;
		}
  if(state) {
    SetColors(BLUE,WHITE);
    }
  else {
    SetColors(WHITE,BLUE);
    }
  LCDPutStringXY(menuItems[n].x+strlen(menuItems[n].name)+1,menuItems[n].y,buf);

	return i;
	}


void drawRGBCube(UGRAPH_COORD_T x1,UGRAPH_COORD_T y1,UGRAPH_COORD_T size) {
  int zsize=size*.5 /*.707*/;
  int x,y,z;
  double r,g,b;
  
  // circa 80 secondi, 19/6/2022 con size=128
  for(z=zsize,g=255; z>0; z--,g-=256.0/zsize) {
    for(y=y1+size,b=0; y>y1; y--,b+=256.0/size) {
      for(x=x1,r=0; x<x1+size; x++,r+=256.0/size) {
        DrawPixel(x+z,y-z,Color565(r,g,b));
        }
      }
    }
  
  }

