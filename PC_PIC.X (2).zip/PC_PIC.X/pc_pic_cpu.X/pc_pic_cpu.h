/* 
 * File:   PC_PIC_CPU.h
 * Author: dario/katia
 *
 * Created on 30 agosto 2021, 11.17
 */

#ifndef PC_PIC_CPU_H
#define	PC_PIC_CPU_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
#include <stdint.h>
#include "../genericTypedefs.h"

int8_t strnicmp(const char *string1, const char *string2, size_t count);
char *strdup(const char *str);  
char *strupr(char *str);  
extern const GFX_COLOR textColors[16];

#include "pc_pic_bios.h"
#include "../pc_pic_video.X/pc_pic_video_bios.h"
#include "../pc_pic_audio.X/pc_pic_audio_bios.h"
#include "../pc_pic_south.X/pc_pic_south_bios.h"

#include "minibasic/minibasic.h"

    
// #define USA_USB_OVC 1
// #define USA_ETHERNET 1
// #define USA_WIFI 1
// #define USA_USB_HOST
// #define USA_USB_HOST_MSD
// #define USA_USB_SLAVE_CDC
#define ENC100_INTERFACE_MODE 0

/* check if build is for a real debug tool */
#if defined(__DEBUG) && !defined(__MPLAB_ICD2_) && !defined(__MPLAB_ICD3_) && \
   !defined(__MPLAB_PICKIT2__) && !defined(__MPLAB_PICKIT3__) && \
   !defined(__MPLAB_REALICE__) && \
   !defined(__MPLAB_DEBUGGER_REAL_ICE) && \
   !defined(__MPLAB_DEBUGGER_ICD3) && \
   !defined(__MPLAB_DEBUGGER_PK3) && \
   !defined(__MPLAB_DEBUGGER_PICKIT2) && \
   !defined(__MPLAB_DEBUGGER_PIC32MXSK)
    #warning Debug with broken MPLAB simulator
    #define USING_SIMULATOR
#endif
    
#define VERNUMH 1
#define VERNUML 0


#ifndef ClrWdt    
#define ClrWdt() { WDTCONbits.WDTCLRKEY=0x5743; }
#endif
    
#include "TCPIP Stack/tcpipconfig.h"
#include "TCPIP Stack/stacktsk.h"
#ifdef USA_ETHERNET
#include "TCPIP Stack/tcp.h"
#endif

struct __attribute__((__packed__)) BIOS_AREA {
    uint16_t signature;
    struct __attribute__((__packed__)) {
        uint8_t numLockBoot:1;
        uint8_t ignoreErrors:1;
        uint8_t useExtRAM:1;
        uint8_t debugMode:1;
        uint8_t verboseMode:1;
        uint8_t inConfig:1;
        } flags;
    uint8_t cpuSpeed,cpuCache;
    uint8_t videoMode;
    uint8_t disc[2];
    uint8_t serial;         //8
    uint8_t parallel;
    uint8_t joystick;
    uint8_t wifi;
    uint8_t ethernet;
    uint8_t audio;
    uint8_t videoCapture;
    uint8_t bootDisc;
	char password[8];
    uint32_t dateTime;      //16      
    
    IP_ADDR		MyIPAddr;               // IP address
	IP_ADDR		MyMask;                 // Subnet mask
	IP_ADDR		MyGateway;              // Default Gateway
	IP_ADDR		PrimaryDNSServer;       // Primary DNS Server
	IP_ADDR		SecondaryDNSServer;     // Secondary DNS Server
	IP_ADDR		DefaultIPAddr;          // Default IP address
	IP_ADDR		DefaultMask;            // Default subnet mask
	BYTE		NetBIOSName[16];        // NetBIOS name
	struct	{
		unsigned char : 6;
		unsigned char bIsDHCPEnabled : 1;
		unsigned char bInConfigMode : 1;
	} Flags;                            // Flag structure
	MAC_ADDR	MyMACAddr;              // Application MAC address
    uint8_t filler;

	char wifiName[32];
	char wifiPasw[32];
    uint8_t     networkType;
    uint8_t     channel;
    IP_ADDR		MyIPAddr2;              // IP address
	IP_ADDR		MyMask2;                // Subnet mask
	IP_ADDR		MyGateway2;             // Default Gateway
	IP_ADDR		PrimaryDNSServer2;      // Primary DNS Server
	struct	{
		unsigned char : 6;
		unsigned char bIsDHCPEnabled : 1;
		unsigned char bInAPMode : 1;
	} Flags2;                           // Flag structure
    uint8_t filler2;
    uint16_t httpPort;
    uint16_t telnetPort;
    
#if defined(WF_CS_TRIS)
    BYTE	MySSID[32];             // Wireless SSID (if using MRF24W)
    BYTE        SsidLength;             // number of bytes in SSID
    BYTE        SecurityMode;           // WF_SECURITY_OPEN or one of the other security modes
    BYTE        SecurityKey[64];        // WiFi Security key, or passphrase.
    BYTE        SecurityKeyLength;      // number of bytes in security key (can be 0)
    BYTE        WepKeyIndex;            // WEP key index (only valid for WEP)
    BYTE        dataValid;
    BYTE        networkType;
    #if defined(EZ_CONFIG_STORE)        // WLAN configuration data stored to NVM
    BYTE        saveSecurityInfo;       // Save 32-byte PSK
    #endif
#endif
	
    char nome_admin[16];
    char pasw_admin[16];

#if defined(STACK_USE_SNMP_SERVER) || defined(STACK_USE_SNMPV3_SERVER)
	// SNMPv2C Read community names
	// SNMP_COMMUNITY_MAX_LEN (8) + 1 null termination byte
	BYTE readCommunity[SNMP_MAX_COMMUNITY_SUPPORT][SNMP_COMMUNITY_MAX_LEN+1]; 

	// SNMPv2C Write community names
	// SNMP_COMMUNITY_MAX_LEN (8) + 1 null termination byte
	BYTE writeCommunity[SNMP_MAX_COMMUNITY_SUPPORT][SNMP_COMMUNITY_MAX_LEN+1];

	UINT32 SnmpEngineBootRcrd;
#endif
    
    BYTE filler_[56];           // sono 200 byte 22/6/22
    };
extern struct __attribute__((__packed__)) BIOS_AREA BiosArea;
void SaveBios(BYTE);
void __attribute__((noreturn)) App_Reset(void);
int handleBIOS(void);
void drawRGBCube(UGRAPH_COORD_T x1,UGRAPH_COORD_T y1,UGRAPH_COORD_T size);

void CreateStdVar(void);
void CreateStdVar2(char);

struct __attribute__((__packed__)) KEYPRESS { 
  uint8_t key,modifier;
  uint8_t new;
  };

typedef struct __attribute__((__packed__)) {
    unsigned char   weekday;    // 
    unsigned char   mday;       // 
    unsigned char   mon;        // 
    unsigned short  year;       // 
	} PIC32_DATE;

typedef struct __attribute__((__packed__)) {
    unsigned char   sec;        // BCD codification for seconds, 00-59
    unsigned char   min;        // BCD codification for minutes, 00-59
    unsigned char   hour;       // BCD codification for hours, 00-24
	} PIC32_TIME;

void SetTimeFromNow(DWORD,PIC32_DATE *,PIC32_TIME *);
DWORD SetNowFromTime(PIC32_DATE,PIC32_TIME);
int SetRTCCFromNow(DWORD);


/** LED ************************************************************/
#define mInitAllLEDs()      LATB &= 0xDFFF; TRISB &= 0xDFFF; LATA &= 0xF9FF; TRISA &= 0xF9FF; 

#define mLED_1              LATBbits.LATB13     // pin 42
#define mGetLED_1()         mLED_1
#define mLED_1_On()         mLED_1 = 1;
#define mLED_1_Off()        mLED_1 = 0;
#define mLED_1_Toggle()     mLED_1 = !mLED_1;

    
#define mExcep              LATAbits.LATA9      // pin 28
#define mPGood              LATAbits.LATA10     // pin 29 (v. anche sw)


/** SWITCH *********************************************************/
#define mInitSwitch1()      TRISAbits.TRISA10=1;

#define mInitAllSwitches()  mInitSwitch1(); CNPUAbits.CNPUA10=1;
#define sw1                 PORTAbits.RA10

    
/** UART ***********************************************************/
#define BAUDRATE       115200UL
#define BRG_DIV        4 
#define BRGH           1 

#define UART_TRISRTS  
#define UART_RTS      
#define UART_TRISDTR  
#define UART_DTR      


void mySYSTEMConfigPerformance(BYTE,BYTE);
void myINTEnableSystemMultiVectoredInt(void);

void UserInit(void);
void handle_events(void);

int execCmd(const char *,void *);
int execCmdROM(const char *,void *);
int execCmd2(const char *,const char*,void *);
int runCmdInterpreter(void);

void InitializeUSART(void);
void putsUART1(unsigned char *);
unsigned int ReadUART1(void);
void WriteUART1(unsigned int data);
void Timer_Init(void);
void PWM_Init(void);

#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#define CORE_TIMER_PERIOD       200000000ull
#else
#define CORE_TIMER_PERIOD       216000000ull
#endif
#define GetSystemClock()		(CORE_TIMER_PERIOD)			// Hz
#define GetInstructionClock()	(GetSystemClock())	// Normally GetSystemClock()/4 for PIC18, GetSystemClock()/2 for PIC24/dsPIC, and GetSystemClock()/1 for PIC32.  Might need changing if using Doze modes.
#define GetPeripheralClock()	(GetInstructionClock()/2)	// Normally GetSystemClock()/4 for PIC18, GetSystemClock()/2 for PIC24/dsPIC, and GetSystemClock()/1 for PIC32.  Divisor may be different if using a PIC32 since it's configurable.
#define PMP_CLOCK_DIVIDER_FAST 28        // meno di 40 non va, 17/6/22 cio� in effetti � il South che non va... si potrebbe rallentare solo quando si usa quello??
// (a 20 il video andava ancora... no, proviam 30,25)
#define PMP_CLOCK_DIVIDER_SLOW 40        // 
#define GetPeripheralClockPMPSPI()	(GetSystemClock()/PMP_CLOCK_DIVIDER_FAST)	// 
#define FCY (GetSystemClock())		// 
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#define FOSC 24000000UL    //Oscillator frequency
#else
#define FOSC 8000000UL    //Oscillator frequency
#endif

#define SRAM_ADDR_CS0 0xC0000000
#define RAM_SIZE 2*1024*1024

void __delay_us(unsigned int);
void __delay_ms(unsigned int);

int inputString(char *buf,int size,const char *prompt,BYTE types);
int inputKey(void);

void suona_USBin(void);
void suona_USBout(void);
void StdBeep(WORD ms);
void ErrorBeep(WORD ms);

int minibasic(MINIBASIC *hInstance,const char *scriptName);

void SoftReset(void);
    
void EEwrite(int addr,BYTE n);
BYTE EEread(int);
void EEinit(void);
    
int SetVideoMode(BYTE,WORD,WORD,BYTE);
void SetColors(WORD /*GFX_COLOR*/ f,WORD /*GFX_COLOR*/ b);
void SetXY(BYTE,WORD /*UGRAPH_COORD_T*/ x,WORD /*UGRAPH_COORD_T pd*/ y);
void SetXYText(uint8_t x,uint8_t y);
void SetCursorMode(uint8_t state,uint8_t mode);
int DrawLine(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,WORD c);
int DrawRectangle(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,WORD c);
void Cls(void);
int GetVideoTextArea(char *s,int n);
int print(const char *);
void KBClear(void);

int SetAudioMode(BYTE);
int SetAudioWave(BYTE,BYTE,WORD,BYTE,BYTE,BYTE,BYTE,BYTE);
int SetAudioFrequency(BYTE,WORD);
int SetAudioSamples(BYTE);
int SetJoystick(BYTE);
int ReadJoystick(int8_t);
int SetMidi(BYTE);
int WriteMidi(BYTE);
int ReadMidi(void);
int SetRTCC(BYTE,BYTE,WORD,BYTE,BYTE,BYTE);
int GetRTCC(BYTE *,BYTE *,WORD *,BYTE *,BYTE *,BYTE *);

int SetSerialPort(DWORD,BYTE,BYTE,BYTE);
int SetParallelPort(BYTE);
int WriteSerial(char);
int WriteParallel(char);
int KeyboardSetLed(BYTE);


enum BUS {
    MASTER_CPU=0b00,
    VIDEO_CARD=0b01,
    AUDIO_CARD=0b10,
    SOUTH_BRIDGE=0b11
    };

void WritePMP(enum BUS,BYTE,BYTE);
void WritePMPs(enum BUS,BYTE,BYTE *,BYTE);
BYTE ReadPMP(enum BUS,BYTE);
BYTE ReadPMPs(enum BUS,BYTE,BYTE *,BYTE);

DWORD GetID(enum BUS bus);
DWORD GetVersion(enum BUS bus);
DWORD GetConfig(enum BUS bus,BYTE *ret);
DWORD GetStatus(enum BUS bus,BYTE *ret);


//
#define	SPISCKTris TRISDbits.TRISD1			// SCK
#define	SPISDITris TRISDbits.TRISD2         // SDI
#define	SPISDOTris TRISDbits.TRISD3			// SDO
#define	SPIECSTris  m_ECS           		// CS ethernet
#define	SPIWCSTris  TRISDbits.TRISD5		// CS WiFi
#define	WINCEIDEResetTris  TRISGbits.TRISG0 // v. cmq jumper e Audio
#define	SPISDSCKTris TRISDbits.TRISD10		// SCK per SDcard
#define	SPISDSDITris TRISDbits.TRISD15      // SDI per SDcard
#define	SPISDSDOTris TRISDbits.TRISD11  	// SDO per SDcard
#define	SD_CS_Tris  TRISDbits.TRISD12		// CS SDcard
#define	SD_CD_Tris  TRISEbits.TRISE8		// CD SDcard
	
#define	m_SPISCKBit LATDbits.LATD1		// pin 76
#define	m_SPISDIBit LATDbits.LATD2		// pin 77
#define	m_SPISDOBit LATDbits.LATD3		// pin 78
#define	m_SPIWCSBit LATDbits.LATD5
#define SPIOUT      m_SPISDOBit 
#define SPIIN       m_SPISDIBit
#define SPICLOCK    SPISCKTris
#define SPIENABLE   m_SPIWCSBit

#define SPI1_FREQUENCY 3400000UL //10000000ul
#warning SPI1_FREQUENCY vs. PMP/PB2 clock... 2.5MHz con SLOW e 3.5 con FAST

#define m_ACS LATFbits.LATF3		// pin 56
#define m_VCS LATGbits.LATG14		// pin 95
#define m_SCS LATAbits.LATA6		// pin 89
#define m_ECS LATDbits.LATD4		// pin 81
#define m_WCS LATDbits.LATD5		// pin 82
#define m_SDCS LATDbits.LATD12		// pin 79
#define m_DCS LATCbits.LATC13		// pin 72
#define m_RCS LATGbits.LATG15		// pin 56

#define m_RD LATCbits.LATC4         // pin 9
#define m_WR LATCbits.LATC3         // pin 8

#define SD_CD PORTEbits.RE8         // pin 18
#define DACK  PORTDbits.RD0         // pin 71

#define m_WINCEIDEResetBit LATGbits.LATG0		// pin  // v. cmq jumper e Audio

#define WINCIRQTris TRISFbits.TRISF0
#define VIRQTris TRISFbits.TRISF1
#define AIRQTris TRISAbits.TRISA3
#define SIRQTris TRISAbits.TRISA7
#define EIRQTris TRISAbits.TRISA15
#define DIRQTris TRISCbits.TRISC14
#define DDRQTris TRISGbits.TRISG0       // anche WINCEIDEReset

#define m_VIRQ PORTFbits.RF1
#define m_VACK PORTFbits.RF1
#define m_VIRQ_CN CNFFbits.CNFF1
#define m_AIRQ PORTAbits.RA3
#define m_AACK PORTAbits.RA3
#define m_AIRQ_CN CNFAbits.CNFA3
#define m_SIRQ PORTAbits.RA7
#define m_SACK PORTAbits.RA7
#define m_SIRQ_CN CNFAbits.CNFA7
#define m_EIRQ PORTAbits.RA15
#define m_EIRQ_CN CNFAbits.CNFA15
#define m_DIRQ PORTCbits.RC14
#define m_DDRQ PORTGbits.RG0       // anche WINCEIDEReset
#define m_WIRQ_CN CNFFbits.CNFF0
// se si vuole... #define ENC100_INT_TRIS EIRQTris
//#define ENC100_INT_IO m_EIRQ

#define VIDEO_WAIT 1
#define AUDIO_WAIT 20       // unire! 15/12
#define SOUTHBRIDGE_WAIT 50


#ifdef	__cplusplus
}
#endif

#endif	/* PC_PIC_CPU_H */


/* protocollo PMP / bus periferiche
abbiamo 256 indirizzi (tranne il video solo 64) e 2 bit CS
(la RAM � a parte, EBI)

0..3 per ID e configurazione generica, in particolare la lettura a 0 restituisce versione ecc

A 4 (in lettura), quando le slave creano un interrupt, si trova "CHI" lo ha generato ossia il sottogruppo

Da 8 in poi ci sono le cose specifiche:
Per la VGA, a 8 metterei risoluzione x,y; VGA/composito
da 16 le primitive video, punto linea rettangolo cerchio
da 32 un bit-blit raw

Per l'audio, a 8 metterei qualit� audio, Hz bit canali
da 16 generazione forme d'onda, rettangolo sinusoide triangolare rumore
da 24 audio raw
da 32 il joystick
da 40 la Midi

Per il south bridge, a 8 metterei la tastiera
da 9 la RS232
a 16 la parallela
a 24 le PS/2



*/

