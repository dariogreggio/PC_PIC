/*********************************************************************
 *
 *                  Headers for TCPIP Demo App
 *
 *********************************************************************
 * FileName:        GlobalHub.h
 * Dependencies:    Compiler.h
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.05 or higher
 *					Microchip C30 v3.12 or higher
 *					Microchip C18 v3.30 or higher
 *					HI-TECH PICC-18 PRO 9.63PL2 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2010 Microchip Technology Inc.  All rights
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and
 * distribute:
 * (i)  the Software when embedded on a Microchip microcontroller or
 *      digital signal controller product ("Device") which is
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c, ENC28J60.h,
 *		ENCX24J600.c and ENCX24J600.h ported to a non-Microchip device
 *		used in conjunction with a Microchip ethernet controller for
 *		the sole purpose of interfacing with the ethernet controller.
 *
 * You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and
 * obligations.
 *
 *
 *
 * Author               Date    Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * E. Wood				4/26/08 Copied from MainDemo.c
 ********************************************************************/

/**********************************************************************
2011-09-13:
    1. Add the UART1 module and use the UART1 interrupt, works


 ***********************************************************************/

//#define BAUD_RATE       (19200)		// bps
/*////////////////////////////////////////////////////////////////////////

RF2-U1RX; RF8-U1TX; are connected to the PLM serial port

2011-09-07 Rev01
    1. Flash memory 1 works. Add flash memory hardware definitions
2011-09-30
    1. Flash write a byte and write array works
2011-10-04
    1. Add smartlinc2 pages
    2. PLM working
2011-10-05
    1. Add all functions, thermostat works
2011-10-06
    1. Add real time clock support
    2. Change all int to INT16; unsigned int to UINT16
2011-10-07
    1. First working version.
    2. Fixed the bug of writing over 256 bytes
    3. Disable the webpages timeout alert lost connection message
2011-10-10
    1. First the saving appconfig bug to make the networking change works
2011-10-11
    1. Add network setting default set by pressing the button1 after powered

2011-10-24
    1. Add function SetRTCBySNTP, only including time and Days setting, no date/month

2011-11-02
    1. Add Thermostat ID bytes and update Thermostat day and time functions

2012-01-27 Rev 0x80
    1. Change the webpages store in Flash Memory
    2. Add Extended message CRC protection in send command

2012-02-02	Rev0x81
    1. Add date/month and year in SetRCTBySNTP

2012-12-12	Rev0x82
    1. Adjust the SNTP seconds to adjust the local time

2012-12-13	Rev0x83
    1. Add date output for dtstatus xml file
    2. Fix the bug when reset the nthermal ID was not read.
    3. Fix the convert AYear, ADay bug.

2012-12-18 Rev0x84
    1. Change the combuff from 100 to 200, make the ext message read/write doable

2013-01-31 Rev0x85
    1. Correct the MAC address with the yosmart ID
    2. Add RFReset line control by define RF_TRIS and RF_IO control

///////////////////////////////////////////////////////////////////////*/

#ifndef _MAINDEMO_H
#define _MAINDEMO_H


#define MQTT_ONLY 1


#define FMVER	0x80

//#define TEST_FREQ               // use the test frequency 787080000  and 781000000


//#define USE_PUBNUB_OR_MQTT    1              // put into Project! none=MQTT, 1=PUBNUB


#define USE_4BYTE_ID
#define Bool char
#define CAMURLLEN	64
#define VAR_PLMVER				(0x00)
#define VAR_ETVER					(0x01)
#define VAR_YOSMARTID			(0x02)
#define VAR_PORT					(0x04)
#define VAR_IP						(0x07)
#define VAR_MASK					(0x05)
#define VAR_GATE					(0x06)
#define VAR_MAC					(0x03)
#define VAR_DHCPE					(0x08)//for radio buttons
#define VAR_DHCPD					(0x09)
#define VAR_DHCP					(0x0A)//for text
#define VAP_APP_MAJOR       (0x0B)
#define VAR_APP_MINOR       (0x0C)
#define VAR_CAMERAURL			(0x88)


// Address in FlashMemory

#define PORTAddress 0x1532
#define VenstarID 0x1534
#define TESTAddress 0x153F
//#define DayofWeektmr 0x1540
#define MyHouseAddress 0x1640
#define ShowRoomFlag 0x1650
#define SomeFlags		 0x1655		// 1byte with 8 bit flags with 1 bit used bit 0
#define ShowSceneFlag 0x1660
#define ShowControlFlag 0x1680
#define CURLAddress 0x1780			// 16 rooms for CURL need 400H, if 10 rooms save


#define NVenstarID 0x1A80


#define UNPWAddress 0x1B80
//#define CCIDADDRESS 0x1BC0			//calc 40 instead of 400 so moved it to 7100
//#define CONTROLLAddress 0x1C00                  // 89 x 240 = 0x5370 + 0x1C00 = 0x6F70
#define DSTData 0x6F71                          //
#define SunriseSunset 0x6F80
#define CityString 0x6FC0
#define SunriseSunsettf 0x7000
#define CCIDADDRESS 0x7100                      // 0x7100 to 0x7500 for CCIDADDRESS for status report ID and grp number
#define MyHouseCAddress 0x7500                  // 24 charactors for C house name
#define ZipAddress  0x7518



//#define adrReset 0x7fff
//
//#define adrOldIDH       0x7ffe
//#define adrOldIDM       0x7ffd
//#define adrOldIDL       0x7ffc
//#define adrOldDevCat    0x7ffb
//#define adrOldSubCat    0x7ffa
//#define adrOldFWVer     0x7ff9
//#define adrOldHWVer     0x7ff8
#define adrDefaultUserName  0x7ff0                  // 8 charactors
#define adrDefaultPassword  0x7fe8                  // 8 charactors
#define adrDefaultPortNumber  0x7fe3                // 5 charactors
#define adrDefaultGuid  0x7fbf                      // 36 charactors
//#define adrOffset   0x7f9b                          // 4 characters  COffset


//#define adrDefaultUserName  0x7ff0                  // 8 charactors
//#define adrDefaultPassword  0x7fe8                  // 8 charactors
//#define adrDefaultPortNumber  0x7fe3                // 5 charactors
//#define adrDefaultGuid  0x7fbf                      // 36 charactors
//#define adrOffset   0x7f9b                          // 4 characters  COffset
//#ifdef DARIO
#define adrDefaultPORT 0x7f98                       // 2 bytes default port address
#define adrgcc      0x7f88                          // control channel
#define adrgal      0x7f78                          // alert channel
#define adrgad      0x7f68                          // administor channel
#define adrProvision    0x7f67                      // saved = 1; not saved: 0
#define adrgak      0x7f46                          // temperary auth key
//#endif
#define adrUserHttpPort 0x7f41                      // 5 charators
#define adrUserSetPortFlag  0x7f40                  // '1' = set; '0' = not set

// 0x8000 to 0x8100 room labels
// 0x8100 to 0x9100 scene labels

#define adrReset        0x7fff
#define adrOldIDH       0xBffe
#define adrOldIDM       0xBffd
#define adrOldIDL       0xBffc
#define adrOldDevCat    0xBffb
#define adrOldSubCat    0xBffa
#define adrOldFWVer     0xBff9
#define adrOldHWVer     0xBff8
#define adrGetUTCFlag   0xBff7
#define adrAlertStatus  0xBff6




#define adrOffset   0xBf9b                          // 4 characters  COffset
#define adrgccr      0xBf30                          // control channel r
#define adrgadr      0xBf20                          // control channel r

#define adrRandSeed 0xBf1e                          // store the seed for
#define adrExceptionOccured 0xBF1C                  // write as 0x5A when exception occurred


//#define adrALCCID     0x10000                       // 0x10000 + 2048 * 4 = 0x0x12000, CCID for alert

#define adrLockData     0x10000                       // Total 8192 bytes will be used for stor Lock data
// Every lock when it is linked: the Lock ID 4 bytes, and the UUID 4 bytes will be stored, the Rolling number will be send out by every time read the status
// So every lock need 8 bytes for store only, for max number of lock can be reached to 1024




//#define adrALControlFlag    0x12000                 // +2048, next 12800
#define adrTimers       0x12800                     // 1024 *4 = 4K
#define CONTROLLAddress 0x13C00                     // 0x13C00 + 104*1024 = 0x2DC00         // Commands 51 characters + 1 flag = 52; 52 * 2 = 104
#define DayofWeektmr    0x2DC00                     // 1024: next address = 0x2E000
#define adrALControlFlag    0x2E000                 // +4096, next 2F000            frequenctly writting area


//
//// address from 0x10000 new flags definitions
//#define adrALControlFlag    0x10000                        // Alert control flags     256 control alert settings
//#define adrALCCID           0x10100                        // Alert ID and Grp; 256 * 4

#define adrLinkedLED        0x10500                        // Linked lamp, max 256 * 4; ID plus a byte for status, active or no-active


#define adrFlashTest        0x1E7FFF

// address from 0x2F000 to 0x2ffff 64K for IO controller scheduls and thermostat scheduls
#define adrLinkedTS1        0x2F000                         // Linked thermostat 1: ID plus schedules
#define adrLinkedTS2        0x2F100                         // Linked thermostat 2: ID plus schedules
#define adrLinkedTS3        0x2F200                         // Linked thermostat 3: ID plus schedules
#define adrLinkedIO1        0x2F300                         // Linked water controller 1: ID plus schedules
#define adrLinkedIO2        0x2F400                         // Linked water controller 2: ID plus schedules
#define adrLinkedIO3        0x2F500                         // Linked water controller 3: ID plus schedules



// Address 0x30000 to 3FFFF 64K bytes for the linking database
#define adrDBStart          0x30000




// BIN start: MPFS_RESERVE_BLOCK    65536*4u
// 0x40000 to 0x7ffff for bin file 256K

// 0x80000 to 0xfffff 512K for store the RF updating firmware
#define RFHexStartAddress   (0x80000ul)
#define LoRaModuleStartAddress   (0x80000ul)

#define TSBinStartAddress   (0x90000ul)           // Max 64k thermostat bin file
#define SCBinStartAddress   (0xA0000ul)           // Max 64K sprinkler controller bin file
#define OPBinStartAddress   (0xB0000ul)           // Max 32K outlet plug bin file


// 0x100000 to 0x17ffff for last good firmware

//   B1 = SPI1ReadByte(0x103001) stored firmware version high byte       0x9000 -  0x6000 + 0x100000
//   B2 = SPI1ReadByte(0x103000) stored firmware version low byte

//    SPI1WriteByte(0x01,0x180000);               // Write the saved last good flag to 0x180000 and 0x180001
// 0x180000 to 0x180001 are for flags for saved last good firmware

// 0x188000 to 0x18f000 32K will used for save the LoRa module firmware????



// 0x190000 to 0x19ffff 64K will used for scenes
// Secnes total 16, each events have max 50 device, total 800 * 50 + 16 * 2 = 40000 + 32 = 40032 characters
// each secenes: 2 characters for number of commands; 64 characters for each commands; 50 * 50 = 2500

#define adrSceneStart   0x190000



// Flash memory 2 for save the download firmware PIC32; address from 0 to 0x1cffff



#define PLMHexStartAddress      (0x001d0000ul)          // In flash 2; from flash address 0 to save the Hex file for firmware updated

#define FLASH_APP_VERSION              (0x1D009000ul)
#define FLASH_KT_ID             (0x1D005f10ul)
#define adrSavedLastGood    0x1fff00                // The byte is 5A if the last good bin saved, in flash 1

//extern ROM BYTE FirmwareVersion[];

#if !defined(THIS_IS_STACK_APPLICATION)
extern BYTE AN0String[8];
#endif

extern BYTE myDHCPBindCount;
extern BYTE DHCPBindCount;

extern BOOL bHubFirmwareUpdate;
extern BOOL bTSFirmwareUpdate;
extern BOOL bSCFirmwareUpdate;
extern BOOL bOPFirmwareUpdate;
extern BOOL bMqttOn;
extern DWORD dwLastMqttOffTime;


void DoUARTConfig(void);

#if defined(EEPROM_CS_TRIS) || defined(SPIFLASH_CS_TRIS)
void SaveAppConfig(const APP_CONFIG *AppConfig);
#else
#define SaveAppConfig(a)
#endif

void SMTPDemo(void);
void PingDemo(void);
void SNMPTrapDemo(void);
void SNMPV2TrapDemo(void);
void GenericTCPClient(void);
void GenericTCPServer(void);
void BerkeleyTCPClientDemo(void);
void BerkeleyTCPServerDemo(void);
void BerkeleyUDPClientDemo(void);


// Define a header structure for validating the AppConfig data structure in EEPROM/Flash

typedef struct {
    unsigned short wConfigurationLength; // Number of bytes saved in EEPROM/Flash (sizeof(APP_CONFIG))
    unsigned short wOriginalChecksum; // Checksum of the original AppConfig defaults as loaded from ROM (to detect when to wipe the EEPROM/Flash record of AppConfig due to a stack change, such as when switching from Ethernet to Wi-Fi)
    unsigned short wCurrentChecksum; // Checksum of the current EEPROM/Flash data.  This protects against using corrupt values if power failure occurs while writing them and helps detect coding errors in which some other task writes to the EEPROM in the AppConfig area.
} NVM_VALIDATION_STRUCT;


// An actual function defined in MainDemo.c for displaying the current IP 
// address on the UART and/or LCD.
void DisplayIPValue(IP_ADDR IPVal);



// Data to be stored in the SPI flash, start from the sector 2

typedef struct {
    unsigned short PortNumber;
    char UserName[8];
    char PassWord[8];
    char MyHouse[16];
    unsigned char Test;
} GLOBAL_DATA_STRUCT;


extern WORD HTTPPort;



typedef struct{
    unsigned char WakeByte;
    unsigned char StatusByte;               // 0: No message, 1: To be handlerMsg; 2: Time out message
    unsigned char Retry;
    unsigned char FromByte;               // 0: normal; 1: From linkage 
    char MsgID[12];
    char MsgCmd[15];
    char MsgData[48];
    DWORD MsgStartTime;
} _SN_KX;


_SN_KX SN_KX[10];



typedef struct{
    unsigned char WakeType;
    unsigned char SendFlag;               // 0: not send, 1: send out
    unsigned char FromFlag;               // 0: default from App, 1: from linkage, 2: Alert
    char StrMsg[48];
    char StrID[12];
    char StrCmd[15];    
} _SN_KX_BUF;


// If the send message after 3 times without answer, save to this _SN_KX_FAIL buffer, it will retry for 3 times, total will be 9 times

typedef struct{
    unsigned char WakeType;
    unsigned char RetryNumber;             //
    char StrMsg[48];
} _SN_KX_FAIL;

typedef struct{
    unsigned char WakeType;
    unsigned char RetryNumber;             //
    char StrMsg[48];
    DWORD RetryStartTime;    
} _SN_KX_RETRY;


// Main Module
extern BOOL CheckForCleanupDone(void);
extern BYTE CheckForCommands(char grp);
extern void DelayMs(WORD ms);
extern void ReadCCID(DWORD grp);
extern void ReadSomeFlags(void);
extern void WriteCCID(DWORD grp);
extern void WriteSomeFlags(void);
extern void ReadURL(unsigned char room);
extern void WriteURL(unsigned char room);
extern void ReadASceneLabel(WORD group);
extern void WriteASceneLabel(WORD group);
extern void ReadTimers(DWORD);
extern void WriteTimers(DWORD, BYTE);
extern void WriteSceneFlags(BYTE);
extern void ReadSceneFlags(BYTE);
extern void ReadAOnOff(WORD group);
extern void ReadControltf(DWORD group);
extern void WriteControltf(DWORD group);
extern void TimeToString(void);
extern void ReadSS(WORD month);
extern void WriteSStf(DWORD group);
extern void ReadSStf(DWORD group);
extern void ReadCity();
extern void WriteCity();
extern void ReadZip();
extern void WriteZip();
extern void ReadDOWtf(DWORD group);
extern void WriteDOWtf(DWORD group);
extern void WriteUNPW();
extern void ReadUNPW();
extern void TODToString();
extern void DODToString();
extern void GetPLMInfo();
extern void SetPLMDevCat();
extern void GetPLMInfo();
extern void SetPLMDevCat();
extern void SLOSendToPLM(char c);
extern void fixspecial(BYTE *str);
extern void WriteARoomLabel(WORD group);
extern void ReadARoomLabel(WORD room);
extern void WriteSRoomFlags();
extern void ReadSRoomFlags();
extern void StringToTime(char *, char *);
extern void TimeToString(void);
extern void SaveSS(BYTE which);
extern void ReadRTCTOD(void);
extern void WriteRTCTOD(void);
extern void UnencodeURL(BYTE *URL);
extern void WriteMyHouse(void);
extern void ReadMyHouse(void);
extern void WriteThermID(void);
extern void ReadThermID(void);
extern void WriteNThermID(void);
extern void ReadNThermID(void);
extern void EraseAllRoomLabels(void);
extern void EraseAllSceneLabels(void);
extern void EraseAllTimers(void);
extern void EraseDOWtf(void);
extern void EraseControltf(void);
extern void EraseAllSceneFlags(void);
extern void EraseAllCustomCommandFlags();
extern void ResetCommands(void);
extern void WriteAOnOff(WORD group);
extern void StringToTOD(char *);
extern void SetSS(void);
extern void sendout(char *String);
extern void WriteRTCDAY();
extern void WritePORT(void);
extern void WriteAllURL(void);
extern BYTE CreateArgs(BYTE** argv);
extern void SetTimers(void);
extern void updateTOD(void);
extern void SDelay(WORD); // Software delay in 10us units

extern void SDelayMs(WORD unit);
extern void ConvertThermIDToByte(void);
extern void ConvertNThermIDToByte(void);

extern void SingleBeep();
extern void DoubleBeep();
extern void LongBeep();
extern void FailBeep();

// CustomHTTPApp module
extern BYTE BuffIndex;
extern BYTE MsgBuffer[25];
extern BYTE MsgCmd1;
extern BYTE MsgCmd2;
extern BYTE MsgFlag;

extern int iOffset;
extern char COffset[4];
extern char subChannel[64];

extern void ReStartScent(void);

// SPIFlash1 Module
extern char cBinVersion[10];
extern void SearchBinVersion();
extern void SPI1WriteByte(unsigned char data, DWORD address);
extern unsigned char SPI1WriteArray(unsigned char* vdata, DWORD address, WORD lenth);
extern unsigned char SPI1ReadByte(DWORD address);
extern void SPI1ReadArray(BYTE *vData, DWORD dwAddress, WORD wLen);

// SPIFlash2 Module
extern void SPI2FlashInit(void);
extern void SPI2FlashReadArray(DWORD dwAddress, BYTE *vData, WORD wLen);
extern void SPI2FlashBeginWrite(DWORD dwAddr);
extern void SPI2FlashWrite(BYTE vData);
extern void SPI2FlashWriteArray(BYTE *vData, WORD wLen);
extern void SPI2FlashEraseSector(DWORD dwAddr);

//extern static void _SendCmd(BYTE cmd);
//extern static void _WaitWhileBusy(void);
//static void _GetStatus(void);

extern unsigned char SPI2ReadByte(DWORD address);
extern void SPI2WriteByte(unsigned char data, DWORD address);
extern void SPI2ReadArray(BYTE *vData, DWORD dwAddress, WORD wLen);
extern unsigned char SPI2WriteArray(unsigned char* vdata, DWORD address, WORD lenth);


extern DWORD dwSPI1Address;
extern DWORD dwSPI2Address;
extern BYTE vSPI2Data;
extern BYTE vRXData[30];
extern BYTE vRXCount;

extern WORD wMSCount;
extern DWORD dwPLMAddress;

// UART1 Module
extern void PLMSendString(char bytes[], unsigned char length);
extern void PLMSendStringFast(char bytes[], unsigned char length);
extern void PLMSendExMsg(void);
extern unsigned int WaitPLMReceiveString(char str[], unsigned char length, unsigned int ms);


extern BYTE vUARTRXFIFO[100];
extern BYTE vUARTTXFIFO[30];
extern volatile BYTE *RXHeadPtr, *RXTailPtr;
extern volatile BYTE *TXHeadPtr, *TXTailPtr;

extern void UART1Init(void);
extern void writePLM(char data);

extern BYTE PLMVer;
extern BYTE PLMHardwareVer;
extern BYTE PLM6Ver;
extern BYTE PLM6HardwareVer;
extern BYTE Machi;
extern BYTE Macmid;
extern BYTE Maclo;
extern Bool GoodPLMData;
extern BYTE AddToGroup;
extern char neverbeenset;
extern BYTE DOWtmrflag;
extern BYTE SCflag;
extern BYTE ALSCflag;

extern char TODString[8]; // Time of dt string
extern char DODString[8]; // Date of dt string
extern BYTE LastLinc[4];
extern char NewChar;

extern BYTE ControlFlag;
extern char ONString[52];

extern char neverbeenset;
extern BYTE SFlags;
extern char MyHouse[24];
extern char ANTString[2][8];
extern unsigned char DOWtmrflag;
extern INT16 RoomCheckedFlag;
extern INT16 SceneCheckedFlag;
extern unsigned char smtpData[128];
extern char Authenticate;
extern char defPassword[9];
extern char defUserName[9];
extern char defGuid[37];
extern char defPortNumber[5];
extern char Password[16];
extern char UserName[16];
extern char COffset[4];
extern unsigned char results;
extern char PLMRxBuffer[200];
extern BYTE lastcommand[60];
extern char Network[16];
extern BYTE a[4];
extern BYTE oldGroup;
extern BYTE startbd;
extern WORD HTTPPort;

extern char ANGString[16];
extern char ANRString[16];
extern char ANTString[2][8];
extern char StartHours;
extern char StopHours;
extern char StartMinutes;
extern char StopMinutes;
extern void TCPDisconnect(TCP_SOCKET);
extern char returnsm(char);
extern WORD StartFlags[16];
extern WORD StopFlags[16];
extern char combuff[203];
extern char CAMURLString[CAMURLLEN];
extern char MyHouse[24];
extern char MyHouseC[24]; // In chinese
extern INT16 RoomCheckedFlag;
extern INT16 SceneCheckedFlag;
extern BYTE CCIDHi;
extern BYTE CCIDMid;
extern BYTE CCIDLo;
extern BYTE CCIDGrp;
extern BYTE ALCCIDHi;
extern BYTE ALCCIDMid;
extern BYTE ALCCIDLo;
extern BYTE ALCCIDGrp;
extern BYTE ThermIDH;
extern BYTE ThermIDM;
extern BYTE ThermIDL;
extern BYTE NThermIDH;
extern BYTE NThermIDM;
extern BYTE NThermIDL;

extern char Dst[7];
extern char City[21];
extern char SendC;
extern BYTE StatusDone;
extern BYTE DoStatusNow;
extern char StatusStr[17];
extern WORD CCIDFlag;
extern BYTE DoStatusWhich;
extern unsigned char AnotherLinked;
extern BYTE ComIndex;
extern char LinkingMode;
extern char GroupLinkingMode;
extern char unLinkingMode;
extern char reset;

extern unsigned char AnotherLinked;
extern Bool RetryMode;
extern Bool Error;
extern unsigned char LStatus;
extern Bool TimeToCheckTimers;
extern char LinkedCCID;
extern BYTE CheckForCU;
extern BOOL OkToNBNSTask;
extern char retrycount;
extern WORD nextgroup;
extern WORD nextroom;
extern WORD nextTS;
extern WORD nextTE;
extern char CAMURLString[CAMURLLEN];
extern char Network[16];
extern BYTE a[4];
extern BYTE lastcommand[60];
extern BYTE LastLinc[4];
//extern BYTE Machi;
//extern BYTE Macmid;
//extern BYTE Maclo;
//extern Bool GoodPLMData;
//extern BYTE AddToGroup;

extern unsigned char GroupNumber;
extern unsigned char GroupNumberRoomOffset;
extern unsigned char currentRoom;
extern unsigned char ramRoom;
extern char CurrentCommand1;
extern char CurrentCommand2;
extern char retrydelay;
extern char ThermID[7];
extern char NThermID[7];
extern BYTE oStartHours;
extern BYTE oStopHours;
extern BYTE oStartMinutes;
extern BYTE oStopMinutes;
extern BYTE Sunriseh;
extern BYTE Sunseth;
extern BYTE Sunrisem;
extern BYTE Sunsetm;
extern BYTE SFlags;
extern char TODHours;
extern char TODMinutes;
extern char TODSeconds;
extern char TODHalfSeconds;
extern char TODYears;
extern char TODMonths;
extern char TODDates;
extern BYTE Days;
extern INT16 ctr[3];
extern char OFFString[52];
extern DWORD StartAddress;
extern BYTE SStf;
extern DWORD ictr;
extern char COffset[4];

extern unsigned char LockUUID[4];
extern unsigned char LockID[4];

//ProgPLM
extern void delay_us(UINT us);

extern void Init_Prog(void);
//extern void enter_3v_device(void);
//extern void P18_3v_bulk_erase (void);
//extern BYTE prog_code_2xJx0 (void);
//extern void prog_last_block (BYTE ha, BYTE la, WORD e, BYTE t);
//extern WORD read_3v_device(void);
//extern BYTE read_comm_val (BYTE comm);
//extern BYTE read_i2c_eeprom (WORD address);
//extern void set_addr_prt (BYTE u, BYTE h, BYTE l);
//extern void write_comm (BYTE comm);
//extern void  write_comm_val (BYTE comm, WORD val);
//extern void write_done_3V (void);
//extern void Stop_Prog(void);
//extern void ReadArray(BYTE* va, WORD wlen, WORD wad);
extern void WritePLMID(BYTE idh, BYTE idm, BYTE idl);
extern void WritePLMTest(WORD w1);
extern void LoRaModuleUpdate(void);
extern void CreateLastGood(void);
extern void UpdateLastGood(void);


extern BOOL bPLMFirmwareUpdate;
extern BOOL bHubFirmwareUpdate;
extern BOOL bValidDefaultUserName; // If the default username and default password were set
extern BOOL bValidUserName; // If the username and password are set
extern BOOL bStartRequest;
extern BOOL bInUpdating;
extern BOOL bInGetFirmware;

extern char uriHost[32];
extern char uriFile[64];
extern BYTE uriType; // 1: PIC32 Hex; 2: PLM; 3:RF; 4: Bin
extern BYTE uriFileValid;
extern char uriGetHost[32];
extern char uriGetFile[32];
extern BYTE uriGetFileValid;

extern unsigned long ulEpoch;
extern unsigned int uiMsgid;

extern char StrBuffer[80];
extern char HexStrBuffer[80];
extern BYTE ByteBuffer[40];
extern WORD_VAL wHexStr;
extern BYTE Macmax; // Add one byte name Macmax + Machi + Macmid + Maclo

extern DWORD BinCheckSum;
extern DWORD BinBytesCount;
extern DWORD BinBytesDone;
extern char UpdatingID[10];

extern char tsID[10];
extern char scID[10];
extern char opID[10];

extern char Uart6RXBuffer[40];
extern char Uart6TXBuffer[40];
extern unsigned char Uart6RXIndex;
extern char PLM6RxBuffer[50];
extern BYTE BuffIndex6;

extern char RandomNumber[8];
extern char RandomKey[32];

extern void PublishSN_KX(unsigned char index, char *strdata);
extern void CopyAllLockData(void);

extern BOOL bFailLockMD5;

extern UINT16 uiLinkedDeviceActive;
extern UINT16 uiLinkedDeviceTotal;
extern UINT16 uiMqttNoConnect;

#endif // _MAINDEMO_H
