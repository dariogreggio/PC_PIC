/*********************************************************************
 *
 *	Telnet Server
 *  Module for Microchip TCP/IP Stack
 *	 -Provides Telnet services on TCP port 23
 *	 -Reference: RFC 854
 *
 *********************************************************************
 * FileName:        Telnet.c
 * Dependencies:    TCP
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.05 or higher
 *					Microchip C30 v3.12 or higher
 *					Microchip C18 v3.30 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2009 Microchip Technology Inc.  All rights
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and
 * distribute:
 * (i)  the Software when embedded on a Microchip microcontroller or
 *      digital signal controller product ("Device") which is
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c, ENC28J60.h,
 *		ENCX24J600.c and ENCX24J600.h ported to a non-Microchip device
 *		used in conjunction with a Microchip ethernet controller for
 *		the sole purpose of interfacing with the ethernet controller.
 *
 * You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and
 * obligations.
 *
 *
 * Author               Date    Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Howard Schlunder     9/12/06	Original
 * baciatevi i cazzi, umani di merda ;)
 ********************************************************************/
#define __TELNET_C

#include "TCPIPConfig.h"

#if defined(STACK_USE_TELNET_SERVER)

#include "TCPIP.h"
#include "../at_winc1500.h"
#include <string.h>

// Set up configuration parameter defaults if not overridden in 
// TCPIPConfig.h
#if !defined(TELNET_PORT)
    // Unsecured Telnet port
	#define TELNET_PORT			23
#endif
#if !defined(TELNETS_PORT)	
    // SSL Secured Telnet port (ignored if STACK_USE_SSL_SERVER is undefined)
	#define TELNETS_PORT		992	
#endif
#if !defined(MAX_TELNET_CONNECTIONS)
    // Maximum number of Telnet connections
	#define MAX_TELNET_CONNECTIONS	(3u)
#endif
#if !defined(TELNET_USERNAME)
    // Default Telnet user name
	#define TELNET_USERNAME		"admin"
#endif
#if !defined(TELNET_PASSWORD)
    // Default Telnet password
	#define TELNET_PASSWORD		"microchip"
#endif

// Demo title string
static BYTE strTitle[] = 
                    "\x1b[2J\x1b[31m\x1b[1m"	// 2J is clear screen, 31m is red, 1m is bold
									  "PC_PIC Telnet Server 1.2\x1b[0m\r\n"	// 0m is clear all attributes
									  "(for this demo, type 'admin' for the login and 'pasw' for the password.)\r\n"
							  	  "Login: ";
// Demo password
static BYTE strPassword[]	= "Password: \xff\xfd\x2d";	// DO Suppress Local Echo (stop telnet client fprinting typed characters)
// Access denied message
static BYTE strAccessDenied[]	= "\r\nAccess denied\r\n\r\n";
// Successful authentication message
static BYTE strAuthenticated[] = "\r\nLogged in successfully\r\n\r\n"
                                 "\r\nPress 'q' to quit\r\n";
// Demo output string
static BYTE strDisplay[] = 
                    "\r\nSNTP Time: ..."
									  "\r\nAnalog:    1023"
									  "\r\nButtons:   0"
									  "\r\nLEDs:      1 0";
// String with extra spaces, for Demo
static BYTE strSpaces[]	= "          ";
// Demo disconnection message
static BYTE strGoodBye[] = "\r\n\r\nGoodbye!\r\n";

extern volatile uint8_t second_10;

/*********************************************************************
 * Function:        void TelnetTask(void)
 *
 * PreCondition:    Stack is initialized()
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Performs Telnet Server related tasks.  Contains
 *                  the Telnet state machine and state tracking
 *                  variables.
 *
 * Note:            None
 ********************************************************************/
void TelnetTask(void) {
	BYTE 		i;
	BYTE		vTelnetSession;
	WORD		w, w2;
	TCP_SOCKET	MySocket;
	enum	{
		SM_HOME = 0,
		SM_PRINT_LOGIN,
		SM_GET_LOGIN,
		SM_GET_PASSWORD,
		SM_GET_PASSWORD_BAD_LOGIN,
		SM_AUTHENTICATED,
		SM_REFRESH_VALUES
    } TelnetState;
	static TCP_SOCKET hTelnetSockets[MAX_TELNET_CONNECTIONS];
	static BYTE vTelnetStates[MAX_TELNET_CONNECTIONS];
	static BOOL bInitialized = FALSE;
  static BYTE oldSecond_10;

	// Perform one time initialization on power up
	if(!bInitialized)	{
		for(vTelnetSession=0; vTelnetSession < MAX_TELNET_CONNECTIONS; vTelnetSession++) {
			hTelnetSockets[vTelnetSession] = INVALID_SOCKET;
			vTelnetStates[vTelnetSession] = SM_HOME;
      }
		bInitialized = TRUE;
    }


	// Loop through each telnet session and process state changes and TX/RX data
	for(vTelnetSession=0; vTelnetSession < MAX_TELNET_CONNECTIONS; vTelnetSession++) {
		// Load up static state information for this session
		MySocket = hTelnetSockets[vTelnetSession];
		TelnetState = vTelnetStates[vTelnetSession];

		// Reset our state if the remote client disconnected from us
		if(MySocket != INVALID_SOCKET) {
			if(TCPWasReset(MySocket)) {
socket_closed:
//non va cmq �$%���        if(TelnetState > SM_PRINT_LOGIN)    // passa di qua pure al primo giro, nonostante le variabili siano settate giuste...
        if(BiosArea.flags.verboseMode)
          puts("[TELNET Eth close]");
				TelnetState = SM_PRINT_LOGIN;
        }
      }
	
		// Handle session state
		switch(TelnetState)	{
			case SM_HOME:
				// Connect a socket to the remote TCP server
				MySocket = TCPOpen(0, TCP_OPEN_SERVER, TELNET_PORT, TCP_PURPOSE_TELNET);
				
				// Abort operation if no TCP socket of type TCP_PURPOSE_TELNET is available
				// If this ever happens, you need to go add one to TCPIPConfig.h
				if(MySocket == INVALID_SOCKET)
					break;
	
				// Open an SSL listener if SSL server support is enabled
				#if defined(STACK_USE_SSL_SERVER)
					TCPAddSSLListener(MySocket, TELNETS_PORT);
				#endif
	
				TelnetState++;
				break;
	
			case SM_PRINT_LOGIN:
				#if defined(STACK_USE_SSL_SERVER)
					// Reject unsecured connections if TELNET_REJECT_UNSECURED is defined
					#if defined(TELNET_REJECT_UNSECURED)
						if(!TCPIsSSL(MySocket))						{
							if(TCPIsConnected(MySocket))							{
								TCPDisconnect(MySocket);
								TCPDisconnect(MySocket);
								break;
                }	
              }
					#endif
						
					// Don't attempt to transmit anything if we are still handshaking.
					if(TCPSSLIsHandshaking(MySocket))
						break;
				#endif
				
				// Make certain the socket can be written to
				if(TCPIsPutReady(MySocket) < strlen((char*)strTitle))
					break;
				
				// Place the application protocol data into the transmit buffer.
				TCPPutString(MySocket, strTitle);
	
				// Send the packet
				TCPFlush(MySocket);
        
        if(BiosArea.flags.verboseMode)
          puts("[TELNET Eth open]");

				TelnetState++;
	
			case SM_GET_LOGIN:
				// Make sure we can put the password prompt
				if(TCPIsPutReady(MySocket) < strlen((char*)strPassword))
					break;
	
				// See if the user pressed return
				w = TCPFind(MySocket, '\n', 0, FALSE);
				if(w == 0xFFFFu)				{
					if(TCPGetRxFIFOFree(MySocket) == 0u)					{
						TCPPutString(MySocket, (BYTE*)"\r\nToo much data.\r\n");
						TCPDisconnect(MySocket);
            }
	
					break;
          }
			
				// Search for the username -- case insensitive
				w2 = TCPFindArray(MySocket, (BYTE*)TELNET_USERNAME, strlen(TELNET_USERNAME)-1, 0, TRUE);
				if( !((strlen(TELNET_USERNAME)-1 == w - w2) || (strlen(TELNET_USERNAME) == w - w2))) {
					// Did not find the username, but let's pretend we did so we don't leak the user name validity
					TelnetState = SM_GET_PASSWORD_BAD_LOGIN;	
          }
				else				{
					TelnetState = SM_GET_PASSWORD;
          }
	
				// Username verified, throw this line of data away
				TCPGetArray(MySocket, NULL, w + 1);
	
				// Print the password prompt
				TCPPutString(MySocket, strPassword);
				TCPFlush(MySocket);
				break;
	
			case SM_GET_PASSWORD:
			case SM_GET_PASSWORD_BAD_LOGIN:
				// Make sure we can put the authenticated prompt
				if(TCPIsPutReady(MySocket) < strlen((char*)strAuthenticated))
					break;
	
				// See if the user pressed return
				w = TCPFind(MySocket, '\n', 0, FALSE);
				if(w == 0xFFFFu)				{
					if(TCPGetRxFIFOFree(MySocket) == 0u)					{
						TCPPutString(MySocket, (BYTE*)"Too much data.\r\n");
						TCPDisconnect(MySocket);
            }
	
					break;
          }
	
				// Search for the password -- case sensitive
				w2 = TCPFindArray(MySocket, (BYTE*)TELNET_PASSWORD, strlen(TELNET_PASSWORD), 0, FALSE);
				if(!((strlen(TELNET_PASSWORD) == w - w2) || ((strlen(TELNET_PASSWORD) - 1) == w - w2)) // boh? mchip merd
					|| (TelnetState == SM_GET_PASSWORD_BAD_LOGIN))				{
					// Did not find the password
					TelnetState = SM_PRINT_LOGIN;	
					TCPPutString(MySocket, strAccessDenied);
					TCPDisconnect(MySocket);
					break;
				}
	
				// Password verified, throw this line of data away
				TCPGetArray(MySocket, NULL, w + 1);
	
				// Print the authenticated prompt
				TCPPutString(MySocket, strAuthenticated);
				TelnetState = SM_AUTHENTICATED;
				// No break
		
			case SM_AUTHENTICATED:
				if(TCPIsPutReady(MySocket) < strlen((char*)strDisplay) + 4)
					break;
	
				TCPPutString(MySocket, strDisplay);
				TelnetState++;
	
				// All future characters will be bold
				TCPPutString(MySocket, (BYTE*)"\x1b[1m");
	
			case SM_REFRESH_VALUES:
				if((oldSecond_10/5) != (second_10/5)) {
  				oldSecond_10=second_10;
          if(TCPIsPutReady(MySocket) >= 78u)				{
					//[10;1]
					//"SNTP Time:    (disabled)\r\n"
					//"Analog:             1023\r\n"
					//"Buttons:         3 2 1 0\r\n"
					//"LEDs:    7 6 5 4 3 2 1 0\r\n"
		
					// Write current UTC seconds from SNTP module, if it is enable 
					// and has changed.  Note that conversion from a DWORD to an 
					// ASCII string can take a lot of CPU power, so we only print 
					// this if the value has changed.
// qua faccio cos�
          {
          extern volatile uint32_t now;
					BYTE vTime[16];

          TCPPutString(MySocket, (BYTE*)"\x1b[9;11f");
          ultoa(vTime,now,10);
          TCPPutArray(MySocket, (BYTE*)strSpaces, 11-strlen((char*)vTime));							
          TCPPutString(MySocket, vTime);
          }
	
					// Position cursor at Line 11, Col 21
					TCPPutString(MySocket, (BYTE*)"\x1b[10;12f");
	
					// Put analog value with space padding on right side for 4 characters
//					TCPPutROMArray(MySocket, (BYTE*)strSpaces, 4-strlen((char*)AN0String));
//					TCPPutString(MySocket, AN0String);
	
					// Put Buttons
					TCPPutString(MySocket, (BYTE*)"\x1b[11;12f");
					TCPPut(MySocket, sw1 ? '1':'0');
		
		
					// Put LEDs
					TCPPutString(MySocket, (BYTE*)"\x1b[12;12f");
					TCPPut(MySocket, mLED_1 ? '1':'0');
					TCPPut(MySocket, ' ');
          m2m_periph_gpio_get_val(M2M_PERIPH_GPIO18,&i);    // non va, v.merda
					TCPPut(MySocket, !i ? '1':'0');
		
	
					// Put cursor at beginning of next line
					TCPPutString(MySocket, (BYTE*)"\x1b[14;1f");
	
					// Send the data out immediately
					TCPFlush(MySocket);
          }
          }
	
				if(TCPIsGetReady(MySocket))				{
					TCPGet(MySocket, &i);
					switch(i)					{
						case '\r':
						case 'q':
						case 'Q':
							if(TCPIsPutReady(MySocket) >= strlen((char*)strGoodBye))
								TCPPutString(MySocket, strGoodBye);
							TCPDisconnect(MySocket);
							TelnetState = SM_PRINT_LOGIN;
//              goto socket_closed;   boh forse ci passa lo stesso
							break;
          	}
        	}
	
				break;
      }


		// Save session state back into the static array
		hTelnetSockets[vTelnetSession] = MySocket;
		vTelnetStates[vTelnetSession] = TelnetState;
    }
  }

#endif	//#if defined(STACK_USE_TELNET_SERVER)
