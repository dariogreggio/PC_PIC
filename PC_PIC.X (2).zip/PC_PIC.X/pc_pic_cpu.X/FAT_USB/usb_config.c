/*
********************************************************************************
                                                                                
Software License Agreement                                                      
                                                                                
Copyright � 2007-2008 Microchip Technology Inc.  All rights reserved.           
                                                                                
Microchip licenses to you the right to use, modify, copy and distribute Software
only when embedded on a Microchip microcontroller or digital signal controller  
that is integrated into your product or third party product (pursuant to the    
sublicense terms in the accompanying license agreement).                        
                                                                                
You should refer to the license agreement accompanying this Software for        
additional information regarding your rights and obligations.                   
                                                                                
https://www.microchip.com/forums/m518341.aspx per webcam
********************************************************************************
*/

// Created by the Microchip USBConfig Utility, Version 2.0.0.0, 11/18/2008, 8:08:56

#include "GenericTypeDefs.h"
#include "pc_pic_cpu.h"
#include "../harmony_pic32mz/usb_host.h"
#include "../harmony_pic32mz/usb_host_msd.h"

// *****************************************************************************
// Media Interface Function Pointer Table for the Mass Storage client driver
// *****************************************************************************

CLIENT_DRIVER_TABLE usbMediaInterfaceTable = {                                           
    USBHostMSDSCSIInitialize,
    USBHostMSDSCSIEventHandler,
    0
};

// *****************************************************************************
// Client Driver Function Pointer Table for the USB Embedded Host foundation
// *****************************************************************************

CLIENT_DRIVER_TABLE usbClientDrvTable[] = {                                        
    {
        USBHostMSDInitialize,
        USBHostMSDEventHandler,
        0
    }
};

// *****************************************************************************
// USB Embedded Host Targeted Peripheral List (TPL)
// *****************************************************************************

USB_TPL usbTPL[] = {
    { INIT_CL_SC_P( 8ul, 6ul, 0x50ul ), 0, 0, {TPL_CLASS_DRV} } // Most types of MSD flash drives
    ,
    { INIT_CL_SC_P( 8ul, 5ul, 0x50ul ), 0, 0, {TPL_CLASS_DRV} } // Some MSD flash drives use this instead
};



/*
// per webcam: https://www.microchip.com/forums/m518341.aspx
CLIENT_DRIVER_TABLE usbClientDrvTable[] = { 
     { 
         USBHostUVCInitialize, 
         USBHostUVCEventHandler, 
         0 
     } 
 }; 

BOOL USBHostUVCEventHandler( BYTE address, USB_EVENT event, void *data, DWORD size ) { 
     ISOCHRONOUS_DATA_BUFFER * isoc_buf; 
 
     switch ( event ) { 
         case EVENT_TRANSFER; 
             isoc_buf = (ISOCHRONOUS_DATA_BUFFER *)(((HOST_TRANSFER_DATA *)data)->pUserData); 
                                                 // process data on the buffer for single transaction 
             // isoc_buf->pBuffer                //   data buffer pointer 
             // isoc_buf->dataLength             //   bytes on the buffer 
 
             isoc_buf->bfDataLengthValid = 0;    // drop the valid flag of this buffer 
             break; 
     } 
 }


usare USBHostReadIsochronous() nel codice
if(USBHostIsochronousBuffersCreate(cam_buf,USB_MAX_ISOCHRONOUS_DATA_BUFFERS,0x0200) == TRUE)

e

RetVal = USBHostReadIsochronous(1,0x82,cam_buf);



"forse":
USB_TPL usbTPL[] = {
    {  SC_VIDEOCONTROL 1 ( 8ul, 6ul, 0x50ul ), 0, 0, {TPL_CLASS_DRV} } // Most types of MSD flash drives
    ,
    { INIT_CL_SC_P( 8ul, 5ul, 0x50ul ), 0, 0, {TPL_CLASS_DRV} } // Some MSD flash drives use this instead
};

*/


