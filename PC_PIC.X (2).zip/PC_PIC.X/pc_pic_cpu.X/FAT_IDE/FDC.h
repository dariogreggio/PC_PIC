// -----------------------------------------------------------------------------
// 3.5"/5.25" DD/HD Disk controller for Arduino
// Copyright (C) 2021 David Hansel
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software Foundation,
// Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA

// ..and you should be dead by now ;) :D #cancerarduino

//	2022 adapted for PC_PIC by G.Dar
// -----------------------------------------------------------------------------

#ifndef ARDUINOFDC_H
#define ARDUINOFDC_H

#include <xc.h>
#include "generictypedefs.h"
//#include "../pc_pic_cpu.h"

// return status for readSector/writeSector and formatDisk functions
#define S_OK         0  // no error
#define S_NOTINIT    1  // ArduinoFDC.begin() was not called
#define S_NOTREADY   2  // Drive is not ready (no disk or power)
#define S_NOSYNC     3  // No sync marks found
#define S_NOHEADER   4  // Sector header not found
#define S_INVALIDID  5  // Sector data record has invalid id
#define S_CRC        6  // Sector data checksum error
#define S_NOTRACK0   7  // No track0 signal
#define S_VERIFY     8  // Verify after write failed
#define S_READONLY   9  // Attempt to write to a write-protected disk


enum FDCDevice_DriveType {
    DT_5_DD,     // 5.25" double density (360 KB) 
    DT_5_DDonHD, // 5.25" double density disk in high density drive (360 KB)
    DT_5_HD,     // 5.25" high density (1.2 MB)
    DT_3_DD,     // 3.5"  double density (720 KB)
    DT_3_HD      // 3.5"  high density (1.44 MB)
  };

enum FDCDevice_DensityPinMode {
    DP_DISCONNECT = 0,    // density pin disconnected (set to INPUT mode)
    DP_OUTPUT_LOW_FOR_HD, // density pin goes LOW for high density disk
    DP_OUTPUT_LOW_FOR_DD  // density pin goes LOW for double density disk
  };
  
struct FDCDevice_DriveGeometryStruct {
  BYTE numTracks;
  BYTE numSectors;
  BYTE dataGap;
  BYTE trackSpacing;
	};

typedef struct __attribute((packed)) _FDC_DEVICE {
  enum FDCDevice_DriveType m_driveType[2];
  enum FDCDevice_DensityPinMode m_densityPinMode[2];
  BYTE m_currentDrive, m_bitLength[2];
  BOOL m_initialized, m_motorState[2];
    } FDCDevice;

  void FDCDevice_FDCDevice(FDCDevice *);
  
  // Initialize pins used for controlling the disk drive
  void FDCDevice_begin(FDCDevice *,enum FDCDevice_DriveType driveAType, enum FDCDevice_DriveType driveBType);

  // Release pins used for controlling the disk drive
  void FDCDevice_end(FDCDevice *);

  // Select drive A(0) or B(1). 
  BOOL FDCDevice_selectDrive(FDCDevice *,BYTE drive);
  
  // Returns which drive is currently selected, A (0) or B (1)
  BYTE FDCDevice_selectedDrive(FDCDevice *);

  // set the drive type for the currently selected drive
  void FDCDevice_setDriveType(FDCDevice *,enum FDCDevice_DriveType type);

  // get the type of the currently selected drive
  enum FDCDevice_DriveType getDriveType(FDCDevice *);

  // returns true if a disk is detected in the drive
  BOOL FDCDevice_haveDisk(FDCDevice *);
  
  // returns true if the disk is write protected
  BOOL FDCDevice_isWriteProtected(FDCDevice *);

  // get number of tracks for the currently selected drive
  BYTE FDCDevice_numTracks(FDCDevice *);

  // get number of sectors for the currently selected drive
  BYTE FDCDevice_numSectors(FDCDevice *);

  // set the density pin mode for the currently selected drive
  void FDCDevice_setDensityPinMode(FDCDevice *,enum FDCDevice_DensityPinMode mode);
  
  // Read a sector from disk,
  // buffer MUST have a size of at least 516 BYTEs. 
  // IMPORTANT: On successful return, the 512 BYTEs of sector data 
  //            read will be in buffer[1..512] (NOT: 0..511!)
  // See error codes above for possible return values
  BYTE FDCDevice_readSector(FDCDevice *,BYTE track, BYTE side, BYTE sector, BYTE *buffer);

  // Write a sector to disk,
  // buffer MUST have a size of at least 516 BYTEs.
  // IMPORTANT: The 512 BYTEs of sector data to be written
  //            must be in buffer[1..512] (NOT: 0..511!)
  // if "verify" is true then the data will be re-read after writing
  // and compared to the data just written.
  // See error codes above for possible return values
  BYTE FDCDevice_writeSector(FDCDevice *,BYTE track, BYTE side, BYTE sector, BYTE *buffer, BOOL verify);

  // Formats a disk
  // buffer is needed to store temporary data while formatting and MUST have
  // a size of at least 144 BYTEs.
  // All sector data is initialized with 0xF6.
  // See error codes above for possible return values
  // IMPORTANT: No DOS file system is initialized, i.e. DOS or Windows
  //            will NOT recognize this as a valid disk
  BYTE FDCDevice_formatDisk(FDCDevice *,BYTE *buffer, BYTE fromTrack /*=0*/, BYTE toTrack /*=255*/);

  // Turn the disk drive motor on. The readSector/writeSector/formatDisk 
  // functions will turn on the motor automatically if it is not running 
  // yet. In that case (and ONLY then) they will also turn it off when finished.
  void FDCDevice_motorOn(FDCDevice *);

  // Turn the disk drive motor off
  void FDCDevice_motorOff(FDCDevice *);

  // Returns true if the disk drive motor is currently running
  BOOL FDCDevice_motorRunning(FDCDevice *);

  void FDCDevice_driveSelect(FDCDevice *,BOOL state);
  void FDCDevice_setDensityPin(FDCDevice *);
  BYTE FDCDevice_getBitLength(FDCDevice *);


#endif
