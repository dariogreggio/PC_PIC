/* Arduino IDEFat Library
 * Copyright (C) 2009 by William Greiman
 * 
 * 2022 version for PC_PIC by KatiaG
 *
 * This file is part of the Arduino IDEFat Library
 *
 * This Library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This Library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS for A PARTICULAR PURPOSE.  See the
 * GNU General Public License formore details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Arduino IDEFat Library.  ifnot, see
 * <http://www.gnu.org/licenses/>.
 */
#include "IDEFat.h"

//------------------------------------------------------------------------------
// raw block cache
// init cacheBlockNumber_to invalid SD block number
uint32_t IDEVolume_cacheBlockNumber_ = 0XFFFFFFFF;
cache_t  IDEVolume_cacheBuffer_;     // 512 byte cache forIDE
IDE* IDEVolume_ideDrive_;          // pointer to SD card object
uint8_t  IDEVolume_cacheDirty_ = 0;  // cacheFlush() will write block ifTRUE
uint32_t IDEVolume_cacheMirrorBlock_ = 0;  // mirror  block forsecond FAT

//==============================================================================
// IDEVolume class

//------------------------------------------------------------------------------
/**
 * \class IDEVolume
 * \brief Access FAT16 and FAT32 volumes on SD and SDHC cards.
 */

  /** Create an instance of IDEVolume */
void IDEVolume_IDEVolume(IDEVolume *vol) { 

  vol->allocSearchStart_=2;
  vol->fatType_=0; 
  }
  
  /** Clear the cache and returns a pointer to the cache.  Used by the WaveRP
   *  recorder to do raw write to the SD card.  Not for normal apps.
   */
uint8_t* IDEVolume_cacheClear(IDEVolume *vol) {
      
  IDEVolume_cacheFlush(vol);
  vol->cacheBlockNumber_ = 0XFFFFFFFF;
  return vol->cacheBuffer_.data;
  }

  /**
   * Initialize a FAT volume.  Try partition one first then try super
   * floppy format.
   *
   * \param[in] dev The IDE2Card where the volume is located.
   *
   * \return The value one, true, is returned for success and
   * the value zero, false, is returned for failure.  Reasons for
   * failure include not finding a valid partition, not finding a valid
   * FAT file system or an I/O error.
   */
  uint8_t IDEVolume_init2(IDEVolume *vol,IDE *dev,uint8_t part);
  uint8_t IDEVolume_init(IDEVolume *vol,IDE* dev) { 
    return IDEVolume_init2(vol,dev, 1) ? TRUE : IDEVolume_init2(vol,dev, 0); 
    }

  // inline functions that return volume info
  /** \return The volume's cluster size in blocks. */
  uint8_t IDEVolume_blocksPerCluster(IDEVolume *vol) {return vol->blocksPerCluster_;}
  /** \return The number of blocks in one FAT. */
  uint32_t IDEVolume_blocksPerFat(IDEVolume *vol)  {return vol->blocksPerFat_;}
  /** \return The total number of clusters in the volume. */
  uint32_t IDEVolume_clusterCount(IDEVolume *vol) {return vol->clusterCount_;}
  /** \return The shift count required to multiply by blocksPerCluster. */
  uint8_t IDEVolume_clusterSizeShift(IDEVolume *vol) {return vol->clusterSizeShift_;}
  /** \return The logical block number for the start of file data. */
  uint32_t IDEVolume_dataStartBlock(IDEVolume *vol) {return vol->dataStartBlock_;}
  /** \return The number of FAT structures on the volume. */
  uint8_t IDEVolume_fatCount(IDEVolume *vol) {return vol->fatCount_;}
  /** \return The logical block number for the start of the first FAT. */
  uint32_t IDEVolume_fatStartBlock(IDEVolume *vol) {return vol->fatStartBlock_;}
  /** \return The FAT type of the volume. Values are 12, 16 or 32. */
  uint8_t IDEVolume_fatType(IDEVolume *vol) {return vol->fatType_;}
  /** \return The number of entries in the root directory for FAT16 volumes. */
  uint32_t IDEVolume_rootDirEntryCount(IDEVolume *vol) {return vol->rootDirEntryCount_;}
  /** \return The logical block number for the start of the root directory
       on FAT16 volumes or the first cluster number on FAT32 volumes. */
  uint32_t IDEVolume_rootDirStart(IDEVolume *vol) {return vol->rootDirStart_;}
  /** return a pointer to the IDE object for this volume */
  static IDE* IDEVolume_ideDrive(IDEVolume *vol) {return vol->ideDrive_;}

//------------------------------------------------------------------------------
  // Allow IDEFile access to IDEVolume private data.

  //----------------------------------------------------------------------------
  uint8_t IDEVolume_allocContiguous(IDEVolume *vol,uint32_t count, uint32_t* curCluster);
  uint8_t IDEVolume_blockOfCluster(IDEVolume *vol,uint32_t position) {
          return (position >> 9) & (vol->blocksPerCluster_ - 1);
    }
  uint32_t IDEVolume_clusterStartBlock(IDEVolume *vol,uint32_t cluster) {
           return vol->dataStartBlock_ + ((cluster - 2) << vol->clusterSizeShift_); 
    }
  uint32_t IDEVolume_blockNumber(IDEVolume *vol,uint32_t cluster, uint32_t position) {
           return IDEVolume_clusterStartBlock(vol,cluster) + IDEVolume_blockOfCluster(vol,position);
    }
  uint8_t IDEVolume_cacheFlush(IDEVolume *vol);
  uint8_t IDEVolume_cacheRawBlock(IDEVolume *vol,uint32_t blockNumber, uint8_t action);
  void IDEVolume_cacheSetDirty(IDEVolume *vol) { vol->cacheDirty_ |= CACHE_FOR_WRITE; }
  uint8_t IDEVolume_cacheZeroBlock(IDEVolume *vol,uint32_t blockNumber);
  uint8_t IDEVolume_chainSize(IDEVolume *vol,uint32_t beginCluster, uint32_t* size);
  uint8_t IDEVolume_fatGet(IDEVolume *vol,uint32_t cluster, uint32_t* value);
  uint8_t IDEVolume_fatPut(IDEVolume *vol,uint32_t cluster, uint32_t value);
  uint8_t IDEVolume_fatPutEOC(IDEVolume *vol,uint32_t cluster) {
    return IDEVolume_fatPut(vol,cluster, 0x0FFFFFFF);
    }
  uint8_t IDEVolume_freeChain(IDEVolume *vol,uint32_t cluster);
  uint8_t IDEVolume_isEOC(IDEVolume *vol,uint32_t cluster) {
    return cluster >= (vol->fatType_ == 16 ? FAT16EOC_MIN : FAT32EOC_MIN);
    }
  uint8_t IDEVolume_readBlock(IDEVolume *vol,uint32_t block, uint8_t* dst) {
    return IDE_readBlock(vol->ideDrive_, block, dst);}
  uint8_t IDEVolume_readData(IDEVolume *vol,uint32_t block, uint16_t offset,
    uint16_t count, uint8_t* dst) {
      return IDE_readData(vol->ideDrive_, block, offset, count, dst);
  }
  uint8_t IDEVolume_writeBlock(IDEVolume *vol,uint32_t block, const uint8_t* dst) {
    return IDE_writeBlock(vol->ideDrive_, block, dst);
  }

//------------------------------------------------------------------------------
// find a contiguous group of clusters
uint8_t IDEVolume_allocContiguous(IDEVolume *vol,uint32_t count, uint32_t* curCluster) {
  // start of group
  uint32_t bgnCluster;
  uint32_t n;

  // flag to save place to start next search
  uint8_t setStart;

  // set search start cluster
  if(*curCluster) {
    // try to make file contiguous
    bgnCluster = *curCluster + 1;

    // don't save new start location
    setStart = FALSE;
		} 
	else {
    // start at likely place forfree cluster
    bgnCluster = vol->allocSearchStart_;

    // save next search start ifone cluster
    setStart = 1 == count;
		}
  // end of group
  uint32_t endCluster = bgnCluster;

  // last cluster of FAT
  uint32_t fatEnd = vol->clusterCount_ + 1;

  // search the FAT forfree clusters
  for(n=0; ; n++, endCluster++) {
    // can't find space checked all clusters
    if(n >= vol->clusterCount_)
      return FALSE;

    // past end - start from beginning of FAT
    if(endCluster > fatEnd) {
      bgnCluster = endCluster = 2;
			}
    uint32_t f;
    if(!IDEVolume_fatGet(vol,endCluster, &f)) 
			return FALSE;

    if(f!=0) {
      // cluster in use try next cluster as bgnCluster
      bgnCluster = endCluster + 1;
	    } 
		else if((endCluster - bgnCluster + 1) == count) {
      // done - found space
      break;
			}
		}
  // mark end of chain
  if(!IDEVolume_fatPutEOC(vol,endCluster)) 
		return FALSE;

  // link clusters
  while(endCluster > bgnCluster) {
    if(!IDEVolume_fatPut(vol,endCluster - 1, endCluster)) 
			return FALSE;
    endCluster--;
		}
  if(*curCluster != 0) {
    // connect chains
    if(!IDEVolume_fatPut(vol,*curCluster, bgnCluster)) 
			return FALSE;
	  }
  // return first cluster number to caller
  *curCluster = bgnCluster;

  // remember possible next free cluster
  if(setStart) 
		vol->allocSearchStart_ = bgnCluster + 1;

  return TRUE;
	}

//------------------------------------------------------------------------------
uint8_t IDEVolume_cacheFlush(IDEVolume *vol) {

  if(vol->cacheDirty_) {
    if(!IDE_writeBlock(vol->ideDrive_,vol->cacheBlockNumber_, IDEVolume_cacheBuffer_.data)) {
      return FALSE;
			}
    // mirror FAT tables
    if(vol->cacheMirrorBlock_) {
      if(!IDE_writeBlock(vol->ideDrive_,vol->cacheMirrorBlock_, IDEVolume_cacheBuffer_.data)) {
        return FALSE;
		    }
      vol->cacheMirrorBlock_ = 0;
			}
    vol->cacheDirty_ = 0;
		}
  return TRUE;
	}

//------------------------------------------------------------------------------
uint8_t IDEVolume_cacheRawBlock(IDEVolume *vol,uint32_t blockNumber, uint8_t action) {

  if(vol->cacheBlockNumber_ != blockNumber) {
    if(!IDEVolume_cacheFlush(vol)) 
			return FALSE;
    if(!IDEVolume_readBlock(vol,blockNumber, IDEVolume_cacheBuffer_.data))
      return FALSE;
    vol->cacheBlockNumber_ = blockNumber;
	  }
  vol->cacheDirty_ |= action;
  return TRUE;
	}

//------------------------------------------------------------------------------
// cache a zero block forblockNumber
uint8_t IDEVolume_cacheZeroBlock(IDEVolume *vol,uint32_t blockNumber) {
	uint16_t i;

  if(!IDEVolume_cacheFlush(vol)) 
		return FALSE;

  // loop take less flash than memset(IDEVolume_cacheBuffer_.data, 0, 512);
  for(i=0; i < 512; i++) {
    IDEVolume_cacheBuffer_.data[i] = 0;
		}
  vol->cacheBlockNumber_ = blockNumber;
  IDEVolume_cacheSetDirty(vol);
  
  return TRUE;
	}

//------------------------------------------------------------------------------
// return the size in bytes of a cluster chain
uint8_t IDEVolume_chainSize(IDEVolume *vol,uint32_t cluster, uint32_t* size) {
  uint32_t s = 0;

  do {
    if(!IDEVolume_fatGet(vol, cluster, &cluster)) 
			return FALSE;
    s += 512UL << vol->clusterSizeShift_;
	  } while(!IDEVolume_isEOC(vol,cluster));
  *size = s;
  
  return TRUE;
	}

//------------------------------------------------------------------------------
// Fetch a FAT entry
uint8_t IDEVolume_fatGet(IDEVolume *vol,uint32_t cluster, uint32_t* value) {

  if(cluster > (vol->clusterCount_ + 1)) 
		return FALSE;
  uint32_t lba = vol->fatStartBlock_;
  lba += vol->fatType_ == 16 ? cluster >> 8 : cluster >> 7;
  if(lba != vol->cacheBlockNumber_) {
    if(!IDEVolume_cacheRawBlock(vol,lba, CACHE_FOR_READ)) 
			return FALSE;
		}
  if(vol->fatType_ == 16) {
    *value = IDEVolume_cacheBuffer_.fat16[cluster & 0xFF];
		} 
	else {
    *value = IDEVolume_cacheBuffer_.fat32[cluster & 0x7F] & FAT32MASK;
		}
  return TRUE;
	}

//------------------------------------------------------------------------------
// Store a FAT entry
uint8_t IDEVolume_fatPut(IDEVolume *vol,uint32_t cluster, uint32_t value) {

  // error if reserved cluster
  if(cluster < 2) 
		return FALSE;

  // error ifnot in FAT
  if(cluster > (vol->clusterCount_ + 1)) 
		return FALSE;

  // calculate block address forentry
  uint32_t lba = vol->fatStartBlock_;
  lba += vol->fatType_ == 16 ? cluster >> 8 : cluster >> 7;

  if(lba != vol->cacheBlockNumber_) {
    if(!IDEVolume_cacheRawBlock(vol,lba, CACHE_FOR_READ)) 
			return FALSE;
		}
  // store entry
  if(vol->fatType_ == 16) {
    IDEVolume_cacheBuffer_.fat16[cluster & 0xFF] = value;
		} 
	else {
    IDEVolume_cacheBuffer_.fat32[cluster & 0x7F] = value;
		}
  IDEVolume_cacheSetDirty(vol);

  // mirror second FAT
  if(vol->fatCount_ > 1) 
		vol->cacheMirrorBlock_ = lba + vol->blocksPerFat_;
  
  return TRUE;
	}

//------------------------------------------------------------------------------
// free a cluster chain
uint8_t IDEVolume_freeChain(IDEVolume *vol,uint32_t cluster) {
  
  // clear free cluster location
  vol->allocSearchStart_ = 2;

  do {
    uint32_t next;
    if(!IDEVolume_fatGet(vol,cluster, &next)) 
      return FALSE;

    // free cluster
    if(!IDEVolume_fatPut(vol,cluster, 0)) 
      return FALSE;

    cluster = next;
    } while(!IDEVolume_isEOC(vol,cluster));

  return TRUE;
  }

//------------------------------------------------------------------------------
/**
 * Initialize a FAT volume.
 *
 * \param[in] dev The SD card where the volume is located.
 *
 * \param[in] part The partition to be used.  Legal values for \a part are
 * 1-4 to use the corresponding partition on a device formatted with
 * a MBR, Master Boot Record, or zero if the device is formatted as
 * a super floppy with the FAT boot sector in block zero.
 *
 * \return The value one, TRUE, is returned for success and
 * the value zero, FALSE, is returned forfailure.  Reasons for
 * failure include not finding a valid partition, not finding a valid
 * FAT file system in the specified partition or an I/O error.
 */
uint8_t IDEVolume_init2(IDEVolume *vol, IDE *dev, uint8_t part) {
  uint32_t volumeStartBlock = 0;
  
  vol->ideDrive_ = dev;

  // ifpart == 0 assume super floppy with FAT boot sector in block zero
  // ifpart > 0 assume mbr volume with partition table
  if(part) {
    if(part > 4)
			return FALSE;
    if(!IDEVolume_cacheRawBlock(vol,volumeStartBlock, CACHE_FOR_READ)) 
			return FALSE;
    part_t* p = &IDEVolume_cacheBuffer_.mbr.part[part-1];
    if((p->boot & 0X7F) !=0  ||
      p->totalSectors < 100 ||
      p->firstSector == 0) {
      // not a valid partition
      return FALSE;
			}
    volumeStartBlock = p->firstSector;
		}
  if(!IDEVolume_cacheRawBlock(vol,volumeStartBlock, CACHE_FOR_READ)) 
		return FALSE;
  bpb_t* bpb = &IDEVolume_cacheBuffer_.fbs.bpb;
  if(bpb->bytesPerSector != 512 ||
    bpb->fatCount == 0 ||
    bpb->reservedSectorCount == 0 ||
    bpb->sectorsPerCluster == 0) {
       // not valid FAT volume
    return FALSE;
		}
  vol->fatCount_ = bpb->fatCount;
  vol->blocksPerCluster_ = bpb->sectorsPerCluster;

  // determine shift that is same as multiply by blocksPerCluster_
  vol->clusterSizeShift_ = 0;
  while(vol->blocksPerCluster_ != (1 << vol->clusterSizeShift_)) {
    // error ifnot power of 2
    if(vol->clusterSizeShift_++ > 7) 
			return FALSE;
		}
  vol->blocksPerFat_ = bpb->sectorsPerFat16 ?
                    bpb->sectorsPerFat16 : bpb->sectorsPerFat32;

  vol->fatStartBlock_ = volumeStartBlock + bpb->reservedSectorCount;

  // count forFAT16 zero forFAT32
  vol->rootDirEntryCount_ = bpb->rootDirEntryCount;

  // directory start forFAT16 dataStart forFAT32
  vol->rootDirStart_ = vol->fatStartBlock_ + bpb->fatCount * vol->blocksPerFat_;

  // data start forFAT16 and FAT32
  vol->dataStartBlock_ = vol->rootDirStart_ + ((32 * bpb->rootDirEntryCount + 511)/512);

  // total blocks forFAT16 or FAT32
  uint32_t totalBlocks = bpb->totalSectors16 ?
                           bpb->totalSectors16 : bpb->totalSectors32;
  // total data blocks
  vol->clusterCount_ = totalBlocks - (vol->dataStartBlock_ - volumeStartBlock);

  // divide by cluster size to get cluster count
  vol->clusterCount_ >>= vol->clusterSizeShift_;

  // FAT type is determined by cluster count
  if(vol->clusterCount_ < 4085) {
    vol->fatType_ = 12;
		}
	else if(vol->clusterCount_ < 65525) {
    vol->fatType_ = 16;
		}
	else {
    vol->rootDirStart_ = bpb->fat32RootCluster;
    vol->fatType_ = 32;
		}
  return TRUE;
	}

