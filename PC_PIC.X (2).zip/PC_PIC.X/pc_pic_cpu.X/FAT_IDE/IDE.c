/**
 * Arduino IDE for MEGA Library
 * Copyright (C) 2011 Gene Toye
 * 
 * 2022 version for PC_PIC by KatiaG
 *
 * This Library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This Library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Arduino IDEFat Library.  ifnot, see
 * <http://www.gnu.org/licenses/>.
 */
 
/**
 * This implementation is based on ideas presented at
 * http://www.pjrc.com/tech/8051/ide/index.html
 */
 
#include "IDE.h"


/**
 * Public Methods
 */
 
/**
 * Initialize ide interface and reset ide device
 */
uint8_t IDE_init(IDE* dev) {
  
  // always output on PA for control lines
  TRISFbits.TRISF8 = 0; // DA0
  TRISGbits.TRISG12 = 0; // DA1
  TRISGbits.TRISG13 = 0; // DA2
  
//  TRISB &= 0b0000000011111111;
  TRISB |= 0b0000000011111111;
#warning ANDREBBERO tutti e 16 (v. write16) ma l� c � la SD...
#warning e quindi togliere SPI SD!
  
  // Set active low lines to high
  LATFbits.LATF8 = 1; 
  LATGbits.LATG12 = 1; 
  LATGbits.LATG13 = 1; 
  // B11000111

  IDE_writeIDEWord(dev,0, TRUE);

  // Initialize IDE
  IDE_ideReset(dev);
  
  IDE_ideInit(dev);
  
  return TRUE;
	}

/**
 * Read single 512 byte sector at LBA blockNumber, storing at dst.
 */
uint8_t IDE_readBlock(IDE* dev,uint32_t blockNumber, uint8_t* dst) {
  
  dev->ideError =  IDE_ideReadSector(dev,blockNumber);

  memcpy(dst, dev->ide_data, sizeof(dev->ide_data));
  
  if(!dev->ideError)
    return TRUE;
  else
    return FALSE;
  }

uint8_t IDE_readData(IDE* dev,uint32_t block, uint16_t offset, uint16_t count, uint8_t* dst) {
  
  dev->ideError =  IDE_ideReadSector(dev,block);

  memcpy(dst, &dev->ide_data[offset], count);
  
  if(!dev->ideError)
    return TRUE;
  else
    return FALSE;
	}

/**
 * Write single 512 byte sector at LBA blockNumber from src
 */
uint8_t IDE_writeBlock(IDE* dev,uint32_t blockNumber, const uint8_t *src) {
  
  memcpy(dev->ide_data, src, sizeof(dev->ide_data));

  dev->ideError =  IDE_ideWriteSector(dev,blockNumber);
  
  if(!dev->ideError)
    return TRUE;
  else
    return FALSE;
	}

/**
 * Retrive drive identification information and store at provided locations
 */
uint8_t IDE_driveInfo(IDE* dev,char *driveModel, char *driveSN,
    char *driveRev, uint16_t *cylinders, uint16_t *heads, uint32_t *sectors, uint32_t *totallba) {
  
  IDE_ideWaitNotBusy(dev);
  
  IDE_ideWrite8(dev,IDE_HEAD, 0xA0);
  
  IDE_ideWaitReady(dev);
  
  IDE_ideWrite8(dev,IDE_COMMAND, IDE_CMD_ID);
  
  IDE_ideWaitDRQ(dev);
  
  dev->ideError = IDE_ideRead8(dev,IDE_ERR);  
  
  if(dev->ideError)
     return FALSE; 

  IDE_ideReadBlock(dev,dev->ide_data, TRUE);
  
  
  // extract model, s/n, rev, cyl, heads, sectors
  strncpy(driveModel, (char *)(dev->ide_data + 54), 20);
  driveModel[20] = '\0';
  strncpy(driveSN, (char *)(dev->ide_data + 20), 10);
  driveSN[10] = '\0';
  strncpy(driveRev, (char *)(dev->ide_data + 46), 4);
  driveRev[4] = '\0';
  
  *cylinders = dev->ide_data[2] * 256 + dev->ide_data[3];
  *heads = dev->ide_data[6] * 256 + dev->ide_data[7];
  *sectors = dev->ide_data[12] * 256 + dev->ide_data[13];
  
  // even though info was read big-endian, words are swapped for this
  *totallba = (uint32_t)(dev->ide_data[120] & 0xff) << 8 |
                 (uint32_t)(dev->ide_data[121] & 0xff)  |
                 (uint32_t)(dev->ide_data[122] & 0xff)  << 24 |
                 (uint32_t)(dev->ide_data[123] & 0xff) << 16;
                 
  return TRUE;
	}

/**
 * Return current IDE error code (or 0)
 */
uint8_t IDE_errorCode(IDE* dev) {
  
	return dev->ideError;
	}

/**
 * Returns 0, provided for compatability with error routines
 * based on Sd2Card class
 */
uint8_t IDE_errorData(IDE* dev) {
  
	// provided for compatability with S2dCard class
	return 0;
	}

/**
 * Print block of memory in hex format to specified Print
 * class (can be instance of Serial)
 */  
#if 0
void IDE_dumpHex(Print *print, uint8_t *data, uint16_t length) {
  char dtxt[64];
  char atxt[17];
  char line[80];
  char *dtp;
  
  for (uint16_t i = 0; i < length; i+=16) {
    memset(dtxt, 0, sizeof(dtxt));
    memset(atxt, 0, sizeof(atxt));
    dtp = dtxt;
    
    dtp += sprintf(dtp, "%04X: ", i);
    for (uint16_t j = 0; j < 16; j++) {
      if((i + j) >= length)
          break;
      uint8_t v = data[i + j];
      if(v >= 32 && v <= 127)
          atxt[j] = v;
      else
          atxt[j] = '.';
      dtp += sprintf(dtp, "%02X ", v);
    }
    sprintf(line, "%-54s %s", dtxt, atxt);
    print->println(line);
    }
  }
#endif

/**
 * Private Methods
 */

/**
 * Set PORT L and PORT C for output
 */ 
void IDE_setDWrite(IDE* dev) {
  
  TRISB &= ~0b0000000011111111; // DD0..7
//  TRISB &= ~0b1111111111111111; // DD0..7
#warning IDEM pin SD card
  TRISE &= ~0b0000001100000000; // DD8..9
  TRISD &= ~0b1111110000000000; // DD10..15
  }

/**
 * Set PORT L and PORT C for input
 */ 
void IDE_setDRead(IDE* dev) {
  
  // set PL and LC to input
  TRISB |= 0b0000000011111111; // DD0..7
//  TRISB |= 0b1111111111111111; // DD0..7
#warning IDEM pin SD card
  TRISE |= 0b0000001100000000; // DD8..9
  TRISD |= 0b1111110000000000; // DD10..15
	}

/**
 * Write single word to IDE interface, swapping for either
 * bigendian or littleendian format - typical PC file systems
 * are stored little endian but other uses may be littleendian
 */
void IDE_writeIDEWord(IDE* dev,uint16_t data, uint8_t bigendian) {
  
  IDE_setDWrite(dev);
  
  uint16_t lsb, msb;
  if(bigendian) {
    lsb = data & 0xFF;
    msb = (data >> 8) & 0xFF;
    } 
  else {
    msb = data & 0xFF;
    lsb = (data >> 8) & 0xFF;
    }
 
  LATB = (LATB & 0b1111111100000000) | lsb;
  LATE = (LATE & 0b1111110011111111) | ((msb << 8) & 0b0000001100000000);
  LATD = (LATD & 0b0000001111111111) | ((msb << 8) & 0b1111110000000000);
  }

/**
 * Write single byte to IDE register, simulating inverter
 * logic of 8255-based design used as reference
 */
void IDE_writeIDEControl(IDE* dev,uint16_t data) {
  uint16_t lsb = data & 0xFF;

  // simulate inverter
  lsb ^= 0xc7; // B11000111
  LATFbits.LATF8 = lsb & 1 ? 1 : 0; 
  LATGbits.LATG12 = lsb & 2 ? 1 : 0; 
  LATGbits.LATG13 = lsb & 4 ? 1 : 0; 
  
  }

/**
 * Read word from IDE interface, swapping for either
 * bigendian or littleindian support
 */
uint16_t IDE_readIDEData(IDE* dev,uint8_t bigendian) {
  
  IDE_setDRead(dev);

  uint16_t lsb = PORTB & 0b0000000011111111;
  uint16_t msb = (PORTE & 0b0000001100000000) >> 8;
  msb |= (PORTD & 0b1111110000000000) >> 8;
  
  if(bigendian)
    return (msb << 8) | lsb;
  else
    return (lsb << 8) | msb;
  }

/**
 * Write IDE control, strobe RD line, then read word from IDE interface
 * in either big or little endian
 */
uint16_t IDE_ideRead16(IDE* dev,uint16_t ideRegister, uint8_t bigendian) {
  
  // drive address
  IDE_writeIDEControl(dev,ideRegister);  
  IDE_writeIDEControl(dev,ideRegister | IDE_RD_LINE);

  // read value
  uint16_t value = IDE_readIDEData(dev,bigendian);
  
  // deassert all control pins
  IDE_writeIDEControl(dev,0);
  
  // return value
  return value;
  }

/**
 * Write IDE control, strobe RD line, then read byte from IDE interface
 */
uint16_t IDE_ideRead8(IDE* dev,uint16_t ideRegister) {
  
  // drive address
  IDE_writeIDEControl(dev,ideRegister); 
  IDE_writeIDEControl(dev,ideRegister | IDE_RD_LINE);
  
  // read lower uint8_t
  uint16_t lsb = IDE_readIDEData(dev,TRUE);
  lsb &= 0xFF;
  
  // deassert all control pins
  IDE_writeIDEControl(dev,0);
  
  // return value
  return lsb;
  }


/**
 * Write word to data bus, write IDE control, strobe WR line
 */
void IDE_ideWrite16(IDE* dev,uint16_t ideRegister, uint16_t value, uint8_t bigendian) {
  
  IDE_writeIDEWord(dev,value, bigendian);

  // drive address
  IDE_writeIDEControl(dev,ideRegister); 
  IDE_writeIDEControl(dev,ideRegister | IDE_WR_LINE);
  IDE_writeIDEControl(dev,ideRegister); 
  }

/**
 * Write byte to data bus, write IDE control, strobe WR line
 */
void IDE_ideWrite8(IDE* dev,uint16_t ideRegister, uint16_t value) {
  // lsb
  uint16_t lsb = value & 0xff;
  
  // write lower uint8_t
  IDE_writeIDEWord(dev,lsb, TRUE);

  // drive address
  IDE_writeIDEControl(dev,ideRegister); 
  IDE_writeIDEControl(dev,ideRegister | IDE_WR_LINE);
  IDE_writeIDEControl(dev,ideRegister); 
	}

/**
 * Reset IDE bus
 */
void IDE_ideReset(IDE* dev) {

  // drive address
  IDE_writeIDEControl(dev,IDE_RST_LINE);  

  // delay for 500 ms.
  __delay_ms(500);
  
  // deassert all control pins
  IDE_writeIDEControl(dev,0);
	}

uint8_t IDE_ideInit(IDE* dev) {

  IDE_ideWrite8(dev,IDE_HEAD,0xA0);
  
  return (IDE_ideWaitReady(dev) & 0xA0) == RDY;
  }

/**
 * Wait for IDE device to clear BSY signal, set DRQ
 */
uint16_t IDE_ideWaitDRQ(IDE* dev) {
  uint16_t status;
  uint16_t mask = DRQ | BSY;
  uint16_t timeout=500;
  
  while(timeout--) {
    status = IDE_ideRead8(dev,IDE_STATUS);
    
    // loop until BSY is clear, DRQ is set
    if((status & mask) == DRQ)
      break;
    
    __delay_ms(1);
		}
  
  return status;
  }

/**
 * Wait for IDE device to clear BSY signal
 */
uint16_t IDE_ideWaitNotBusy(IDE* dev) {
  uint16_t status;
  uint16_t timeout=500;
  
  while(timeout--) {
    status = IDE_ideRead8(dev,IDE_STATUS);
    
    // loop until BSY is clear
    if((status & BSY) == 0)
      break;
    
    __delay_ms(1);
		}
  
  return status;
	}

/**
 * Wait for IDE device to clear BSY signal, set RDY
 */
uint16_t IDE_ideWaitReady(IDE* dev) {
  uint16_t status;
  uint16_t mask = RDY | BSY;
  uint16_t timeout=500 /* 5000*/;
  
  while(timeout--) {
    status = IDE_ideRead8(dev,IDE_STATUS);
    
    // loop until BSY is clear, RDY is set
    if((status & mask) == RDY)
      break;
    
    __delay_ms(1);
    }  
  
  return status;
  }

/**
 * Write LBA to IDE bus
 */
void IDE_WriteLBA(IDE* dev,uint32_t lba) {
  
  // lba is 4 uint8_t address
  uint16_t b3 = (lba >> 24) & 0xFF;
  uint16_t b2 = (lba >> 16) & 0xFF;
  uint16_t b1 = (lba >> 8) & 0xFF;
  uint16_t b0 = lba       & 0xFF;
  
  b3 &= 0x0F;
  b3 |= 0xE0;

  IDE_ideWrite8(dev,IDE_HEAD, b3);
  
  IDE_ideWrite8(dev,IDE_CYL_MSB, b2);
  
  IDE_ideWrite8(dev,IDE_CYL_LSB, b1);
  
  IDE_ideWrite8(dev,IDE_SECTOR, b0);
  
  IDE_ideWrite8(dev,IDE_SEC_CNT, 1);
	}

/**
 * Read 512 bytes from IDE bus
 */
void IDE_ideReadBlock(IDE* dev,uint8_t *block, uint8_t bigendian) {
  int i;
  
  for(i=0; i < 512; i += 2) {
    uint16_t word = IDE_ideRead16(dev,IDE_DATA, bigendian);
    *block++ = (word >> 8) & 0xFF;
    *block++ = word & 0xFF;
		}
	}

/**
 * Write 512 bytes to IDE bus
 */
void IDE_ideWriteBlock(IDE* dev,uint8_t *block, uint8_t bigendian) {
  int i;

  for(i=0; i < 512; i += 2) {
    uint16_t value;
    
    value = (*block++ & 0xff) << 8;
    value |= (*block++ & 0xff);
    IDE_ideWrite16(dev,IDE_DATA, value, bigendian);
		}
	}

/**
 * Read 512 byte sector at lba into class buffer
 */
int IDE_ideReadSector(IDE* dev,uint32_t lba) {
  
  memset(dev->ide_data, 0, sizeof(dev->ide_data));
  
  IDE_ideWaitNotBusy(dev);
  
  IDE_WriteLBA(dev,lba);
  
  IDE_ideWrite8(dev,IDE_COMMAND, IDE_CMD_READ);
  
  uint16_t status = IDE_ideWaitDRQ(dev);

  uint16_t err = IDE_ideRead8(dev,IDE_ERR);  
  if(err == 0)
    IDE_ideReadBlock(dev,dev->ide_data, FALSE);
    
  return err;
  }

/**
 * Write 512 byte sector at lba from class buffer
 */
int IDE_ideWriteSector(IDE* dev,uint32_t lba) {
  
  IDE_ideWaitNotBusy(dev);
  
  IDE_WriteLBA(dev,lba);
  
  IDE_ideWrite8(dev,IDE_COMMAND, IDE_CMD_WRITE);
  
  uint16_t status = IDE_ideWaitDRQ(dev);

  uint16_t err = IDE_ideRead8(dev,IDE_ERR);  

  if(err == 0) {
    IDE_ideWriteBlock(dev,dev->ide_data, FALSE);
    status = IDE_ideWaitNotBusy(dev);
    err = IDE_ideRead8(dev,IDE_ERR);  
		}

  return err;
	}

/**
 * Compute 32 bit LBA from head, cylinder, sector values
 */
uint32_t IDE_computeLBA(int head, int cylinder, int sector) {
  
  uint32_t lba = (uint32_t)(head & 0xff) << 24 |
      (uint32_t)(cylinder & 0xffff) << 16 |
      (uint32_t)(sector & 0xff);
  
  return lba;
  }


