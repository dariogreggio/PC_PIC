/* Arduino IDEFat Library
 * Copyright (C) 2009 by William Greiman
 *
 * 2022 version for PC_PIC by KatiaG
 * 
 * This file is part of the Arduino IDEFat Library
 *
 * This Library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This Library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS forA PARTICULAR PURPOSE.  See the
 * GNU General Public License formore details.
 *
 * You should have received a copy of the GNU General Public License
 * along with the Arduino IDEFat Library.  ifnot, see
 * <http://www.gnu.org/licenses/>.
 * 
 * https://github.com/pixe1f10w/idefat-arduino/blob/master/IDEFile.cpp
 */

#include "IDEFat.h"

/** Default date for file timestamps is 1 Jan 2000 */
uint16_t const FAT_DEFAULT_DATE = ((2000 - 1980) << 9) | (1 << 5) | 1;
/** Default time for file timestamp is 1 am */
uint16_t const FAT_DEFAULT_TIME = (1 << 11);

/** Directory entry is part of a long name */
inline uint8_t DIR_IS_LONG_NAME(const dir_t* dir) {
  return (dir->attributes & DIR_ATT_LONG_NAME_MASK) == DIR_ATT_LONG_NAME;
	}

/** Mask for file/subdirectory tests */
uint8_t const DIR_ATT_FILE_TYPE_MASK = (DIR_ATT_VOLUME_ID | DIR_ATT_DIRECTORY);
/** Directory entry is for a file */
inline uint8_t DIR_IS_FILE(const dir_t* dir) {
  return (dir->attributes & DIR_ATT_FILE_TYPE_MASK) == 0;
	}

/** Directory entry is for a subdirectory */
inline uint8_t DIR_IS_SUBDIR(const dir_t* dir) {
  return (dir->attributes & DIR_ATT_FILE_TYPE_MASK) == DIR_ATT_DIRECTORY;
	}

/** Directory entry is for Volume label */
inline uint8_t DIR_IS_VOLUME(const dir_t* dir) {
  return (dir->attributes & DIR_ATT_FILE_TYPE_MASK) == DIR_ATT_VOLUME_ID;
	}

/** Directory entry is for a file or subdirectory */
inline uint8_t DIR_IS_FILE_OR_SUBDIR(const dir_t* dir) {
  return (dir->attributes & DIR_ATT_VOLUME_ID) == 0;
	}

void IDEFile_IDEFile(IDEFile* file) { file->type_=FAT_FILE_TYPE_CLOSED;}
uint8_t IDEFile_dirIndex(IDEFile *file) { return file->dirIndex_; }
void clearUnbufferedRead(IDEFile *file) {
  file->flags_ &= ~F_FILE_UNBUFFERED_READ;
  }
void IDEFile_rewind(IDEFile *file) {
  file->curPosition_ = file->curCluster_ = 0;
  }
uint8_t close(IDEFile *file);
uint8_t contiguousRange(IDEFile *file,uint32_t* bgnBlock, uint32_t* endBlock);
uint8_t createContiguous(IDEFile * dirFile,
        const char* fileName, uint32_t size);
/** \return The current cluster number for a file or directory. */
uint32_t curCluster(IDEFile *file) {return file->curCluster_;}
/** \return The current position for a file or directory. */
uint32_t curPosition(IDEFile *file) {return file->curPosition_;}
uint8_t IDEFile_seekCur(IDEFile *file,uint32_t pos) {
  return IDEFile_seekSet(file,file->curPosition_ + pos);
  }
uint8_t IDEFile_seekEnd(IDEFile *file) {return IDEFile_seekSet(file,file->fileSize_);}
uint8_t IDEFile_type(IDEFile *file) { return file->type_; }
void IDEFile_setUnbufferedRead(IDEFile *file) {
      
  if(IDEFile_isFile(file)) 
    file->flags_ |= F_FILE_UNBUFFERED_READ;
  }
uint8_t IDEFile_unbufferedRead(IDEFile *file) {
  return file->flags_ & F_FILE_UNBUFFERED_READ;
  }
IDEVolume* IDEFile_volume(IDEFile *file) { return file->vol_; }

#if 0 //ALLOW_DEPRECATED_FUNCTIONS
// Deprecated functions  - suppress cpplint warnings with NOLINT comment
  /** \deprecated Use:
   * uint8_t IDEFile::contiguousRange(uint32_t* bgnBlock, uint32_t* endBlock);
   */
  uint8_t IDEFile_contiguousRange(IDEFile*,uint32_t *bgnBlock, uint32_t *endBlock) {  // NOLINT
    return contiguousRange(&bgnBlock, &endBlock);
  }
 /** \deprecated Use:
   * uint8_t IDEFile::createContiguous(IDEFile* dirFile,
   *   const char* fileName, uint32_t size)
   */
  uint8_t IDEFile_createContiguous(IDEFile* dirFile,  // NOLINT
    const char* fileName, uint32_t size) {
    return createContiguous(&dirFile, fileName, size);
    }

  /**
   * \deprecated Use:
   * static void IDEFile::dateTimeCallback(
   *   void (*dateTime)(uint16_t* date, uint16_t* time));
   */
  static void IDEFile_dateTimeCallback(
    void (*dateTime)(uint16_t& date, uint16_t& time)) {  // NOLINT
    oldDateTime_ = dateTime;
    dateTime_ = dateTime ? oldToNew : 0;
    }
  /** \deprecated  Do not use in new apps */
  uint8_t IDEFile_open2(IDEFile *dirFile, const char* fileName) {  // NOLINT
    return IDEFile_open(dirFile, fileName, O_RDWR);
    }
  /** \deprecated Use:
   * uint8_t IDEFile::open(IDEFile* dirFile, uint16_t index, uint8_t oflag);
   */
  uint8_t IDEFile_open3(IDEFile *dirFile, uint16_t index, uint8_t oflag) {  // NOLINT
    return IDEFile_open(&dirFile, index, oflag);
  }
  /** \deprecated Use: uint8_t IDEFile::openRoot(IDEVolume* vol); */
  uint8_t IDEFile_openRoot(IDEFile*,IDEVolume& vol) {return IDEFile_openRoot(&vol);}  // NOLINT

  /** \deprecated Use: int8_t IDEFile::readDir(dir_t* dir); */
  int8_t IDEFile_readDir(IDEFile*,dir_t& dir) {return IDEFile_readDir(&dir);}  // NOLINT
  /** \deprecated Use:
   * static uint8_t IDEFile::remove(IDEFile* dirFile, const char* fileName);
   */
  static uint8_t IDEFile_remove(IDEFile *dirFile, const char* fileName) {  // NOLINT
    return IDEFile_remove(&dirFile, fileName);
  }
//------------------------------------------------------------------------------
// rest are private

  static void (*oldDateTime_)(uint16_t& date, uint16_t& time);  // NOLINT
  static void oldToNew(uint16_t* date, uint16_t* time) {
    uint16_t d;
    uint16_t t;
    oldDateTime_(d, t);
    *date = d;
    *time = t;
  }
#endif  // ALLOW_DEPRECATED_FUNCTIONS

//------------------------------------------------------------------------------
// callback function for date/time

#if 0 //ALLOW_DEPRECATED_FUNCTIONS
// suppress cpplint warnings with NOLINT comment
void (*IDEFile_oldDateTime_)(uint16_t * date, uint16_t * time);  // NOLINT
#endif // ALLOW_DEPRECATED_FUNCTIONS
//------------------------------------------------------------------------------
// add a cluster to a file
uint8_t IDEFile_addCluster(IDEFile *file) {
  
  if(!IDEVolume_allocContiguous(file->vol_, 1, &file->curCluster_)) 
    return FALSE;

  // iffirst cluster of file link to directory entry
  if(file->firstCluster_ == 0) {
    file->firstCluster_ = file->curCluster_;
    file->flags_ |= F_FILE_DIR_DIRTY;
	  }
  return TRUE;
  }

//------------------------------------------------------------------------------
// Add a cluster to a directory file and zero the cluster.
// return with first block of cluster in the cache
uint8_t IDEFile_addDirCluster(IDEFile *file) {
  uint8_t i;
  
  if(!IDEFile_addCluster(file)) 
    return FALSE;

  // zero data in cluster insure first cluster is in cache
  uint32_t block = IDEVolume_clusterStartBlock(file->vol_,file->curCluster_);
  for(i=file->vol_->blocksPerCluster_; i != 0; i--) {
    if(!IDEVolume_cacheZeroBlock(file->vol_,block + i - 1)) 
      return FALSE;
    }
  // Increase directory file size by cluster size
  file->fileSize_ += 512UL << file->vol_->clusterSizeShift_;
  return TRUE;
  }

//------------------------------------------------------------------------------
// cache a file's directory entry
// return pointer to cached entry or null forfailure
dir_t* IDEFile_cacheDirEntry(IDEFile *file,uint8_t action) {

  if(!IDEVolume_cacheRawBlock(file->vol_,file->dirBlock_, action)) 
		return NULL;
  return file->vol_->cacheBuffer_.dir + file->dirIndex_;
	}

//------------------------------------------------------------------------------
/**
 *  Close a file and force cached data and directory information
 *  to be written to the storage device.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include no file is open or an I/O error.
 */
uint8_t IDEFile_close(IDEFile *file) {
  
  if(!IDEFile_sync(file))
    return FALSE;
  file->type_ = FAT_FILE_TYPE_CLOSED;
  return TRUE;
  }

//------------------------------------------------------------------------------
/**
 * Check forcontiguous file and return its raw block range.
 *
 * \param[out] bgnBlock the first block address forthe file.
 * \param[out] endBlock the last  block address forthe file.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include file is not contiguous, file has zero length
 * or an I/O error occurred.
 */
uint8_t IDEFile_contiguousRange(IDEFile *file,uint32_t* bgnBlock, uint32_t* endBlock) {
  uint32_t c;
  
  // error if no blocks
  if(file->firstCluster_ == 0) 
    return FALSE;

  for(c=file->firstCluster_; ; c++) {
    uint32_t next;
    if(!IDEVolume_fatGet(file->vol_,c, &next)) 
      return FALSE;

    // check forcontiguous
    if(next != (c + 1)) {
      // error ifnot end of chain
      if(!IDEVolume_isEOC(file->vol_,next)) 
        return FALSE;
      *bgnBlock = IDEVolume_clusterStartBlock(file->vol_,file->firstCluster_);
      *endBlock = IDEVolume_clusterStartBlock(file->vol_,c)
                  + file->vol_->blocksPerCluster_ - 1;
      return TRUE;
			}
		}
	}

//------------------------------------------------------------------------------
/**
 * Create and open a new contiguous file of a specified size.
 *
 * \note This function only supports short DOS 8.3 names.
 * See open() formore information.
 *
 * \param[in] dirFile The directory where the file will be created.
 * \param[in] fileName A valid DOS 8.3 file name.
 * \param[in] size The desired file size.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include \a fileName contains
 * an invalid DOS 8.3 file name, the FAT volume has not been initialized,
 * a file is already open, the file already exists, the root
 * directory is full or an I/O error.
 *
 */
uint8_t IDEFile_createContiguous(IDEFile* file, IDEFile* dirFile,
        const char* fileName, uint32_t size) {
  
  // don't allow zero length file
  if(size == 0) 
    return FALSE;
  if(!IDEFile_open2(file,dirFile, fileName, O_CREAT | O_EXCL | O_RDWR)) 
    return FALSE;

  // calculate number of clusters needed
  uint32_t count = ((size - 1) >> (file->vol_->clusterSizeShift_ + 9)) + 1;

  // allocate clusters
  if(!IDEVolume_allocContiguous(file->vol_,count, &file->firstCluster_)) {
    remove();
    return FALSE;
		}
  file->fileSize_ = size;

  // insure sync() will update dir entry
  file->flags_ |= F_FILE_DIR_DIRTY;
  return IDEFile_sync(file);
	}

//------------------------------------------------------------------------------
/**
 * Return a files directory entry
 *
 * \param[out] dir Location forreturn of the files directory entry.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 */
uint8_t IDEFile_dirEntry(IDEFile *file,dir_t* dir) {
  
  // make sure fields on SD are correct
  if(!IDEFile_sync(file)) 
    return FALSE;

  // read entry
  dir_t* p = IDEFile_cacheDirEntry(file,CACHE_FOR_READ);
  if(!p) 
    return FALSE;

  // copy to caller's struct
  memcpy(dir, p, sizeof(dir_t));
  return TRUE;
	}

//------------------------------------------------------------------------------
/**
 * Format the name field of \a dir into the 13 byte array
 * \a name in standard 8.3 short name format.
 *
 * \param[in] dir The directory structure containing the name.
 * \param[out] name A 13 byte char array forthe formatted name.
 */
void IDEFile_dirName(const dir_t* dir, char* name) {
  uint8_t j = 0,i;
  
  for(i=0; i < 11; i++) {
    if(dir->name[i] == ' ')
      continue;
    if(i == 8) 
      name[j++] = '.';
    name[j++] = dir->name[i];
		}
  name[j] = 0;
	}

//------------------------------------------------------------------------------
/** List directory contents to Serial.
 *
 * \param[in] flags The inclusive OR of
 *
 * LS_DATE - %Print file modification date
 *
 * LS_SIZE - %Print file size.
 *
 * LS_R - Recursive list of subdirectories.
 *
 * \param[in] indent Amount of space before file name. Used forrecursive
 * list to indicate subdirectory level.
 */
#if 0
void IDEFile_ls(uint8_t flags, uint8_t indent) {
  dir_t* p;

  rewind();
  while((p = readDirCache())) {
    // done if past last used entry
    if(p->name[0] == DIR_NAME_FREE) 
      break;

    // skip deleted entry and entries for. and  ..
    if(p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') 
      continue;

    // only list subdirectories and files
    if(!DIR_IS_FILE_OR_SUBDIR(p)) 
      continue;

    // print any indent spaces
    for(int8_t i = 0; i < indent; i++) 
      Serial.print(' ');

    // print file name with possible blank fill
    printDirName(*p, flags & (LS_DATE | LS_SIZE) ? 14 : 0);

    // print modify date/time if requested
    if(flags & LS_DATE) {
       printFatDate(p->lastWriteDate);
       Serial.print(' ');
       printFatTime(p->lastWriteTime);
	    }
    // print size ifrequested
    if(!DIR_IS_SUBDIR(p) && (flags & LS_SIZE)) {
      Serial.print(' ');
      Serial.print(p->fileSize);
		  }
    Serial.println();

    // list subdirectory content if requested
    if((flags & LS_R) && DIR_IS_SUBDIR(p)) {
      uint16_t index = curPosition()/32 - 1;
      IDEFile s;
      if(s.open(this, index, O_READ)) 
        s.ls(flags, indent + 2);
      seekSet(32 * (index + 1));
			}
		}
	}
#endif


//------------------------------------------------------------------------------
// format directory name field from a 8.3 name string
uint8_t IDEFile_make83Name(const char* str, uint8_t* name) {
  uint8_t c;
  uint8_t n = 7;  // max index forpart before dot
  uint8_t i = 0;
  
  // blank fill name and extension
  while(i < 11) 
    name[i++] = ' ';
  i=0;
  while((c = *str++) != '\0') {
    if(c == '.') {
      if(n == 10) 
        return FALSE;  // only one dot allowed
      n = 10;  // max index forfull 8.3 name
      i = 8;   // place forextension
			} 
		else {
      // illegal FAT characters
      const char *p = "|<>^+=?/[];,*\"\\";
      uint8_t b;
      while((b = *p++)) 
        if(b == c) 
          return FALSE;
      // check size and only allow ASCII printable characters
      if(i > n || c < 0x21 || c > 0x7E)
        return FALSE;
      // only upper case allowed in 8.3 names - convert lower to upper
      name[i++] = c < 'a' || c > 'z' ?  c : c + ('A' - 'a');
			}
		}
  // must have a file name, extension is optional
  return name[0] != ' ';
	}

//------------------------------------------------------------------------------
/** Make a new directory.
 *
 * \param[in] dir An open IDEFat instance forthe directory that will containing
 * the new directory.
 *
 * \param[in] dirName A valid 8.3 DOS name forthe new directory.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include this IDEFile is already open, \a dir is not a
 * directory, \a dirName is invalid or already exists in \a dir.
 */
uint8_t IDEFile_makeDir(IDEFile*file, IDEFile* dir, const char* dirName) {
  dir_t d;
  uint8_t i;

  // create a normal file
  if(!IDEFile_open2(file,dir, dirName, O_CREAT | O_EXCL | O_RDWR)) 
    return FALSE;

  // convert IDEFile to directory
  file->flags_ = O_READ;
  file->type_ = FAT_FILE_TYPE_SUBDIR;

  // allocate and zero first cluster
  if(!IDEFile_addDirCluster(file))
    return FALSE;

  // force entry to HD
  if(!IDEFile_sync(file)) 
    return FALSE;

  // cache entry - should already be in cache due to sync() call
  dir_t* p = IDEFile_cacheDirEntry(file,CACHE_FOR_WRITE);
  if(!p) 
		return FALSE;

  // change directory entry  attribute
  p->attributes = DIR_ATT_DIRECTORY;

  // make entry for'.'
  memcpy(&d, p, sizeof(d));
  for(i=1; i < 11; i++) 
    d.name[i] = ' ';
  d.name[0] = '.';

  // cache block for'.'  and '..'
  uint32_t block = IDEVolume_clusterStartBlock(file->vol_,file->firstCluster_);
  if(!IDEVolume_cacheRawBlock(file->vol_, block, CACHE_FOR_WRITE)) 
    return FALSE;

  // copy '.' to block
  memcpy(&file->vol_->cacheBuffer_.dir[0], &d, sizeof(d));

  // make entry for'..'
  d.name[1] = '.';
  if(IDEFile_isRoot(dir)) {
    d.firstClusterLow = 0;
    d.firstClusterHigh = 0;
		} 
	else {
    d.firstClusterLow = dir->firstCluster_ & 0XFFFF;
    d.firstClusterHigh = dir->firstCluster_ >> 16;
		}
  // copy '..' to block
  memcpy(&file->vol_->cacheBuffer_.dir[1], &d, sizeof(d));

  // set position after '..'
  file->curPosition_ = 2 * sizeof(d);

  // write first block
  return IDEVolume_cacheFlush(file->vol_);
	}

//------------------------------------------------------------------------------
/**
 * Open a file or directory by name.
 *
 * \param[in] dirFile An open IDEFat instance for the directory containing the
 * file to be opened.
 *
 * \param[in] fileName A valid 8.3 DOS name fora file to be opened.
 *
 * \param[in] oflag Values for\a oflag are constructed by a bitwise-inclusive
 * OR of flags from the following list
 *
 * O_READ - Open for reading.
 *
 * O_RDONLY - Same as O_READ.
 *
 * O_WRITE - Open for writing.
 *
 * O_WRONLY - Same as O_WRITE.
 *
 * O_RDWR - Open forreading and writing.
 *
 * O_APPEND - if set, the file offset shall be set to the end of the
 * file prior to each write.
 *
 * O_CREAT - if the file exists, this flag has no effect except as noted
 * under O_EXCL below. Otherwise, the file shall be created
 *
 * O_EXCL - if O_CREAT and O_EXCL are set, open() shall fail ifthe file exists.
 *
 * O_SYNC - Call sync() after each write.  This flag should not be used with
 * write(uint8_t), write_P(PGM_P), writeln_P(PGM_P), or the Arduino Print class.
 * These functions do character at a time writes so sync() will be called
 * after each byte.
 *
 * O_TRUNC - ifthe file exists and is a regular file, and the file is
 * successfully opened and is not read only, its length shall be truncated to 0.
 *
 * \note Directory files must be opened read only.  Write and truncation is
 * not allowed fordirectory files.
 *
 * \return The value one, true, is returned for success and
 * the value zero, false, is returned for failure.
 * Reasons forfailure include this IDEFile is already open, \a difFile is not
 * a directory, \a fileName is invalid, the file does not exist
 * or can't be opened in the access mode specified by oflag.
 */
uint8_t IDEFile_open2(IDEFile *file, IDEFile* dirFile, const char* fileName, uint8_t oflag) {
  uint8_t dname[11];
  dir_t* p;

  // error if already open
  if(IDEFile_isOpen(file))
    return FALSE;

  if(!IDEFile_make83Name(fileName, dname)) 
    return FALSE;
  file->vol_ = dirFile->vol_;
  IDEFile_rewind(dirFile);

  // bool forempty entry found
  uint8_t emptyFound = FALSE;

  // search forfile
  while(dirFile->curPosition_ < dirFile->fileSize_) {
    uint8_t index = 0XF & (dirFile->curPosition_ >> 5);
    p = IDEFile_readDirCache(dirFile);
    if(!p) 
      return FALSE;

    if(p->name[0] == DIR_NAME_FREE || p->name[0] == DIR_NAME_DELETED) {
      // remember first empty slot
      if(!emptyFound) {
        emptyFound = TRUE;
        file->dirIndex_ = index;
        file->dirBlock_ = file->vol_->cacheBlockNumber_;
				}
      // done ifno entries follow
      if(p->name[0] == DIR_NAME_FREE) 
        break;
			} 
		else if(!memcmp(dname, p->name, 11)) {
      // don't open existing file ifO_CREAT and O_EXCL
      if((oflag & (O_CREAT | O_EXCL)) == (O_CREAT | O_EXCL)) 
        return FALSE;

      // open found file
      return IDEFile_openCachedEntry(file,0xF & index, oflag);
			}
		}
  // only create file ifO_CREAT and O_WRITE
  if((oflag & (O_CREAT | O_WRITE)) != (O_CREAT | O_WRITE)) 
    return FALSE;

  // cache found slot or add cluster ifend of file
  if(emptyFound) {
    p = IDEFile_cacheDirEntry(file,CACHE_FOR_WRITE);
    if(!p) 
      return FALSE;
	  } 
	else {
    if(dirFile->type_ == FAT_FILE_TYPE_ROOT16) 
      return FALSE;

    // add and zero cluster for dirFile - first cluster is in cache forwrite
    if(!IDEFile_addDirCluster(dirFile)) 
      return FALSE;

    // use first entry in cluster
    file->dirIndex_ = 0;
    p = file->vol_->cacheBuffer_.dir;
		}
  // initialize as empty file
  memset(p, 0, sizeof(dir_t));
  memcpy(p->name, dname, 11);

  // set timestamps
  if(file->dateTime_) {
    // call user function
    file->dateTime_(&p->creationDate, &p->creationTime);
		}
	else {
    // use default date/time
    p->creationDate = FAT_DEFAULT_DATE;
    p->creationTime = FAT_DEFAULT_TIME;
		}
  p->lastAccessDate = p->creationDate;
  p->lastWriteDate = p->creationDate;
  p->lastWriteTime = p->creationTime;

  // force write of entry to HD
  if(!IDEVolume_cacheFlush(file->vol_)) 
    return FALSE;

  // open entry in cache
  return IDEFile_openCachedEntry(file,file->dirIndex_, oflag);
	}

//------------------------------------------------------------------------------
/**
 * Open a file by index.
 *
 * \param[in] dirFile An open IDEFat instance forthe directory.
 *
 * \param[in] index The \a index of the directory entry forthe file to be
 * opened.  The value for\a index is (directory file position)/32.
 *
 * \param[in] oflag Values for\a oflag are constructed by a bitwise-inclusive
 * OR of flags O_READ, O_WRITE, O_TRUNC, and O_SYNC.
 *
 * See open() by fileName fordefinition of flags and return values.
 *
 */
uint8_t IDEFile_open3(IDEFile *file, IDEFile* dirFile, uint16_t index, uint8_t oflag) {
  
  // error if already open
  if(IDEFile_isOpen(file))
    return FALSE;

  // don't open existing file ifO_CREAT and O_EXCL - user call error
  if((oflag & (O_CREAT | O_EXCL)) == (O_CREAT | O_EXCL)) 
    return FALSE;

  file->vol_ = dirFile->vol_;

  // seek to location of entry
  if(!IDEFile_seekSet(dirFile,32 * index)) 
    return FALSE;

  // read entry into cache
  dir_t* p = IDEFile_readDirCache(dirFile);
  if(!p) 
		return FALSE;

  // error ifempty slot or '.' or '..'
  if(p->name[0] == DIR_NAME_FREE ||
      p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') {
    return FALSE;
		}
  // open cached entry
  return IDEFile_openCachedEntry(file,index & 0xF, oflag);
	}

//------------------------------------------------------------------------------
// open a cached directory entry. Assumes vol_ is initializes
uint8_t IDEFile_openCachedEntry(IDEFile *file,uint8_t dirIndex, uint8_t oflag) {
  
  // location of entry in cache
  dir_t* p =file->vol_->cacheBuffer_.dir + dirIndex;

  // write or truncate is an error fora directory or read-only file
  if(p->attributes & (DIR_ATT_READ_ONLY | DIR_ATT_DIRECTORY)) {
    if(oflag & (O_WRITE | O_TRUNC)) 
      return FALSE;
		}
  // remember location of directory entry on SD
  file->dirIndex_ = dirIndex;
  file->dirBlock_ = file->vol_->cacheBlockNumber_;

  // copy first cluster number fordirectory fields
  file->firstCluster_ = (uint32_t)p->firstClusterHigh << 16;
  file->firstCluster_ |= p->firstClusterLow;

  // make sure it is a normal file or subdirectory
  if(DIR_IS_FILE(p)) {
    file->fileSize_ = p->fileSize;
    file->type_ = FAT_FILE_TYPE_NORMAL;
		} 
	else if(DIR_IS_SUBDIR(p)) {
    if(!IDEVolume_chainSize(file->vol_,file->firstCluster_, &file->fileSize_)) 
      return FALSE;
    file->type_ = FAT_FILE_TYPE_SUBDIR;
		} 
	else {
    return FALSE;
  }
  // save open flags for read/write
  file->flags_ = oflag & (O_ACCMODE | O_SYNC | O_APPEND);

  // set to start of file
  file->curCluster_ = 0;
  file->curPosition_ = 0;

  // truncate file to zero length if requested
  if(oflag & O_TRUNC) 
    return IDEFile_truncate(file,0);
  return TRUE;
  }

void dateTimeCallback(IDEFile *file,
  void (*dateTime)(uint16_t* date, uint16_t* time)) {
  file->dateTime_ = dateTime;
  }
void dateTimeCallbackCancel(IDEFile *file) {
    // use explicit zero since NULL is not defined for Sanguino
    file->dateTime_ = 0;
    }
/** \return Address of the block that contains this file's directory. */
uint32_t IDEFile_dirBlock(IDEFile *file) {return file->dirBlock_;}
uint8_t IDEFile_dirEntry(IDEFile *file,dir_t* dir);
/** \return Index of this file's directory in the block dirBlock. */
uint8_t IDEFile_dirIndex(IDEFile *file);
void IDEFile_dirName(const dir_t *dir, char* name);
/** \return The total number of bytes in a file or directory. */
uint32_t IDEFile_fileSize(IDEFile *file) {return file->fileSize_;}
/** \return The first cluster number for a file or directory. */
uint32_t IDEFile_firstCluster(IDEFile *file) {return file->firstCluster_;}
/** \return True if this is a IDEFile for a directory else false. */
uint8_t IDEFile_isDir(IDEFile *file) {return file->type_ >= FAT_FILE_TYPE_MIN_DIR;}
/** \return True if this is a IDEFile for a file else false. */
uint8_t IDEFile_isFile(IDEFile *file) {return file->type_ == FAT_FILE_TYPE_NORMAL;}
/** \return True if this is a IDEFile for an open file/directory else false. */
uint8_t IDEFile_isOpen(IDEFile *file) {return file->type_ != FAT_FILE_TYPE_CLOSED;}
/** \return True if this is a IDEFile for a subdirectory else false. */
uint8_t IDEFile_isSubDir(IDEFile *file) {return file->type_ == FAT_FILE_TYPE_SUBDIR;}
/** \return True if this is a IDEFile for the root directory. */
uint8_t IDEFile_isRoot(IDEFile *file) {  return file->type_ == FAT_FILE_TYPE_ROOT16 || file->type_ == FAT_FILE_TYPE_ROOT32;
  }

//------------------------------------------------------------------------------
/**
 * Open a volume's root directory.
 *
 * \param[in] vol The FAT volume containing the root directory to be opened.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include the FAT volume has not been initialized
 * or it a FAT12 volume.
 */
uint8_t IDEFile_openRoot(IDEFile *file,IDEVolume* vol) {
  
  // error if file is already open
  if(IDEFile_isOpen(file)) 
    return FALSE;

  if(IDEVolume_fatType(vol) == 16) {
    file->type_ = FAT_FILE_TYPE_ROOT16;
    file->firstCluster_ = 0;
    file->fileSize_ = 32 * IDEVolume_rootDirEntryCount(vol);
		} 
	else if(IDEVolume_fatType(vol) == 32) {
    file->type_ = FAT_FILE_TYPE_ROOT32;
    file->firstCluster_ = IDEVolume_rootDirStart(file->vol_);
    if(!IDEVolume_chainSize(vol,file->firstCluster_, &file->fileSize_)) 
      return FALSE;
		}
	else {
    // volume is not initialized or FAT12
    return FALSE;
		}
  file->vol_ = vol;
  // read only
  file->flags_ = O_READ;

  // set to start of file
  file->curCluster_ = 0;
  file->curPosition_ = 0;

  // root has no directory entry
  file->dirBlock_ = 0;
  file->dirIndex_ = 0;
  return TRUE;
	}

#if 0
//------------------------------------------------------------------------------
/** %Print the name field of a directory entry in 8.3 format to Serial.
 *
 * \param[in] dir The directory structure containing the name.
 * \param[in] width Blank fill name iflength is less than \a width.
 */
void IDEFile_printDirName(const dir_t& dir, uint8_t width) {
  uint8_t w = 0;
  
  for(uint8_t i = 0; i < 11; i++) {
    if(dir.name[i] == ' ')
      continue;
    if(i == 8) {
      Serial.print('.');
      w++;
			}
    Serial.print(dir.name[i]);
    w++;
  }
  if(DIR_IS_SUBDIR(&dir)) {
    Serial.print('/');
    w++;
		}
  while(w < width) {
    Serial.print(' ');
    w++;
		}
	}

//------------------------------------------------------------------------------
/** %Print a directory date field to Serial.
 *
 *  Format is yyyy-mm-dd.
 *
 * \param[in] fatDate The date field from a directory entry.
 */
void IDEFile_printFatDate(uint16_t fatDate) {
  
  Serial.print(FAT_YEAR(fatDate));
  Serial.print('-');
  printTwoDigits(FAT_MONTH(fatDate));
  Serial.print('-');
  printTwoDigits(FAT_DAY(fatDate));
	}

//------------------------------------------------------------------------------
/** %Print a directory time field to Serial.
 *
 * Format is hh:mm:ss.
 *
 * \param[in] fatTime The time field from a directory entry.
 */
void IDEFile_printFatTime(uint16_t fatTime) {
  
  printTwoDigits(FAT_HOUR(fatTime));
  Serial.print(':');
  printTwoDigits(FAT_MINUTE(fatTime));
  Serial.print(':');
  printTwoDigits(FAT_SECOND(fatTime));
	}

//------------------------------------------------------------------------------
/** %Print a value as two digits to Serial.
 *
 * \param[in] v Value to be printed, 0 <= \a v <= 99
 */
void IDEFile_printTwoDigits(uint8_t v) {
  char str[3];
  
  str[0] = '0' + v/10;
  str[1] = '0' + v % 10;
  str[2] = 0;
  Serial.print(str);
	}
#endif

//------------------------------------------------------------------------------
/**
 * Read data from a file starting at the current position.
 *
 * \param[out] buf Pointer to the location that will receive the data.
 *
 * \param[in] nbyte Maximum number of bytes to read.
 *
 * \return for success read() returns the number of bytes read.
 * A value less than \a nbyte, including zero, will be returned
 * ifend of file is reached.
 * ifan error occurs, read() returns -1.  Possible errors include
 * read() called before a file has been opened, corrupt file system
 * or an I/O error occurred.
 */
int16_t IDEFile_read(IDEFile *file,void* buf, uint16_t nbyte) {
  uint8_t* dst = (uint8_t*)buf;

  // error if not open or write only
  if(!IDEFile_isOpen(file) || !(file->flags_ & O_READ)) 
    return -1;

  // max bytes left in file
  if(nbyte > (file->fileSize_ - file->curPosition_)) 
    nbyte = file->fileSize_ - file->curPosition_;

  // amount left to read
  uint16_t toRead = nbyte;
  while(toRead > 0) {
    uint32_t block;  // raw device block number
    uint16_t offset = file->curPosition_ & 0x1FF;  // offset in block
    if(file->type_ == FAT_FILE_TYPE_ROOT16) {
      block = IDEVolume_rootDirStart(file->vol_) + (file->curPosition_ >> 9);
	    } 
		else {
      uint8_t blockOfCluster = IDEVolume_blockOfCluster(file->vol_,file->curPosition_);
      if(offset == 0 && blockOfCluster == 0) {
        // start of new cluster
        if(file->curPosition_ == 0) {
          // use first cluster in file
          file->curCluster_ = file->firstCluster_;
		      } 
				else {
          // get next cluster from FAT
          if(!IDEVolume_fatGet(file->vol_,file->curCluster_, &file->curCluster_)) 
            return -1;
			    }
				}
      block = IDEVolume_clusterStartBlock(file->vol_,file->curCluster_) + blockOfCluster;
			}
    uint16_t n = toRead;

    // amount to be read from current block
    if(n > (512 - offset)) 
			n = 512 - offset;

    // no buffering needed ifn == 512 or user requests no buffering
    if((IDEFile_unbufferedRead(file) || n == 512) &&
      block != file->vol_->cacheBlockNumber_) {
      if(!IDEVolume_readData(file->vol_,block, offset, n, dst)) 
        return -1;
      dst += n;
			}
		else {
      // read block to cache and copy data to caller
      if(!IDEVolume_cacheRawBlock(file->vol_,block, CACHE_FOR_READ)) 
        return -1;
      uint8_t* src = file->vol_->cacheBuffer_.data + offset;
      uint8_t* end = src + n;
      while(src != end) 
        *dst++ = *src++;
			}
    file->curPosition_ += n;
    toRead -= n;
		}
  return nbyte;
	}

int16_t IDEFile_read1(IDEFile *file) {
  uint8_t b;
  return read(file,&b, 1) == 1 ? b : -1;
  }

//------------------------------------------------------------------------------
/**
 * Read the next directory entry from a directory file.
 *
 * \param[out] dir The dir_t struct that will receive the data.
 *
 * \return forsuccess readDir() returns the number of bytes read.
 * A value of zero will be returned ifend of file is reached.
 * ifan error occurs, readDir() returns -1.  Possible errors include
 * readDir() called before a directory has been opened, this is not
 * a directory file or an I/O error occurred.
 */
int8_t IDEFile_readDir(IDEFile *file, dir_t* dir) {
  int8_t n;
  
  // if not a directory file or miss-positioned return an error
  if(!IDEFile_isDir(file) || (0x1F & file->curPosition_)) 
    return -1;

  while((n = IDEFile_read(file, dir, sizeof(dir_t))) == sizeof(dir_t)) {
    // last entry ifDIR_NAME_FREE
    if(dir->name[0] == DIR_NAME_FREE) 
      break;
    // skip empty entries and entry for.  and ..
    if(dir->name[0] == DIR_NAME_DELETED || dir->name[0] == '.') 
      continue;
    // return ifnormal file or subdirectory
    if(DIR_IS_FILE_OR_SUBDIR(dir)) 
      return n;
		}
  // error, end of file, or past last entry
  return n < 0 ? -1 : 0;
	}

//------------------------------------------------------------------------------
// Read next directory entry into the cache
// Assumes file is correctly positioned
dir_t* IDEFile_readDirCache(IDEFile *file) {
  
  // error if not directory
  if(!IDEFile_isDir(file)) 
    return NULL;

  // index of entry in cache
  uint8_t i = (file->curPosition_ >> 5) & 0xF;

  // use read to locate and cache block
  if(IDEFile_read1(file) < 0) 
		return NULL;

  // advance to next entry
  file->curPosition_ += 31;

  // return pointer to entry
  return (file->vol_->cacheBuffer_.dir + i);
	}

//------------------------------------------------------------------------------
/**
 * Remove a file.
 *
 * The directory entry and all data forthe file are deleted.
 *
 * \note This function should not be used to delete the 8.3 version of a
 * file that has a long name. forexample ifa file has the long name
 * "New Text Document.txt" you should not delete the 8.3 name "NEWTEX~1.TXT".
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include the file read-only, is a directory,
 * or an I/O error occurred.
 */
uint8_t IDEFile_remove(IDEFile *file) {
  
  // free any clusters - will fail ifread-only or directory
  if(!IDEFile_truncate(file,0)) 
    return FALSE;

  // cache directory entry
  dir_t* d = IDEFile_cacheDirEntry(file,CACHE_FOR_WRITE);
  if(!d) 
    return FALSE;

  // mark entry deleted
  d->name[0] = DIR_NAME_DELETED;

  // set this IDEFile closed
  file->type_ = FAT_FILE_TYPE_CLOSED;

  // write entry to HD
  return IDEVolume_cacheFlush(file->vol_);
	}

//------------------------------------------------------------------------------
/**
 * Remove a file.
 *
 * The directory entry and all data forthe file are deleted.
 *
 * \param[in] dirFile The directory that contains the file.
 * \param[in] fileName The name of the file to be removed.
 *
 * \note This function should not be used to delete the 8.3 version of a
 * file that has a long name. forexample ifa file has the long name
 * "New Text Document.txt" you should not delete the 8.3 name "NEWTEX~1.TXT".
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include the file is a directory, is read only,
 * \a dirFile is not a directory, \a fileName is not found
 * or an I/O error occurred.
 */
uint8_t IDEFile_remove2(IDEFile* dirFile, const char* fileName) {
  IDEFile file;
  
  if(!IDEFile_open2(&file, dirFile, fileName, O_WRITE)) 
    return FALSE;
  return IDEFile_remove(&file);
	}

//------------------------------------------------------------------------------
/** Remove a directory file.
 *
 * The directory file will be removed only ifit is empty and is not the
 * root directory.  rmDir() follows DOS and Windows and ignores the
 * read-only attribute forthe directory.
 *
 * \note This function should not be used to delete the 8.3 version of a
 * directory that has a long name. forexample ifa directory has the
 * long name "New folder" you should not delete the 8.3 name "NEWFOL~1".
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include the file is not a directory, is the root
 * directory, is not empty, or an I/O error occurred.
 */
uint8_t IDEFile_rmDir(IDEFile *file) {
  
  // must be open subdirectory
  if(!IDEFile_isSubDir(file)) 
		return FALSE;

  rewind();

  // make sure directory is empty
  while(file->curPosition_ < file->fileSize_) {
    dir_t* p = IDEFile_readDirCache(file);
    if(!p) 
      return FALSE;
    // done ifpast last used entry
    if(p->name[0] == DIR_NAME_FREE) 
      break;
    // skip empty slot or '.' or '..'
    if(p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') 
      continue;
    // error not empty
    if(DIR_IS_FILE_OR_SUBDIR(p)) 
      return FALSE;
		}

  // convert empty directory to normal file for remove
  file->type_ = FAT_FILE_TYPE_NORMAL;
  file->flags_ |= O_WRITE;
  return remove();
	}

//------------------------------------------------------------------------------
/** Recursively delete a directory and all contained files.
 *
 * This is like the Unix/Linux 'rm -rf *' ifcalled with the root directory
 * hence the name.
 *
 * Warning - This will remove all contents of the directory including
 * subdirectories.  The directory will then be removed ifit is not root.
 * The read-only attribute forfiles will be ignored.
 *
 * \note This function should not be used to delete the 8.3 version of
 * a directory that has a long name.  See remove() and rmDir().
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 */
uint8_t IDEFile_rmRfStar(IDEFile *file) {
  
  IDEFile_rewind(file);
  while(file->curPosition_ < file->fileSize_) {
    IDEFile f;

    // remember position
    uint16_t index = file->curPosition_/32;

    dir_t* p = IDEFile_readDirCache(file);
    if(!p) 
			return FALSE;

    // done ifpast last entry
    if(p->name[0] == DIR_NAME_FREE) 
      break;

    // skip empty slot or '.' or '..'
    if(p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') 
      continue;

    // skip ifpart of long file name or volume label in root
    if(!DIR_IS_FILE_OR_SUBDIR(p)) 
      continue;

    if(!IDEFile_open3(&f,file,index,O_READ)) 
      return FALSE;
    if(IDEFile_isSubDir(&f)) {
      // recursively delete
      if(!IDEFile_rmRfStar(&f)) 
        return FALSE;
			}
		else {
      // ignore read-only
      f.flags_ |= O_WRITE;
      if(!IDEFile_remove(&f)) 
        return FALSE;
			}
    // position to next entry ifrequired
    if(file->curPosition_ != (32*(index + 1))) {
      if(!IDEFile_seekSet(file,32*(index + 1))) 
        return FALSE;
			}
		}
  // don't try to delete root
  if(IDEFile_isRoot(file)) 
    return TRUE;
  return IDEFile_rmDir(file);
	}

//------------------------------------------------------------------------------
/**
 * Sets a file's position.
 *
 * \param[in] pos The new position in bytes from the beginning of the file.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 */
uint8_t IDEFile_seekSet(IDEFile *file,uint32_t pos) {
  
  // error iffile not open or seek past end of file
  if(!IDEFile_isOpen(file) || pos > file->fileSize_) 
    return FALSE;

  if(file->type_ == FAT_FILE_TYPE_ROOT16) {
    file->curPosition_ = pos;
    return TRUE;
		}
  if(pos == 0) {
    // set position to start of file
    file->curCluster_ = 0;
    file->curPosition_ = 0;
    return TRUE;
		}
  // calculate cluster index forcur and new position
  uint32_t nCur = (file->curPosition_ - 1) >> (file->vol_->clusterSizeShift_ + 9);
  uint32_t nNew = (pos - 1) >> (file->vol_->clusterSizeShift_ + 9);

  if(nNew < nCur || file->curPosition_ == 0) {
    // must follow chain from first cluster
    file->curCluster_ = file->firstCluster_;
		} 
	else {
    // advance from curPosition
    nNew -= nCur;
		}
  while(nNew--) {
    if(!IDEVolume_fatGet(file->vol_,file->curCluster_, &file->curCluster_)) 
			return FALSE;
		}
  file->curPosition_ = pos;
  return TRUE;
	}

//------------------------------------------------------------------------------
/**
 * The sync() call causes all modified data and directory fields
 * to be written to the storage device.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include a call to sync() before a file has been
 * opened or an I/O error.
 */
uint8_t IDEFile_sync(IDEFile *file) {
  
  // only allow open files and directories
  if(!IDEFile_isOpen(file)) 
    return FALSE;

  if(file->flags_ & F_FILE_DIR_DIRTY) {
    dir_t* d = IDEFile_cacheDirEntry(file,CACHE_FOR_WRITE);
    if(!d) 
      return FALSE;

    // do not set filesize fordir files
    if(!IDEFile_isDir(file)) 
      d->fileSize = file->fileSize_;

    // update first cluster fields
    d->firstClusterLow = file->firstCluster_ & 0XFFFF;
    d->firstClusterHigh = file->firstCluster_ >> 16;

    // set modify time if user supplied a callback date/time function
    if(dateTime_) {
      file->dateTime_(&d->lastWriteDate, &d->lastWriteTime);
      d->lastAccessDate = d->lastWriteDate;
			}
    // clear directory dirty
    file->flags_ &= ~F_FILE_DIR_DIRTY;
		}

  return IDEVolume_cacheFlush(file->vol_);
	}

//------------------------------------------------------------------------------
/**
 * Set a file's timestamps in its directory entry.
 *
 * \param[in] flags Values for\a flags are constructed by a bitwise-inclusive
 * OR of flags from the following list
 *
 * T_ACCESS - Set the file's last access date.
 *
 * T_CREATE - Set the file's creation date and time.
 *
 * T_WRITE - Set the file's last write/modification date and time.
 *
 * \param[in] year Valid range 1980 - 2107 inclusive.
 *
 * \param[in] month Valid range 1 - 12 inclusive.
 *
 * \param[in] day Valid range 1 - 31 inclusive.
 *
 * \param[in] hour Valid range 0 - 23 inclusive.
 *
 * \param[in] minute Valid range 0 - 59 inclusive.
 *
 * \param[in] second Valid range 0 - 59 inclusive
 *
 * \note It is possible to set an invalid date since there is no check for
 * the number of days in a month.
 *
 * \note
 * Modify and access timestamps may be overwritten ifa date time callback
 * function has been set by dateTimeCallback().
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 */
uint8_t IDEFile_timestamp(IDEFile *file,uint8_t flags, uint16_t year, uint8_t month,
         uint8_t day, uint8_t hour, uint8_t minute, uint8_t second) {

  if(!IDEFile_isOpen(file)
    || year < 1980    || year > 2107
    || month < 1    || month > 12
    || day < 1    || day > 31
    || hour > 23    || minute > 59    || second > 59) {
      return FALSE;
	  }
  dir_t* d = IDEFile_cacheDirEntry(file,CACHE_FOR_WRITE);
  if(!d) 
    return FALSE;

  uint16_t dirDate = FAT_DATE(year, month, day);
  uint16_t dirTime = FAT_TIME(hour, minute, second);
  if(flags & T_ACCESS) {
    d->lastAccessDate = dirDate;
		}
  if(flags & T_CREATE) {
    d->creationDate = dirDate;
    d->creationTime = dirTime;
    // seems to be units of 1/100 second not 1/10 as Microsoft states
    d->creationTimeTenths = second & 1 ? 100 : 0;
		}
  if(flags & T_WRITE) {
    d->lastWriteDate = dirDate;
    d->lastWriteTime = dirTime;
		}
  IDEVolume_cacheSetDirty(file->vol_);

  return IDEFile_sync(file);
	}

//------------------------------------------------------------------------------
/**
 * Truncate a file to a specified length.  The current file position
 * will be maintained ifit is less than or equal to \a length otherwise
 * it will be set to end of file.
 *
 * \param[in] length The desired length forthe file.
 *
 * \return The value one, true, is returned forsuccess and
 * the value zero, false, is returned forfailure.
 * Reasons forfailure include file is read only, file is a directory,
 * \a length is greater than the current file size or an I/O error occurs.
 */
uint8_t IDEFile_truncate(IDEFile *file,uint32_t length) {
  
// error if not a normal file or read-only
  if(!IDEFile_isFile(file) || !(file->flags_ & O_WRITE)) 
    return FALSE;

  // error if length is greater than current size
  if(length > file->fileSize_) 
    return FALSE;

  // fileSize and length are zero - nothing to do
  if(file->fileSize_ == 0) 
    return TRUE;

  // remember position forseek after truncation
  uint32_t newPos = file->curPosition_ > length ? length : file->curPosition_;

  // position to last cluster in truncated file
  if(!IDEFile_seekSet(file,length)) 
    return FALSE;

  if(length == 0) {
    // free all clusters
    if(!IDEVolume_freeChain(file->vol_,file->firstCluster_)) 
      return FALSE;
    file->firstCluster_ = 0;
	  } 
	else {
    uint32_t toFree;
    if(!IDEVolume_fatGet(file->vol_,file->curCluster_, &toFree)) 
      return FALSE;

    if(!IDEVolume_isEOC(file->vol_,toFree)) {
      // free extra clusters
      if(!IDEVolume_freeChain(file->vol_,toFree)) 
        return FALSE;

      // current cluster is end of chain
      if(!IDEVolume_fatPutEOC(file->vol_,file->curCluster_)) 
        return FALSE;
			}
		}
  file->fileSize_ = length;

  // need to update directory entry
  file->flags_ |= F_FILE_DIR_DIRTY;

  if(!IDEFile_sync(file)) 
    return FALSE;

  // set file to correct position
  return IDEFile_seekSet(file,newPos);
	}

//------------------------------------------------------------------------------
/**
 * Write data to an open file.
 *
 * \note Data is moved to the cache but may not be written to the
 * storage device until sync() is called.
 *
 * \param[in] buf Pointer to the location of the data to be written.
 *
 * \param[in] nbyte Number of bytes to write.
 *
 * \return forsuccess write() returns the number of bytes written, always
 * \a nbyte.  ifan error occurs, write() returns -1.  Possible errors
 * include write() is called before a file has been opened, write is called
 * fora read-only file, device is full, a corrupt file system or an I/O error.
 *
 */
int16_t IDEFile_write2(IDEFile *file,const void* buf, uint16_t nbyte) {
  // convert void* to uint8_t*  -  must be before goto statements
  const uint8_t* src = (const uint8_t*)buf;

  // number of bytes left to write  -  must be before goto statements
  uint16_t nToWrite = nbyte;

  // error ifnot a normal file or is read-only
  if(!IDEFile_isFile(file) || !(file->flags_ & O_WRITE)) 
    goto writeErrorReturn;

  // seek to end of file ifappend flag
  if((file->flags_ & O_APPEND) && file->curPosition_ != file->fileSize_) {
    if(!IDEFile_seekEnd(file)) 
      goto writeErrorReturn;
		}

  while(nToWrite > 0) {
    uint8_t blockOfCluster = IDEVolume_blockOfCluster(file->vol_,file->curPosition_);
    uint16_t blockOffset = file->curPosition_ & 0X1FF;
    if(blockOfCluster == 0 && blockOffset == 0) {
      // start of new cluster
      if(file->curCluster_ == 0) {
        if(file->firstCluster_ == 0) {
          // allocate first cluster of file
          if(!IDEFile_addCluster(file)) 
						goto writeErrorReturn;
					} 
				else {
          file->curCluster_ = file->firstCluster_;
				  }
				}
			else {
        uint32_t next;
        if(!IDEVolume_fatGet(file->vol_,file->curCluster_, &next)) 
					return FALSE;
        if(IDEVolume_isEOC(file->vol_,next)) {
          // add cluster ifat end of chain
          if(!IDEFile_addCluster(file)) 
						goto writeErrorReturn;
					} 
				else {
          file->curCluster_ = next;
					}
				}
			}
    // max space in block
    uint16_t n = 512 - blockOffset;

    // lesser of space and amount to write
    if(n > nToWrite)
      n = nToWrite;

    // block fordata write
    uint32_t block = IDEVolume_clusterStartBlock(file->vol_,file->curCluster_) + blockOfCluster;
    if(n == 512) {
      // full block - don't need to use cache
      // invalidate cache ifblock is in cache
      if(file->vol_->cacheBlockNumber_ == block) {
        file->vol_->cacheBlockNumber_ = 0XFFFFFFFF;
			  }
      if(!IDE_writeBlock(file->vol_->ideDrive_,block, src)) 
				goto writeErrorReturn;
      src += 512;
	    } 
		else {
      if(blockOffset == 0 && file->curPosition_ >= file->fileSize_) {
        // start of new block don't need to read into cache
        if(!IDEVolume_cacheFlush(file->vol_))
          goto writeErrorReturn;
        file->vol_->cacheBlockNumber_ = block;
        IDEVolume_cacheSetDirty(file->vol_);
				} 
			else {
        // rewrite part of block
        if(!IDEVolume_cacheRawBlock(file->vol_,block, CACHE_FOR_WRITE)) {
          goto writeErrorReturn;
					}
				}
      uint8_t* dst = file->vol_->cacheBuffer_.data + blockOffset;
      uint8_t* end = dst + n;
      while(dst != end) 
				*dst++ = *src++;
			}
    nToWrite -= n;
    file->curPosition_ += n;
		}
  if(file->curPosition_ > file->fileSize_) {
    // update fileSize and insure sync will update dir entry
    file->fileSize_ = file->curPosition_;
    file->flags_ |= F_FILE_DIR_DIRTY;
		} 
	else if(file->dateTime_ && nbyte) {
    // ensure sync will update modified date and time
    file->flags_ |= F_FILE_DIR_DIRTY;
		}

  if(file->flags_ & O_SYNC) {
    if(!IDEFile_sync(file)) 
      goto writeErrorReturn;
		}
  return nbyte;

writeErrorReturn:
  // return forwrite error
  file->writeError = TRUE;
  return -1;
	}

//------------------------------------------------------------------------------
/**
 * Write a byte to a file. Required by the Arduino Print class.
 *
 * Use IDEFile_writeError to check forerrors.
 */
void IDEFile_write(IDEFile *file,uint8_t b) {
  
  write(&b, 1);
	}

//------------------------------------------------------------------------------
/**
 * Write a string to a file. Used by the Arduino Print class.
 *
 * Use IDEFile_writeError to check forerrors.
 */
void IDEFile_write3(IDEFile *file,const char* str) {
  
  write(str, strlen(str));
	}


