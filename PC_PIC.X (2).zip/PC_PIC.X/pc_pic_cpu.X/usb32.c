#include "system_config.h"
#include "system_definitions.h"

#include "harmony_app.h"
#include "usb_host_msd.h"


void SYS_Tasks(void) {

  // Maintain system services 
  
  // SYS_TMR Device layer tasks routine 
  SYS_TMR_Tasks(sysObj.sysTmr);

  // Maintain Device Drivers 

  // Maintain Middleware & Other Libraries 
 
  // USBHS Driver Task Routine 
  DRV_USBHS_Tasks(sysObj.drvUSBObject);
         
#ifdef USA_USB_HOST
  // USB Host layer task routine.
  USB_HOST_Tasks(sysObj.usbHostObject0);
#endif

#ifdef USA_USB_SLAVE_CDC
  // USB Device layer tasks routine 
  USB_DEVICE_Tasks(sysObj.usbDevObject0);
#endif
  
  // Maintain the application's state machine. 
  APP_Tasks();
	}




// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************


/******************************************************
 * USB Driver Initialization
 ******************************************************/
// *****************************************************************************
/* USB VBUS Switch State

  Summary:
    Defines the possible states of the USB VBUS Switch on this board

  Description:
    This enumeration defines the possible states of the USB VBUS Switch on this
    board.

  Remarks:
 presi da BSP. andate a casa...
*/

#ifdef USA_USB_HOST
typedef enum {
    // USB VBUS Switch disable 
    BSP_USB_VBUS_SWITCH_STATE_DISABLE = /*DOM-IGNORE-BEGIN*/0/*DOM-IGNORE-END*/,
    // USB VBUS Switch enable 
    BSP_USB_VBUS_SWITCH_STATE_ENABLE = /*DOM-IGNORE-BEGIN*/1/*DOM-IGNORE-END*/
  } BSP_USB_VBUS_SWITCH_STATE;
void BSP_USBVBUSPowerEnable(uint8_t port, bool enable);
bool BSP_USBVBUSSwitchOverCurrentDetect(uint8_t port);
#endif

/****************************************************
 * Endpoint Table needed by the Device Layer.
 ****************************************************/
uint8_t __attribute__((aligned(512))) endPointTable[DRV_USBHS_ENDPOINTS_NUMBER * 32];

const DRV_USBHS_INIT drvUSBHSInit = {
  
#ifdef USA_USB_HOST
    /* Interrupt Source for USB module */
    .interruptSource = INT_SOURCE_USB_1,
    
    /* Interrupt Source for USB module */
    .interruptSourceUSBDma = INT_SOURCE_USB_1_DMA,

    /* System module initialization */
    .moduleInit = {SYS_MODULE_POWER_RUN_FULL},

    /* Operation Mode */
    .operationMode = DRV_USBHS_OPMODE_HOST,

    /* Operation Speed */ 
    .operationSpeed = USB_SPEED_HIGH,
    
    /* Stop in idle */
    .stopInIdle = false,

    /* Suspend in sleep */
    .suspendInSleep = false,

    /* Identifies peripheral (PLIB-level) ID */
    .usbID = USBHS_ID_0,
    
    /* Root Hub Port indication */
    .portIndication = NULL,
        
     /* Power Enable */ 
    .portPowerEnable = BSP_USBVBUSPowerEnable,
    
    /* Over Current detection */ 
    .portOverCurrentDetect = BSP_USBVBUSSwitchOverCurrentDetect,
    
     /* Available Current */
    .rootHubAvailableCurrent = 500,
#endif
     
    
#ifdef USA_USB_SLAVE_CDC
    .endpointTable= endPointTable,
    
    // Interrupt Source for USB module
    .interruptSource = INT_SOURCE_USB_1,
    
    // Interrupt Source for USB module
    .interruptSourceUSBDma = INT_SOURCE_USB_1_DMA,

    // System module initialization
    .moduleInit = {SYS_MODULE_POWER_RUN_FULL},

    // Operation Mode
    .operationMode = DRV_USBHS_OPMODE_DEVICE,

    // Operation Speed
    .operationSpeed = /*USB_SPEED_FULL */USB_SPEED_HIGH,
    
    // Stop in idle
    .stopInIdle = false,

    // Suspend in sleep
    .suspendInSleep = false,

    // Identifies peripheral (PLIB-level) ID
    .usbID = USBHS_ID_0
    
#endif
  };

/* Structure to hold the object handles for the modules in the system. */
SYSTEM_OBJECTS sysObj;



// *****************************************************************************
// *****************************************************************************
// Section: Module Initialization Data
// *****************************************************************************
// *****************************************************************************

/*** File System Initialization Data ***/

#ifdef USA_USB_HOST_MSD
const SYS_FS_MEDIA_MOUNT_DATA sysfsMountTable[SYS_FS_VOLUME_NUMBER] = {
    
    {
		.mountName = SYS_FS_MEDIA_IDX0_MOUNT_NAME_VOLUME_IDX0,
		.devName   = SYS_FS_MEDIA_IDX0_DEVICE_NAME_VOLUME_IDX0, 
		.mediaType = SYS_FS_MEDIA_TYPE_IDX0,
		.fsType   = SYS_FS_TYPE_IDX0   
    },
         
	};


const SYS_FS_REGISTRATION_TABLE sysFSInit[SYS_FS_MAX_FILE_SYSTEM_TYPE] = {
    {
        .nativeFileSystemType = FAT,
        .nativeFileSystemFunctions = &FatFsFunctions
    }
	};
#endif


const DRV_TMR_INIT drvTmr0InitData = {
    .moduleInit.sys.powerState = DRV_TMR_POWER_STATE_IDX0,
    .tmrId = DRV_TMR_PERIPHERAL_ID_IDX0,
    .clockSource = DRV_TMR_CLOCK_SOURCE_IDX0,
    .prescale = DRV_TMR_PRESCALE_IDX0,
    .mode = DRV_TMR_OPERATION_MODE_IDX0,
    .interruptSource = DRV_TMR_INTERRUPT_SOURCE_IDX0,
    .asyncWriteEnable = false,
  };

/*** TMR Service Initialization Data ***/
const SYS_TMR_INIT sysTmrInitData = {
    .moduleInit = {SYS_MODULE_POWER_RUN_FULL},
    .drvIndex = DRV_TMR_INDEX_0,
    .tmrFreq = 1000, 
	}; 

// *****************************************************************************
// *****************************************************************************
// Section: Library/Stack Initialization Data
// *****************************************************************************
// *****************************************************************************

#if defined(USA_USB_HOST)
const USB_HOST_TPL_ENTRY USBTPList[ USB_HOST_TPL_ENTRIES ] = {
	
#if defined(USA_USB_HOST_UVC)
  TPL_INTERFACE_CLASS(USB_UVC_CLASS_CODE, NULL, (void*)USB_HOST_UVC_INTERFACE),
//  TPL_INTERFACE_CLASS(USB_VENDOR_SPECIFIC_CLASS_CODE, NULL, (void*)USB_HOST_UVC_INTERFACE),
//  TPL_INTERFACE_CLASS(USB_AUDIO_CLASS_CODE, NULL, (void*)USB_HOST_AUDIO_V1_INTERFACE),
//  TPL_INTERFACE_CLASS_SUBCLASS_PROTOCOL(0x08, 0x06, 0x50, NULL, USB_HOST_MSD_INTERFACE) ,
  
  //webcam PSP:
// ff 0 0; 2    // vendor specific
// 01 1 0; 2    // audio
// 01 2 0; 2    // audio
  
  //scheda cattura USB:
// 0e 3 0; 1    // video/UVC
// 01 1 0; 2    // audio
// 01 1 0; 2    // audio


	
// per webcam: https://www.microchip.com/forums/m518341.aspx
//    {  SC_VIDEOCONTROL 1 ( 8ul, 6ul, 0x50ul ), 0, 0, {TPL_CLASS_DRV} } // 
//    ,
//    { INIT_CL_SC_P( 8ul, 5ul, 0x50ul ), 0, 0, {TPL_CLASS_DRV} } // 
#endif
#if defined(USA_USB_HOST_MSD)
  TPL_INTERFACE_CLASS_SUBCLASS_PROTOCOL(0x08, 0x06, 0x50, NULL,  USB_HOST_MSD_INTERFACE) ,
#endif
  
	};


const USB_HOST_HCD hcdTable = {
  .drvIndex = DRV_USBHS_INDEX_0,
  .hcdInterface = DRV_USBHS_HOST_INTERFACE
	};

const USB_HOST_INIT usbHostInitData = {
  .nTPLEntries = 1 ,
  .tplList = (USB_HOST_TPL_ENTRY *)USBTPList,
  .hostControllerDrivers = (USB_HOST_HCD *)&hcdTable
	};
#endif

#ifdef USA_USB_SLAVE_CDC
/**************************************************
 * USB Device Function Driver Init Data
 **************************************************/
const USB_DEVICE_CDC_INIT cdcInit0 = {
    .queueSizeRead = 1,
    .queueSizeWrite = 1,
    .queueSizeSerialStateNotification = 1
    };
    
/**************************************************
 * USB Device Layer Function Driver Registration Table
 **************************************************/
const USB_DEVICE_FUNCTION_REGISTRATION_TABLE funcRegistrationTable[1] = {
    // Function 1
    { 
        .configurationValue = 1,    /* Configuration value */ 
        .interfaceNumber = 0,       /* First interfaceNumber of this function */ 
        .speed = USB_SPEED_HIGH | USB_SPEED_FULL,    /* Function Speed */ 
        .numberOfInterfaces = 2,    /* Number of interfaces */
        .funcDriverIndex = 0,  /* Index of CDC Function Driver */
        .driver = (void*)USB_DEVICE_CDC_FUNCTION_DRIVER,    /* USB CDC function data exposed to device layer */
        .funcDriverInit = (void*)&cdcInit0    /* Function driver init data */
    },
  };

extern const USB_DEVICE_MASTER_DESCRIPTOR usbMasterDescriptor;

/****************************************************
 * USB Device Layer Initialization Data
 ****************************************************/
const USB_DEVICE_INIT usbDevInitData = {
    // System module initialization
    .moduleInit = {SYS_MODULE_POWER_RUN_FULL},
    
    // Number of function drivers registered to this instance of the USB device layer
    .registeredFuncCount = 1,
    
    // Function driver table registered to this instance of the USB device layer
    .registeredFunctions = (USB_DEVICE_FUNCTION_REGISTRATION_TABLE*)funcRegistrationTable,

    // Pointer to USB Descriptor structure
    .usbMasterDescriptor = (USB_DEVICE_MASTER_DESCRIPTOR*)&usbMasterDescriptor,

    // USB Device Speed
    .deviceSpeed = USB_SPEED_HIGH,
    
    // Index of the USB Driver to be used by this Device Layer Instance
    .driverIndex = DRV_USBHS_INDEX_0,

    // Pointer to the USB Driver Functions.
    .usbDriverInterface = DRV_USBHS_DEVICE_INTERFACE,
    
  };
#endif

// *****************************************************************************
// *****************************************************************************
// Section: System Initialization
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void SYS_Initialize(void *data)

  Summary:
    Initializes the board, services, drivers, application and other modules.

  Remarks:
    See prototype in system/common/sys_module.h.
 */
void SYS_Initialize(void *data) {

  // Initialize Drivers 
  sysObj.drvTmr0 = DRV_TMR_Initialize(DRV_TMR_INDEX_0, (SYS_MODULE_INIT *)&drvTmr0InitData);

  SYS_INT_VectorPrioritySet(INT_VECTOR_T2, INT_PRIORITY_LEVEL4);
  SYS_INT_VectorSubprioritySet(INT_VECTOR_T2, INT_SUBPRIORITY_LEVEL0);
 
 
  // Initialize USB Driver 
  sysObj.drvUSBObject = DRV_USBHS_Initialize(DRV_USBHS_INDEX_0, (SYS_MODULE_INIT *)&drvUSBHSInit);
    
  // Set priority of USB interrupt source 
  SYS_INT_VectorPrioritySet(INT_VECTOR_USB1, INT_PRIORITY_LEVEL5);

  // Set Sub-priority of USB interrupt source 
  SYS_INT_VectorSubprioritySet(INT_VECTOR_USB1, INT_SUBPRIORITY_LEVEL0);

  // Set the priority of the USB DMA Interrupt 
  SYS_INT_VectorPrioritySet(INT_VECTOR_USB1_DMA, INT_PRIORITY_LEVEL5);

  // Set Sub-priority of the USB DMA Interrupt 
  SYS_INT_VectorSubprioritySet(INT_VECTOR_USB1_DMA, INT_SUBPRIORITY_LEVEL0);
    
  // Initialize System Services 
//    SYS_PORTS_Initialize();


  /*** Interrupt Service Initialization Code ***/
  SYS_INT_Initialize();

  /*** TMR Service Initialization Code ***/
  sysObj.sysTmr  = SYS_TMR_Initialize(SYS_TMR_INDEX_0, (const SYS_MODULE_INIT *const)&sysTmrInitData);

  /* Initialize Middleware */
 
#ifdef USA_USB_HOST
  // Initialize the USB Host layer 
  sysObj.usbHostObject0 = USB_HOST_Initialize((SYS_MODULE_INIT *)&usbHostInitData);
#endif
#ifdef USA_USB_SLAVE_CDC
  /* Initialize the USB device layer */
  sysObj.usbDevObject0 = USB_DEVICE_Initialize(USB_DEVICE_INDEX_0 , (SYS_MODULE_INIT *)&usbDevInitData);
#endif

  // Enable Global Interrupts 
  SYS_INT_Enable();

  // Initialize the Application 
  APP_Initialize();
  
#ifdef USBID_OVERRIDE   // v. anche USBHS_USBIDOverrideEnable_Default
  USBCRCONbits.USBIDOVEN = 1;
  USBCRCONbits.USBIDVAL = 0; //0 = force USB A (Host), 1 = force USB B (Device)
#endif
	}


#ifdef USA_USB_HOST
void BSP_USBVBUSPowerEnable(uint8_t port, bool enable) {
    /* Enable the VBUS switch */

//  PLIB_PORTS_PinWrite( PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_13, enable );
  //ma potrebbe essere RB5 su DM32
#warning . VERIFICARE USB POWER
  if(enable) {
//    *(&LATBSET + (6 - 1) * 0x40) = 1<<13;
    LATBSET = _LATB_LATB5_MASK;
    }
  else {
//    *(&LATBCLR + (6 - 1) * 0x40) = 1<<13;
    LATBCLR = _LATB_LATB5_MASK;
    }
  }

bool BSP_USBVBUSSwitchOverCurrentDetect(uint8_t port) {
  
  return(false);
  }
#endif

