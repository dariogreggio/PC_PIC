#ifndef _INCLUDES_H
#define _INCLUDES_H


/***********************************************
*                 includes.h
*
* Sorts out processor family specific includes and defines.
*
* Started: 6 December 2007 - Michael Pearce
*
* Currently supported:
*  Microchip PIC18, dsPIC33, PIC32
*
************************************************
*         Version Information
************************************************
* 20071206 - Start of file - Michael Pearce
* 20071206 - readapted to C18 - Dario Greggio
* 20190811 - readapted to C32 - Dario Greggio
* 20200214 - readapted to XC16/forgetIVrea - Dario/C Greggio
* 20210902 - readapted to XC32/PC_PIC motherboard - Dario/Katia Greggio
***********************************************/



#define MINIBASIC_COPYRIGHT_STRING "MiniBasic for PIC32MZ v2.1.0 - 28/6/2022\n"

#include <xc.h>


typedef const char * STRINGFARPTR;
typedef const char * STRINGPTR;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>   //??
#include <stdarg.h>
#include <math.h>
#include <limits.h>
#include <ctype.h>
#include <assert.h>


//#include <malloc.h>


#define _H_USER ((FILE*)((int)-1))
#define _H_USART ((FILE*)((int)-2));
  



#include "../genericTypedefs.h"
#include "../pc_pic_cpu.h"
//#include "../../pc_pic_video.X/Adafruit_GFX.h"
#include "../../pc_pic_video.X/Adafruit_colors.h"
#include "../../pc_pic_video.X/gfxfont.h"
#include "minibasic.h"
#include "iohw.h"
#include "fat_sd/fsconfig.h"
#include "fat_sd/fsio.h"



#endif   // _INCLUDES_H



