#ifndef basic_h
#define basic_h
/*
  Minibasic header file
  By Malcolm Mclean
*/

#include "serial.h"

#define IDLENGTH 8    /* maximum length of variable */
#define MAXFORS 8     /* maximum number of nested fors */
#define MAXGOSUB 8    /* maximum number of gosubs */
#define MAXDIMS 2     /* maximum indices for dimensions */
#define BSTATIC static

/*#define INTONLY  */     /* numbers are integers rather than double */
#undef SMALLTOKENS    /* use shortened tokens to reduce program size */
#define STDINOUT      /* use stdin/stdout for print/input, otherwise you have to define it */

#ifdef INTONLY
#define NUMTYPE int
#undef USEFLOATS
#else
#define NUMTYPE double
#define USEFLOATS
#endif

#ifdef STDINOUT
#define outchar(x) putchar_serial0(x)
#define inchar() waitkey_serial0()
#define inkey() getkey_serial0()
#undef INEOF
#define ineof() 0
#define outflush() {};
#endif

#define PEEKPOKE
#define NEXTLG 3   /* controls chunk size for allocation of variables */

#undef BASICASSERT

#ifdef BASICASSERT
#define ASSERTDEBUG(x) x
#else
#define ASSERTDEBUG(x) {}
#endif

typedef void (*addbasictoken)(int chv, void *v);

int basic(const char *script);
void outstrint(char *s, int x);
void outstrhex(char *s, unsigned int x);
void outstr(char *x);
void outint(int x);
int instrn(char *x, int len);
int innum(NUMTYPE *val);
char *myitoa(int n);
char *myitoahex(unsigned int n);
long mystrtol(const char *str, char **end);

typedef struct 
{
  int inquote;
  int notlastspace;
} tokstat;

typedef struct
{
  char *s;
  int toknum;
  int charnum;
} untokstat;

void inittokenizestate(tokstat *t);
void tokenizeline(char *str, char **end, tokstat *tk, addbasictoken abt, void *v);
void inituntokenizestate(untokstat *utk, char *str);
int untokenizecode(untokstat *utk);

#endif
