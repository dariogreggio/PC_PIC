#ifndef _MINIBASIC_H
#define _MINIBASIC_H

/*
  Minibasic header file
  By Malcolm Mclean
  Small changes for PIC18, by DarioG 29/11/07
  Start Changes for Dspic33fj256GP710  JeffD 25/10/08
  Start Changes for PIC24FJ256GA010  CG 14/5/14 (la morte sia con rivoli e giaveno)
  Start Changes for dsPIC33EP512GP502  DG/CG 29/9/14 (after a lovely skirty day!)
	Changes for VGA24, 07.15
  Start Changes for PIC32MZ  GD 11/8/19 FUCK HUMANS! DIE!!
  Breakthrough version 2021
*/


#include <stdio.h>
#include "../../generictypedefs.h"
#include "../../Compiler.h"

#include "../pc_pic_cpu.h"
#include "../breakthrough.h"



//--------------- Version -----------------------------------------

extern const char MiniBasicCopyrightString[];

//---------------- System Hardware Defs ---------------------------



#define IDLENGTH 32    /* maximum length of variable */
#define MAXFORS 32     /* maximum number of nested fors */
#define MAXDIMS 5     /* maximum indices for dimensions */
#define MAXGOSUB 32    /* maximum number of gosubs */
#define MAXFILES 10     // FS_MAX_FILES_OPEN


typedef uint16_t LINE_NUMBER_TYPE;

#undef SMALLTOKENS    /* use shortened tokens to reduce program size */



#define NUM_TYPE double




#define NEXTLG 3   /* controls chunk size for allocation of variables */

#undef BASICASSERT

#ifdef BASICASSERT
#define ASSERTDEBUG(x) x
#else
#define ASSERTDEBUG(x) {}
#endif

typedef void (*addbasictoken)(int chv, void *v);


// error codes (in BASIC script) defined 
enum __attribute__ ((__packed__)) MINIBASIC_ERRORS {
	ERR_CLEAR = 0,
	ERR_SYNTAX,
	ERR_OUTOFMEMORY,
	ERR_IDTOOLONG,
	ERR_NOSUCHVARIABLE,
	ERR_BADSUBSCRIPT,
	ERR_TOOMANYDIMS,
	ERR_TOOMANYINITS,
    ERR_BADTYPE,
	ERR_TOOMANYFORS,
	ERR_NONEXT,   //10
	ERR_NOFOR,
	ERR_DIVIDEBYZERO,
	ERR_NEGLOG,
	ERR_NEGSQRT,
	ERR_BADSINCOS,
	ERR_EOF,
	ERR_ILLEGALOFFSET,
	ERR_TYPEMISMATCH,
	ERR_INPUTTOOLONG,
	ERR_BADVALUE,   //20
	ERR_NOTINT,
	ERR_TOOMANYGOSUB,
	ERR_NORETURN,
	ERR_FORMULATOOCOMPLEX,
	ERR_FILE,
	ERR_NETWORK,
	ERR_STOP,
	ERR_INTERNAL    //27 per gestione eccezioni 
	};

//================================== Basic SCRIPT to run in script.c ===================================
extern const char demoscript[];
//======================================================================================================


void outstrint(char *s, int x);
void outstrhex(char *s, unsigned int x);
void outstr(char *x);
void outint(int x);
int instrn(char *x, int len);
int innum(NUM_TYPE *val);
char *myitoa(int n);
char *myitoahex(unsigned int n);
BYTE myhextob(char c);
unsigned int myhextoi(const char *p);

typedef struct  __attribute((packed)) {
  uint8_t inquote;
  uint8_t notlastspace;
	} TOKSTAT;

typedef struct  __attribute((packed)) {
  char *s;
  uint16_t toknum;
  uint16_t charnum;
	} UNTOKSTAT;

void inittokenizestate(TOKSTAT *t);
void tokenizeline(char *str, char **end, TOKSTAT *tk, addbasictoken abt, void *v);
void inituntokenizestate(UNTOKSTAT *utk, char *str);
int untokenizecode(UNTOKSTAT *utk);




void Delay_uS(unsigned char );
//void Delay_mS_free(WORD);



typedef uint16_t DIM_SIZE;
typedef uint8_t TOKEN_NUM;
typedef uint8_t IDENT_LEN;

typedef struct __attribute((packed)) {
  char *str;				/* points to start of line */
  LINE_NUMBER_TYPE no;                 /* line number */
	} LINE;

enum {
	FLTID=1,
	INTID=2,
	STRID=8
	};
    
typedef union __attribute((packed)) {
  NUM_TYPE dval;			  /* its value if a real */
  char    *sval;				/* its value if a string (malloced) */
  int     ival;	        /* its value if an int */
	} VARIABLEDATA;

typedef struct __attribute((packed)) {
  VARIABLEDATA d;               /* data in variable */
  char id[IDLENGTH];				/* id of variable */
  uint32_t /*uint8_t  ALIGNMENT in alloc dinamica! */   type;		    /* its type, STRID or FLTID or INTID */
	// unsigned int * fixed_address??
	} VARIABLE;

typedef union __attribute((packed)) {
  char        **str;	        /* pointer to string data */
  NUM_TYPE     *dval;	        /* pointer to real data */
  int         *ival;	        /* pointer to int data */
	} DIMVARPTR;

typedef struct __attribute((packed)) {
  char id[IDLENGTH];			/* id of dimensioned variable */
  TOKEN_NUM type;					/* its type, STRID or FLTID (or INTID)*/
  uint32_t /*uint8_t  ALIGNMENT in alloc dinamica! */  ndims;			/* number of dimensions */
  DIM_SIZE dim[MAXDIMS];			/* dimensions in x y order */
  DIMVARPTR     d;              /* pointers to string/real data */
	} DIMVAR;

typedef union __attribute((packed)) {
  char        **sval;			/* pointer to string data */
  NUM_TYPE     *dval;		    /* pointer to real data */
  int         *ival;	        /* pointer to int data */
	} LVALUEDATA;

typedef struct __attribute((packed)) {
  LVALUEDATA    d;              /* data pointed to by LVALUE */
  uint8_t type;			/* type of variable (STRID or FLTID or INTID or B_ERROR) */   
	} LVALUE;

typedef struct __attribute((packed)) {
  char id[IDLENGTH];			/* id of control variable */
// type??
  LINE_NUMBER_TYPE nextline;			/* line below FOR to which control passes */
  NUM_TYPE toval;			/* terminal value */
  NUM_TYPE step;			/* step size */
	} FORLOOP;

typedef struct __attribute((packed)) {
	void *handle;
	uint8_t number;
	uint8_t type;
	} FILE_DESCR;

enum _FILE_TYPES {
	FILE_COM,
#ifdef USA_USB_SLAVE_CDC
	FILE_CDC,
#endif
	FILE_USB,
	FILE_TCP,
	FILE_UDP,
	FILE_DISK
	};


typedef struct __attribute((packed)) {
	const char *tokenname;
	uint8_t length;
	} TOKEN_LIST;

typedef DWORD COLORREF;
/*typedef struct _COLORREF {
	char red;
	char green;
	char blue;
	} COLORREF; mah, no.. */


struct __attribute((packed)) EVENT_HANDLER {
	LINE_NUMBER_TYPE handler;
	LINE_NUMBER_TYPE errorline;
	enum MINIBASIC_ERRORS errorcode;
	};

typedef struct __attribute((packed)) _MINIBASIC {
  //OCCHIO ALLINEAMENTI!
  FORLOOP forStack[MAXFORS];   // stack for FOR loop control 
  LINE_NUMBER_TYPE gosubStack[MAXGOSUB];		// GOSUB stack
  LINE_NUMBER_TYPE doStack[MAXFORS];		// DO stack - same # allowed as for's
  uint8_t nfors;					// number of fors on stack
  uint8_t ngosubs;
  uint8_t ndos;
  uint8_t inBlock;

  FILE_DESCR openFiles[MAXFILES];		// open files descriptors


  VARIABLE *variables;			// the script's variables
  DIMVAR *dimVariables;		// dimensioned arrays
  LINE *lines;					// list of line starts

  uint16_t nvariables;				// number of variables
  uint16_t ndimVariables;			// number of dimensioned arrays
  uint16_t nlines;					// number of BASIC lines in program
  int16_t curline;      // usa -1 come marker di fine...

  char *string;        // string we are parsing

  HWND hWnd;
  THREAD *threadID;

  enum MINIBASIC_ERRORS errorFlag;           // set when error in input encountered
  uint8_t lastExprType;
  uint8_t nfiles;
  uint8_t incomingChar[2];
  
  struct __attribute((packed)) EVENT_HANDLER errorHandler,irqHandler;
  
  COLORREF Color,ColorBK;
  POINT Cursor;
  GFX_COLOR ColorPalette,ColorPaletteBK;

  TOKEN_NUM token;          // current token (lookahead)
  
  } MINIBASIC;
STATIC_ASSERT(!(sizeof(struct _MINIBASIC) % 4),0);

int basic(MINIBASIC *instance,const char *script,BYTE where);
void cleanup(MINIBASIC *minstance,uint8_t alsoprogram);

#endif


