/*****************************************************************
*                           Mini BASIC                           *
*                        by Malcolm McLean                       *
*                           version 1.0                          *
*                                                                *
*                  adapted to PIC18 etc  by  Dario Greggio       *
*                           29/11/2007  
*						started port to C30 Dspic33fJ256GP710    *
*						26/10/08 JeffD							*
* 					2014-2015 porting to dsPIC33 / XC16 (free)
*						2017: PIC24EP
*						2019: PIC32MZ, anche con USB host
 *          2020: forgetIvrea con display TFT ST7735, e ILI9341
 *          2021: PC_PIC motherboard, PIC32MZ
*****************************************************************/


#include "includes.h"
#include "../at_winc1500.h"
#include <ctype.h>

#if defined(USA_USB_HOST_MSD)
#include "../harmony_pic32mz/usb_host_msd.h"
#include "../harmony_pic32mz/usb_host_scsi.h"
#endif

// casini con ERR include finire #include "fat_ide/idefat.h"

#undef stricmp    // per at_winc1500 ... �$%@#
#undef strnicmp

extern BYTE eventReceived;
extern struct KEYPRESS keypress;
extern SIZE Screen,ScreenText;

BYTE byteRecMidi,byteRec232;
extern DWORD now;
#ifdef USA_WIFI
extern BYTE myRSSI;
extern Ipv4Addr myIp;
extern uint8_t internetBuffer[256];
extern uint8_t rxBuffer[1536];
#endif

struct SUPERFILE {    // v. COMMAND e unire! (casini con gli include...
  union {
    FSFILE *f1;
#if defined(USA_USB_HOST_MSD)
    SYS_FS_HANDLE f2;
#endif
//v.sopra    IDEFile *f3;
    void *f;
    };
  signed char drive;
  };
int subOpenfile(struct SUPERFILE *,const char *,char);
int subReadfile(struct SUPERFILE *,void *, uint16_t);
int subWritefile(struct SUPERFILE *, const void *, uint16_t);
int subClosefile(struct SUPERFILE *);

extern unsigned int __attribute__((section("_linkergenerated"))) _splim;
extern unsigned int __attribute__((section("_linkergenerated"))) _stack;
extern DWORD extRAMtot;


/* tokens defined */
#define EOS 23
#define VALUE 24
#define PI 40
#define E 41


#define B_ERROR 20
#define EOL 21
#define EQUALS 22
#define DIMFLTID 26
#define DIMSTRID 27
#define DIMINTID 28
#define QUOTE 29
#define GREATER 30
#define LESS 31
#define SEMICOLON 32
#define DIESIS 33
//#define AMPERSAND 38


enum __attribute((packed)){
	DIV=100,
	MULT,
	OPAREN,
  CPAREN,
  PLUS,
  MINUS,
  SHRIEK,
  AMPERSAND,
  COMMA,
  COLON,
  BITNOT,
  MOD,

	PRINT,PRINT2,
	LET,
	DIM,
	IF,
	THEN,
	ELSE,
	AND,
	OR,
	XOR,
	NOT,
	GOTO,
	INPUTTOK,
  OUTPUTTOK,   //123 v. doOpen
  APPEND,
  SERVER,
  CLIENT,
	REM,REM2,
	FOR,
	TO,
	NEXT,
	STEP,
	GOSUB,
	RETURN,
	DO,
	LOOP,
	WHILE,
	UNTIL,
	ON,
	ERRORTOK,
	BEGIN,
	BEND,
	IRQ,
	END,
	RUN,
	SHELL,
	CONTINUE,
	STOP,
	SLEEP,
	SYS,
	POKE,
	EEPOKE,
	SETPIN,
	OUTD,
	OUTDAC,
	SOUND,
	TONE,
	PLAY,
	BEEP,
	OPEN,
	CLOSE,
	AS,
	DIRTOK,CD,MD,RD,
	RENAME,DELETE,FORMAT,
	CLS,LOCATE,
	LINETOK,RECTANGLE,ELLIPSE,ARC,TRIANGLE,POINTTOK,SETCOLOR,SETBKCOLOR,BITBLT,
  LIST,NEW,LOAD,SAVE,QUIT,
	WIFICONNECT,
  
	SIN,
	COS,
	TAN,
	LOG,
	EXP,
	POW,
	SQR,
	ERR,
	STATUSTOK,
	PEEK,
	TIMER,
	ABS,
	MIN,
	MAX,
	IIF,
	LEN,
	ASC,
	ASIN,
	ACOS,
	ATAN,
	INTTOK,
	RND,
	VAL,
	VALLEN,
	MEM,
	USR,
	IND,
	INADC,
	INSTR,
	PENX,PENY,
	CURSORX,CURSORY,
	SCREENX,SCREENY,
	JOYSTICK,
	DISKSPACE,
	EEPEEK,
	TEMPERATURE,
	RSSI,
  BIOS,

	CHRSTRING,
	STRSTRING,
	LEFTSTRING,
	RIGHTSTRING,
	MIDSTRING,
	STRINGSTRING,
	HEXSTRING,
	TRIMSTRING,
	TIMESTRING,
	INKEYSTRING,
	MIDISTRING,
#ifdef USA_BREAKTHROUGH
	MENUKEYSTRING,
#endif
	ERRORSTRING,
  VERSTRING,
  DIRSTRING,
  CURDIRSTRING,
	IPADDRESSSTRING,
	ACCESSPOINTSSTRING,
	};


/* relational operators defined */

enum {
	ROP_EQ=1,         // equals 
	ROP_NEQ,	        // doesn't equal 
	ROP_LT,		        // less than 
	ROP_LTE,         // less than or equals 
	ROP_GT,          // greater than 
	ROP_GTE          // greater than or equals 
	};


static void doLine(MINIBASIC *);
static void doRectangle(MINIBASIC *);
static void doEllipse(MINIBASIC *);
static void doArc(MINIBASIC *);
static void doTriangle(MINIBASIC *);
static void doPoint(MINIBASIC *);
static void doSetcolor(MINIBASIC *);
static void doSetBkcolor(MINIBASIC *);
static void doBitblt(MINIBASIC *);


int inkey(void);
  
const GFX_COLOR textColors[16]={BLACK,BLUE,GREEN,CYAN, RED,MAGENTA,YELLOW,GRAY192 /*LIGHTGRAY*/,
	LIGHTGRAY /*DARKGRAY*/,BRIGHTBLUE,BRIGHTGREEN,BRIGHTCYAN, BRIGHTRED,BRIGHTMAGENTA,BRIGHTYELLOW,WHITE};   // come in MS-DOS :)

const char * const error_msgs[] = {
	"",
	"Syntax error",
	"Out of memory",
	"Identifier too long",
	"No such variable",
	"Bad subscript", 
	"Too many dimensions",
	"Too many initialisers",
	"Illegal type",
	"Too many nested FOR or DO",
	"FOR/DO without matching NEXT/LOOP",    //10
	"NEXT/LOOP without matching FOR/DO",
	"Divide by zero",
	"Negative logarithm",
	"Negative square root",
	"Sine or cosine out of range",
	"End of input file",
	"Illegal offset",
	"Type mismatch",
	"Input too long",
	"Bad value",
	"Not an integer",
	"Too many GOSUB",
	"RETURN without GOSUB",
	"Formula too complex",
	"File error",
	"Network error",
	"BREAKPOINT (press C to continue or ESC to stop)",
	"Fatal internal error"
	};



const char * const EmptyString="";

TOKEN_LIST const tl[] = {
	{ "PRINT",5 },
	{ "?",1 },
	{ "LET",3 },
	{ "DIM",3 },
	{ "IF",2 },
	{ "THEN",4 },
	{ "ELSE",4 },
	{ "AND",3 },
	{ "OR",2 },
	{ "XOR",3 },
	{ "NOT",3 },
	{ "GOTO",4 },
	{ "INPUT",5 },
	{ "OUTPUT",6 },
	{ "APPEND",6 },
	{ "SERVER",6 },
	{ "CLIENT",6 },
	{ "REM",3 },
	{ "'",1 },
	{ "FOR",3 },
	{ "TO",2 },
	{ "NEXT",4 },
	{ "STEP",4 },
	{ "GOSUB",5 },
	{ "RETURN",6 },
	{ "DO",2 },
	{ "LOOP",4 },
	{ "WHILE",5 },
	{ "UNTIL",5 },
	{ "ON",2 },
	{ "ERROR",5 },
	{ "BEGIN",5 },
	{ "BEND",4 },
	{ "IRQ",3 },
	{ "END",3 },
	{ "RUN",3 },
	{ "SHELL",5 },
	{ "CONTINUE",8 },
	{ "STOP",4 },
	{ "SLEEP",5 },
	{ "SYS",3 },
	{ "POKE",4 },
	{ "EEPOKE",6 },
	{ "SETPIN",6 },
	{ "OUTD",4 },
	{ "OUTDAC",6 },
	{ "SOUND",5 },
	{ "TONE",4 },
	{ "PLAY",4 },
	{ "BEEP",4 },
	{ "OPEN",4 },
	{ "CLOSE",5 },
	{ "AS",2 },
	{ "DIRCMD",6 }, { "CD",2 }, { "MD",2 }, { "RD",2 }, { "RENAME",3 }, { "DELETE",6 }, { "FORMAT",6 },
	{ "CLS",3 }, { "LOCATE",6 },
	{ "LINE",4 }, { "RECTANGLE",9 }, { "ELLIPSE",7 }, { "ARC",3 }, { "TRIANGLE",8 }, { "POINT",5 }, { "SETCOLOR",8 }, { "SETBKCOLOR",10 }, { "BITBLT",6 },
	{ "LIST",4 },
	{ "NEW",3 },
	{ "LOAD",4 },	{ "SAVE",4 },
	{ "QUIT",4 },
	{ "WIFICONNECT",11 },
  
	{ "SIN",3 },
	{ "COS",3 },
	{ "TAN",3 },
	{ "LOG",3 },
	{ "EXP",3 },
	{ "POW",3 },
	{ "SQR",3 },
	{ "ERR",3 },
	{ "STATUS",6 },
	{ "PEEK",4 },
	{ "TIMER",5 },
	{ "ABS",3 },
	{ "MIN",3 },
	{ "MAX",3 },
	{ "IIF",3 },
	{ "LEN",3 },
	{ "ASC",3 },
	{ "ASIN",4 },
	{ "ACOS",4 },
	{ "ATAN",4 },
	{ "INT",3 },
	{ "RND",3 },
	{ "VAL",3 },
	{ "VALLEN",6 },
	{ "MEM",3 },
	{ "USR",3 },
	{ "IND",3 },
	{ "INADC",5 },
	{ "INSTR",5 },
	{ "PENX",4 }, { "PENY",4 }, { "CURSORX",7 },{ "CURSORY",7 }, { "SCREENX",7 },{ "SCREENY",7 }, 
  { "JOYSTICK",8 },
  { "DISKSPACE",9 },
	{ "EEPEEK",6 },
	{ "TEMPERATURE",11 },
	{ "RSSI",4 },
	{ "BIOS",4 },

	{ "CHR$",4 },
	{ "STR$",4 },
	{ "LEFT$",5 },
	{ "RIGHT$",6 },
	{ "MID$",4 },
	{ "STRING$",7 },
	{ "HEX$",4 },
	{ "TRIM$",5 },
	{ "TIME$",5 },
	{ "INKEY$",6 },
	{ "MIDI$",5 },
#ifdef USA_BREAKTHROUGH
	{ "MENUKEY$",8 },
#endif
	{ "ER$",3 },
	{ "VER$",4 },
	{ "DIR$",4 },
	{ "CURDIR$",7 },
	{ "IPADDRESS$",10 },
	{ "ACCESSPOINTS$",13 },
	};


#define basicAssert(x) //myTextOut(mInstance,"assert!") //assert((x))



int setup(MINIBASIC *instance,char *script);
void cleanup(MINIBASIC *,uint8_t);

void reportError(MINIBASIC *,LINE_NUMBER_TYPE lineno);
int16_t findLine(MINIBASIC *,LINE_NUMBER_TYPE no);

LINE_NUMBER_TYPE line(MINIBASIC *mInstance);
void doPrint(MINIBASIC *);
void doLet(MINIBASIC *,int8_t);
void doDim(MINIBASIC *);
LINE_NUMBER_TYPE doIf(MINIBASIC *);
LINE_NUMBER_TYPE doGoto(MINIBASIC *);
LINE_NUMBER_TYPE doGosub(MINIBASIC *);
LINE_NUMBER_TYPE doReturn(MINIBASIC *);
LINE_NUMBER_TYPE doOn(MINIBASIC *);
void doInput(MINIBASIC *);
void doRem(MINIBASIC *);
LINE_NUMBER_TYPE doFor(MINIBASIC *);
LINE_NUMBER_TYPE doNext(MINIBASIC *);
LINE_NUMBER_TYPE doDo(MINIBASIC *);
LINE_NUMBER_TYPE doLoop(MINIBASIC *);
void doPoke(MINIBASIC *);
void doEEPoke(MINIBASIC *);
void doOpen(MINIBASIC *);
void doClose(MINIBASIC *);
void doSleep(MINIBASIC *);
void doSetpin(MINIBASIC *);
void doSound(MINIBASIC *);
void doTone(MINIBASIC *);
void doPlay(MINIBASIC *);
void doBeep(MINIBASIC *);
void doOutd(MINIBASIC *);
void doOutdac(MINIBASIC *);
void doSys(MINIBASIC *);
void doStop(MINIBASIC *);
void doError(MINIBASIC *);
void doDir(MINIBASIC *);
void doFormat(MINIBASIC *mInstance);
void doDelete(MINIBASIC *mInstance);
void doRename(MINIBASIC *mInstance);
void doCD(MINIBASIC *mInstance);
void doRD(MINIBASIC *mInstance);
void doMD(MINIBASIC *mInstance);
void doCls(MINIBASIC *);
void doLocate(MINIBASIC *);
LINE_NUMBER_TYPE doRun(MINIBASIC *);
void doShell(MINIBASIC *);
void doContinue(MINIBASIC *);
void doList(MINIBASIC *);
void doNew(MINIBASIC *);
void doLoad(MINIBASIC *);
void doSave(MINIBASIC *);
void doQuit(MINIBASIC *);
void doWificonnect(MINIBASIC *);

void lvalue(MINIBASIC *,LVALUE *lv);
int subLoad(char *,char *);

signed char boolExpr(MINIBASIC *);
signed char rop(MINIBASIC *,signed char , NUM_TYPE , NUM_TYPE);
signed char iRop(MINIBASIC *,signed char , int , int);
signed char strRop(MINIBASIC *,signed char , const char * , const char *);
signed char boolFactor(MINIBASIC *);
signed char relOp(MINIBASIC *);


NUM_TYPE expr(MINIBASIC *);
NUM_TYPE term(MINIBASIC *);
NUM_TYPE factor(MINIBASIC *);
NUM_TYPE instr(MINIBASIC *);
NUM_TYPE variable(MINIBASIC *);
int ivariable(MINIBASIC *);
NUM_TYPE dimVariable(MINIBASIC *);
int dimivariable(MINIBASIC *);


VARIABLE *findVariable(MINIBASIC *,const char *id);
DIMVAR *findDimVar(MINIBASIC *,const char *id);
DIMVAR *dimension(MINIBASIC *,const char *id, int ndims, ...);
void *getDimVar(MINIBASIC*,DIMVAR *dv, ...);
VARIABLE *addFloat(MINIBASIC *,const char *id);
VARIABLE *addString(MINIBASIC *,const char *id);
VARIABLE *addInt(MINIBASIC *,const char *id);
DIMVAR *adddimvar(MINIBASIC *,const char *id);

char *stringExpr(MINIBASIC *);
char *chrString(MINIBASIC *);
char *strString(MINIBASIC *);
char *leftString(MINIBASIC *);
char *rightString(MINIBASIC *);
char *midString(MINIBASIC *);
char *stringString(MINIBASIC *);
char *hexString(MINIBASIC *);
char *trimString(MINIBASIC *);
char *timeString(MINIBASIC *);
char *inkeyString(MINIBASIC *);
char *midiString(MINIBASIC *);
#ifdef USA_BREAKTHROUGH
char *menukeyString(MINIBASIC *);
#endif
char *errorString(MINIBASIC *);
char *verString(MINIBASIC *);
char *stringDimVar(MINIBASIC *);
char *stringVar(MINIBASIC *);
char *stringLiteral(MINIBASIC *);
char *dirString(MINIBASIC *);
char *curdirString(MINIBASIC *);
char *ipaddressString(MINIBASIC *);
char *accesspointsString(MINIBASIC *);

int integer(MINIBASIC *,NUM_TYPE x);

void match(MINIBASIC *,TOKEN_NUM tok);
void setError(MINIBASIC *,enum MINIBASIC_ERRORS errorcode);
LINE_NUMBER_TYPE getNextLine(char *str);
TOKEN_NUM getToken(char *str);
uint8_t tokenLen(MINIBASIC *,char *str, TOKEN_NUM token);

char isString(TOKEN_NUM token);
NUM_TYPE getValue(char *str, IDENT_LEN *len);
void getId(MINIBASIC *,char *str, char *out, IDENT_LEN *len);

static void mystrgrablit(char *dest, char *src);
static char *mystrend(char *str, char quote);
static int myStrCount(char *str, char ch);
char *strdup(const char *str);    // non c'� in libreria �$%&
static char *myStrConcat(const char *str, const char *cat);
double factorial(double x);

static char myitoabuf[9];
unsigned char lastExprType;
static char *skipSpaces(char *);
int8_t strnicmp(const char *, const char *, size_t);

const char MiniBasicCopyrightString[]= {MINIBASIC_COPYRIGHT_STRING};
static char *scriptAllocated=NULL;
char theScript[32767];

extern SIZE Screen;

int myTextOut(MINIBASIC *mInstance,const char *s);
int myCR(MINIBASIC *mInstance);


//====================================================== MAIN ===================================================================
int minibasic(MINIBASIC *hInstance,const char *scriptName) {
  BYTE ch;
  int i;
  char *cmdPointer,*parmsPointer;
  char commandLine[128]={0},lastCommandLine[128]={0};
  int commandLineCnt=0;
  HDC hDC;

    
/*	static const char rom greeting[] = 
		"Minibasic-PIC 0.1\n"
#if !defined(__18CXX)
		"R-Run\n"
		"L-List\n"
		#ifdef EDITOR
		"E-Edit\n"
		#endif
		"P-Program\n\n";
#else
		"\n";
#endif
		*/


//------------------------------------------------------------- Send CopyRight Message ----------------------------------------------------------
#ifdef USA_BREAKTHROUGH
  GetDC(hInstance->hWnd,&hDC);
	SetTextColor(&hDC,BRIGHTGREEN);
 	TextOut(&hDC,0,0,MiniBasicCopyrightString);  // c'� anche in WM_CREATE di l�, unire...
#else
	SetColors(BRIGHTGREEN,BLACK);
  Cls();
  hInstance->Cursor.x=0; hInstance->Cursor.y=0;
 	myTextOut(hInstance,MiniBasicCopyrightString/*greeting*/);  // 
  myCR(hInstance);
  sprintf(commandLine,"%u Bytes free.", ((unsigned int)&ch) - ((unsigned int)&_splim));
  myTextOut(hInstance,commandLine);
  *commandLine=0;
#endif
  myCR(hInstance);
  myTextOut(hInstance,"Ready.");
  myCR(hInstance); /*deve/devono dipendere da xsize.. */


//------------------------------------------------------------- Run Script -----------------------------------------------------------------------
  
  do {
    
    handle_events();
    hInstance->incomingChar[0]=keypress.key;
    hInstance->incomingChar[1]=keypress.modifier;
    KBClear();
    
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
    SYS_Tasks();
#ifdef USA_USB_HOST_MSD
    SYS_FS_Tasks();
#endif
#else
    APP_Tasks();
#endif

#ifdef USA_WIFI
  	m2m_wifi_handle_events(NULL);
#endif
#ifdef USA_ETHERNET
    StackTask();
    StackApplications();
#endif

    if(hInstance->incomingChar[0]) {

#if 0
 FINIRE! con modifier      if(hInstance->incomingChar=='.'/*\x7f'*/ && 
         ((keypress.modifier & 0xf) | (keypress.modifier>>4)) == 0b00000101) { // CTRL-ALT-CANC!
        App_Reset();
        // o uscire al S.O. qua? ma poi occhio rimbalzi
        }
#endif
 
     if((hInstance->incomingChar[0]>=' ' && hInstance->incomingChar[0]<=0x7e) ||
      hInstance->incomingChar[0]=='\r' || hInstance->incomingChar[0]=='\n' || hInstance->incomingChar[0]=='\x8') {


      ch=hInstance->incomingChar[0];
      hInstance->incomingChar[0]=0;

      if(commandLineCnt<sizeof(commandLine)) {
        commandLine[commandLineCnt++]=ch;
        commandLine[commandLineCnt]=0;
        hInstance->Cursor.x++;
        if(hInstance->Cursor.x >= ScreenText.cx) {
          myCR(hInstance);
          }
        
        if(hInstance->incomingChar[0]==0x9a && 
           ((hInstance->incomingChar[1] & 0xf) | (hInstance->incomingChar[1] >> 4)) == 0b00000101) { // CTRL-ALT-CANC! anche qua? s�
          App_Reset();
          }
        
        switch(ch) {
          default:
            if(isprint(ch))
              putchar(ch);
            break;
          case '\x8':
            // backspace
            commandLine[--commandLineCnt]=0;    // xch� cmq l'ho messo in commandline...
            hInstance->Cursor.x--;
            if(commandLineCnt>0) {
              commandLine[--commandLineCnt]=0;
              hInstance->Cursor.x--;
              putchar('\x8');
              }
//            SetXY(1,hInstance->Cursor.x*1 /*textsize*/ ,hInstance->Cursor.y*1 /*textsize*/ );
//            putchar(' ');   // o mandare 0x08 e far fare alla scheda video??
            break;
          case '\r':
            commandLine[commandLineCnt--]=0;            // pulisco cmq il successivo, in caso di prec. comando lungo..
            commandLine[commandLineCnt]=0;            // tolgo LF
            break;
          case '\n':
            commandLine[--commandLineCnt]=0;            // tolgo CR NO! compatibilit� con minibasic-script
            myCR(hInstance);
  
            cmdPointer=&commandLine[0];   // per warning...
//            myTextOut(hInstance,cmdPointer);

            hInstance->errorFlag=0;
            hInstance->nfors=hInstance->ngosubs=hInstance->ndos=hInstance->inBlock=0;
            
            strcpy(lastCommandLine,commandLine);

            if(!strnicmp(commandLine,"RUN",3)) {
              parmsPointer=skipSpaces(cmdPointer+3);
              if(*parmsPointer=='\"') {
                struct SUPERFILE f1;
                char buf[128],*p;
                // OVVIAMENTE andare anche su C: E: !
                
                strncpy(buf,parmsPointer+1,120);
                if(p=strchr(buf,'\"'))
                  *p=0;
                if(!strchr(buf,'.'))
                  strcat(buf,".BAS");

                f1.drive='A';
                p=theScript;
                if(subOpenfile(&f1,buf,'r')) { 
                  while(1) {
                    if(subReadfile(&f1,p,1) == 1) {  // o FSfgets??
                      if(*p != 13 && *p != 9)    // cmq tolgo CR e TAB
                        p++;
                      }
                    else
                      break;
                    }
                  *p=0;
                  subClosefile(&f1);
                  i=basic(hInstance,theScript,0);
  //                if(!i)
  //                  break;
                  goto ready2;
                  }
                else {
                  myTextOut(hInstance,"Program not found");
                  myCR(hInstance);
                  goto ready;
                  }
                }     // se nomefile..
              else {
                goto execline;
                }
              }
            else if(!strnicmp(commandLine,"QUIT",4)) {    // ev. returnCode/errorLevel?
              goto fine;
              break;
              }
            else {
          		if(*cmdPointer) {
execline:
                hInstance->string = cmdPointer;
                hInstance->token = getToken(hInstance->string);
                hInstance->errorFlag = 0;
                i = line(hInstance);
                if(hInstance->errorFlag) {
                  myTextOut(hInstance,error_msgs[hInstance->errorFlag]);
                  ErrorBeep(200);
                  hInstance->errorFlag=0;
                  myCR(hInstance);
                  }
ready2:
                myCR(hInstance);
ready:
                myTextOut(hInstance,"Ready.");
                }
              else {
//                putchar('\n'); 
                }
              }
            myCR(hInstance);
            
            commandLineCnt=0;
            memset(commandLine,0,sizeof(commandLine));;

            break;
          }

        }
      }     // char accepted
    else {
      switch(hInstance->incomingChar[0]) {
        case 0xa1: // F1
//          strcpy(commandLine,lastCommandLine);
//          commandLineCnt=strlen(commandLine);
//          myTextOut(hInstance,commandLine);
          break;
        case 0xa3: // F3
          strcpy(commandLine,lastCommandLine);
          commandLineCnt=strlen(commandLine);
          myTextOut(hInstance,commandLine);
          break;
        case 0x94: // up, 
          break;
        case 0x91: // right
          // gestire frecce qua?
          break;
        }
      }
      }
    
//    handleWinTimers();
//    manageWindows(i);    // fare ogni mS

    } while(1);


//------------------------------------------------------------- Finished running Basic Script ---------------------------------------------------
fine:
          
#ifdef USA_BREAKTHROUGH
 	do_print(&hDC,"\nPress a key to restart");
  //compila ma non esiste???!!! 2/1/22
#else
#endif
  
  if(scriptAllocated) {
    free((void *)scriptAllocated);
    scriptAllocated=NULL;
    }

#ifdef USA_BREAKTHROUGH
  ReleaseDC(hInstance->hWnd,&hDC);
#else
#endif

  
	return 0;
	}



//======================================================= Basic Interpriture Start ==============================================================
/*
  Interpret a BASIC script

  Params: script - the script to run
  Returns: 0 on success, 1 on error condition.
*/

int basic(MINIBASIC *mInstance,const char *script,BYTE where) {
  int16_t /*LINE_NUMBER_TYPE per marker fine*/ nextline;
  int answer = 0;

  mInstance->curline=0;

  mInstance->ColorPalette=textColors[0] /*BLACK*/;
  mInstance->Color=ColorRGB(mInstance->ColorPalette);
	mInstance->ColorPaletteBK=textColors[7] /*WHITE*/;
  mInstance->ColorBK=ColorRGB(mInstance->ColorPaletteBK);
//	setTextColorBG(textColors[mInstance->ColorPalette],textColors[mInstance->ColorPaletteBK]); 
  Cls();
	mInstance->Cursor.x=0;
  mInstance->Cursor.y=0;
 	
  if(where) {
    subLoad((char *)script,theScript);
    }
  else {
    strcpy(theScript,script);
    }

  if(setup(mInstance,(char *)theScript) == -1)				//Run setup Function to extract data from the Script
    return 1;										//Script error END
  
  
 	while(mInstance->curline != -1) {			//Loop through Script Running each Line

		mInstance->string = mInstance->lines[mInstance->curline].str;
		mInstance->token = getToken(mInstance->string);
		
		mInstance->errorFlag = 0;
		
    match(mInstance,VALUE);
		nextline = line(mInstance);
    
		if(mInstance->errorFlag)	{
			if(!mInstance->errorHandler.handler)
				reportError(mInstance,mInstance->lines[mInstance->curline].no);

//      printf("errorhandler: %u,%u\r\n",mInstance->errorFlag,mInstance->errorHandler.handler);
      
      if(mInstance->errorFlag == ERR_STOP)	{
        int i;

#if 0
        do {
          i=mInstance->incomingChar;
          Yield(mInstance->threadID);
          ClrWdt();
          }	while(i != 'C' && i != '\x1b');
#else
//          SYS_Tasks();
          goto handle_error2;
#endif

        if(i == '\x1b')	{     // usare CTRL-C ....
          goto handle_error2;
          }
        }
      else	{
//handle_error:
        if(mInstance->errorHandler.handler)	{
          nextline = mInstance->errorHandler.handler;
          mInstance->errorHandler.errorcode=mInstance->errorFlag;
          mInstance->errorHandler.errorline=mInstance->lines[mInstance->curline].no;
          }
        else	{
handle_error2:
          answer=1;
          break;
          }
        }
      }

		if(nextline == -1)			// p.es. comando END
	  	break;

		if(nextline == 0)	{				//Line increment from 0 to 1
    	mInstance->curline++;

 			if(mInstance->curline == mInstance->nlines)			//check if last line has been read
   			break;
   		}
		else {							//find next line
    	mInstance->curline = findLine(mInstance,nextline);
 			if(mInstance->curline == (int16_t)-1) {
        char buf[32];
        sprintf(buf,"line %d not found", nextline);		// QUESTO NON viene trappato.. non ha senso..!
		    myTextOut(mInstance,buf);
        myCR(mInstance);
				goto handle_error2;
  			}
   		}
		ClrWdt();
    
    Yield(mInstance->threadID);
    
    mLED_1 ^= 1;     //  

//    if(mInstance->incomingChar == '\x1b')
      if(mInstance->incomingChar[0] =='c' && mInstance->incomingChar[1] == 0b00000001)
#warning FINIRE modifier qua!
        break;
      setError(mInstance,ERR_STOP);
      

    handle_events();
    mInstance->incomingChar[0]=keypress.key; mInstance->incomingChar[1]=keypress.modifier;
    KBClear();

#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
    SYS_Tasks();
#ifdef USA_USB_HOST_MSD
    SYS_FS_Tasks();
#endif
#else
    APP_Tasks();
#endif

#ifdef USA_WIFI
  	m2m_wifi_handle_events(NULL);
#endif
#ifdef USA_ETHERNET
    StackTask();
    StackApplications();
#endif

  	} //While finish



  cleanup(mInstance,1);
  
  return answer;
	}

//===============================================================================================================================================================




/*
  Sets up all our globals, including the list of lines.
  Params: script - the script passed by the user
  Returns: 0 on success, -1 on failure
*/
int setup(MINIBASIC *mInstance,char *script) {
  int i;

  mInstance->nlines = myStrCount(script,'\n');						//Count the lines in the Basic Script by counting \n
  mInstance->lines = (LINE *)malloc(mInstance->nlines * sizeof(LINE));
  if(!mInstance->lines) {
    myTextOut(mInstance,"Out of memory");
    myCR(mInstance);
		return -1;
  	}
  for(i=0; i<mInstance->nlines; i++) {
		if(isdigit(*script)) {
      mInstance->lines[i].str = script;
	  	mInstance->lines[i].no = atoi(script);
			}
		else {
	  	i--;
	  	mInstance->nlines--;
			}
		script = (char *)strchr((char *)script,'\n');

		script++;
  	}
  if(!mInstance->nlines) {
    myTextOut(mInstance,"Can't read program");
    myCR(mInstance);
    free(mInstance->lines);
		return -1;
  	}

  for(i=1; i<mInstance->nlines; i++) {
		if(mInstance->lines[i].no <= mInstance->lines[i-1].no) {
      char buf[32];
      sprintf(buf,"program lines %d and %d not in order", 
	  		mInstance->lines[i-1].no, mInstance->lines[i].no);
      myTextOut(mInstance,buf);
      myCR(mInstance);
	  	free(mInstance->lines);
	  	return -1;
  		}
		}

  mInstance->nvariables = 0;
  mInstance->variables = NULL;

  mInstance->dimVariables = 0;
  mInstance->ndimVariables = 0;

  return 0;
	}


/*
  frees all the memory we have allocated
*/
void cleanup(MINIBASIC *mInstance,uint8_t alsoprogram) {
  int i;
  int ii;
  int size;

  for(i=0; i<mInstance->nvariables; i++) {
		if(mInstance->variables[i].type == STRID) {
			if(mInstance->variables[i].d.sval)
		  	free(mInstance->variables[i].d.sval);
			mInstance->variables[i].d.sval=0;
			}
		}
  if(mInstance->variables)
	 	free(mInstance->variables);
  mInstance->variables = NULL;
  mInstance->nvariables = 0;

  for(i=0; i<mInstance->ndimVariables; i++) {
    if(mInstance->dimVariables[i].type == STRID)	{
	  	if(mInstance->dimVariables[i].d.str) {
				size = 1;
        for(ii=0; ii<mInstance->dimVariables[i].ndims; ii++)
		  		size *= mInstance->dimVariables[i].dim[ii];
	    	for(ii=0; ii<size; ii++) {
		  		if(mInstance->dimVariables[i].d.str[ii])
		    		free(mInstance->dimVariables[i].d.str[ii]);
	    		mInstance->dimVariables[i].d.str[ii]=0;
					}
				free(mInstance->dimVariables[i].d.str);
				mInstance->dimVariables[i].d.str=0;
	  		}
			}
		else {
		  if(mInstance->dimVariables[i].d.dval)
				free(mInstance->dimVariables[i].d.dval);
		  mInstance->dimVariables[i].d.dval=0;
			}
  	}

  if(mInstance->dimVariables)
		free(mInstance->dimVariables);
  mInstance->dimVariables=0;
 
  mInstance->dimVariables = 0;
  mInstance->ndimVariables = 0;

	if(alsoprogram) {
	  if(mInstance->lines)
			free(mInstance->lines);
	  mInstance->lines = 0;
  	mInstance->nlines = 0;
		}

	mInstance->nfors=0;
	mInstance->ngosubs=0;
	mInstance->ndos=0;
	mInstance->inBlock=0;

	mInstance->errorHandler.handler=0;
	mInstance->errorHandler.errorline=0;
	mInstance->errorHandler.errorcode=0;
	mInstance->irqHandler.handler=0;
	mInstance->irqHandler.errorline=0;
	mInstance->irqHandler.errorcode=0;
	}


/*
  error report function.
  for reporting errors in the user's script.
  checks the global errorFlag.
  writes to fperr.
  Params: lineno - the line on which the error occurred
*/
void reportError(MINIBASIC *mInstance,LINE_NUMBER_TYPE lineno) {


  if(mInstance->errorFlag == ERR_CLEAR) {
	  basicAssert(0);
		}
	else if(mInstance->errorFlag >= ERR_SYNTAX && mInstance->errorFlag <= ERR_STOP) {
// tolto a-capo, specie su display piccoli...
    if(lineno != -1) {
      char buf[64];
      sprintf(buf,"%s at line %d",error_msgs[mInstance->errorFlag],lineno);
      myTextOut(mInstance,buf);
	    goto acapo;
      }
    else {
      myTextOut(mInstance,error_msgs[mInstance->errorFlag]);
	    goto acapo;
      }
		}
	else {
    if(lineno != -1) {
      char buf[32];
  	  sprintf(buf,"ERROR at line %d", lineno);
      myTextOut(mInstance,buf);
      }
    else
      myTextOut(mInstance,"ERROR");
acapo:
    myCR(mInstance);
    myCR(mInstance);
	  }
	}


/*
  binary search for a line
  Params: no - line number to find
  Returns: index of the line, or -1 on fail.
*/
int16_t /*LINE_NUMBER_TYPE*/ findLine(MINIBASIC *mInstance,LINE_NUMBER_TYPE no) {    // signed per ndicare fine...
  int high;
  int low;
  int mid;

  low = 0;
  high = mInstance->nlines-1;
  while(high > low + 1) {
    mid = (high + low)/2;
		if(mInstance->lines[mid].no == no)
		  return mid;
		if(mInstance->lines[mid].no > no)
		  high = mid;
		else
		  low = mid;
	  }

  if(mInstance->lines[low].no == no)
		mid = low;
  else if(mInstance->lines[high].no == no)
		mid = high;
  else
		mid = -1;

  return mid;
	}


/*
  Parse a line. High level parse function
*/
LINE_NUMBER_TYPE line(MINIBASIC *mInstance) {
  LINE_NUMBER_TYPE answer;
  char *str;

//  match(mInstance,VALUE);   // spostato fuori, x gestire command-line

rifo:
	answer = 0;
  switch(mInstance->token) {
	
    case PRINT:
    case PRINT2:
		  doPrint(mInstance);
		  break;
		case POKE:
			doPoke(mInstance);
			break;
		case EEPOKE:
			doEEPoke(mInstance);
			break;
		case SYS:
			doSys(mInstance);
			break;
		case SLEEP:
			doSleep(mInstance);
			break;
		case STOP:
			doStop(mInstance);
			break;
    case SETPIN:
		  doSetpin(mInstance);
			break;
		case OUTD:
			doOutd(mInstance);
			break;
		case OUTDAC:
//			dotwoset();
			doOutdac(mInstance);
			break;
		case SOUND:
			doSound(mInstance);
			break;
		case TONE:
//			dothreeset(); doTone()
			doTone(mInstance);    //MessageBeep ..
			break;
		case PLAY:
			doPlay(mInstance);
			break;
		case BEEP:
			doBeep(mInstance);
			break;
		case OPEN:
			doOpen(mInstance);
			break;
		case CLOSE:
			doClose(mInstance);
			break;
		case DIRTOK:     // 
			doDir(mInstance);
			break;
		case RENAME:     // 
			doRename(mInstance);
			break;
		case DELETE:     // 
			doDelete(mInstance);
			break;
		case CD:
			doCD(mInstance);
			break;
		case MD:
			doMD(mInstance);
			break;
		case RD:
			doRD(mInstance);
			break;
		case FORMAT:
			doFormat(mInstance);
			break;
		case CLS:
			doCls(mInstance);
			break;
		case LOCATE:
			doLocate(mInstance);
			break;
    case LET:
		  doLet(mInstance,1);
		  break;
		case DIM:
		  doDim(mInstance);
		  break;
		case IF:
		  answer = doIf(mInstance);
			if(answer<0)			// OCCHIO! unsigned 
				goto rifo;
		  break;
		case END:
      match(mInstance,END);
		  answer = -1;
		  break;
		case GOTO:
		  answer = doGoto(mInstance);
		  break;
		case GOSUB:
			answer = doGosub(mInstance);
			break;
		case ERRORTOK:
			doError(mInstance);
			break;
		case RETURN:
			answer = doReturn(mInstance);
			break;
		case ON:
		  answer = doOn(mInstance);
		  break;
		case RUN:
			answer = doRun(mInstance);
			break;
		case SHELL:
			/*answer = */doShell(mInstance);
			break;
		case CONTINUE:
			doContinue(mInstance);
			break;
		case LIST:
      doList(mInstance);
		  break;
		case NEW:
      doNew(mInstance);
		  answer = -1;    // per interrompere esecuzione :)
		  break;
		case LOAD:
      doLoad(mInstance);
		  answer = -1;    // per interrompere esecuzione :)
		  break;
		case SAVE:
      doSave(mInstance);
		  answer = -1;    // e boh..
		  break;
		case QUIT:
		  answer = -1;    // per interrompere esecuzione :)
		  break;

		case INPUTTOK:
		  doInput(mInstance);
		  break;
		case REM:
		case REM2:
		case ELSE:			// defaults to here, i.e. when a IF statement is TRUE
do_rem:
		  doRem(mInstance);
		  return 0;
		  break;
		case FOR:
		  answer = doFor(mInstance);
		  break;
		case NEXT:
		  answer = doNext(mInstance);
		  break;
		case DO:
		  answer = doDo(mInstance);
		  break;
		case LOOP:
		  answer = doLoop(mInstance);
		  break;
		case BEGIN:
		  mInstance->inBlock++;
		  break;
		case BEND:
			if(mInstance->inBlock>0)
				mInstance->inBlock--;
			else
		    setError(mInstance,ERR_NOFOR);
		  break;
		case COLON:
			goto rifo;
			break;

		case LINETOK:
		  doLine(mInstance);
		  break;
		case RECTANGLE:
		  doRectangle(mInstance);
		  break;
		case TRIANGLE:
		  doTriangle(mInstance);
		  break;
		case ELLIPSE:
		  doEllipse(mInstance);
		  break;
		case ARC:
		  doArc(mInstance);
		  break;
		case POINTTOK:
		  doPoint(mInstance);
		  break;
		case SETCOLOR:
		  doSetcolor(mInstance);
		  break;
		case SETBKCOLOR:
		  doSetBkcolor(mInstance);
		  break;
		case BITBLT:
		  doBitblt(mInstance);
		  break;

		default:
//		  setError(mInstance,ERR_SYNTAX);
      
      // if isdigit o mInstance->token==VALUE  per inserire righe...
      
			doLet(mInstance,0);
		  break;
	  }

	if(!answer) {
	  if(mInstance->token == ELSE || mInstance->token==REM || mInstance->token==REM2) {
			goto do_rem;
			}

	  if(mInstance->token != EOS) {

			/*match(mInstance,VALUE);*/
			/* check for a newline */
			str = mInstance->string;
			while(isspace(*str)) {
			  if(*str == '\n' || *str == ':')
			    break;
			  str++;
				}
	
			if(*str == ':') {
				match(mInstance,COLON);
				if(!mInstance->errorFlag)			// specie per STOP
			  	goto rifo;
				else
					goto fine;
				}
			if(*str != '\n')
			  setError(mInstance,ERR_SYNTAX);
	  	}
		}

fine:
  return answer;
	}



/*
  the PRINT statement
*/
void doPrint(MINIBASIC *mInstance) {
  static char *str;
  static NUM_TYPE x;
	void *ftemp=NULL;
  enum _FILE_TYPES filetype=-1;
	uint8_t pendingCR=0;                 // per semicolon a fine riga

  match(mInstance,mInstance->token);		// e PRINT2 
/*	if(errorFlag) {
		errorFlag=0;			// PATCHina...
	  match(mInstance,PRINT2);
		}*/

  mInstance->string=skipSpaces(mInstance->string);
//	t=getToken(string); USARE?
  if(*mInstance->string == '#')	{	// per print to file
		unsigned int f,i;
    
//  printf("#%u\r\n",mInstance->token);
		match(mInstance,DIESIS);
    
		f=integer(mInstance,expr(mInstance));
		match(mInstance,COMMA);
//  printf(",%u %u\r\n",f,mInstance->token);


		for(i=0; i<mInstance->nfiles; i++) {
			if(mInstance->openFiles[i].number==f) {
        filetype=mInstance->openFiles[i].type;
				switch(filetype) {
					case FILE_COM:
//            ftemp=mInstance->openFiles[i].handle;
						break;
#ifdef USA_USB_SLAVE_CDC
					case FILE_CDC:
						break;
#endif
#if defined(USA_USB_HOST_MSD)
					case FILE_USB:
            ftemp=mInstance->openFiles[i].handle;
						break;
#endif
#ifdef USA_WIFI
					case FILE_TCP:
            ftemp=mInstance->openFiles[i].handle;
            *rxBuffer=0;
						break;
					case FILE_UDP:
            ftemp=mInstance->openFiles[i].handle;
            *rxBuffer=0;
						break;
#endif
					case FILE_DISK:
//						FSfwrite("aaa",3,1,mInstance->openFiles[i].handle);		// gestire...
            ftemp=mInstance->openFiles[i].handle;
						break;
					}
				}
			}
		}

  while(1) {
    if(isString(mInstance->token)) {
      str = stringExpr(mInstance);
// if errorFlag NON dovrebbe stampare...
	  	if(str) {
				switch(filetype) {
					case FILE_COM:
          {
            char *p=str;
            while(*p)
              WriteSerial(*p++);
          }
						break;
#ifdef USA_USB_SLAVE_CDC
					case FILE_CDC:
            printf("%s",str);
						break;
#endif
#if defined(USA_USB_HOST_MSD)
					case FILE_USB:
            SYS_FS_FileWrite((SYS_FS_HANDLE)ftemp,str,strlen(str));
//            USBFSfwrite(str,strlen(str),1,ftemp);
						break;
#endif
#ifdef USA_WIFI
					case FILE_TCP:
            strcat(rxBuffer,str);
						break;
					case FILE_UDP:
            strcat(rxBuffer,str);
						break;
#endif
					case FILE_DISK:
            if(FSfwrite(str,strlen(str),1,ftemp) != strlen(str)) {
              setError(mInstance,ERR_FILE);
              }
						break;
          default:
            myTextOut(mInstance,str);
						break;
					}

				pendingCR=1;
        free(str);
	  		}
			}
		else if(mInstance->token == INTID) {
			int i;

			i=integer(mInstance,expr(mInstance));
      {
      char buf[16];
			if(i>=0)
    	  sprintf(buf," %d",i);	// metto lo spazio prima dei numeri... se non negativi...
      else
        sprintf(buf,"%d",i);
      switch(filetype) {
        case FILE_COM:
          {
            char *p=buf;
            while(*p)
              WriteSerial(*p++);
          }
          break;
#ifdef USA_USB_SLAVE_CDC
        case FILE_CDC:
          printf("%s",buf);
          break;
#endif
#if defined(USA_USB_HOST_MSD)
        case FILE_USB:
//          USBFSfwrite(buf,strlen(buf),1,ftemp);
          SYS_FS_FileWrite((SYS_FS_HANDLE)ftemp,buf,strlen(buf));
          break;
#endif
#ifdef USA_WIFI
        case FILE_TCP:
          strcat(rxBuffer,buf);
          break;
        case FILE_UDP:
          strcat(rxBuffer,buf);
          break;
#endif
        case FILE_DISK:
          if(FSfwrite(buf,strlen(buf),1,ftemp) != strlen(buf)) {
            setError(mInstance,ERR_FILE);
            }
          break;
        default:
          myTextOut(mInstance,buf);
          break;
        }
      }
			pendingCR=1;
			}
		else if(mInstance->token != EOS && mInstance->token != EOL && mInstance->token != COLON) /*if(mInstance->token == VALUE || mInstance->token == FLTID) */{
			static long n;
			static char buf[20];

	  	x = expr(mInstance);
// if errorFlag NON dovrebbe stampare...

//			x -= (double)(long)x;
//			n=x*1000000.0;
			n=(long) (fabs(x - (double)(long)x ) * 1000000.0);
//	  	fprintf(fpout, (STRINGFARPTR)"%g", x);
			if(n)	{	// un trucchetto per stampare interi o float
				unsigned char i;
        
        // metto lo spazio prima dei numeri... se non negativi...
  			if(x>=0)
    			sprintf(buf,(STRINGFARPTR)" %ld.%06lu", (long) x, (long) n); 
        else
    			sprintf(buf,(STRINGFARPTR)"%ld.%06lu", (long) x, (long) n); 
				for(i=strlen(buf)-1; i; i--) {
					if(buf[i] == '0')
						buf[i]=0;
					else
						break;
					}
				}
			else {
  			if(x>=0)
  				sprintf(buf," %ld", (long)x); 	// metto lo spazio prima dei numeri... se non negativi...
        else
          sprintf(buf,"%ld", (long)x); 
        }
      switch(filetype) {
        case FILE_COM:
          {
            char *p=buf;
            while(*p)
              WriteSerial(*p++);
          }
          break;
#ifdef USA_USB_SLAVE_CDC
        case FILE_CDC:
          printf("%s",buf);
          break;
#endif
#if defined(USA_USB_HOST_MSD)
        case FILE_USB:
          SYS_FS_FileWrite((SYS_FS_HANDLE)ftemp,buf,strlen(buf));
//          USBFSfwrite(buf,strlen(buf),1,ftemp);
          break;
#endif
#ifdef USA_WIFI
        case FILE_TCP:
          strcat(rxBuffer,buf);
          break;
        case FILE_UDP:
          strcat(rxBuffer,buf);
          break;
#endif
        case FILE_DISK:
          if(FSfwrite(buf,strlen(buf),1,ftemp) != strlen(buf)) {
            setError(mInstance,ERR_FILE);
            }
          break;
        default:
          myTextOut(mInstance,buf);
          break;
        }

			pendingCR=1;
			}
		else
			pendingCR=1;


		if(mInstance->token == COMMA) {
//	    putc('\t', fpout);			// should print 8 chars or up to next tab...
      switch(filetype) {
        case FILE_COM:
          WriteSerial(' ');
          break;
#ifdef USA_USB_SLAVE_CDC
        case FILE_CDC:
          putchar(' ');
          break;
#endif
#if defined(USA_USB_HOST_MSD)
        case FILE_USB:
          SYS_FS_FileWrite((SYS_FS_HANDLE)ftemp," ",1);
//          USBFSfwrite(" ",1,1,ftemp);
          break;
#endif
#ifdef USA_WIFI
        case FILE_TCP:
          strcat(rxBuffer," ");
          break;
        case FILE_UDP:
          strcat(rxBuffer," ");
          break;
#endif
        case FILE_DISK:
          if(FSfwrite(" ",1,1,ftemp) != 1) {
            setError(mInstance,ERR_FILE);
            }
          break;
        default:
					do {
						/*mInstance->Cursor.x += */ myTextOut(mInstance," ");
						} while(mInstance->Cursor.x % (ScreenText.cx>25 ? 8 : 4));   // bah, s�
          break;
        }

	  	match(mInstance,COMMA);
			pendingCR=0;
			}
		else if(mInstance->token == SEMICOLON) {
	  	match(mInstance,SEMICOLON);
			pendingCR=0;
			}
		else
	  	break;
  	}

// naturalmente, se rxBuffer sfora, errore?!  diverso tra tcp e udp..
  
  if(!pendingCR /*token == SEMICOLON*/) {
//		match(mInstance,SEMICOLON);
//    fflush(fpout);
    switch(filetype) {
#ifdef USA_WIFI
      case FILE_TCP:
        send((SOCKET)(int)ftemp, rxBuffer, strlen(rxBuffer), 0);
        break;
      case FILE_UDP:
        send((SOCKET)(int)ftemp, rxBuffer, strlen(rxBuffer), 0);
        break;
#endif
      default:
        break;
      }
  	}
  else {
    switch(filetype) {
      case FILE_COM:
        WriteSerial('\r'); WriteSerial('\n');
        break;
#ifdef USA_USB_SLAVE_CDC
      case FILE_CDC:
        putchar('\r'); putchar('\n');
        break;
#endif
#if defined(USA_USB_HOST_MSD)
      case FILE_USB:
        SYS_FS_FileWrite((SYS_FS_HANDLE)ftemp,"\r\n",2);
//        USBFSfwrite("\r\n",2,1,ftemp);
        break;
#endif
#ifdef USA_WIFI
      case FILE_TCP:
        strcat(rxBuffer,"\r\n");
        send((SOCKET)(int)ftemp, rxBuffer, strlen(rxBuffer), 0);
        break;
      case FILE_UDP:
        strcat(rxBuffer,"\r\n");
        send((SOCKET)(int)ftemp, rxBuffer, strlen(rxBuffer), 0);
        break;
#endif
      case FILE_DISK:
        if(FSfwrite("\r\n",2,1,ftemp) != 2) {
          setError(mInstance,ERR_FILE);
          }
        break;
      default:
        putchar('\n');
        mInstance->Cursor.y++; mInstance->Cursor.x=0;
        if(mInstance->Cursor.y >= ScreenText.cy) {
          mInstance->Cursor.y--;
          }
        SetXYText(mInstance->Cursor.x,mInstance->Cursor.y);
        break;
      }

    //ScrollWindow()
		}

	}


/*
  --------------------
*/
void doCls(MINIBASIC *mInstance) {
  RECT rc;
  HDC myDC,*hDC;
  BRUSH b;

  match(mInstance,CLS);
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  mInstance->Cursor.x=0;
  mInstance->Cursor.y=0;
  
//  HDC *myDC=BeginPaint(mInstance->hWnd,NULL,TRUE);
  GetClientRect(mInstance->hWnd,&rc);
  b=CreateSolidBrush(WHITE);
  FillRect(hDC,&rc,b);
//  EndPaint(mInstance->hWnd,NULL,FALSE);   // FALSE per consentire altre operazioni hDC :) (v.)
  // ovvero lo levo del tutto!

  ReleaseDC(mInstance->hWnd,hDC);
  
#else
  mInstance->Cursor.x=0;
  mInstance->Cursor.y=0;
  Cls();    // usa il colore nero e non il bkcolor...
#endif
  
	}



/*
  ------------------
*/
void doLocate(MINIBASIC *mInstance) {
  unsigned char x,y;

	match(mInstance,LOCATE);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  y = integer(mInstance,expr(mInstance));

  mInstance->Cursor.x=x;
  mInstance->Cursor.y=y;
	}


/*
  ------------------
*/
LINE_NUMBER_TYPE doOn(MINIBASIC *mInstance) {
  unsigned char n;
	TOKEN_NUM t;
	LINE_NUMBER_TYPE x;

	match(mInstance,ON);
	t=getToken(mInstance->string);

	if(t==ERRORTOK) {
		match(mInstance,ERRORTOK);
		getToken(mInstance->string);
		match(mInstance,GOTO);
		mInstance->errorHandler.handler = integer(mInstance,expr(mInstance));
		return 0;
		}
	else if(t==IRQ) {
		match(mInstance,IRQ);
		getToken(mInstance->string);
		match(mInstance,GOTO);
		mInstance->irqHandler.handler = integer(mInstance,expr(mInstance));
		return 0;
		}
	else {
		n = integer(mInstance,expr(mInstance));
		t=getToken(mInstance->string);
		if(t==GOSUB) {
			match(mInstance,GOSUB);
			if(mInstance->ngosubs >= MAXGOSUB) {
				setError(mInstance,ERR_TOOMANYGOSUB);
				return -1;
				}
			}
		else
			match(mInstance,GOTO);

	//FINIRE!
		while(n--) {
			x = integer(mInstance,expr(mInstance));
			mInstance->string=skipSpaces(mInstance->string);
			if(*mInstance->string != ',' /*COMMA*/)
				break;
			if(mInstance->errorFlag)
				break;
			}

		if(t==GOSUB) {
		  mInstance->gosubStack[mInstance->ngosubs++] = getNextLine(mInstance->string);
			}

		return x;
		}

	}


/*
  the OPEN and CLOSE statement
*/
void doOpen(MINIBASIC *mInstance) {		// OPEN filename [FOR mode][ACCESS access][lock] AS [#]file number [LEN=reclen] (stile GWBASIC)
	uint8_t fileno;
	uint8_t mode;
	char *str;

	match(mInstance,OPEN);
  str = stringExpr(mInstance);
//  if(mInstance->token == FOR) { boh a me pare NECESSARIO
		match(mInstance,FOR);

    if(mInstance->token == APPEND)
      mode=2;
    else if(mInstance->token == OUTPUTTOK)
      mode=1;
    else if(mInstance->token == INPUTTOK)
      mode=0;
//    else if(mInstance->token == SERVER)   // per udp e tcp..
//      mode=0;
//    else if(mInstance->token == CLIENT)
//      mode=0;
    else {
      // ev. APPEND ecc
  		setError(mInstance,ERR_SYNTAX);
      goto open_error;
    }
    
    match(mInstance,mInstance->token);

//		}
  match(mInstance,AS);
	fileno = integer(mInstance,expr(mInstance));
  
  if(fileno<1) {
 		setError(mInstance,ERR_BADVALUE);
    goto open_error;
    }

//  printf("%s %u %u\r\n",str,mode, fileno);
  
	if(mInstance->nfiles < (MAXFILES-1)) {
		mInstance->openFiles[mInstance->nfiles].number=fileno;
/*A device may be one of the following:
A:, B:, C:... 	Disk Drive
KYBD: 	Keyboard (input only)
SCRN: 	Screen (output only)
LPT1: 	Line Printer 1
LPT2: 	Line Printer 2
LPT3: 	Line Printer 3
COM1: 	RS-232 Communications 1
COMn: 	RS-232 Communications n
USB:    a file on USB Pendrive
CDC:    serial port over USB (slave)
TCP:    
UDP:      */
		if(!strnicmp(str,"COM:",4)) {
			mInstance->openFiles[mInstance->nfiles].type=FILE_COM;
			mInstance->openFiles[mInstance->nfiles].handle=(void *)(int)str[4];
      SetSerialPort(9600,8,0,1);
//    	InitUART((BYTE)(DWORD)mInstance->openFiles[mInstance->nfiles].handle,9600); 
      mInstance->nfiles++;
			}
#ifdef USA_USB_SLAVE_CDC
		else if(!strnicmp(str,"CDC:",4)) {
			mInstance->openFiles[mInstance->nfiles].type=FILE_CDC;
			mInstance->openFiles[mInstance->nfiles].handle=0;		// 
      mInstance->nfiles++;
			}
#endif
#ifdef USA_WIFI
		else if(!strnicmp(str,"TCP:",4)) {
      struct sockaddr_in strAddr;
      uint16_t u16ServerPort,tOut;
      char *p;
      if(p=strchr(str+4,':')) {
        u16ServerPort=atoi(p+1);
        *p=0;
        }
      else
        u16ServerPort=80;    //
			mInstance->openFiles[mInstance->nfiles].type=FILE_TCP;
			mInstance->openFiles[mInstance->nfiles].handle=(void*)(int)socket(AF_INET,SOCK_STREAM,0);		// handle tcp
      if(mInstance->openFiles[mInstance->nfiles].handle >= 0) {
        strAddr.sin_family = AF_INET;
        strAddr.sin_port = _htons(u16ServerPort);
        strAddr.sin_addr.s_addr = 0; //INADDR_ANY
        if(0) { // se ACCEPT - FARE!
          bind((SOCKET)(int)(mInstance->openFiles[mInstance->nfiles].handle), (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
          }
        else {
          strAddr.sin_addr.s_addr = nmi_inet_addr(str+4);
          if(!strAddr.sin_addr.s_addr) {
            *(unsigned long*)internetBuffer=0;
            tOut=0;
            gethostbyname((uint8_t*)str+4);
            while(!*(unsigned long*)internetBuffer && tOut<DNS_TIMEOUT) {
              m2m_wifi_handle_events(NULL);
              tOut++;
              __delay_ms(1);
              }
            strAddr.sin_addr.s_addr=*(unsigned long*)internetBuffer;
            }
          connect((SOCKET)(int)mInstance->openFiles[mInstance->nfiles].handle, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
          //aspettare msg di CONNECT ed ev. dare errore...
//  setError(mInstance,ERR_NETWORK);
          }
        }
      mInstance->nfiles++;
			}
		else if(!strnicmp(str,"UDP:",4)) {
      struct sockaddr_in strAddr;
      uint16_t u16ServerPort,tOut;
      uint32_t u32EnableCallbacks=1;
      char *p;
      if(p=strchr(str+4,':')) {
        u16ServerPort=atoi(p+1);
        *p=0;
        }
      else
        u16ServerPort=12345;    // :)
			mInstance->openFiles[mInstance->nfiles].type=FILE_UDP;
			mInstance->openFiles[mInstance->nfiles].handle=(void*)(int)socket(AF_INET,SOCK_DGRAM,0);		// handle udp
      if(mInstance->openFiles[mInstance->nfiles].handle >= 0) {
        strAddr.sin_family = AF_INET;
        strAddr.sin_port = _htons(u16ServerPort);
        strAddr.sin_addr.s_addr = 0; //INADDR_ANY
        if(0) { // se ACCEPT/SERVER - FARE!
          bind((SOCKET)(int)mInstance->openFiles[mInstance->nfiles].handle, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
          }
        else {
          strAddr.sin_addr.s_addr = nmi_inet_addr(str+4);
          if(!strAddr.sin_addr.s_addr) {
            *(unsigned long*)internetBuffer=0;
            tOut=0;
            gethostbyname((uint8_t*)str+4);
            while(!*(unsigned long*)internetBuffer && tOut<DNS_TIMEOUT) {
              m2m_wifi_handle_events(NULL);
              tOut++;
              __delay_ms(1);
              }
            strAddr.sin_addr.s_addr=*(unsigned long*)internetBuffer;
            }
          sendto((SOCKET)(int)mInstance->openFiles[mInstance->nfiles].handle, rxBuffer, 1, 0, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
          // serve la sendto per impostare indirizzo... mando un primo byte tanto per...
        	setsockopt((SOCKET)(int)mInstance->openFiles[mInstance->nfiles].handle, SOL_SOCKET, SO_SET_UDP_SEND_CALLBACK, &u32EnableCallbacks, 4);
//  setError(mInstance,ERR_NETWORK);
          }
        }
      mInstance->nfiles++;
			}
#endif
#if defined(USA_USB_HOST_MSD)
		else if(!strnicmp(str,"USB:",4) || !strnicmp(str,"E:",2)) {
#warning USARE SUPERFILE!
			FSFILE *f;
			mInstance->openFiles[mInstance->nfiles].type=FILE_USB;
//			f=USBFSfopen(str,mode==2 ? FS_APPEND : (mode==1 ? FS_WRITEPLUS : FS_READ));			// finire!
      f=(void *)SYS_FS_FileOpen(str, mode==2 ? SYS_FS_FILE_OPEN_APPEND : (mode==1 ? SYS_FS_FILE_OPEN_WRITE : SYS_FS_FILE_OPEN_READ));
      if(f) {
    		mInstance->openFiles[mInstance->nfiles].number=fileno;
        mInstance->openFiles[mInstance->nfiles].handle=f;
        mInstance->nfiles++;
        }
      else {
    		mInstance->openFiles[mInstance->nfiles--].number=0;
    		setError(mInstance,ERR_FILE);
        }
			}
#endif
		else if(!strnicmp(str,"A:",2) || !strnicmp(str,"C:",2)) {
      goto is_disk;   // bah s� :)
			}
		else {
			FSFILE *f;
is_disk:
			mInstance->openFiles[mInstance->nfiles].type=FILE_DISK;
			f=FSfopen(str,mode==2 ? FS_APPEND : (mode==1 ? FS_WRITEPLUS : FS_READ));
//  printf(" %s %u %u\r\n",str,mode, f);
      
      if(f) {
    		mInstance->openFiles[mInstance->nfiles].number=fileno;
        mInstance->openFiles[mInstance->nfiles].handle=f;
        mInstance->nfiles++;
        }
      else {
    		mInstance->openFiles[mInstance->nfiles--].number=0;
    		setError(mInstance,ERR_FILE);
        }
			}
open_error:
		free(str);
		}
	else {
      
		setError(mInstance,ERR_FILE);
		}
	}


void doClose(MINIBASIC *mInstance) {
	int i;
	unsigned int n;

	match(mInstance,CLOSE);
 	n = integer(mInstance,expr(mInstance));		// 

	for(i=0; i<mInstance->nfiles; i++) {
		if(mInstance->openFiles[i].number==n) {
			switch(mInstance->openFiles[i].type) {
				case FILE_COM:
//          CloseUART((BYTE)(DWORD)mInstance->openFiles[i].handle);
					break;
#ifdef USA_USB_SLAVE_CDC
				case FILE_CDC:
					break;
#endif
#if defined(USA_USB_HOST_MSD)
				case FILE_USB:
//					USBFSfclose(mInstance->openFiles[i].handle);
          SYS_FS_FileClose((SYS_FS_HANDLE)mInstance->openFiles[i].handle);
					break;
#endif
#ifdef USA_WIFI
				case FILE_TCP:
          close((SOCKET)(int)mInstance->openFiles[i].handle);
          // se ACCEPTED, gestire...
					break;
				case FILE_UDP:
          close((SOCKET)(int)mInstance->openFiles[i].handle);
					break;
#endif
				case FILE_DISK:
					FSfclose(mInstance->openFiles[i].handle);
					break;
				}

			int j;
			for(j=i+1; j<mInstance->nfiles; j++) {
				mInstance->openFiles[j-1].number=mInstance->openFiles[j].number;
				mInstance->openFiles[j-1].handle=mInstance->openFiles[j].handle;
				mInstance->openFiles[j-1].type=mInstance->openFiles[j].type;
				}
			mInstance->nfiles--;
			goto fine;
			}
		}

	setError(mInstance,ERR_FILE);

fine: ;
	}

void doDir(MINIBASIC *mInstance) {
  SearchRec rec;
  FS_DISK_PROPERTIES disk_properties;
  int i;
  WORD totfiles,totdirs,totsize;
  char *str,*filter;
  char buf[32];
  
	match(mInstance,DIRTOK);
  str = stringExpr(mInstance);
  if(str && *str) {
    filter=str;
    }
  else
    filter="*.*";
      
//      if(!SDcardOK) {
#if defined(USA_USB_HOST_MSD)
      if(filter[1] == ':' && filter[0] == 'E') {
        i=USBFindFirst( filter, ATTR_MASK ^ ATTR_VOLUME, &rec);
//        printf("Directory of %s","E:\\");    // finire :)
        }
/*  SYS_FS_FSTAT stat; 
  SYS_FS_HANDLE handle;
  
  if((handle=SYS_FS_DirOpen("/")) != SYS_FS_HANDLE_INVALID) {
    while(SYS_FS_DirSearch(handle,"*.*",SYS_FS_ATTR_MASK,&stat) == SYS_FS_RES_SUCCESS) {
      ClrWdt();
      puts(stat.fname);
      }
    SYS_FS_DirClose(handle);
    }
  */
#endif
  i=FindFirst(filter, ATTR_VOLUME, &rec);
  if(!i) {
    sprintf(buf,"Volume in drive %s is %s","C:\\",rec.filename);    // finire :)
    myTextOut(mInstance,buf);
    myCR(mInstance);
    }
  
  i=FindFirst(filter, ATTR_MASK ^ ATTR_VOLUME, &rec);
  sprintf(buf,"Directory of %s","C:\\");    // finire :)
  myTextOut(mInstance,buf);
  myCR(mInstance);

  if(!i) {

    totfiles=0; totdirs=0; totsize=0;
    do {
      myTextOut(mInstance,rec.filename);
      mInstance->Cursor.x = 13;
      if(rec.attributes & ATTR_DIRECTORY) {
        myTextOut(mInstance,"DIR");
        totdirs++;
        }
      else {
        sprintf(buf,"%-9u",rec.filesize);
        totsize+=rec.filesize;
        myTextOut(mInstance,buf);
        mInstance->Cursor.x = 23;
        sprintf(buf,"%02u/%02u/%04u %02u:%02u:%02u",
          (rec.timestamp >> 16) & 31,
          (rec.timestamp >> (5+16)) & 15,
          (rec.timestamp >> (9+16)) + 1980,
          (rec.timestamp >> 11) & 31,
          (rec.timestamp >> 5) & 63,
          rec.timestamp & 63);
        myTextOut(mInstance,buf);
        }

      mInstance->Cursor.y++; mInstance->Cursor.x=0;
      totfiles++;
      } while(!FindNext(&rec));
  	}
  else {
    setError(mInstance,ERR_FILE);
    goto fine;
    }

  // stampare...totdirs e totsize
  disk_properties.new_request=1;
  do {
    FSGetDiskProperties(&disk_properties);
    ClrWdt();
    } while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
  if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS) {
    sprintf(buf,"%u file%c %lu KBytes free",totfiles,totfiles==1 ? ' ' : 's',
            disk_properties.results.free_clusters*disk_properties.results.sectors_per_cluster*disk_properties.results.sector_size/1024); 
    myTextOut(mInstance,buf);
    myCR(mInstance);
    }

fine:
  if(str)
    free(str);
	}

void doFormat(MINIBASIC *mInstance) {
  int i; 
  char *str;
  
	match(mInstance,FORMAT);
  str = stringExpr(mInstance);
  
  if(str) {
#if defined(USA_USB_HOST_MSD)
    if(str[1] == ':' && str[0] == 'E') {
      i=USBFSformat(1,rand(),str);
//        printf("Directory of %s","E:\\");    // finire :)
      }
#endif
    i=FSformat(1,rand(),str);
    if(i)
      setError(mInstance,ERR_FILE);
    free(str);
    }
  }
  
void doRename(MINIBASIC *mInstance) {
  int i; 
  FSFILE *f;
  char *str1,*str2;
  
	match(mInstance,RENAME);
  str1 = stringExpr(mInstance);
	match(mInstance,COMMA);
  str2 = stringExpr(mInstance);
  
  if(str1 && str2) {
    if((f=FSfopen(str1,FS_READ))) {
      i=FSrename(str2,f);
      if(i)
        setError(mInstance,ERR_FILE);
      }
    else
      setError(mInstance,ERR_FILE);
    }
  free(str1);
  free(str2);
  }
  
void doDelete(MINIBASIC *mInstance) {
  int i; 
  char *str;
  
	match(mInstance,DELETE);
  str = stringExpr(mInstance);
  
  if(str) {
    i=FSremove(str);
    if(i)
      setError(mInstance,ERR_FILE);
    free(str);
    }
  }
  
void doCD(MINIBASIC *mInstance) {
  int i; 
  char *str;
  
	match(mInstance,CD);
  str = stringExpr(mInstance);
  
  if(str) {
    i=FSchdir(str);
    if(i)
      setError(mInstance,ERR_FILE);
    free(str);
    }
  }
  
void doMD(MINIBASIC *mInstance) {
  int i; 
  char *str;
  
	match(mInstance,MD);
  str = stringExpr(mInstance);
  
  if(str) {
    i=FSmkdir(str);
    if(i)
      setError(mInstance,ERR_FILE);
    free(str);
    }
  }
  
void doRD(MINIBASIC *mInstance) {
  int i; 
  char *str;
  
	match(mInstance,RD);
  str = stringExpr(mInstance);
  
  if(str) {
    i=FSrmdir(str,TRUE);
    if(i)
      setError(mInstance,ERR_FILE);
    free(str);
    }
  }
  

/*
  the POKE statement
*/
void doPoke(MINIBASIC *mInstance) {
  unsigned int adr;
  unsigned int dat;
  
  match(mInstance,POKE);
  adr = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  dat = integer(mInstance,expr(mInstance));
  *((unsigned char *)adr) = dat;
	}

void doEEPoke(MINIBASIC *mInstance) {
  unsigned int adr;
  unsigned int dat;
  
  match(mInstance,EEPOKE);
  adr = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  dat = integer(mInstance,expr(mInstance));
  EEwrite(adr,dat);
	}



/*
  the SLEEP statement
*/
void doSleep(MINIBASIC *mInstance) {
  int t;

  match(mInstance,SLEEP);
  t = integer(mInstance,expr(mInstance));
  if(t<0) {
		Sleep();
		}
	else {
    DWORD t2=timeGetTime()+t;
#ifdef USA_BREAKTHROUGH
		while(timeGetTime() < t2) {
//			__delay_ms(1);
			Yield(mInstance->threadID);
      ClrWdt();
      }
/*		while(t--) {
			__delay_ms(1);
			Yield(mInstance->threadID); // ovviamente dopo di questa il tempo sar� sbagliato, va usato un tipo timeGetTime :)
      timeGetTime();
      ClrWdt();
			}*/
#else
		while(t--) {
			__delay_ms(1);
      ClrWdt();
      }
#endif
		}
	}



/*
  the RUN statement
*/
LINE_NUMBER_TYPE doRun(MINIBASIC *mInstance) {
  int t=0;

  match(mInstance,RUN);
	if(mInstance->token==VALUE)
	  t = integer(mInstance,expr(mInstance));			// 
	cleanup(mInstance,0);

	if(t)
		mInstance->curline=findLine(mInstance,t);
	else
		mInstance->curline=0;
  
  mInstance->string = mInstance->lines[mInstance->curline].str;
  mInstance->token = getToken(mInstance->string);
  mInstance->errorFlag = 0;

#warning RUN non va... bisogna passare da commandline a basic() ...
	return mInstance->curline;
	}

void doShell(MINIBASIC *mInstance) {
  char *str;
  
  match(mInstance,SHELL);
  str=stringExpr(mInstance);
  if(str) {
    execCmd(str,NULL);
    free(str);
    }
	}

/*
  the CONTINUE statement
*/
void doContinue(MINIBASIC *mInstance) {

  match(mInstance,CONTINUE);
	mInstance->errorFlag=0;
	}

void doList(MINIBASIC *mInstance) {
  int i;
  char buf[256],j;
  
  match(mInstance,LIST);
  i=0;
 	while(i < mInstance->nlines) {			//Loop through Script Running each Line
    for(j=0; j<255; j++) {
      buf[j]=mInstance->lines[i].str[j];
      if(buf[j]=='\n')
        break;
      }
    buf[j]=0;
		myTextOut(mInstance,buf);
    myCR(mInstance);
   	i++;
    }
  
    myCR(mInstance);

  // fare...
	// ovvero :)
/*	if(theScript)
    puts(theScript);
 * */
	}
  
void doNew(MINIBASIC *mInstance) {
  
  match(mInstance,NEW);
	*theScript=0;
  cleanup(mInstance,1);   // verificare, se si usa!
	}

int subLoad(char *s,char *p) {
  FSFILE *f;
  int n=0;
  
  *p=0;
  if((f = FSfopen(s, "r"))) { 
    while(1) {
      if(FSfread(p,1,1,f) == 1) {  // o FSfgets??
        if(*p != 13 && *p != 9)    // cmq tolgo CR e TAB
          p++;
        n++;
        }
      else
        break;
      }
    *p=0;
    FSfclose(f);
    return n;
    }
  else {
    return -1;
    }
  }
  
void doLoad(MINIBASIC *mInstance) {
	char *filename;
  
  match(mInstance,LOAD);
  filename=stringExpr(mInstance);
  if(filename) {
    if(subLoad(filename,theScript) < 0)
      setError(mInstance,ERR_FILE);
    else
      setup(mInstance,theScript);
    }
	}

void doSave(MINIBASIC *mInstance) {
  FSFILE *f;
  int i,n=0;
	char *filename;
  
  match(mInstance,SAVE);
  filename=stringExpr(mInstance);
  
  if((f = FSfopen(filename, "w"))) { 
    i=0;
    while(i < mInstance->nlines) {			//Loop through Script Running each Line
      n+=FSfwrite(mInstance->lines[i].str,strlen(mInstance->lines[i].str),1,f);
      FSputc('\n',f); n++;
      i++;
      }
    FSfclose(f);
//    return n;
    }
  else
    setError(mInstance,ERR_FILE);
	}

void doWificonnect(MINIBASIC *mInstance) {
#ifdef USA_WIFI
	char *ap,*pasw;
	int auth,chan;

  match(mInstance,WIFICONNECT);

	auth=M2M_WIFI_SEC_WPA_PSK;
	chan=M2M_WIFI_CH_ALL;

  ap=stringExpr(mInstance);
	match(mInstance,COMMA);
  pasw=stringExpr(mInstance);
	if(mInstance->token==COMMA) {
		match(mInstance,COMMA);
		auth=expr(mInstance);
		if(mInstance->token==COMMA) {
			match(mInstance,COMMA);
			chan=expr(mInstance);
			}
		}

  /*mInstance->errorFlag= v. callback ...*/ m2m_wifi_connect(ap,12,M2M_WIFI_SEC_WPA_PSK,pasw,chan);
	while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS) {
    ClrWdt();
		}
#else
  setError(mInstance,ERR_NETWORK);
#endif
  }


/*
  ------------------
*/
void doSetpin(MINIBASIC *mInstance) {
  unsigned char port, pin, mode;
  
  match(mInstance,SETPIN);
  port = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  pin = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  mode = integer(mInstance,expr(mInstance));
	setpin(port,pin,mode);
	}


/*
  ------------------
*/
void doSound(MINIBASIC *mInstance) {    // SOUND canale,frequenza [,TIPO[,volume]]
  int channel,type=QUADRA,freq,stereo,bits,volume=100;
  
  match(mInstance,SOUND);
//  SetAudioMode(SYNTH);    // in effetti credo implicita in setaudiowave SOLO SE SERVE
  channel = expr(mInstance);
  match(mInstance,COMMA);
  freq = expr(mInstance);
  if(mInstance->token == COMMA) {
    match(mInstance,COMMA);
    type = expr(mInstance);
    if(mInstance->token == COMMA) {
      match(mInstance,COMMA);
      volume = expr(mInstance);
      }
    }
  
  SetAudioWave(channel,type,freq,2,8,volume,1 /* mix*/,0);
	}
void doPlay(MINIBASIC *mInstance) {
  char *str;
  
  match(mInstance,PLAY);
  SetAudioMode(SAMPLES);
  str=stringExpr(mInstance);
  
  if(str) {
    FSFILE *f;
    char buf[128];
    
    if((f = FSfopen(str, "r"))) { 
      do {
        if(FSfread(buf,1,1,f)==1) {
          SetAudioSamples(*buf);
          }
        else 
          break;
        } while(1);
      FSfclose(f);
      }
    free(str);
    }
	}
void doTone(MINIBASIC *mInstance) {
  unsigned char port, pin, freq;
  
  match(mInstance,TONE);
  port = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  pin = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  freq = integer(mInstance,expr(mInstance));
	tone(port,pin,freq);
	}

void doBeep(MINIBASIC *mInstance) {
  WORD durata;
  
  match(mInstance,BEEP);
  durata = expr(mInstance);
  // usare StdBeep(durata) ??
  OC1CONbits.ON=1;    //
  __delay_ms(durata); 
  OC1CONbits.ON=0;
  ClrWdt();
	}


/*
  ------------------
*/
void doOutd(MINIBASIC *mInstance) {
  unsigned char port, pin, value;
  
  match(mInstance,OUTD);
  port = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  pin = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  value = integer(mInstance,expr(mInstance));
	outd(port,pin,value);
	}



/*
  ------------------
*/
void doOutdac(MINIBASIC *mInstance) {
  unsigned char port, value;
  
  match(mInstance,OUTDAC);
  port = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  value = integer(mInstance,expr(mInstance));
	outdac(port,value);
	}



/*
  the LET statement
*/
void doLet(MINIBASIC *mInstance,int8_t matchlet) {
	LVALUE lv;
  char *temp;
	int n,t;
#warning prende una parola (minuscola o maiuscola ) da sola senza dire nulla (credo cerchi di vederla come variabile)
//#warning e non da nemmeno errore su statement maiuscoli sbagliati...  
//#warning e tipo PI lo prende minuscolo ma le funzioni maiuscole...
  if(matchlet) {
		match(mInstance,LET);
		}


//	lv.d.dval=(float *)100;
//			fprintf(fperr,"DEBUG: lv=%x, lv.d=%x\n",lv,lv.d.dval);
	
  lvalue(mInstance,&lv);
//			fprintf(fperr,"DEBUG1: lv=%x, lv.d=%x\n",lv,lv.d);


  switch(lv.type) {
    case FLTID:
		  match(mInstance,EQUALS);
			*lv.d.dval = expr(mInstance);
			break;

   	case INTID:
		  match(mInstance,EQUALS);
//			if(lv.d.ival)
				*lv.d.ival = integer(mInstance,expr(mInstance));
			break;

    case STRID:
		  match(mInstance,EQUALS);
			temp = *lv.d.sval;
			*lv.d.sval = stringExpr(mInstance);
			if(temp)
				free(temp);
			break;

    case TIMER:
			lv.type=INTID;
			match(mInstance,OPAREN);
		  t = integer(mInstance,expr(mInstance));
			match(mInstance,CPAREN);
		  match(mInstance,EQUALS);
			n=integer(mInstance,expr(mInstance));

			switch(t) {
				case 1:
					TMR1=n;
					break;
				case 2:
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#else
					TMR2=n;   // OCCHIO USB!!
#endif
					break;
				case 3:
					TMR3=n;
					break;
				case 4:
					TMR4=n;
					break;
				case 5:
					TMR5=n;
					break;
				default:
					setError(mInstance,ERR_BADVALUE);
					break;
				}

//				*lv.d.ival = n;   // mettere??
			break;  //break timer

  	case MIDSTRING:
			{
	  	char *str2,*str3;
			int len;
				
			match(mInstance,OPAREN);

//			fprintf(fperr,"DEBUG2: lv=%x, lv.d=%x\n",lv,lv.d);

//			/* *lv.d.sval= */ stringVar();		// cercaVar ...
		  lvalue(mInstance,&lv);
			if(lv.type != STRID)
				setError(mInstance,ERR_TYPEMISMATCH);
			if(mInstance->errorFlag)
				break;

			match(mInstance,COMMA);
			n = integer(mInstance,expr(mInstance));
			if(mInstance->token==COMMA) {
				match(mInstance,COMMA);
				t = integer(mInstance,expr(mInstance));
				}
			else
				t=-1;

			match(mInstance,CPAREN);

//			t= strlen(*lv.d.sval);
			if(t > (int) strlen(*lv.d.sval) || t<n || !t)	{
				setError(mInstance,ERR_ILLEGALOFFSET);
				break;
  			}

			len=strlen(*lv.d.sval);
			if(t>0)
				len=len-n+t;
			else
				len=len+n;

			str3 = (char *)malloc(len + 1);
			if(!str3) {
				setError(mInstance,ERR_OUTOFMEMORY);
				break;
  			}

			match(mInstance,EQUALS);
			str2=stringExpr(mInstance);

//			fprintf(fperr,"DEBUG2: str3=%s, str2=%s, org=%s\n",str3,str2,*lv.d.sval);
			strcpy(str3,*lv.d.sval);
			strcpy(str3+n,str2);
//			fprintf(fperr,"DEBUG2: str3=%s, str2=%s\n",str3,str2);
			if(t > 0)
				{
				strcat(str3,(*lv.d.sval)+t+n);
				}
//			fprintf(fperr,"DEBUG2: str3=%s, str2=%s\n",str3,str2);

			free(str2);
			temp = *lv.d.sval;
			*lv.d.sval = str3;
			if(temp)
				free(temp);

			}//end MIDSTRING
			
			break;
      
    case MIDISTRING:
    {
	  	char *str2;
		  match(mInstance,EQUALS);
			if(!isString(mInstance->token))
				setError(mInstance,ERR_TYPEMISMATCH);
      else {
        str2=stringExpr(mInstance);

        if(str2) {
          WriteMidi(*str2);
          free(str2);
          }
  //      else
  //      ;
      }
    }
			break;
      
		default:
      setError(mInstance,ERR_SYNTAX);
			break;
		}
	
	}



/*
  the DIM statement
*/
void doDim(MINIBASIC *mInstance) {
  BYTE ndims = 0;
  double dims[MAXDIMS+1];
  char name[IDLENGTH];
  IDENT_LEN len;
  DIMVAR *dimvar;
  unsigned char i;
  int size = 1;

  match(mInstance,DIM);

  switch(mInstance->token) {
    case DIMFLTID:
		case DIMSTRID:
		case DIMINTID:
      getId(mInstance,mInstance->string, name, &len);
			match(mInstance,mInstance->token);
			dims[ndims++] = expr(mInstance);
			while(mInstance->token == COMMA) {
				match(mInstance,COMMA);
				dims[ndims++] = expr(mInstance);
				if(ndims > MAXDIMS)	{
					setError(mInstance,ERR_TOOMANYDIMS);
					return;
					}
				} 

		  match(mInstance,CPAREN);
	  
			for(i=0; i<ndims; i++) {
				if(dims[i] < 0 || dims[i] != (int) dims[i])	{
					setError(mInstance,ERR_BADSUBSCRIPT);
					return;
				}
			}
	  switch(ndims) {
	    case 1:
				dimvar = dimension(mInstance,name, 1, (int) dims[0]);
				break;
			case 2:
				dimvar = dimension(mInstance,name, 2, (int) dims[0], (int) dims[1]);
				break;
			case 3:
				dimvar = dimension(mInstance,name, 3, (int) dims[0], (int) dims[1], (int) dims[2]);
				break;
			case 4:
				dimvar = dimension(mInstance,name, 4, (int) dims[0], (int) dims[1], (int) dims[2], (int) dims[3]);
				break;
			case 5:
				dimvar = dimension(mInstance,name, 5, (int) dims[0], (int) dims[1], (int) dims[2], (int) dims[3], (int) dims[4]);
				break;
			}
			break;
		default:
	    setError(mInstance,ERR_SYNTAX);
	    return;
	  }
  if(dimvar == 0) {
	/* out of memory */
		setError(mInstance,ERR_OUTOFMEMORY);
		return;
		}


  if(mInstance->token == EQUALS) {
    match(mInstance,EQUALS);

		for(i=0; i<dimvar->ndims; i++)
			size *= dimvar->dim[i];

		switch(dimvar->type) {
      case FLTID:
				i = 0;
				dimvar->d.dval[i++] = expr(mInstance);
				while(mInstance->token == COMMA && i < size)	{
					match(mInstance,COMMA);
					dimvar->d.dval[i++] = expr(mInstance);
					if(mInstance->errorFlag)
						break;
					}
				break;
			case STRID:
				i = 0;
				if(dimvar->d.str[i])
					free(dimvar->d.str[i]);
				dimvar->d.str[i++] = stringExpr(mInstance);

				while(mInstance->token == COMMA && i < size)	{
					match(mInstance,COMMA);
					if(dimvar->d.str[i])
						free(dimvar->d.str[i]);
					dimvar->d.str[i++] = stringExpr(mInstance);
					if(mInstance->errorFlag)
						break;
					}
				break;
#ifdef INT_AND_REAL    
				//FINIRE
#endif
			}
		
		if(mInstance->token == COMMA)
			setError(mInstance,ERR_TOOMANYINITS);
		}

	}


/*
  the IF statement.
  if jump taken, returns new line no, else returns 0
*/
LINE_NUMBER_TYPE doIf(MINIBASIC *mInstance) {
  char condition;
  LINE_NUMBER_TYPE jumpthen, jumpelse = 0;

  match(mInstance,IF);
  condition = boolExpr(mInstance);
  match(mInstance,THEN);
  jumpthen = integer(mInstance,expr(mInstance));
  if(mInstance->token == ELSE) {
		match(mInstance,ELSE);
		jumpelse = integer(mInstance,expr(mInstance));
		}

  return condition ? jumpthen : jumpelse;
	}

/*
  the GOTO satement
  returns new line number
*/
LINE_NUMBER_TYPE doGoto(MINIBASIC *mInstance) {

  match(mInstance,GOTO);
  return integer(mInstance,expr(mInstance));
	}

LINE_NUMBER_TYPE doGosub(MINIBASIC *mInstance) {
  LINE_NUMBER_TYPE toline;

  match(mInstance,GOSUB);
  toline = integer (mInstance, expr(mInstance));
  if(mInstance->ngosubs >= MAXGOSUB) {
	  setError(mInstance,ERR_TOOMANYGOSUB);
	  return -1;
		}
  mInstance->gosubStack[mInstance->ngosubs++] = getNextLine(mInstance->string);
  return toline;
	}

void doError(MINIBASIC *mInstance) {

  match(mInstance,ERRORTOK);
  setError(mInstance,integer (mInstance, expr(mInstance)));
	}

LINE_NUMBER_TYPE doReturn(MINIBASIC *mInstance) {

  match(mInstance,RETURN);
  if(mInstance->ngosubs <= 0) {
	  setError(mInstance,ERR_NORETURN);
	  return -1;
		}
  return mInstance->gosubStack[--mInstance->ngosubs];
	}


/*
  The FOR statement.

  Pushes the for stack.
  Returns line to jump to, or -1 to end program
*/
LINE_NUMBER_TYPE doFor(MINIBASIC *mInstance) {
  LVALUE lv;
  char id[IDLENGTH];
  IDENT_LEN len;
  NUM_TYPE initval;
  NUM_TYPE toval;
  NUM_TYPE stepval;
  char *savestring;
  int answer;

  match(mInstance,FOR);
  getId(mInstance,mInstance->string, id, &len);

  lvalue(mInstance,&lv);
  if(lv.type != FLTID && lv.type != INTID) {
    setError(mInstance,ERR_TYPEMISMATCH);
		return -1;
		}
  match(mInstance,EQUALS);
  initval = expr(mInstance);
  match(mInstance,TO);
  toval = expr(mInstance);
  if(mInstance->token == STEP) {
    match(mInstance,STEP);
		stepval = expr(mInstance);
		}
  else
    stepval = 1.0;

  if(lv.type == INTID) {
	  *lv.d.ival = initval;
		}
	else
	  *lv.d.dval = initval;

  if(mInstance->nfors > MAXFORS - 1) {
		setError(mInstance,ERR_TOOMANYFORS);
		return -1;
	  }
#warning lo statement : dopo FOR non funziona... 2021 (� perch� ragiona solo in termini di Righe e non di statement..)
  if(((stepval < 0) && (initval <= toval)) || ((stepval > 0) && (initval >= toval))) {
	  char nextid[IDLENGTH];
		savestring = mInstance->string;
    while((mInstance->string = strchr((char *)mInstance->string, '\n')))	{
      mInstance->errorFlag = 0;
		  mInstance->token = getToken(mInstance->string);
		  match(mInstance,VALUE);
		  if(mInstance->token == NEXT) {
		    match(mInstance,NEXT);
				if(mInstance->token == FLTID || mInstance->token == DIMFLTID) {
		      getId(mInstance,mInstance->string, nextid, &len);
				  if(!strcmp(id, nextid)) {
						answer = getNextLine(mInstance->string);
						mInstance->string = savestring;
						mInstance->token = getToken(mInstance->string);
						return answer ? answer : -1;
				  	}
					}
		  	}
			}

		setError(mInstance,ERR_NONEXT);
		return -1;
  	}
  else {
		strcpy(mInstance->forStack[mInstance->nfors].id, id);
		mInstance->forStack[mInstance->nfors].nextline = getNextLine(mInstance->string);
		mInstance->forStack[mInstance->nfors].step = stepval;
		mInstance->forStack[mInstance->nfors].toval = toval;
		mInstance->nfors++;
    return 0;
	  }

	}



/*
  the NEXT statement
  updates the counting index, and returns line to jump to
*/
LINE_NUMBER_TYPE doNext(MINIBASIC *mInstance) {
  char id[IDLENGTH];
  IDENT_LEN len;
  LVALUE lv;
	BYTE n;

  match(mInstance,NEXT);

  if(mInstance->nfors>0) {
		n=mInstance->nfors-1;
		if(mInstance->token == EOL) {
			VARIABLE *var;
			var = findVariable(mInstance,mInstance->forStack[n].id);
/*			if(!var) {		// IMPOSSIBILE!
				setError(mInstance,ERR_OUTOFMEMORY);
				return 0;
				}*/
			lv.type = var->type;
			lv.d.dval = &var->d.dval;		// both int & real
			}
		else {
	    getId(mInstance,mInstance->string, id, &len);
			if(strcmp(id,mInstance->forStack[n].id)) {
		    setError(mInstance,ERR_NOFOR);
				return 0;
				}
	    lvalue(mInstance,&lv);
			}
  	if(lv.type != FLTID && lv.type != INTID) {
		  setError(mInstance,ERR_TYPEMISMATCH);
	  	return -1;
			}
	  if(lv.type == FLTID) {
	    *lv.d.dval += mInstance->forStack[n].step;
			if( (mInstance->forStack[n].step < 0 && *lv.d.dval < mInstance->forStack[n].toval) ||
				(mInstance->forStack[n].step > 0 && *lv.d.dval > mInstance->forStack[n].toval)) {
			  mInstance->nfors--;
			  return 0;
				}
			else {
	      return mInstance->forStack[n].nextline;
				}
			}
		else {
	    *lv.d.ival += (int)mInstance->forStack[n].step;
			if( (mInstance->forStack[n].step < 0 && *lv.d.ival < mInstance->forStack[n].toval) ||
				(mInstance->forStack[n].step > 0 && *lv.d.ival > mInstance->forStack[n].toval)) {
			  mInstance->nfors--;
			  return 0;
				}
			else {
	      return mInstance->forStack[n].nextline;
				}
			}
  	}
  else {
    setError(mInstance,ERR_NOFOR);
		return -1;
  	}
	}


/*
  The DO statement.

  Pushes the do stack.
  Returns line to jump to, or -1 to end program
*/
LINE_NUMBER_TYPE doDo(MINIBASIC *mInstance) {
  int t;

  match(mInstance,DO);
  if(mInstance->token == WHILE) {
	  match(mInstance,WHILE);
		t = boolExpr(mInstance);
		}
  else if(mInstance->token == UNTIL) {
	  match(mInstance,UNTIL);
		t = !boolExpr(mInstance);
		}
	else {
    t=1;
		}

  if(mInstance->ndos > MAXFORS - 1) {
		setError(mInstance,ERR_TOOMANYFORS);
		return -1;
	  }
  else {
		if(t) {
			mInstance->doStack[mInstance->ndos++] = mInstance->lines[mInstance->curline].no /*getNextLine(string)*/;
			return 0;
			}
		else {
			uint8_t n;

			n=0;
			do {
				mInstance->curline++;
				mInstance->string = mInstance->lines[mInstance->curline].str;
				mInstance->token = getToken(mInstance->string);
				if(mInstance->token==DO)
					n++;
				if(mInstance->token==LOOP)
					n--;
				// use inBlocks...
				if(mInstance->token==EOS) {
				  setError(mInstance,ERR_SYNTAX /* or NEXT / LOOP not found... */);
					break;;
					}
				} while(mInstance->token != LOOP && n==0);
			return mInstance->lines[mInstance->curline+1].no;
			}
	  }

	}



/*
  The LOOP statement.

  Uses the do stack.
  Returns line to jump to, or -1 to end program

*/
LINE_NUMBER_TYPE doLoop(MINIBASIC *mInstance) {
  int t;

  match(mInstance,LOOP);
  if(mInstance->token == WHILE) {
	  match(mInstance,WHILE);
		t = boolExpr(mInstance);
		}
  else if(mInstance->token == UNTIL) {
	  match(mInstance,UNTIL);
		t = !boolExpr(mInstance);
		}
	else {
    t=1;
		}

	if(mInstance->ndos>0) {
    return t ? mInstance->doStack[--mInstance->ndos] : 0;
		}
  else {
    setError(mInstance,ERR_NOFOR);
		return -1;
  	}
	}


/*
  the INPUT statement
*/
void doInput(MINIBASIC *mInstance) {
  LVALUE lv;
  char buff[256];
  char *end;

  match(mInstance,INPUTTOK);
  lvalue(mInstance,&lv);

  //v. anche inputString ecc..
  
  switch(lv.type) {
		case FLTID:
			while(scanf((char *)"%lf", lv.d.dval) != 1) {
// FINIRE!
				mInstance->incomingChar[0];
        //getchar();
				}
			break;
		case INTID:
			while(scanf((char *)"%d", lv.d.ival) != 1) {
        mInstance->incomingChar[0];
      //getchar();
				}
			break;
		case STRID:
			if(*lv.d.sval) {
				free(*lv.d.sval);
				*lv.d.sval = 0;
				}
			if(gets(buff) == 0)	{
				setError(mInstance,ERR_EOF);
				return;
				}
			end = strchr(buff, '\n');
			if(!end) {
				setError(mInstance,ERR_INPUTTOOLONG);
				return;
				}
			*end = 0;
			*lv.d.sval = strdup(buff);
			if(!*lv.d.sval)	{
				setError(mInstance,ERR_OUTOFMEMORY);
				return;
				}
			break;
		default:
			return;
		}
	}


/*
  the REM statement.
  Note is unique as the rest of the line is not parsed
*/
void doRem(MINIBASIC *mInstance) {

//  match(mInstance,REM);
  
  match(mInstance,mInstance->token);		// e REM2 ??
	}


/*
  ------------------
*/
void doSys(MINIBASIC *mInstance) {
  unsigned int a;
  
  match(mInstance,SYS);
  a = integer(mInstance,expr(mInstance));

//__asm__("MOV _a,W0");		// tendenzialmente "a" si trova gi� in W0 ! (v. disassembly)
//__asm__("CALL W0");
//  _jr_hb();
//  __asm__("j": "=c" (a));   // VERIFICARE!
	}



/*
  ------STOP--------
*/
void doStop(MINIBASIC *mInstance) {

  match(mInstance,STOP);
	setError(mInstance,ERR_STOP);
  
// waits for a key, (vedere sopra loop che gestisce keypress/WM_CHAR per errori!)
	}


void doLine(MINIBASIC *mInstance) {
  POINT pt1,pt2;
  BYTE size;
  HDC myDC,*hDC;

  match(mInstance,LINETOK);
  pt1.x = integer(mInstance,expr(mInstance));
  if(pt1.x < 0 || pt1.x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt1.y = integer(mInstance,expr(mInstance));
  if(pt1.y < 0 || pt1.y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt2.x = integer(mInstance,expr(mInstance));
  if(pt2.x < 0 || pt2.x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt2.y = integer(mInstance,expr(mInstance));
  if(pt2.y < 0 || pt2.y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);

  if(mInstance->token == COMMA) {
    match(mInstance,COMMA);
    size=integer(mInstance,expr(mInstance));
    }
  else
    size=1;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  hDC->pen=CreatePen(PS_SOLID,size,Color24To565(mInstance->Color));
  MoveTo(hDC,pt1.x,pt1.y);
  LineTo(hDC,pt2.x,pt2.y);
  mInstance->Cursor.x=pt2.x;
  mInstance->Cursor.y=pt2.y;
  ReleaseDC(mInstance->hWnd,hDC);
#else
  DrawLine(pt1.x,pt1.y,pt2.x,pt2.y,Color24To565(mInstance->Color));
// no! text  mInstance->Cursor.x=pt1.x;
//  mInstance->Cursor.y=pt1.y;
#endif
	}

void doRectangle(MINIBASIC *mInstance) {
  POINT pt[2];
  BYTE size;
  HDC myDC,*hDC;

  match(mInstance,RECTANGLE);
  pt[0].x = integer(mInstance,expr(mInstance));
  if(pt[0].x < 0 || pt[0].x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[0].y = integer(mInstance,expr(mInstance));
  if(pt[0].y < 0 || pt[0].y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[1].x = integer(mInstance,expr(mInstance));
  if(pt[1].x < 0 || pt[1].x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[1].y = integer(mInstance,expr(mInstance));
  if(pt[1].y < 0 || pt[1].y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
	
  if(mInstance->token == COMMA) {
    match(mInstance,COMMA);
    size=integer(mInstance,expr(mInstance));
    }
  else
    size=1;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  hDC->pen=CreatePen(PS_SOLID,size,Color24To565(mInstance->Color));
  Rectangle(hDC,pt[0].x,pt[0].y,pt[1].x,pt[1].y);
  ReleaseDC(mInstance->hWnd,hDC);
#else
  DrawRectangle(pt[0].x,pt[0].y,pt[1].x,pt[1].y,Color24To565(mInstance->Color));
#endif
	}

void doTriangle(MINIBASIC *mInstance) {
  POINT pt[4];
  BYTE size;
  HDC myDC,*hDC;

  match(mInstance,TRIANGLE);
  pt[3].x = pt[0].x = integer(mInstance,expr(mInstance));
  if(pt[0].x < 0 || pt[0].x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[3].y = pt[0].y = integer(mInstance,expr(mInstance));
  if(pt[0].y < 0 || pt[0].y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[1].x = integer(mInstance,expr(mInstance));
  if(pt[1].x < 0 || pt[1].x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[1].y = integer(mInstance,expr(mInstance));
  if(pt[1].y < 0 || pt[1].y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[2].x = integer(mInstance,expr(mInstance));
  if(pt[2].x < 0 || pt[2].x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt[2].y = integer(mInstance,expr(mInstance));
  if(pt[2].y < 0 || pt[2].y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
	
  if(mInstance->token == COMMA) {
    match(mInstance,COMMA);
    size=integer(mInstance,expr(mInstance));
    }
  else
    size=1;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  hDC->pen=CreatePen(PS_SOLID,size,Color24To565(mInstance->Color));
  Polygon(hDC,pt,4);
  ReleaseDC(mInstance->hWnd,hDC);
#else
  DrawLine(pt[0].x,pt[0].y,pt[1].x,pt[1].y,Color24To565(mInstance->Color));
  DrawLine(pt[1].x,pt[1].y,pt[2].x,pt[2].y,Color24To565(mInstance->Color));
  DrawLine(pt[2].x,pt[2].y,pt[3].x,pt[3].y,Color24To565(mInstance->Color));
#endif
	}

void doEllipse(MINIBASIC *mInstance) {
  POINT pt;
  uint16_t r;
  BYTE size;
  HDC myDC,*hDC;

  match(mInstance,ELLIPSE);
  pt.x = integer(mInstance,expr(mInstance));
  if(pt.x < 0 || pt.x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt.y = integer(mInstance,expr(mInstance));
  if(pt.y < 0 || pt.y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  r = integer(mInstance,expr(mInstance));
	
  if(mInstance->token == COMMA) {
    match(mInstance,COMMA);
    size=integer(mInstance,expr(mInstance));
    }
  else
    size=1;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  hDC->pen=CreatePen(PS_SOLID,size,Color24To565(mInstance->Color));
  hDC->brush=CreateSolidBrush(Color24To565(mInstance->ColorBK));
  Ellipse(hDC,pt.x-r,pt.y-r,pt.x+r,pt.y+r);
  ReleaseDC(mInstance->hWnd,hDC);
#else
  DrawCircle(pt.x,pt.y,r,Color24To565(mInstance->Color));
#endif
  
	}

void doArc(MINIBASIC *mInstance) {
  uint16_t x1,y1,x2,y2;
  BYTE size;
  HDC myDC,*hDC;

  match(mInstance,ARC);
  x1 = integer(mInstance,expr(mInstance));
  if(x1 < 0 || x1 > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  y1 = integer(mInstance,expr(mInstance));
  if(y1 < 0 || y1 > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  x2 = integer(mInstance,expr(mInstance));
  if(x2 < 0 || x2 > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  y2 = integer(mInstance,expr(mInstance));
  if(y2 < 0 || y2 > Screen.cy)
		setError(mInstance, ERR_BADVALUE);

  if(mInstance->token == COMMA) {
    match(mInstance,COMMA);
    size=integer(mInstance,expr(mInstance));
    }
  else
    size=1;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  hDC->pen=CreatePen(PS_SOLID,size,Color24To565(mInstance->Color));
// finire...
  ReleaseDC(mInstance->hWnd,hDC);
#else
// finire...
#endif
	}

void doPoint(MINIBASIC *mInstance) {
  POINT pt;
  BYTE size;
  int32_t c;
  HDC myDC,*hDC;

  match(mInstance,POINTTOK);
  pt.x = integer(mInstance,expr(mInstance));
  if(pt.x < 0 || pt.x > Screen.cx)
		setError(mInstance, ERR_BADVALUE);
  match(mInstance,COMMA);
  pt.y = integer(mInstance,expr(mInstance));
  if(pt.y < 0 || pt.y > Screen.cy)
		setError(mInstance, ERR_BADVALUE);
  
  if(mInstance->token == COMMA) {   // pu� seguire size...
    match(mInstance,COMMA);
    size=integer(mInstance,expr(mInstance));
    if(mInstance->token == COMMA) {   // ..e color
      match(mInstance,COMMA);
      c = expr(mInstance);
      if(c < 0) {	// se negativo, RGB!
        c=-c;
        if(c > 0xffffff)
          setError(mInstance, ERR_BADVALUE);
        }
      else if(c > 15)
        setError(mInstance, ERR_BADVALUE);
      else {
        c=ColorRGB(textColors[c]);
        }
      }
    else
      c=ColorRGB(mInstance->ColorPalette);
    }
  else
    size=1;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
//  hDC.pen=CreatePen(PS_SOLID,size,mInstance->Color);
  mInstance->Cursor.x=pt.x;
  mInstance->Cursor.y=pt.y;

  if(size==1)
    SetPixel(hDC,pt.x,pt.y,Color24To565(c));
  else {
    RECT rc;
    BRUSH b;
    rc.left=pt.x;
    rc.top=pt.y;
    rc.right=rc.left+size;
    rc.bottom=rc.top+size;
    b=CreateSolidBrush(Color24To565(c));
    FillRect(hDC,&rc,b);
    }
	
  ReleaseDC(mInstance->hWnd,hDC);
#else
// no! text  mInstance->Cursor.x=pt.x;
//  mInstance->Cursor.y=pt.y;

  if(size==1)
    DrawPixel(pt.x,pt.y,Color24To565(c));
  else {
    RECT rc;
    rc.left=pt.x;
    rc.top=pt.y;
    rc.right=rc.left+size;
    rc.bottom=rc.top+size;
    DrawRectangle(rc.left,rc.top,rc.right,rc.bottom,Color24To565(c));
#warning FILLED!
    }
#endif

}

void doSetcolor(MINIBASIC *mInstance) {
  int32_t c;
  
  match(mInstance,SETCOLOR);
  c = expr(mInstance);
  if(c < 0) {	// se negativo, RGB!
		c=-c;
		if(c > 0xffffff)
			setError(mInstance, ERR_BADVALUE);
		mInstance->Color=c;
		mInstance->ColorPalette=Color24To565(c);
		}
  else if(c > 15)
		setError(mInstance, ERR_BADVALUE);
	else {
		mInstance->ColorPalette=textColors[c];
		mInstance->Color=ColorRGB(mInstance->ColorPalette);
		}
  SetColors(Color24To565(mInstance->Color),Color24To565(mInstance->ColorBK)); // questo serve cmq per printf/putchar
	}

void doSetBkcolor(MINIBASIC *mInstance) {
  int32_t c;
  
  match(mInstance,SETBKCOLOR);
  c = expr(mInstance);
  if(c < 0) {	// se negativo, RGB!
		c=-c;
		if(c > 0xffffff)
			setError(mInstance, ERR_BADVALUE);
		mInstance->ColorBK=c;
		mInstance->ColorPaletteBK=Color24To565(c);
		}
  else if(c > 15)
		setError(mInstance, ERR_BADVALUE);
	else {
	  mInstance->ColorPaletteBK=textColors[c];
		mInstance->ColorBK=ColorRGB(mInstance->ColorPaletteBK);
		}
  SetColors(Color24To565(mInstance->Color),Color24To565(mInstance->ColorBK)); // questo serve cmq per printf/putchar
	}

void doBitblt(MINIBASIC *mInstance) {
	}


/*
  Get an lvalue from the environment
  Params: lv - structure to fill.
  Notes: missing variables (but not out of range subscripts)
         are added to the variable list.
*/
void lvalue(MINIBASIC *mInstance,LVALUE *lv) {
  char name[IDLENGTH];
  IDENT_LEN len;
  VARIABLE *var;
  DIMVAR *dimvar;
  DIM_SIZE index[MAXDIMS];
  void *valptr = 0;
  char type;
  
  lv->type = B_ERROR;
  lv->d.dval = 0;		// clears them all

  switch(mInstance->token) {
    case FLTID:
			getId(mInstance,mInstance->string, name, &len);
			match(mInstance,FLTID);
			var = findVariable(mInstance,name);
			if(!var)
				var = addFloat(mInstance,name);
			if(!var) {
				setError(mInstance,ERR_OUTOFMEMORY);
				return;
				}
			lv->type = FLTID;
			lv->d.dval = &var->d.dval;
			break;
    case STRID:
			getId(mInstance,mInstance->string, name, &len);
			match(mInstance,STRID);
			var = findVariable(mInstance,name);
			if(!var)
				var = addString(mInstance,name);
			if(!var) {
				setError(mInstance,ERR_OUTOFMEMORY);
				return;
				}
			lv->type = STRID;
			lv->d.sval = &var->d.sval;
			break;
    case INTID:
			getId(mInstance,mInstance->string, name, &len);
			match(mInstance,INTID);
			var = findVariable(mInstance,name);
			if(!var)
				var = addInt(mInstance,name);
			if(!var) {
				setError(mInstance,ERR_OUTOFMEMORY);
				return;
				}
			lv->type = INTID;
			lv->d.ival = &var->d.ival;
			break;
		case DIMFLTID:
		case DIMSTRID:
		case DIMINTID:
			type = (mInstance->token == DIMFLTID) ? FLTID : ((mInstance->token == DIMSTRID) ? STRID : INTID);
			getId(mInstance,mInstance->string, name, &len);
			match(mInstance,mInstance->token);
			dimvar = findDimVar(mInstance,name);
			if(dimvar) {
				switch(dimvar->ndims)	{
					case 1:
						index[0] = integer(mInstance,expr(mInstance));
						if(!mInstance->errorFlag)
              valptr = getDimVar(mInstance,dimvar, index[0]);
						break;
					case 2:
						index[0] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[1] = integer(mInstance,expr(mInstance));
						if(!mInstance->errorFlag)
							valptr = getDimVar(mInstance,dimvar, index[0], index[1]);
						break;
					case 3:
						index[0] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[1] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[2] = integer(mInstance,expr(mInstance));
						if(!mInstance->errorFlag)
							valptr = getDimVar(mInstance,dimvar, index[0], index[1], index[2]);
						break;
				  case 4:
						index[0] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[1] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
            index[2] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[3] = integer(mInstance,expr(mInstance));
						if(!mInstance->errorFlag)
							valptr = getDimVar(mInstance,dimvar, index[0], index[1], index[2], index[3]);
						break;
					case 5:
						index[0] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[1] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[2] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[3] = integer(mInstance,expr(mInstance));
						match(mInstance,COMMA);
						index[4] = integer(mInstance,expr(mInstance));
						if(!mInstance->errorFlag)
							valptr = getDimVar(mInstance,dimvar, index[0], index[1], index[2], index[3]);
						break;
					}
				match(mInstance,CPAREN);
				}
			else {
				setError(mInstance,ERR_NOSUCHVARIABLE);
				return;
				}
	  if(valptr) {
			lv->type = type;
	    if(type == FLTID)
	      lv->d.dval = valptr;
	    else if(type == STRID)
	      lv->d.sval = valptr;
	    else if(type == INTID)
	      lv->d.ival = valptr;
			else
				basicAssert(0);
		  }
		  break;
		case TIMER:
			match(mInstance,TIMER);
			lv->type = TIMER;
//			lv->dval = &var->dval;
//			lv->sval = 0;
			break;
		case MIDSTRING:
			match(mInstance,MIDSTRING);
			lv->type = MIDSTRING;
//			lv->dval = &var->dval;
//			lv->sval = 0;
			break;
		case MIDISTRING:
			match(mInstance,MIDISTRING);
			lv->type = MIDISTRING;
//			lv->dval = &var->dval;
//			lv->sval = 0;
			break;
		default:
			setError(mInstance,ERR_SYNTAX);
		  break;
		}
	}


/*
  parse a boolean expression
  consists of expressions or strings and relational operators,
  and parentheses
*/
signed char boolExpr(MINIBASIC *mInstance) {
  signed char left;
  signed char right;
  
  left = boolFactor(mInstance);

  while(1) {
    switch(mInstance->token) {
			case AND:
				match(mInstance,AND);
				right = boolExpr(mInstance);
				return (left && right) ? -1 : 0;
			case OR:
				match(mInstance,OR);
				right = boolExpr(mInstance);
				return (left || right) ? -1 : 0;
			default:
				return left;
			}
		}
	}


/*
  boolean factor, consists of expression relOp expression
    or string relOp string, or ( boolExpr())
*/
signed char boolFactor(MINIBASIC *mInstance) {
  signed char answer;
  NUM_TYPE left;
  NUM_TYPE right;
  signed char op;
  char *strleft;
  char *strright;

  switch(mInstance->token) {
    case OPAREN:
			match(mInstance,OPAREN);
			answer = boolExpr(mInstance);
			match(mInstance,CPAREN);
			break;
		default:
			if(isString(mInstance->token)) {
				strleft = stringExpr(mInstance);
				op = relOp(mInstance);
				strright = stringExpr(mInstance);
				if(!strleft || !strright)	{
					if(strleft)
						free(strleft);
					if(strright)
						free(strright);
					return 0;
					}
				answer= strRop(mInstance,op,strleft,strright);
			
				free(strleft);
				free(strright);
			  }
		  else {
		    left = expr(mInstance);
//				op = relOp();
//				right = expr(mInstance);
//				answer= rop(op,left,right);
				answer=left;
				}
			break;
	  }

  return answer;
	}


/*
  ------------------
*/
signed char rop(MINIBASIC *mInstance,signed char op, NUM_TYPE left, NUM_TYPE right) {
	signed char answer;

	switch(op) {
		case ROP_EQ:
			answer = (left == right) ? -1 : 0;
			break;
		case ROP_NEQ:
			answer = (left != right) ? -1 : 0;
			break;
		case ROP_LT:
			answer = (left < right) ? -1 : 0;
			break;
		case ROP_LTE:
			answer = (left <= right) ? -1 : 0;
			break;
		case ROP_GT:
			answer = (left > right) ? -1 : 0;
			break;
		case ROP_GTE:
			answer = (left >= right) ? -1 : 0;
			break;
		default:
		  mInstance->errorFlag = 1;
		  return 0;
		}

	return answer;
	}



/*
  ------------------
*/
signed char strRop(MINIBASIC *mInstance,signed char op, const char *left, const char *right) {
	signed char answer;

	answer = strcmp(left, right);
	switch(op) {
		case ROP_EQ:
			answer = answer == 0 ? -1 : 0;
			break;
		case ROP_NEQ:
			answer = answer == 0 ? 0 : -1;
			break;
		case ROP_LT:
			answer = answer < 0 ? -1 : 0;
			break;
		case ROP_LTE:
			answer = answer <= 0 ? -1 : 0;
			break;
		case ROP_GT:
			answer = answer > 0 ? -1 : 0;
			break;
		case ROP_GTE:
			answer = answer >= 0 ? -1 : 0;
			break;
		default:
			answer = 0;
			break;
		}

	return answer;
	}


/*
  ------------------
*/
signed char iRop(MINIBASIC *mInstance,signed char op, int left, int right) {
	char answer;

	switch(op) {
		case ROP_EQ:
			answer = (left == right) ? -1 : 0;
			break;
		case ROP_NEQ:
			answer = (left != right) ? -1 : 0;
			break;
		case ROP_LT:
			answer = (left < right) ? -1 : 0;
			break;
		case ROP_LTE:
			answer = (left <= right) ? -1 : 0;
			break;
		case ROP_GT:
			answer = (left > right) ? -1 : 0;
			break;
		case ROP_GTE:
			answer = (left >= right) ? -1 : 0;
			break;
		default:
		  mInstance->errorFlag = 1;
		  return 0;
		}

	return answer;
	}



/*
  get a relational operator
  returns operator parsed or ERROR
*/
signed char relOp(MINIBASIC *mInstance) {

  switch(mInstance->token) {
    case EQUALS:
		  match(mInstance,EQUALS);
			return ROP_EQ;
			break;
    case GREATER:
			match(mInstance,GREATER);
			if(mInstance->token == EQUALS) {
        match(mInstance,EQUALS);
				return ROP_GTE;
				}
			return ROP_GT; 
			break;
		case LESS:
      match(mInstance,LESS);
			if(mInstance->token == EQUALS) {
				match(mInstance,EQUALS);
				return ROP_LTE;
				}
			else if(mInstance->token == GREATER) {
				match(mInstance,GREATER);
				return ROP_NEQ;
				}
			return ROP_LT;
			break;
		default:
			setError(mInstance,ERR_SYNTAX);
			return B_ERROR;
			break;
		}
	}



/*
  parses an expression
*/
NUM_TYPE expr(MINIBASIC *mInstance) {
  NUM_TYPE left;
  NUM_TYPE right;
  uint8_t op;

	mInstance->lastExprType=0;
	
  left = term(mInstance);

  while(1) {
	
    switch(mInstance->token)	{
			case PLUS:
				match(mInstance,PLUS);
				right = term(mInstance);
				left += right;
				break;
			case MINUS:
				match(mInstance,MINUS);
				right = term(mInstance);
				left -= right;
				break;
			default:
				op=relOp(mInstance);			//Find relationship operator  eg = > < >= <=
        if(mInstance->errorFlag==ERR_SYNTAX || mInstance->errorFlag==ERR_NOSUCHVARIABLE)    // bah..
          mInstance->errorFlag=0;
#warning TOGLIERE?? se no sparisce errore...
				if(op != B_ERROR) {		//If operator found OK
          if(mInstance->errorFlag==ERR_SYNTAX || mInstance->errorFlag==ERR_NOSUCHVARIABLE)    // bah..
    				mInstance->errorFlag=0;
					match(mInstance,op);			//Check Operator
					right = term(mInstance);		//Get Value Data
					left= rop(mInstance,op,left,right);
					}
				else {
					return left;
					}
				break;
			}
		}
	}


/*
  parses a term 
*/
NUM_TYPE term(MINIBASIC *mInstance) {
  NUM_TYPE left;
  NUM_TYPE right;

  left = factor(mInstance);
  
  while(1) {
    switch(mInstance->token) {
			case MULT:
				match(mInstance,MULT);
				right = factor(mInstance);
				left *= right;
				break;
			case DIV:
				match(mInstance,DIV);
				right = factor(mInstance);
				if(right != 0.0)
					left /= right;
				else
					setError(mInstance,ERR_DIVIDEBYZERO);
				break;
			case MOD:
				match(mInstance,MOD);
				right = factor(mInstance);
				left = fmod(left, right);
				break;
			case OR:
				match(mInstance,OR);
				right = factor(mInstance);
				left = (NUM_TYPE) (((unsigned int)left) | ((unsigned int)right));
				break;
			case AND:
				match(mInstance,AND);
				right = factor(mInstance);
				left = (NUM_TYPE) (((unsigned int)left) & ((unsigned int)right));
				break;
			case XOR:
				match(mInstance,XOR);
				right = factor(mInstance);
				left = (NUM_TYPE) (((unsigned int)left) ^ ((unsigned int)right));
				break;
			case BITNOT:
				match(mInstance,BITNOT);
				right = factor(mInstance);
				left = (NUM_TYPE) ~ ((unsigned int)right);
        //PROVARE!!
				break;
			default:
				return left;
			}
	  }

	}


/*
  parses a factor
*/
NUM_TYPE factor(MINIBASIC *mInstance) {
	NUM_TYPE answer=0;
  char *str;
  char *end;		// NO const
	int t,t1;
  IDENT_LEN len;

  switch(mInstance->token) {
    case OPAREN:
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			break;
		case VALUE:
			answer = getValue(mInstance->string, &len);
			match(mInstance,VALUE);
			break;
		case NOT:
			match(mInstance,NOT);
			answer = (NUM_TYPE) (~( integer(mInstance, factor(mInstance))));
			break;
		case MINUS:
			match(mInstance,MINUS);
			answer = -factor(mInstance);
			break;
		case FLTID:
  		mInstance->lastExprType=FLTID;
			answer = variable(mInstance);
			break;
		case INTID:
			if(!mInstance->lastExprType)
				mInstance->lastExprType=INTID;
			answer = ivariable(mInstance);
			break;
		case DIMFLTID:
			answer = dimVariable(mInstance);
			break;
		case DIMINTID:
			answer = dimivariable(mInstance);
			break;
		case E:
			answer = exp(1.0);
			match(mInstance,E);
			break;
		case PI:
			answer = acos(0.0) * 2.0;
			match(mInstance,PI);
			break;
		case AMPERSAND:   // solo &""... provare, e/o fare &H 
			match(mInstance,AMPERSAND);
			str = stringExpr(mInstance);
			if(str) {
  			answer = myhextoi(str);
				free(str);
	  		}
			else
				answer = 0;
			break;
		case SIN:
			match(mInstance,SIN);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = sin(answer);
			break;
		case COS:
			match(mInstance,COS);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = cos(answer);
			break;
		case TAN:
			match(mInstance,TAN);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = tan(answer);
			break;
		case LOG:
			match(mInstance,LOG);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			if(answer > 0)
				answer = log(answer);
			else
				setError(mInstance,ERR_NEGLOG);
			break;
		case EXP:
			match(mInstance,EXP);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = exp(answer);
			break;
		case POW:
			match(mInstance,POW);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,COMMA);
			answer = pow(answer, expr(mInstance));
			match(mInstance,CPAREN);
			break;
		case SQR:
			match(mInstance,SQR);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			if(answer >= 0.0)
				answer = sqrt(answer);
			else
				setError(mInstance,ERR_NEGSQRT);
			break;
    case IIF:
		  match(mInstance,IIF);
		  match(mInstance,OPAREN);
			if(boolExpr(mInstance)) {
			  match(mInstance,COMMA);
				answer = expr(mInstance);
			  match(mInstance,COMMA);
				expr(mInstance);
				}
			else {
			  match(mInstance,COMMA);
				expr(mInstance);
			  match(mInstance,COMMA);
				answer = expr(mInstance);
				}
		  match(mInstance,CPAREN);
			break;
		case ABS:
			match(mInstance,ABS);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = fabs(answer);
			break;
		case MIN:
			{
			NUM_TYPE answer2;
			match(mInstance,MIN);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,COMMA);
			answer2 = expr(mInstance);
			match(mInstance,CPAREN);
			answer = answer < answer2 ? answer : answer2;
			}
			break;
		case MAX:
			{
			NUM_TYPE answer2;
			match(mInstance,MAX);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,COMMA);
			answer2 = expr(mInstance);
			match(mInstance,CPAREN);
			answer = answer > answer2 ? answer : answer2;
			}
			break;

		case PEEK:
			match(mInstance,PEEK);
			match(mInstance,OPAREN);
      t = integer(mInstance, expr(mInstance));
			answer = (NUM_TYPE) (*((unsigned char *)t));
      // si schianta sempre! ? 26/6/22
			match(mInstance,CPAREN);
			break;
    case USR:
		  match(mInstance,USR);
		  match(mInstance,OPAREN);
		  t = integer(mInstance, expr(mInstance));
		  match(mInstance,CPAREN);
			{	// asm ...
//  _jr_hb();
//  __asm__("j": "=c" (t));   // VERIFICARE!
			}
			break;

		case TIMER:
			match(mInstance,TIMER);
			match(mInstance,OPAREN);
		  t = integer(mInstance, expr(mInstance));
			switch(t) {
				case 1:
					answer = (NUM_TYPE)TMR1;
					break;
				case 2:
					answer = (NUM_TYPE)TMR2;    // occhio usb!
					break;
				case 3:
					answer = (NUM_TYPE)TMR3;
					break;
				case 4:
					answer = (NUM_TYPE)TMR4;
					break;
				case 5:
					answer = (NUM_TYPE)TMR5;
					break;
				default:
					setError(mInstance,ERR_BADVALUE);
					break;
				}
			match(mInstance,CPAREN);
			break;
      
		case JOYSTICK:
			match(mInstance,JOYSTICK);
			match(mInstance,OPAREN);
		  t = integer(mInstance, expr(mInstance));
      answer = ReadJoystick(t);
			match(mInstance,CPAREN);
			break;
      
		case ERR:
			match(mInstance,ERR);
			match(mInstance,OPAREN);
		  t = integer(mInstance, expr(mInstance));
			match(mInstance,CPAREN);
			answer = t ? mInstance->errorHandler.errorline : mInstance->errorHandler.errorcode;
			break;
		case STATUSTOK:
			{
			char c;
			match(mInstance,STATUSTOK);
			match(mInstance,OPAREN);
		  t = integer(mInstance, expr(mInstance));
			match(mInstance,CPAREN);
			switch(t) {
				case 0:		// Reset
//					answer = RCON;
					answer = RCON;    // bah :)
          RCON=0;
					break;
				case 1:		// Wakeup
					answer = (RCONbits.SLEEP ? 1 : 0) | (RCONbits.WDTO ? 2 : 0);
					break;
				case 2:
					answer = c;
					break;
				case 3:
					c=U1RXREG;
					answer = c;
					break;
				case 4:
					c=U2RXREG;
					answer = c;
					break;
          
        case 16:
          answer = FSerror();
					break;
#if defined(USA_USB_HOST_MSD)
        case 17:
          answer = SYS_FS_Error();
					break;
#endif
				}
			}
			break;
		case LEN:
			match(mInstance,LEN);
			match(mInstance,OPAREN);
			str = stringExpr(mInstance);
			match(mInstance,CPAREN);
			if(str) {
				answer = strlen(str);
				free(str);
	  		}
			else
				answer = 0;
			break;
    case ASC:
			match(mInstance,ASC);
			match(mInstance,OPAREN);
			str = stringExpr(mInstance);
			match(mInstance,CPAREN);
			if(str) {
				answer = *str;
				free(str);
				}
			else
				answer = 0;
			break;
    case ASIN:
			match(mInstance,ASIN);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			if(answer >= -1 && answer <= 1)
				answer = asin(answer);
			else
				setError(mInstance,ERR_BADSINCOS);
			break;
    case ACOS:
			match(mInstance,ACOS);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			if(answer >= -1 && answer <= 1)
				answer = acos(answer);
			else
				setError(mInstance,ERR_BADSINCOS);
			break;
    case ATAN:
			match(mInstance,ATAN);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = atan(answer);
			break;
    case INTTOK:
			match(mInstance,INTTOK);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			answer = floor(answer);
			break;
    case RND:
			match(mInstance,RND);
			match(mInstance,OPAREN);
			answer = expr(mInstance);
			match(mInstance,CPAREN);
			t = integer(mInstance,answer);
			if(t > 1) {
				double d;
				d=rand() * answer;
				answer = floor(d/(RAND_MAX + 1.0));
				}
			else if(t == 1)
				answer = rand()/(RAND_MAX + 1.0);
			else {
				if(answer < 0)
		  		srand( (unsigned) -answer);
				answer = 0;
	  		}
			break;
    case VAL:
		  match(mInstance,VAL);
		  match(mInstance,OPAREN);
		  str = stringExpr(mInstance);
		  match(mInstance,CPAREN);
	  	if(str) {
	    	answer = strtod(str , NULL);
				free(str);
	  		}
	  	else
				answer = 0;
			break;
		case VALLEN:
			match(mInstance,VALLEN);
			match(mInstance,OPAREN);
			str = stringExpr(mInstance);
			match(mInstance,CPAREN);
			if(str) {
				strtod(str, &end);		// works all the same even if end is ROM - only len is needed!
				answer = end - str;
				free(str);
				}
			else
				answer = 0.0;
			break;
    case MEM:
		  match(mInstance,MEM);
		  match(mInstance,OPAREN);
		  t = integer(mInstance, expr(mInstance));
		  match(mInstance,CPAREN);
	  	if(t<0) {
	    	// fare garbage collection?
        t=-t;
	  		}
  
      switch(t) {
        case 0:
          return ((unsigned int)&t) - ((unsigned int)&_splim);
          // _dump_heap_info per info su memoria dinamica...
          //heap_free() in heap_info.c, provare
//          return heap_free();
          break;
        case 1:
          return extRAMtot;
          break;
        case 2:
    // v. bitlash...            return ((char *)&vstack[vsptr])-stringPool;    // spazio dal fondo di stack (che scende da top) e stringpool (che sale da sotto)
//          break;
        case 3:
    // eeprom..      return E2END*2;
          break;
        case 4:
          goto fai_diskspace;
          break;
        default:
  		    setError(mInstance,ERR_BADVALUE);
          break;
        }
			break;
		case INSTR:
	  	answer = instr(mInstance);
	  	break;
		case PENX:
			match(mInstance,PENX);
//			match(mInstance,OPAREN);
//			match(mInstance,CPAREN);
//    	outd(1,0,1);
//#warning FINIRE TOUCH RESISTIVO che per� passa a windows :)
//      __delay_ms(50);
//			answer = inadc(0);
      {
      POINT pt;
#ifdef USA_BREAKTHROUGH
      GetCursorPos(&pt);
#else
#endif
      answer=pt.x;
      }
		  break;
		case PENY:
			match(mInstance,PENY);
//			match(mInstance,OPAREN);
//			match(mInstance,CPAREN);
//    	outd(1,1,1);
//      __delay_ms(50);
//			answer = inadc(1);
      {
      POINT pt;
#ifdef USA_BREAKTHROUGH
      GetCursorPos(&pt);
#else
#endif
      answer=pt.y;
      }
		  break;
		case CURSORX:
			match(mInstance,CURSORX);
#ifdef USA_BREAKTHROUGH
      answer=mInstance->hWnd->caret   fare;
#else
      answer=mInstance->Cursor.x;
#endif
		  break;
		case CURSORY:
			match(mInstance,CURSORY);
#ifdef USA_BREAKTHROUGH
      answer=mInstance->hWnd->caret   fare;
#else
      answer=mInstance->Cursor.y;
#endif
		  break;
		case SCREENX:
			match(mInstance,SCREENX);
#ifdef USA_BREAKTHROUGH
      answer=mInstance->hWnd->clientArea.right-mInstance->hWnd->clientArea.left;
#else
      answer=Screen.cx;
#endif
		  break;
		case SCREENY:
			match(mInstance,SCREENY);
#ifdef USA_BREAKTHROUGH
      answer=mInstance->hWnd->clientArea.bottom-mInstance->hWnd->clientArea.top;
#else
      answer=Screen.cy;
#endif
		  break;
		case DISKSPACE:
			match(mInstance,DISKSPACE);
			{
		  FS_DISK_PROPERTIES disk_properties;
fai_diskspace:
			disk_properties.new_request=1;
			do {
				FSGetDiskProperties(&disk_properties);
				ClrWdt();
				} while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
			if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS)
				answer=disk_properties.results.free_clusters*disk_properties.results.sectors_per_cluster*disk_properties.results.sector_size/1024; 
			else
				answer=0;
			}
		  break;
		case EEPEEK:
			match(mInstance,EEPEEK);
			match(mInstance,OPAREN);
			t = integer(mInstance, expr(mInstance));
			match(mInstance,CPAREN);
      return EEread(t);
      break;
		case IND:
			match(mInstance,IND);
			match(mInstance,OPAREN);
			t = integer(mInstance, expr(mInstance));
			match(mInstance,COMMA);
			t1 = integer(mInstance, expr(mInstance));
			match(mInstance,CPAREN);
			answer = ind(t,t1);
			break;
		case INADC:
			match(mInstance,INADC);
			match(mInstance,OPAREN);
			t = integer(mInstance, expr(mInstance));
			match(mInstance,CPAREN);
			answer = inadc(t);
			break;
		case TEMPERATURE:
			match(mInstance,TEMPERATURE);
			answer = ReadTemperature();
      break;
		case RSSI:
			match(mInstance,RSSI);
#ifdef USA_WIFI
      m2m_wifi_req_curr_rssi();
      answer=myRSSI;
#endif
      break;
		case BIOS:
    {
      int t2;
      BYTE buf[16];
      
			match(mInstance,BIOS);
			match(mInstance,OPAREN);
			t = integer(mInstance, expr(mInstance));
			match(mInstance,COMMA);
			t1 = integer(mInstance, expr(mInstance));
			match(mInstance,COMMA);
			t2 = integer(mInstance, expr(mInstance));
			match(mInstance,CPAREN);
      if(t>0 && t<=SOUTH_BRIDGE && /*t1 controllare? && */ t2<15) {
        ReadPMPs(t,t1,buf,t2+1);
        answer = buf[t2];
        }
      else {
    		setError(mInstance, ERR_BADVALUE);
        }
    }
      break;
		default:
		  if(isString(mInstance->token))
				setError(mInstance,ERR_TYPEMISMATCH);
		  else
		    setError(mInstance,ERR_SYNTAX);
	  	break;
  	}

  while(mInstance->token == SHRIEK) {
    match(mInstance,SHRIEK);
		answer = factorial(answer);
  	}

  return answer;
	}



/*
  calcualte the INSTR() function.
*/
NUM_TYPE instr(MINIBASIC *mInstance) {
  char *str;
  char *substr;
  char *end;
  int answer = 0;
  int offset;

  match(mInstance,INSTR);
  match(mInstance,OPAREN);
  str = stringExpr(mInstance);
  match(mInstance,COMMA);
  substr = stringExpr(mInstance);
  match(mInstance,COMMA);
  offset = integer(mInstance,expr(mInstance));
  offset--;
  match(mInstance,CPAREN);

  if(!str || !substr) {
    if(str)
			free(str);
		if(substr)
		  free(substr);
		return 0;
	  }

  if(offset >= 0 && offset < (int) strlen(str)) {
    end = strstr(str + offset, substr);
    if(end)
			answer = end - str + 1;
		}

  free(str);
  free(substr);

  return (NUM_TYPE)answer;
	}



/*
  get the value of a scalar variable from string
  matches FLTID
*/
NUM_TYPE variable(MINIBASIC *mInstance) {
  VARIABLE *var;
  char id[IDLENGTH];
  IDENT_LEN len;

  getId(mInstance,mInstance->string, id, &len);
  match(mInstance,FLTID);
  var = findVariable(mInstance,id);
  if(var)
    return var->d.dval;
  else {
		setError(mInstance,ERR_NOSUCHVARIABLE);
		return 0.0;
	  }
	}


/*
  get the value of a scalar variable from string
  matches INTID
*/
int ivariable(MINIBASIC *mInstance) {
  VARIABLE *var;
  char id[IDLENGTH];
  IDENT_LEN len;

  getId(mInstance,mInstance->string, id, &len);
  match(mInstance,INTID);
  var = findVariable(mInstance,id);
  if(var)
    return var->d.ival;
  else {
		setError(mInstance,ERR_NOSUCHVARIABLE);
		return 0;
	  }
	}


/*
  get value of a dimensioned variable from string.
  matches DIMFLTID
*/
NUM_TYPE dimVariable(MINIBASIC *mInstance) {
  DIMVAR *dimvar;
  char id[IDLENGTH];
  IDENT_LEN len;
  DIM_SIZE index[MAXDIMS];
  NUM_TYPE *answer;

  getId(mInstance,mInstance->string, id, &len);
  match(mInstance,DIMFLTID);
  dimvar = findDimVar(mInstance,id);
  if(!dimvar) {
    setError(mInstance,ERR_NOSUCHVARIABLE);
		return 0.0;
  	}

  if(dimvar) {
    switch(dimvar->ndims) {
		  case 1:
		    index[0] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0]);
				break;
      case 2:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1]);
				break;
		  case 3:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[2] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1], index[2]);
				break;
		  case 4:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[2] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[3] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1], index[2], index[3]);
				break;
		  case 5:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[2] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[3] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[4] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1], index[2], index[3], index[4]);
				break;
			}

		match(mInstance,CPAREN);
  	}

  if(answer)
		return *answer;

  return 0.0;

	}

int dimivariable(MINIBASIC *mInstance) {
//fare??
	}


/*
  find a scalar variable in variables list
  Params: id - id to get
  Returns: pointer to that entry, 0 on fail
*/
VARIABLE *findVariable(MINIBASIC *mInstance,const char *id) {
  int i;

  for(i=0; i<mInstance->nvariables; i++)
		if(!strcmp(mInstance->variables[i].id, id))
			return &mInstance->variables[i];
  return NULL;
	}


/*
  get a dimensioned array by name
  Params: id (includes opening parenthesis)
  Returns: pointer to array entry or 0 on fail
*/
DIMVAR *findDimVar(MINIBASIC *mInstance,const char *id) {
  int i;

  for(i=0; i<mInstance->ndimVariables; i++)
		if(!strcmp(mInstance->dimVariables[i].id, id))
			return &mInstance->dimVariables[i];
  return 0;
	}


/*
  dimension an array.
  Params: id - the id of the array (include leading ()
          ndims - number of dimension (1-5)
		  ... - integers giving dimension size, 
*/
DIMVAR *dimension(MINIBASIC *mInstance,const char *id, int ndims, ...) {
  DIMVAR *dv;
  va_list vargs;
  int size = 1;
  int oldsize = 1;
  unsigned char i;
  DIM_SIZE dimensions[MAXDIMS];
  NUM_TYPE *dtemp;
  char **stemp;
  int *itemp;

  basicAssert(ndims <= MAXDIMS);
  if(ndims > MAXDIMS)
		return 0;

  dv = findDimVar(mInstance,id);
  if(!dv)
		dv = adddimvar(mInstance,id);
  if(!dv) {
    setError(mInstance,ERR_OUTOFMEMORY);
		return 0;
  	}

  if(dv->ndims) {
    for(i=0; i<dv->ndims; i++)
			oldsize *= dv->dim[i];
  	}
  else
		oldsize = 0;

  va_start(vargs, ndims);
  for(i=0; i<ndims; i++) {
		dimensions[i] = va_arg(vargs, int);
    size *= dimensions[i];
  	}
  va_end(vargs);

  switch(dv->type) {
    case FLTID:
      dtemp = (double *)realloc(dv->d.dval, size * sizeof(double));
      if(dtemp)
        dv->d.dval = dtemp;
			else {
				setError(mInstance,ERR_OUTOFMEMORY);
				return 0;
	  		}
			break;
		case STRID:
			if(dv->d.str) {
				for(i=size; i<oldsize; i++)
					if(dv->d.str[i]) {
						free(dv->d.str[i]);
						dv->d.str[i] = 0;
			  		}
		  	}
			stemp = (char **)realloc(dv->d.str, size * sizeof(char *));
			if(stemp) {
				dv->d.str = stemp;
				for(i=oldsize; i<size; i++)
		  		dv->d.str[i] = 0;
	  		}
			else {
				for(i=0; i<oldsize; i++)
		  		if(dv->d.str[i]) {
						free(dv->d.str[i]);
		    		dv->d.str[i] = 0;
		  			}
				setError(mInstance,ERR_OUTOFMEMORY);
				return 0;
	  		}
			break;
    case INTID:
      itemp = (int *)realloc(dv->d.ival, size * sizeof(int));
      if(itemp)
        dv->d.ival = itemp;
			else {
				setError(mInstance,ERR_OUTOFMEMORY);
				return 0;
	  		}
			break;
		default:
			basicAssert(0);
			break;
		}

  for(i=0; i<MAXDIMS; i++)
		dv->dim[i] = dimensions[i];
  dv->ndims = ndims;

  return dv;
	}


/*
  get the address of a dimensioned array element.
  works for both string and real arrays.
  Params: dv - the array's entry in variable list
          ... - integers telling which array element to get
  Returns: the address of that element, 0 on fail
*/ 
void *getDimVar(MINIBASIC *mInstance,DIMVAR *dv, ...) {
  va_list vargs;
  DIM_SIZE index[MAXDIMS];
  int i;
  void *answer = 0;

  va_start(vargs, dv);
  for(i=0; i<dv->ndims; i++) {
		index[i] = va_arg(vargs, int);
    index[i]--;
		}
  va_end(vargs);

  for(i=0; i<dv->ndims; i++)
    if(index[i] >= dv->dim[i] || index[i] < 0) {
			setError(mInstance,ERR_BADSUBSCRIPT);
			return 0;
		}

  if(dv->type == FLTID) {
    switch(dv->ndims) {
      case 1:
	  		answer = &dv->d.dval[ index[0] ]; 
				break;
      case 2:
				answer = &dv->d.dval[ index[1] * dv->dim[0] 
					+ index[0] ];
				break;
      case 3:
				answer = &dv->d.dval[ index[2] * (dv->dim[0] * dv->dim[1]) 
				+ index[1] * dv->dim[0] 
				+ index[0] ];
		    break;
      case 4:
				answer = &dv->d.dval[ index[3] * (dv->dim[0] + dv->dim[1] + dv->dim[2]) 
					+ index[2] * (dv->dim[0] * dv->dim[1]) 
					+ index[1] * dv->dim[0] 
					+ index[0] ];
				// MANCA BREAK???
      case 5:
				answer = &dv->d.dval[ index[4] * (dv->dim[0] + dv->dim[1] + dv->dim[2] + dv->dim[3])
					+ index[3] * (dv->dim[0] + dv->dim[1] + dv->dim[2])
					+ index[2] * (dv->dim[0] + dv->dim[1])
					+ index[1] * dv->dim[0]
					+ index[0] ];
				break;
			}
		}
  else if(dv->type == STRID) {
		switch(dv->ndims)	{
      case 1:
	  		answer = &dv->d.str[ index[0] ]; 
				break;
      case 2:
				answer = &dv->d.str[ index[1] * dv->dim[0] 
					+ index[0] ];
				break;
      case 3:
				answer = &dv->d.str[ index[2] * (dv->dim[0] * dv->dim[1]) 
				+ index[1] * dv->dim[0] 
				+ index[0] ];
				break;
      case 4:
				answer = &dv->d.str[ index[3] * (dv->dim[0] + dv->dim[1] + dv->dim[2]) 
					+ index[2] * (dv->dim[0] * dv->dim[1]) 
					+ index[1] * dv->dim[0] 
					+ index[0] ];
				// MANCA BREAK???
      case 5:
				answer = &dv->d.str[ index[4] * (dv->dim[0] + dv->dim[1] + dv->dim[2] + dv->dim[3])
					+ index[3] * (dv->dim[0] + dv->dim[1] + dv->dim[2])
					+ index[2] * (dv->dim[0] + dv->dim[1])
					+ index[1] * dv->dim[0]
					+ index[0] ];
				break;
			}
		}
  else if(dv->type == INTID) {
    switch(dv->ndims) {
      case 1:
	  		answer = &dv->d.ival[ index[0] ]; 
				break;
      case 2:
				answer = &dv->d.ival[ index[1] * dv->dim[0] 
					+ index[0] ];
				break;
      case 3:
				answer = &dv->d.ival[ index[2] * (dv->dim[0] * dv->dim[1]) 
				+ index[1] * dv->dim[0] 
				+ index[0] ];
		    break;
      case 4:
				answer = &dv->d.ival[ index[3] * (dv->dim[0] + dv->dim[1] + dv->dim[2]) 
					+ index[2] * (dv->dim[0] * dv->dim[1]) 
					+ index[1] * dv->dim[0] 
					+ index[0] ];
				// MANCA BREAK???
      case 5:
				answer = &dv->d.ival[ index[4] * (dv->dim[0] + dv->dim[1] + dv->dim[2] + dv->dim[3])
					+ index[3] * (dv->dim[0] + dv->dim[1] + dv->dim[2])
					+ index[2] * (dv->dim[0] + dv->dim[1])
					+ index[1] * dv->dim[0]
					+ index[0] ];
				break;
		}
		}

  return answer;
	}



/*
  ------------------
*/
VARIABLE *addNewVar(MINIBASIC *mInstance,const char *id, char type) {
  VARIABLE *vars;

  vars = (VARIABLE *)realloc(mInstance->variables, (mInstance->nvariables + 1) * sizeof(VARIABLE));
  if(vars) {
		mInstance->variables = vars;
    strncpy(mInstance->variables[mInstance->nvariables].id, id, IDLENGTH-1);
		mInstance->variables[mInstance->nvariables].d.dval = 0;		// clears all
		mInstance->variables[mInstance->nvariables].type = type;
		mInstance->nvariables++;
		return &mInstance->variables[mInstance->nvariables-1];
	  }
  else {
		setError(mInstance,ERR_OUTOFMEMORY);
		return 0;
		}
	}



/*
  add a real variable to our variable list
  Params: id - id of variable to add.
  Returns: pointer to new entry in table
*/
VARIABLE *addFloat(MINIBASIC *mInstance,const char *id) {
  VARIABLE *v = addNewVar(mInstance,id,FLTID);

  return v; 
	}



/*
  add a string variable to table.
  Params: id - id of variable to get (including trailing $)
  Retruns: pointer to new entry in table, 0 on fail.       
*/
VARIABLE *addString(MINIBASIC *mInstance,const char *id) {
  VARIABLE *v = addNewVar(mInstance,id,STRID);

  return v; 
	}


/*
  add a integer variable to our variable list
  Params: id - id of variable to add.
  Returns: pointer to new entry in table
*/
VARIABLE *addInt(MINIBASIC *mInstance,const char *id) {
  VARIABLE *v = addNewVar(mInstance,id,INTID);

  return v;
	}




/*
  add a new array to our symbol table.
  Params: id - id of array (include leading ()
  Returns: pointer to new entry, 0 on fail.
*/
DIMVAR *adddimvar(MINIBASIC *mInstance,const char *id) {
  DIMVAR *vars;

  vars = (DIMVAR *)realloc(mInstance->dimVariables, (mInstance->ndimVariables + 1) * sizeof(DIMVAR));
  if(vars) {
    mInstance->dimVariables = vars;
		strcpy(mInstance->dimVariables[mInstance->ndimVariables].id, id);
		mInstance->dimVariables[mInstance->ndimVariables].d.dval = 0;
		mInstance->dimVariables[mInstance->ndimVariables].ndims = 0;
		mInstance->dimVariables[mInstance->ndimVariables].type = strchr(id, '$') ? STRID : (strchr(id, '%') ? INTID : FLTID);
		mInstance->ndimVariables++;
		return &mInstance->dimVariables[mInstance->ndimVariables-1];
	  }
  else
		setError(mInstance,ERR_OUTOFMEMORY);
 
  return 0;
	}


/*
  high level string parsing function.
  Returns: a malloced pointer, or 0 on error condition.
  caller must free!
*/
char *stringExpr(MINIBASIC *mInstance) {
  char *left;
  char *right;
  char *temp;

  switch(mInstance->token) {
    case DIMSTRID:
			left = strdup(stringDimVar(mInstance));
			break;
    case STRID:
      left = strdup(stringVar(mInstance));
		  break;
		case QUOTE:
			left = stringLiteral(mInstance);
			break;
		case CHRSTRING:
			left = chrString(mInstance);
			break;
		case STRSTRING:
			left = strString(mInstance);
			break;
		case LEFTSTRING:
			left = leftString(mInstance);
			break;
		case RIGHTSTRING:
			left = rightString(mInstance);
			break;
		case MIDSTRING:
			left = midString(mInstance);
			break;
		case INKEYSTRING:
			left = inkeyString(mInstance);
			break;
		case MIDISTRING:
			left = midiString(mInstance);
			break;
#ifdef USA_BREAKTHROUGH
		case MENUKEYSTRING:
			left = menukeyString(mInstance);
			break;
#endif
		case ERRORSTRING:
			left = errorString(mInstance);
			break;
    case VERSTRING:
			left = verString(mInstance);
	  	break;
		case STRINGSTRING:
			left = stringString(mInstance);
			break;
		case HEXSTRING:
			left = hexString(mInstance);
			break;
		case TRIMSTRING:
			left = trimString(mInstance);
			break;
		case TIMESTRING:
			left = timeString(mInstance);
			break;
    case DIRSTRING:   // v. anche doDir
      left = dirString(mInstance);
      break;
    case CURDIRSTRING: 
      left = curdirString(mInstance);
      break;
    case IPADDRESSSTRING:
      left = ipaddressString(mInstance);
      break;
    case ACCESSPOINTSSTRING: 
      left = accesspointsString(mInstance);
      break;
		default:
			if(!isString(mInstance->token))
				setError(mInstance,ERR_TYPEMISMATCH);
			else
				setError(mInstance,ERR_SYNTAX);
			return strdup(EmptyString);
			break;
	  }

  if(!left) {
    setError(mInstance,ERR_OUTOFMEMORY);
    return 0;
		}

  switch(mInstance->token) {
    case PLUS:
			match(mInstance,PLUS);
			right = stringExpr(mInstance);
			if(right) {
				temp = myStrConcat(left, right);
				free(right);
				if(temp) {
		  		free(left);
					left = temp;
					}
				else
		  		setError(mInstance,ERR_OUTOFMEMORY);
	  		}
			else
				setError(mInstance,ERR_OUTOFMEMORY);
			break;
		default:
			return left;
			break;
	  }

  return left;
	}



/*
  parse the CHR$ token
*/
char *chrString(MINIBASIC *mInstance) {
  char x;
  char buff[2];
  char *answer;

  match(mInstance,CHRSTRING);
  match(mInstance,OPAREN);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,CPAREN);

  buff[0] = (char) x;
  buff[1] = 0;
  answer = strdup(buff);

  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}


/*
  parse the HEX$ token
*/
char *hexString(MINIBASIC *mInstance) {
  int x;
  char *answer;

  match(mInstance,HEXSTRING);
  match(mInstance,OPAREN);
  x = expr(mInstance);
  match(mInstance,CPAREN);

  answer = strdup(myitoahex((int)x));
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}


/*
  parse the token
*/
char *trimString(MINIBASIC *mInstance) {
  char *str,*str2,*str3;
  char *answer;

  match(mInstance,TRIMSTRING);
  match(mInstance,OPAREN);
  str = stringExpr(mInstance);
  if(!str)
		return 0;
  match(mInstance,CPAREN);

	str3=str;
  while(isspace(*str))
		str++;
	str2=str;
  while(*str)
		str++;
	str--;
  while(isspace(*str))
		str--;
  *(str+1) = 0;
  answer = strdup(str2);
  free(str3);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
	}

char *timeString(MINIBASIC *mInstance) {
  DWORD ti;
  char *answer,buf[32];
  PIC32_DATE date;
  PIC32_TIME time;

  match(mInstance,TIMESTRING);
  if(mInstance->token == OPAREN) {
    match(mInstance,OPAREN);
    ti = expr(mInstance);
    match(mInstance,CPAREN);
    }
  else {
    ti=now;
    }

  SetTimeFromNow(ti,&date,&time);
  sprintf(buf,"%02u/%02u/%04u %02u:%02u:%02u",
          date.mday,date.mon,date.year,
          time.hour,time.min,time.sec);
          
  answer = strdup(buf);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
	}


/*
  handle INKEY$ token, based on inkey() (numeric)
*/
char *inkeyString(MINIBASIC *mInstance) {
  char buf[2];
	int i;
  char *answer;

  match(mInstance,INKEYSTRING);
//  match(mInstance,OPAREN);
//  match(mInstance,CPAREN);

	i=mInstance->incomingChar[0];
	if(i>0) {
		buf[0]=i;
		buf[1]=0;
		}
	else
		buf[0]=0;
  answer = strdup(buf);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}

char *midiString(MINIBASIC *mInstance) {
  char buf[2];
	int i;
  char *answer;

  match(mInstance,MIDISTRING);
//  match(mInstance,OPAREN);
//  match(mInstance,CPAREN);

  buf[0] = ReadMidi(); //byteRecMidi
  buf[1]=0;
    
  answer = strdup(buf);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}

#ifdef USA_BREAKTHROUGH
char *menukeyString(MINIBASIC *mInstance) {
  char buf[2];
	int i;
  char *answer;

  match(mInstance,MENUKEYSTRING);
  match(mInstance,OPAREN);
  match(mInstance,CPAREN);

//	i=menucommand();
  //fare
		buf[0]=0;
    
  answer = strdup(buf);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}
#endif

/*
  handle ER$ token, based on inkey() (numeric) ??
*/
char *errorString(MINIBASIC *mInstance) {
  char *answer;
	BYTE x;

  match(mInstance,ERRORSTRING);
  match(mInstance,OPAREN);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,CPAREN);

	if(x >= sizeof(error_msgs)/sizeof(char *)) {
		setError(mInstance, ERR_BADVALUE);
		}
	
  answer = strdup((STRINGFARPTR)error_msgs[x]);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}

char *verString(MINIBASIC *mInstance) {
  char *answer;
  char buff[6];

  match(mInstance,VERSTRING);
  buff[0]=MINIBASIC_COPYRIGHT_STRING[23];
  buff[1]=MINIBASIC_COPYRIGHT_STRING[23+1];
  buff[2]=MINIBASIC_COPYRIGHT_STRING[23+2];
  buff[3]=MINIBASIC_COPYRIGHT_STRING[23+3];
  buff[4]=MINIBASIC_COPYRIGHT_STRING[23+4];
  buff[5] = 0;
  answer = strdup(buff);

  if(!answer)
    setError(mInstance,ERR_OUTOFMEMORY);

  return answer;
	}


/*
  parse the STR$ token
*/
char *strString(MINIBASIC *mInstance) {
  NUM_TYPE x;
  char buff[20];
  char *answer;

  match(mInstance,STRSTRING);
  match(mInstance,OPAREN);
  x = expr(mInstance);
  match(mInstance,CPAREN);

  //sprintf(buff, "%g", x);
	{
	long n;
	n=(long) fabs(((x - (long) x ) * 1000000));
//	sprintf(buff,(STRINGFARPTR)"%d.%06lu", (int) x, (int) fabs(((x - (int) x ) * 1000000))); 
	if(n) {		// un trucchetto per stampare interi o float
		unsigned char i;

		sprintf(buff,(STRINGFARPTR)"%ld.%06lu", (long) x, (long) n); 
		for(i=strlen(buff)-1; i; i--) {
			if(buff[i] == '0')
				buff[i]=0;
			else
				break;
			}
		}
	else
		sprintf(buff,(STRINGFARPTR)"%ld", (long) x); 
  answer = strdup(buff);
	}
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
	}


/*
  parse the LEFT$ token
*/
char *leftString(MINIBASIC *mInstance) {
  char *str;
  int x;
  char *answer;

  match(mInstance,LEFTSTRING);
  match(mInstance,OPAREN);
  str = stringExpr(mInstance);
  if(!str)
		return 0;
  match(mInstance,COMMA);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,CPAREN);

  if(x > (int) strlen(str))
		return str;
  if(x < 0) {
    setError(mInstance,ERR_ILLEGALOFFSET);
    return str;
  	}
  str[x] = 0;
  answer = strdup(str);
  free(str);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
	}


/*
  parse the RIGHT$ token
*/
char *rightString(MINIBASIC *mInstance) {
  int x;
  char *str;
  char *answer;

  match(mInstance,RIGHTSTRING);
  match(mInstance,OPAREN);
  str = stringExpr(mInstance);
  if(!str)
		return 0;
  match(mInstance,COMMA);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,CPAREN);

  if( x > (int) strlen(str))
		return str;

  if(x < 0) {
    setError(mInstance,ERR_ILLEGALOFFSET);
		return str;
  	}
  
  answer = strdup( &str[strlen(str) - x] );
  free(str);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
	}


/*
  parse the MID$ token
*/
char *midString(MINIBASIC *mInstance) {
  char *str;
  int x;
  int len;
  char *answer;
  char *temp;

  match(mInstance,MIDSTRING);
  match(mInstance,OPAREN);
  str = stringExpr(mInstance);
  match(mInstance,COMMA);
  x = integer(mInstance,expr(mInstance));
	if(mInstance->token==COMMA) {
		match(mInstance,COMMA);
		len = integer(mInstance,expr(mInstance));
		}
	else
		len=-1;
  match(mInstance,CPAREN);

  if(!str)
		return 0;

  if(len == -1)
		len = strlen(str) - x + 1;

  if( x > (int) strlen(str) || len < 1) {
		free(str);
		answer = strdup(EmptyString);
		if(!answer)
	  	setError(mInstance,ERR_OUTOFMEMORY);
    return answer;
  	}
  
  if(x < 1) {
    setError(mInstance,ERR_ILLEGALOFFSET);
		return str;
  	}

  temp = &str[x-1];

  answer = (char *)malloc(len + 1);
  if(!answer) {
    setError(mInstance,ERR_OUTOFMEMORY);
		return str;
  	}
  strncpy(answer, temp, len);
  answer[len] = 0;
  free(str);

  return answer;
	}


/*
  parse the string$ token
*/
char *stringString(MINIBASIC *mInstance) {
  int x;
  char *str;
  char *answer;
  int len;
  int N;
  int i;

  match(mInstance,STRINGSTRING);
  match(mInstance,OPAREN);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,COMMA);
  str = stringExpr(mInstance);
  match(mInstance,CPAREN);

  if(!str)
		return 0;

  N = x;

  if(N < 1) {
    free(str);
		answer = strdup(EmptyString);
		if(!answer)
	  	setError(mInstance,ERR_OUTOFMEMORY);
		return answer;
	  }

  len = strlen(str);
  answer = (char *)malloc( N * len + 1 );
  if(!answer) {
    free(str);
		setError(mInstance,ERR_OUTOFMEMORY);
		return 0;
  	}
  for(i=0; i < N; i++) {
    strcpy(answer + len * i, str);
  	}
  free(str);

  return answer;
	}


/*
  read a dimensioned string variable from input.
  Returns: pointer to string (not malloced) 
*/
char *stringDimVar(MINIBASIC *mInstance) {
  char id[IDLENGTH];
  IDENT_LEN len;
  DIMVAR *dimvar;
  char **answer;
  DIM_SIZE index[MAXDIMS];

  getId(mInstance,mInstance->string, id, &len);
  match(mInstance,DIMSTRID);
  dimvar = findDimVar(mInstance,id);

  if(dimvar) {
    switch(dimvar->ndims) {
	  	case 1:
	    	index[0] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0]);
				break;
      case 2:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1]);
				break;
		  case 3:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[2] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1], index[2]);
				break;
		  case 4:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[2] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[3] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1], index[2], index[3]);
				break;
		  case 5:
				index[0] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[1] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[2] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[3] = integer(mInstance,expr(mInstance));
				match(mInstance,COMMA);
				index[4] = integer(mInstance,expr(mInstance));
				answer = getDimVar(mInstance,dimvar, index[0], index[1], index[2], index[3], index[4]);
				break;
			}

		match(mInstance,CPAREN);
  	}
  else
		setError(mInstance,ERR_NOSUCHVARIABLE);

  if(!mInstance->errorFlag)
		if(*answer)
	     return *answer;
	 
  return (char *)EmptyString;
	}



/*
  parse a string variable.
  Returns: pointer to string (not malloced) 
*/
char *stringVar(MINIBASIC *mInstance) {
  char id[IDLENGTH];
  IDENT_LEN len;
  VARIABLE *var;

  getId(mInstance,mInstance->string, id, &len);
  match(mInstance,STRID);
  var = findVariable(mInstance,id);
  if(var) {
    if(var->d.sval)
	  	return var->d.sval;
		else
			return (char *)EmptyString;
  	}
  setError(mInstance,ERR_NOSUCHVARIABLE);
  return (char *)EmptyString;
	}


/* returns directory as a CSV list of files + free space*/
char *dirString(MINIBASIC *mInstance) {
  SearchRec rec;
  FS_DISK_PROPERTIES disk_properties;
  int i,totfiles; 
  char *str,*filter,*result;
  char buf[32];
  char *answer;

  match(mInstance,DIRSTRING);
  match(mInstance,OPAREN);
  str = stringExpr(mInstance);
  match(mInstance,CPAREN);

  WORD totFiles;

//      if(!SDcardOK) {
  filter=str;
  if(!*filter)
    filter="*.*";
#if defined(USA_USB_HOST_MSD)
      if(filter[1] == ':' && filter[0] == 'E') {
        i=USBFindFirst( filter, ATTR_MASK ^ ATTR_VOLUME, &rec);
//        printf("Directory of %s","E:\\");    // finire :)
        }
#endif
  i=FindFirst(filter, ATTR_MASK ^ ATTR_VOLUME, &rec);

  if(!i) {
    totfiles=0;
    result=malloc(50 +20 /*freespace*/);
    if(!result) {
      setError(mInstance,ERR_OUTOFMEMORY);
      goto fine;
      }
    *result=0;

    do {
      strcat(result,rec.filename); 
      strcat(result,"\t");
      if(rec.attributes & ATTR_DIRECTORY) {
        strcat(result,"DIR\t");
        }
      else {
        sprintf(buf,"%u\t",rec.filesize);
        strcat(result,buf);
        sprintf(buf,"%02u/%02u/%04u %02u:%02u:%02u\t",
          (rec.timestamp >> 16) & 31,
          (rec.timestamp >> (5+16)) & 15,
          (rec.timestamp >> (9+16)) + 1980,
          (rec.timestamp >> 11) & 31,
          (rec.timestamp >> 5) & 63,
          rec.timestamp & 63);
        strcat(result,buf);
        }

      totfiles++;
      result=realloc(result,50*(totfiles+1)+20);
      if(!result) {
        setError(mInstance,ERR_OUTOFMEMORY);
        goto fine;
        }

      } while(!FindNext(&rec));
    }
  else {
    free(result);
    setError(mInstance,ERR_FILE);
    goto fine;
    }

  disk_properties.new_request=1;
  do {
    FSGetDiskProperties(&disk_properties);
    ClrWdt();
    } while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
  if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS) {
    sprintf(buf,"%lu\r",disk_properties.results.free_clusters*disk_properties.results.sectors_per_cluster*disk_properties.results.sector_size/1024); 
    strcat(result,buf);
    }

  answer= strdup(result);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;

fine:
  free(str);
  return (char *)EmptyString;
  }

char *curdirString(MINIBASIC *mInstance) {
  char *answer;

  match(mInstance,CURDIRSTRING);

  answer= strdup(FSgetcwd(NULL,0));
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
  }

char *ipaddressString(MINIBASIC *mInstance) {
  char buf[32],*answer;
  int x=0;

  match(mInstance,IPADDRESSSTRING);
  match(mInstance,OPAREN);
  x = integer(mInstance,expr(mInstance));
  match(mInstance,CPAREN);

#if defined(USA_WIFI) && defined(USA_ETHERNET)
  if(x==0)
    sprintf(buf,"%u.%u.%u.%u",myIp.addr[0],myIp.addr[1],myIp.addr[2],myIp.addr[3]);
  else
    sprintf(buf,"%u.%u.%u.%u",BiosArea.MyIPAddr.v[0],BiosArea.MyIPAddr.v[1],BiosArea.MyIPAddr.v[2],BiosArea.MyIPAddr.v[3]);
#elif defined(USA_WIFI)
  sprintf(buf,"%u.%u.%u.%u",myIp.addr[0],myIp.addr[1],myIp.addr[2],myIp.addr[3]);
#elif defined(USA_ETHERNET)
  sprintf(buf,"%u.%u.%u.%u",BiosArea.MyIPAddr.v[0],BiosArea.MyIPAddr.v[1],BiosArea.MyIPAddr.v[2],BiosArea.MyIPAddr.v[3]);
#else
  sprintf(buf,"%u.%u.%u.%u",0,0,0,0);
#endif
  
  answer= strdup(buf);
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
  return answer;
  }

char *accesspointsString(MINIBASIC *mInstance) {
  char *answer;
  int n;
  WORD tOut=0;

  match(mInstance,ACCESSPOINTSSTRING);

  if(mInstance->token==INTID) {
  	n=integer(mInstance,expr(mInstance));
    }
  else
    n=M2M_WIFI_CH_ALL;
  
#ifdef USA_WIFI
  *(unsigned long*)internetBuffer=0;
  m2m_wifi_request_scan(n);    // serve callback...
	while(tOut<5000) {
    m2m_wifi_handle_events(NULL);
    tOut++;
    __delay_ms(1);
		}
  // opp. provare m2m_wifi_req_scan_result(uint8 index);
  // e v. anche m2m_wifi_get_num_ap_found(void)


  answer= strdup(internetBuffer);
  *internetBuffer=0;
  if(!answer)
		setError(mInstance,ERR_OUTOFMEMORY);
#else
  answer=(char*)EmptyString;
#endif
  return answer;
  }


/*
  parse a string literal
  Returns: malloced string literal
  Notes: newlines aren't allowed in literals, but blind concatenation across newlines is. 
*/
char *stringLiteral(MINIBASIC *mInstance) {
  int len = 1;
  char *answer = 0;
  char *temp;
  char *substr;
  char * end;

  while(mInstance->token == QUOTE) {
    mInstance->string=skipSpaces(mInstance->string);

    end = mystrend(mInstance->string, '"');
    if(end) {
      len = end - mInstance->string;
      substr = (char *)malloc(len);
	  	if(!substr) {
	    	setError(mInstance,ERR_OUTOFMEMORY);
	    	return answer;
	  		}
	  	mystrgrablit(substr, mInstance->string);
	  	if(answer) {
				temp = myStrConcat(answer, substr);
	    	free(substr);
				free(answer);
				answer = temp;
				if(!answer) {
	      	setError(mInstance,ERR_OUTOFMEMORY);
		  		return answer;
					}
	  		}
	  	else
	    	answer = substr;
		  mInstance->string = end;
			}
		else {
		  setError(mInstance,ERR_SYNTAX);
		  return answer;
			}

		match(mInstance,QUOTE);
  	}

  return answer;
	}


/*
  cast a double to an integer, triggering errors if out of range
*/
int integer(MINIBASIC *mInstance,double x) {

  if(isString(mInstance->token))
		setError(mInstance, ERR_TYPEMISMATCH);
  if( x < INT_MIN || x > INT_MAX )
		setError(mInstance, ERR_BADVALUE);
  
//  if( x != floor(x))
//		setError(mInstance, ERR_NOTINT);   bah ma fottiti bigotto del cazzo :D
  
  return (int)x;
	}



/*
  check that we have a token of the passed type 
    (if not set the errorFlag)
  Move parser on to next token. Sets token and string.
*/
void match(MINIBASIC *mInstance,TOKEN_NUM tok) {

  if(mInstance->token != tok) {
		setError(mInstance,ERR_SYNTAX);
		return;
	  }

  mInstance->string=skipSpaces(mInstance->string);

  mInstance->string += tokenLen(mInstance,mInstance->string, mInstance->token);
  mInstance->token = getToken(mInstance->string);
  if(mInstance->token == B_ERROR)
		setError(mInstance,ERR_SYNTAX);

	}


/*
  set the errorFlag.
  Params: errorcode - the error.
  Notes: ignores error cascades
*/
/*BSTATIC*/ void setError(MINIBASIC *mInstance,enum MINIBASIC_ERRORS errorcode) {

  if(!mInstance->errorFlag || !errorcode)
		mInstance->errorFlag = errorcode;
	}


/*
  get the next line number
  Params: str - pointer to parse string
  Returns: line no of next line, 0 if end
  Notes: goes to newline, then finds
         first line starting with a digit.
*/
LINE_NUMBER_TYPE getNextLine(char * str) {

  while(*str) {
    while(*str && *str != '\n')
	  	str++;
    if(*str == 0)
	  	return 0;
    str++;
    if(isdigit(*str))
	  	return atoi(str);
  	}
  return 0;
	}



/*
  get a token from the string
  Params: str - string to read token from
  Notes: ignores white space between tokens
*/
TOKEN_NUM getToken(char * str) {
	unsigned char i,j;
  
  str=skipSpaces(str);

  if(isdigit(*str))
    return VALUE;
 
  switch(*str) {
    case 0:
	  	return EOS;
    case '\n':
	  	return EOL;
		case '/': 
		  return DIV;
		case '*':
		  return MULT;
		case '(':
		  return OPAREN;
		case ')':
		  return CPAREN;
		case '+':
		  return PLUS;
		case '-':
		  return MINUS;
		case '!':
		  return SHRIEK;
		case '&':
		  return AMPERSAND;
		case ',':
		  return COMMA;
		case ';':
		  return SEMICOLON;
		case ':':
		  return COLON;
		case '#':
		  return DIESIS;
		case '"':
		  return QUOTE;
		case '=':
		  return EQUALS;
		case '<':
		  return LESS;
		case '>':
		  return GREATER;
		case '~':
		  return BITNOT;
		case '?':
		  return PRINT2;
		case '\'':
		  return REM2;
		default:

		  if(*str=='e' && !isalnum(str[1]))
				return E;
		  if(*str=='p' && str[1]=='i' && !isalnum(str[2]))
				return PI;
//		  if(isupper(*str)) {
//#warning tolto UPPERCASE basic! 2022 fuck bigots ;)
				for(i=0; i<sizeof(tl)/sizeof(TOKEN_LIST); i++) {
// bit of wasted code: ? and ' are searched here too, but they are not found (not strings) and handled above...
					j=tl[i].length;
					if(!strnicmp((char *)str, (char *)tl[i].tokenname, j) &&
					  !isalnum(str[j]))
						return i+PRINT;
					}
//			  }			  /* end isupper() */
	
		  if(isalpha(*str)) {
				while(isalnum(*str))
				  str++;
				switch(*str) {
				  case '%':
						return str[1] == '(' ? DIMINTID : INTID;
				  case '$':
						return str[1] == '(' ? DIMSTRID : STRID;
				  case '(':
						return DIMFLTID;
				  default:
						return FLTID;
					}
			  }
		
			return B_ERROR;
			break;
	  } 		// switch
	}



/*
  get the length of a token.
  Params: str - pointer to the string containing the token
          token - the type of the token read
  Returns: length of the token, or 0 for EOL to prevent
           it being read past.
*/
unsigned char tokenLen(MINIBASIC *mInstance,char * str, TOKEN_NUM token) {
  IDENT_LEN len = 0;
  char buff[20];

  switch(token) {
    case EOS:
	  	return 0;
    case EOL:
	  	return 1;
    case VALUE:
	  	getValue(str, &len);
	  	return len;
		case DIMSTRID:
		case DIMFLTID:
		case STRID:
			// fallthrough
//		  getId(mInstance,str, buff, &len);
//	  	return len;
		case INTID:
			// fallthrough
//	  	getId(mInstance,str, buff, &len);
//	  	return len;
		case FLTID:
	  	getId(mInstance,str, buff, &len);
	  	return len;
    case PI:
	  	return 2;
    case E:
	  	return 1;

    case DIV:
    case MULT:
		case OPAREN:
    case CPAREN:
    case PLUS:
    case MINUS:
//    case NOT:
    case SHRIEK:
    case COMMA:
		case QUOTE:
		case EQUALS:
		case LESS:
		case GREATER:
		case SEMICOLON:
		case COLON:
		case DIESIS:
		case BITNOT:
			return 1;
    case AMPERSAND:
			return 1;

    case B_ERROR:
	  	return 0;

		default:
			if(token>=PRINT && token<(PRINT+sizeof(tl)/sizeof(TOKEN_LIST)))
				return tl[token-PRINT].length;
			else
		  	basicAssert(0);
		  return 0;
  	}
	}


/*
  test if a token represents a string expression
  Params: token - token to test
  Returns: 1 if a string, else 0
*/
char isString(TOKEN_NUM token) {
//	unsigned char a=CHRSTRING;

  if(token == STRID || token == QUOTE || token == DIMSTRID 
		|| token >= CHRSTRING
/*	  || token == CHRSTRING || token == STRSTRING 
	  || token == LEFTSTRING || token == RIGHTSTRING 
	  || token == MIDSTRING || token == STRINGSTRING || token == HEXSTRING
		|| token == TRIMSTRING || token == INKEYSTRING || token == ERRORSTRING */ )
		return 1;
  return 0;
	}


/*
  get a numerical value from the parse string
  Params: str - the string to search
          len - return pinter for no chars read
  Retuns: the value of the string.
*/
NUM_TYPE getValue(char *str, IDENT_LEN *len) {
  NUM_TYPE answer;
  char *end;		// no CONST
	
  answer = strtod(str, &end);

  basicAssert(end != str);
  *len = end - str;
  return answer;
	}


/*
  getId - get an id from the parse string:
  Params: str - string to search
          out - id output [32 chars max ]
		  len - return pointer for id length
  Notes: triggers an error if id > 31 chars
         the id includes the $ and ( qualifiers.
*/
void getId(MINIBASIC *mInstance,char * str, char *out, IDENT_LEN *len) {
  IDENT_LEN nread = 0;

  str=skipSpaces(str);
  basicAssert(isalpha(*str));
  while(isalnum(*str)) {
		if(nread < IDLENGTH-1)
			out[nread++] = *str++;
		else {
			setError(mInstance,ERR_IDTOOLONG);
			break;
			}
		}
  if(*str == '$' || *str == '%') {
		if(nread < IDLENGTH-1)
		  out[nread++] = *str++;
		else
		 setError(mInstance,ERR_IDTOOLONG);
	  }
  if(*str == '(') {
		if(nread < IDLENGTH-1)
		  out[nread++] = *str++;
		else
		  setError(mInstance,ERR_IDTOOLONG);
	  }
  out[nread] = 0;
  *len = nread;
	}



/*
  grab a literal from the parse string.
  Params: dest - destination string
          src - source string
  Notes: strings are in quotes, double quotes the escape
*/
static void mystrgrablit(char *dest, char * src) {
  
	basicAssert(*src == 0x22 /* '\"' */);
  src++;
  
  while(*src) {
		if(*src == '"')	{
	  	if(src[1] == '"') {
				*dest++ = *src;
	    	src++;
	    	src++;
	  		}
	  	else
				break;
			}
		else
    	*dest++ = *src++;
  	}

  *dest = 0;
	}



/*
  find where a source string literal ends
  Params: src - string to check (must point to quote)
          quote - character to use for quotation
  Returns: pointer to quote which ends string
  Notes: quotes escape quotes
*/
static char *mystrend(char * str, char quote) {
  
	basicAssert(*str == quote);
  str++;

  while(*str) {
    while(*str != quote) {
	  	if(*str == '\n' || *str == 0)
				return 0;
	  	str++;
			}
    if(str[1] == quote)
	  	str += 2;
		else
	  	break;
  	}

  return (char *) (*str ? str : 0);
	}


/*
  Count the instances of ch in str
  Params: str - string to check
          ch - character to count
  Returns: number of times ch occurs in str. 
*/
static int myStrCount(char *str, char ch) {
  int answer=0;

  while(*str) {
    if(*str++ == ch)
		  answer++;
  	}

  return answer;
	}


/*
  duplicate a string:
  Params: str - string to duplicate
  Returns: malloced duplicate.
*/
char *strdup(const char *str) {
  char *answer;

  answer = (char *)malloc(strlen(str) + 1);
  if(answer)
    strcpy(answer,str);

  return answer;
	}

char *strupr(char *str) {   // frocissimi!
  char *answer=str;
  
  while(*str) {
    if(isalpha(*str))
      *str &= ~0x20;
    str++;
    }
  
  return answer;
  }



/*
  concatenate two strings
  Params: str - firsts string
          cat - second string
  Returns: malloced string.
*/
static char *myStrConcat(const char *str, const char *cat) {
  int len;
  char *answer;

  len = strlen(str) + strlen(cat);
  answer = (char *)malloc(len + 1);
  if(answer) {
    strcpy(answer, str);
    strcat(answer, cat);
  	}
  return answer;
	}



/*
  compute x!  
*/
double factorial(double x) {
  double answer = 1.0;
  double t;

  if(x > 1000.0)
    x = 1000.0;

  for(t=1; t<=x; t+=1.0)
		answer *= t;

  return answer;
	}




/******************** PIC32 ?? Specific Functions **********************/


char *mystrchr(char * s, unsigned char c) {
	
	while(*s) {
		if(*s == c)
			return s;
		s++;
		}

	return NULL;
	}
#define tolower(c)     ((c) | 0x20)   // v. ctype ma � tutto a cazzo..
#define toupper(c)     ((c) & ~0x20)
int8_t stricmp(const char *string1, const char *string2) {

  while(tolower(*string1) == tolower(*string2)) {
    if(!*string1)
      return 0;
    string1++;
    string2++;
    }
  return tolower(*(unsigned const char *)string1) - tolower(*(unsigned const char *)string2);
	}

int8_t strnicmp(const char *string1, const char *string2, size_t count) {

  if(!count)
    return 0;

  do {
    if(tolower((unsigned char)*string1) != tolower((unsigned char)*string2++))
      return (int)tolower((unsigned char)*string1) -	(int)tolower((unsigned char)*--string2);
    if(!*string1++)
      break;
    } while(--count);
  
	return 0;
	}





//void assert(char s) {}		// already in libs...


char *myitoahex(unsigned int n) {
	char *p = &myitoabuf[sizeof(myitoabuf)-1];
	
  *p = '\0';
	do {
		*(--p) = "0123456789ABCDEF"[n & 0x0F];
		} while ((n >>= 4) > 0);
	return p;
	}

BYTE myhextob(char c) {
  
  if(isdigit(c))
    return c-'0';
  else if(toupper(c) >='A' && toupper(c) <='F')
    return toupper(c)-'A'+10;
  }
unsigned int myhextoi(const char *p) {
  unsigned int n=0;
  BYTE c;
	
  while(c=*p++) {
    n *= 16;
    n += myhextob(c);
    }
	return n;
	}


static char *skipSpaces(char *str) {

	while(/* isspace*/ *str == ' ' || *str == 9)
		str++;
	return str;
	}


// ----------------------------------------------------
int myTextOut(MINIBASIC *mInstance,const char *s) {
  HDC myDC,*hDC;
  
#ifdef USA_BREAKTHROUGH
  hDC=GetDC(mInstance->hWnd,&myDC);
  SetTextColor(hDC,Color24To565(mInstance->Color));
  SetBkColor(hDC,Color24To565(mInstance->ColorBK));

  TextOut(hDC,mInstance->Cursor.x*hDC->font.size*6,
          mInstance->Cursor.y*hDC->font.size*8,s);
  ReleaseDC(mInstance->hWnd,hDC);
#else
  SetColors(Color24To565(mInstance->Color),Color24To565(mInstance->ColorBK));
  SetXYText(mInstance->Cursor.x,mInstance->Cursor.y);
  
  while(*s) {
    switch(*s) {
      case 8:   // filtro via un po' di cose qua!
      case 10:
      case 13:
        break;
      case 9:   // TAB dovrebbe essere gestito sopra da PRINT
        break;
      default:
        putchar(*s);
        mInstance->Cursor.x++;
        if(mInstance->Cursor.x >= ScreenText.cx) {
          mInstance->Cursor.y++;
          if(mInstance->Cursor.y >= ScreenText.cy) {
            mInstance->Cursor.y--;
            }
        break;
        }
      }
    s++;
    }
#endif
  
  return 1;
  }

int myCR(MINIBASIC *mInstance) {
  
  mInstance->Cursor.x=0;  mInstance->Cursor.y++;
  if(mInstance->Cursor.y >= ScreenText.cy) {
    mInstance->Cursor.y--;
    putchar('\n');    // forzo scroll!
    }
  SetXYText(mInstance->Cursor.x,mInstance->Cursor.y);
  return 1;
  }

int inkey(void) {
  BYTE keypress[2];
//  extern struct KEYPRESS keypress;

  ReadPMPs(SOUTH_BRIDGE,BIOS_KEYBOARD_READ,keypress,2);
	//qua faccio cos�... verificare...
  //e i keypressModif
  return keypress[0] /* | keypress[1]*/;
  
//v.      inputKey();
//    i=inputKey();
//    ch=tolower(LOBYTE(i));

  }

