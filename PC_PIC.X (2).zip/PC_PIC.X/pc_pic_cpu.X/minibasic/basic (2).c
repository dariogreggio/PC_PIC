/*****************************************************************
*                           Mini BASIC                           *
*                        by Malcolm McLean                       *
*                           version 1.0                          *
*                        (modified by DLM)                       *
*  DLM changes under same permissive license as original McLean  *
*  license                                                       *
*****************************************************************/

/*
License from 
http://www.personal.leeds.ac.uk/~bgy1mm/Minibasic/MiniBasicHome.html

You can do virtually anything you like with this code, including incorporating
it into your own programs, or modifying as the basis for a scripting language
of your own. It would be nice to be acknowledged but I don't insist on it - you
can pretend that you created the program on your own if it makes your boss
happy. The only thing you can't do is restrict my rights in the program in
any way. So any derivative works or enhancements I can use as I see fit.
*/

#include "all.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <limits.h>
#include <ctype.h>

#undef isalnum
#undef isalpha
#undef isdigit
#undef isspace

#include "basic.h"
#include "io.h"
#include "term.h"

typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
typedef unsigned char tokennum;
typedef signed short dimsize;
#define MAXDIMSIZE 32000
typedef signed short linenumbertype;

typedef struct
{
#ifdef SMALLTOKENS
	char const tokenname[4];
#else
	char const tokenname[7];
#endif
	int8 length;
} tokenlist;

/* tokens defined */
#define EOS 0 
#define VALUE 1

#define ERROR 2
#define STRID 3
#define FLTID 4
#define DIMFLTID 5
#define DIMSTRID 6

/* relational operators defined */

#define ROP_EQ 1         /* equals */
#define ROP_NEQ 2        /* doesn't equal */
#define ROP_LT 3         /* less than */
#define ROP_LTE 4        /* less than or equals */
#define ROP_GT 5         /* greater than */
#define ROP_GTE 6        /* greater than or equals */

/* error codes (in BASIC script) defined */
#define ERR_CLEAR 0
#define ERR_SYNTAX 1
#define ERR_OUTOFMEMORY 2
#define ERR_IDTOOLONG 3
#define ERR_NOSUCHVARIABLE 4
#define ERR_BADSUBSCRIPT 5
#define ERR_TOOMANYDIMS 6
#define ERR_TOOMANYINITS 7
#define ERR_BADTYPE 8
#define ERR_TOOMANYFORS 9
#define ERR_NONEXT 10
#define ERR_NOFOR 11
#define ERR_DIVIDEBYZERO 12
#define ERR_NEGLOG 13
#define ERR_NEGSQRT 14
#define ERR_BADSINCOS 15
#define ERR_EOF 16
#define ERR_TYPEMISMATCH 17
#define ERR_INPUTTOOLONG 18
#define ERR_BADVALUE 19
#define ERR_NOTINT 20
#define ERR_TOOMANYGOSUB 21
#define ERR_NORETURN 22

#define TOKENBASE 130

#define QUOTE '\"'
#define BITAND '&'
#define OPAREN '('
#define CPAREN ')'
#define MULT '*'
#define PLUS '+'
#define COMMA ','
#define MINUS '-'
#define DIV '/'
#define SEMICOLON ';'
#define LESS '<'
#define EQUALS '='
#define GREATER '>'
#define BITOR '|'
#define BITNOT '~'
#define BITXOR '^'
#define SHORTPRINT '?'

#ifdef SMALLTOKENS
tokenlist const tl[] = {
#define ABS (TOKENBASE+1)
	{ "ABS",   -3 },
#ifdef USEFLOATS
#define ACOS (ABS+1)
	{ "ACOS",  -4 },
#define AND (ACOS+1)
#else
#define AND (ABS+1)
#endif
	{ "AND",   -3 },
#define ASCII (AND+1)
	{ "ASC",   -3 },
#ifdef USEFLOATS
#define ASIN (ASCII+1)
	{ "ASIN",  -4 },
#define ATAN (ASIN+1)
	{ "ATAN",  -4 },
#define BOLD (ATAN+1)
#else
#define BOLD (ASCII+1)
#endif
    { "BLD",   -3 },
#define CHRSTRING (BOLD+1)
	{ "CHR$",   4 },
#define CLREOL (CHRSTRING+1)
    { "CLE",    -3 },
#define CLRSCR (CLREOL+1)
    { "CLS",    -3 },
#ifdef USEFLOATS
#define COS (CLRSCR+1)
	{ "COS",   -3 },
#define DIM (COS+1)
#else
#define DIM (CLRSCR+1)
#endif
	{ "DIM",   -3 },
#define ELSE (DIM+1)
    { "ELS",   -3 },
#define END (ELSE+1)
    { "END",   -3 },
#define ERR (END+1)
    { "ERR",   -3 },
#ifdef USEFLOATS
#define EXP (ERR+1)
    { "EXP",   -3 },
#define FOR (EXP+1)
#else
#define FOR (ERR+1)
#endif
	{ "FOR",   -3 },
#define GOSUB (FOR+1)
	{ "GSB",   -3 },
#define GOTO (GOSUB+1)
	{ "GTO",   -3 },
#define HEXSTRING (GOTO+1)
	{ "HEX$",   4 },
#define IF (HEXSTRING+1)
	{ "IF",    -2 },
#define INADC (IF+1)
    { "INA",   -3 },
#define IND (INADC+1)
    { "IND",   -3 },
#define INKEY (IND+1)
	{ "INK",   -3 },
#define INPUT (INKEY+1)
	{ "INP",   -3 },
#define INSTR (INPUT+1)
	{ "INS",   -3 },
#define INT (INSTR+1)
	{ "INT",   -3 },
#define LEN (INT+1)
	{ "LEN",   -3 },
#define LET (LEN+1)
	{ "LET",   -3 },
#define LEFTSTRING (LET+1)
	{ "LFT$",   4 },
#define LOCATE (LEFTSTRING+1)
    { "LOC",   -3 },
#ifdef USEFLOATS
#define LOG (LOCATE+1)
	{ "LOG",   -3 },
#define MIDSTRING (LOG+1)
#else
#define MIDSTRING (LOCATE+1)
#endif
	{ "MID$",   4 },
#define MOD (MIDSTRING+1)
	{ "MOD",   -3 },
#define NEXT (MOD+1)
	{ "NXT",   -3 },
#define ONERROR (NEXT+1)
    { "OER",   -3 },
#define OR (ONERROR+1)
	{ "OR",    -2 },
#define OUTDAC (OR+1)
    { "OTA",   -3 },
#define OUTD (OUTDAC+1)
    { "OTD",   -3 },
#define PEEK (OUTD+1)
    { "PEK",   -3 },
#ifdef USEFLOATS
#define PI (PEEK+1)
	{ "PI",    -2 },
#define POKE (PI+1)
#else
#define POKE (PEEK+1)
#endif
    { "PKE",   -3 },
#ifdef USEFLOATS
#define POW (POKE+1)
	{ "POW",   -3 },
#define PRINT (POW+1)
#else
#define PRINT (POKE+1)
#endif
	{ "PRT",   -3 },
#define PWM (PRINT+1)
    { "PWM",   -3 },
#define REM (PWM+1)
	{ "REM",   -3 },
#define RIGHTSTRING (REM+1)
	{ "RHT$",   4 },
#define RND (RIGHTSTRING+1)
	{ "RND",   -3 },
#define RETURN (RND+1)
	{ "RTN",   -3 },
#define SETPIN (RETURN+1)
    { "SEP",   -3 },
#ifdef USEFLOATS
#define SIN (SETPIN+1)
	{ "SIN",   -3 },
#define SQRT (SIN+1)
	{ "SQRT",  -4 },
#define STRINGSTRING (SQRT+1)
#else
#define STRINGSTRING (SETPIN+1)
#endif
	{ "STG$",   4 },
#define STEP (STRINGSTRING+1)
	{ "STP",   -3 },
#define STRSTRING (STEP+1)
	{ "STR$",   4 },
#ifdef USEFLOATS
#define TAN (STRSTRING+1)
	{ "TAN",   -3 },
#define THEN (TAN+1)
#else
#define THEN (STRSTRING+1)
#endif
	{ "THN",   -3 },
#define TO (THEN+1)
	{ "TO",    -2 },
#define TONE (TO+1)
    { "TON",   -3 },
#define VAL (TONE+1)
	{ "VAL",   -3 },
#define VALLEN (VAL+1)
	{ "VLN",   -3 }
};
#else
tokenlist const tl[] = {
#define ABS (TOKENBASE+1)
	{ "ABS",   -3 },
#ifdef USEFLOATS
#define ACOS (ABS+1)
	{ "ACOS",  -4 },
#define AND (ACOS+1)
#else
#define AND (ABS+1)
#endif
	{ "AND",   -3 },
#define ASCII (AND+1)
	{ "ASCII", -5 },
#ifdef USEFLOATS
#define ASIN (ASCII+1)
	{ "ASIN",  -4 },
#define ATAN (ASIN+1)
	{ "ATAN",  -4 },
#define BOLD (ATAN+1)
#else
#define BOLD (ASCII+1)
#endif
    { "BOLD",  -4 },
#define CHRSTRING (BOLD+1)
	{ "CHR$",   4 },
#define CLREOL (CHRSTRING+1)
    { "CLREOL",   -6 },
#define CLRSCR (CLREOL+1)
    { "CLRSCR",   -6 },
#ifdef USEFLOATS
#define COS (CLRSCR+1)
	{ "COS",   -3 },
#define DIM (COS+1)
#else
#define DIM (CLRSCR+1)
#endif
	{ "DIM",   -3 },
#define ELSE (DIM+1)
    { "ELSE",  -4 },
#define END (ELSE+1)
    { "END",   -3 },
#define ERR (END+1)
    { "ERR",   -3 },
#ifdef USEFLOATS
#define EXP (ERR+1)
    { "EXP",   -3 },
#define FOR (EXP+1)
#else
#define FOR (ERR+1)
#endif
	{ "FOR",   -3 },
#define GOSUB (FOR+1)
	{ "GOSUB", -5 },
#define GOTO (GOSUB+1)
	{ "GOTO",  -4 },
#define HEXSTRING (GOTO+1)
	{ "HEX$",   4 },
#define IF (HEXSTRING+1)
	{ "IF",    -2 },
#define INADC (IF+1)
    { "INADC", -5 },
#define IND (INADC+1)
    { "IND",   -3 },
#define INKEY (IND+1)
	{ "INKEY", -5 },
#define INPUT (INKEY+1)
	{ "INPUT", -5 },
#define INSTR (INPUT+1)
	{ "INSTR", -5 },
#define INT (INSTR+1)
	{ "INT",   -3 },
#define LEFTSTRING (INT+1)
	{ "LEFT$",  5 },
#define LEN (LEFTSTRING+1)
	{ "LEN",   -3 },
#define LET (LEN+1)
	{ "LET",   -3 },
#define LOCATE (LET+1)
    { "LOCATE", -6 },
#ifdef USEFLOATS
#define LOG (LOCATE+1)
	{ "LOG",   -3 },
#define MIDSTRING (LOG+1)
#else
#define MIDSTRING (LOCATE+1)
#endif
	{ "MID$",   4 },
#define MOD (MIDSTRING+1)
	{ "MOD",   -3 },
#define NEXT (MOD+1)
	{ "NEXT",  -4 },
#define ONERROR (NEXT+1)
    { "ONERROR", -7 },
#define OR (ONERROR+1)
	{ "OR",    -2 },
#define OUTD (OR+1)
    { "OUTD",  -4 },
#define OUTDAC (OUTD+1)
    { "OUTDAC", -6 },
#define PEEK (OUTDAC+1)
    { "PEEK",  -4 },
#ifdef USEFLOATS
#define PI (PEEK+1)
	{ "PI",    -2 },
#define POKE (PI+1)
#else
#define POKE (PEEK+1)
#endif
    { "POKE",  -4 },
#ifdef USEFLOATS
#define POW (POKE+1)
	{ "POW",   -3 },
#define PRINT (POW+1)
#else
#define PRINT (POKE+1)
#endif
	{ "PRINT", -5 },
#define PWM (PRINT+1)
    { "PWM",   -3 },
#define REM (PWM+1)
	{ "REM",   -3 },
#define RETURN (REM+1)
	{ "RETURN",-6 },
#define RIGHTSTRING (RETURN+1)
	{ "RIGHT$", 6 },
#define RND (RIGHTSTRING+1)
	{ "RND",   -3 },
#define SETPIN (RND+1)
    { "SETPIN", -6 },
#ifdef USEFLOATS
#define SIN (SETPIN+1)
	{ "SIN",   -3 },
#define SQRT (SIN+1)
	{ "SQRT",  -4 },
#define STEP (SQRT+1)
#else
#define STEP (SETPIN+1)
#endif
	{ "STEP",  -4 },
#define STRSTRING (STEP+1)
	{ "STR$",   4 },
#define STRINGSTRING (STRSTRING+1)
	{ "STRING$", 7 },
#ifdef USEFLOATS
#define TAN (STRINGSTRING+1)
	{ "TAN",   -3 },
#define THEN (TAN+1)
#else
#define THEN (STRINGSTRING+1)
#endif
	{ "THEN",  -4 },
#define TO (THEN+1)
	{ "TO",    -2 },
#define TONE (TO+1)
    { "TONE",  -4 },
#define VAL (TONE+1)
	{ "VAL",   -3 },
#define VALLEN (VAL+1)
	{ "VALLEN",-6 }
};
#endif

#define TOKENLISTENTRIES (sizeof(tl)/sizeof(tokenlist))

typedef struct
{
  linenumbertype no;        /* line number */
  const char *str;		    /* points to start of line */
}LINE;

typedef union
{
  numtype       dval;	 	    /* its value if a real */
  STRINGARRAY   *sval;			/* its value if a string (malloced) */
} VARIABLEDATA;

typedef struct
{
  char         id[IDLENGTH];	/* id of variable */
  tokennum     type;		    /* its type, STRID or FLTID */
  VARIABLEDATA d;               /* data in variable */
} VARIABLE;

typedef union
{
  STRINGARRAY   **str;	        /* pointer to string data */
  numtype       *dval;	        /* pointer to real data */
} DIMVARPTR;

typedef struct
{
  char          id[IDLENGTH];	/* id of dimensioned variable */
  tokennum      type;		    /* its type, STRID or FLTID */
  int8          ndims;	        /* number of dimensions */
  dimsize       dim[MAXDIMS];	/* dimensions in x y order */
  DIMVARPTR     d;              /* pointers to string/real data */
} DIMVAR;

typedef union
{
  STRINGARRAY   **sval;			/* pointer to string data */
  numtype       *dval;		    /* pointer to real data */
} LVALUEDATA;

typedef struct			
{
  int           type;			/* type of variable (STRID or FLTID or ERROR) */   
  LVALUEDATA    d;              /* data pointed to by LVALUE */
} LVALUE;

typedef struct
{
  char           id[IDLENGTH];  /* id of control variable */
  linenumbertype nextline;		/* line below FOR to which control passes */
  numtype        toval;			/* terminal value */
  numtype        step;			/* step size */
} FORLOOP;

BSTATIC char *mydtoa(double n);

BSTATIC FORLOOP forstack[MAXFORS];   /* stack for for loop conrol */
BSTATIC int nfors;					 /* number of fors on stack */

BSTATIC linenumbertype gosubstack[MAXGOSUB];
BSTATIC int ngosub;

BSTATIC VARIABLE *variables;		/* the script's variables */
BSTATIC int nvariables;				/* number of variables */

BSTATIC DIMVAR *dimvariables;		/* dimensioned arrays */
BSTATIC int ndimvariables;			/* number of dimensioned arrays */

BSTATIC LINE *lines;				/* list of line starts */
BSTATIC int nlines;					/* number of BASIC lines in program */

BSTATIC const char *string;         /* string we are parsing */
BSTATIC tokennum token;             /* current token (lookahead) */
BSTATIC int errorflag;             /* set when error in input encountered */
BSTATIC int lasterrorflag;         /* last error that was encountered */
BSTATIC linenumbertype onerrorline; /* if we set on error then we go to this line */
BSTATIC linenumbertype errorline;   /* if we set on error then we go to this line */
BSTATIC int curline;

BSTATIC int setup(const char *script);
BSTATIC void cleanup(void);
BSTATIC int innum(numtype *val);
BSTATIC char *mydtoa(double n);

BSTATIC void reporterror(linenumbertype lineno);
BSTATIC int findline(linenumbertype no);

BSTATIC linenumbertype line(void);
BSTATIC void doprint(void);
BSTATIC void dopoke(void);
BSTATIC void dotwoset(void);
BSTATIC void dothreeset(void);
BSTATIC void dolet(void);
BSTATIC void dodim(void);
BSTATIC void dobold(void);
BSTATIC void dolocate(void);
BSTATIC void doonerror(void);
BSTATIC linenumbertype doif(void);
BSTATIC linenumbertype dogoto(void);
BSTATIC linenumbertype dogosub(void);
BSTATIC linenumbertype doreturn(void);
BSTATIC void doinput(void);
BSTATIC void dorem(void);
BSTATIC linenumbertype dofor(void);
BSTATIC linenumbertype donext(void);

BSTATIC void lvalue(LVALUE *lv);

BSTATIC int boolexpr(void);
BSTATIC int boolfactor(void);
BSTATIC int relop(void);

BSTATIC numtype expr(void);
BSTATIC numtype term(void);
BSTATIC numtype factor(void);
BSTATIC numtype instr(void);
BSTATIC numtype variable(void);
BSTATIC numtype dimvariable(void);

BSTATIC VARIABLE *findvariable(const char *id);
BSTATIC DIMVAR *finddimvar(const char *id);
BSTATIC DIMVAR *dimension(const char *id, int ndims, dimsize *intdims);
BSTATIC void *getdimvar(DIMVAR *dv, dimsize *intdims);
BSTATIC VARIABLE *addfloat(const char *id);
BSTATIC VARIABLE *addstring(const char *id);
BSTATIC DIMVAR *adddimvar(const char *id);

BSTATIC STRINGARRAY *stringexpr(void);
BSTATIC STRINGARRAY *chrstring(void);
BSTATIC STRINGARRAY *strstring(void);
BSTATIC STRINGARRAY *leftstring(void);
BSTATIC STRINGARRAY *rightstring(void);
BSTATIC STRINGARRAY *midstring(void);
BSTATIC STRINGARRAY *stringstring(void);
BSTATIC STRINGARRAY *hexstring(void);
BSTATIC STRINGARRAY *stringdimvar(void);
BSTATIC STRINGARRAY *stringvar(void);
BSTATIC STRINGARRAY *stringliteral(void);
BSTATIC STRINGARRAY *createstringarray(int len);
BSTATIC STRINGARRAY *stringarraydup(STRINGARRAY *str);
BSTATIC STRINGARRAY *stringarrayduppart(STRINGARRAY *str, int offset, int len);
BSTATIC STRINGARRAY *stringarraychar(const char *str);
BSTATIC STRINGARRAY *stringarrayconcat(STRINGARRAY *s1, STRINGARRAY *s2);
BSTATIC void         mystrgrablit(STRINGARRAY *dest, const char *src);  /* only used in mystringgrablit */
BSTATIC int          stringarraycmp(STRINGARRAY *s1, STRINGARRAY *s2);
BSTATIC int          strstrarray(STRINGARRAY *str, STRINGARRAY *substr, int offset);

BSTATIC STRINGARRAY emptystring = { 0, { 0 } };

#define EMPTYSTRING &emptystring

#ifdef USEFLOATS
BSTATIC int integer(numtype x);
#else
#define integer(x) (x)
#endif

BSTATIC void match(int tok);
BSTATIC void seterror(int errorcode);
BSTATIC linenumbertype getnextline(void);
BSTATIC tokennum gettoken(void);
BSTATIC int tokenlen(const char *str, tokennum token);

BSTATIC int isstring(tokennum token);
BSTATIC numtype getvalue(const char *str, int *len);
BSTATIC void getid(const char *str, char *out, int *len);

BSTATIC char *mystrend(const char *str, char quote);   /* only used in stringliteral */
BSTATIC int mystrcount(const char *str, char ch);      /* only used in setup() */

#ifdef USEFLOATS
BSTATIC char *mydtoa(double n)
{
    gcvt(n, 10, myitoabuf);
	return myitoabuf;
}

int errno;
int *__errno(void)
{
    return &errno;
}
#endif

BSTATIC int innum(numtype *val)
{
	char s[16];
	int err = instrn(s, sizeof(s)-1);
	if (err >= 0) {
#ifdef USEFLOATS
	*val = strtod(s, NULL);
#else
	*val = mystrtol(s, NULL);
#endif
	}
	return err;
}

#ifdef BASICASSERT
BSTATIC void basicassert(int x, char *reason)
{
	if (x==0) {
		outstr("oops! assert thrown ");
		outstr(reason);
		outstr("\n");
	}
}
#endif

BSTATIC void outnum(numtype x)
{
#ifdef USEFLOATS
    outstr(mydtoa(x));
#else
	outstr(myitoa(x));
#endif
}

/*
  Interpret a BASIC script

  Params: script - the script to run
          in - input stream
		  out - output stream
		  err - error stream 
  Returns: 0 on success, 1 on error condition.
*/
int basic(const char *script)
{
  linenumbertype nextline;
  int answer = 0;

  nfors = ngosub = 0;
  lasterrorflag = 0;
  onerrorline = errorline = -1;

  if( setup(script) == -1 )
    return 1;
  
  curline = 0;
  while(curline != -1)
  {
	LINE *l = &lines[curline];
    string = l->str;

	errorflag = 0;

	nextline = line();
	if(errorflag)
	{
	  if (onerrorline < 0) {
		reporterror(l->no);
		answer = 1;
		break;
	  } else {
	    lasterrorflag = errorflag;
		nextline = onerrorline;
		onerrorline = -1;
		errorline = l->no;
		nfors = ngosub = 0;
	  }
	}

	if(nextline == -1)
	  break;

	if(nextline == 0)
	{
      curline++;
	  if(curline == nlines)
	    break;
    }
	else
    {
      curline = findline(nextline);
	  if(curline == -1)
	  {
        outstrint("line not found: ", nextline);
		answer = 1;
		break;
	  }
    }
  }

  cleanup();
  
  return answer;
}

/*
  Sets up all our globals, including the list of lines.
  Params: script - the script passed by the user
  Returns: 0 on success, -1 on failure
*/
BSTATIC int setup(const char *script)
{
  int i, linen, lastline = 0;

  nlines = mystrcount(script, '\n');
  lines = malloc(nlines * sizeof(LINE));
  if(!lines)
  {
    outstr("Out of memory\n");
	return -1;
  }
  for(i=0;i<nlines;i++)
  {
    script = skipspaceslf(script);
	if (*script == '\n')
	{
		i--;
		nlines--;
	} else
	{
		LINE *l = &lines[i];
		if(isdigit(*script))
			linen = mystrtol(script, 0);
		else
			linen = lastline+1;
		if (lastline >= linen) 
		{
			outstr("program lines not in order: ");
			outint(lastline);
			outstrint(" and ",linen);
			free(lines);
			return -1;
		}
		lastline = linen;
		l->str = script;
		if (linen < 32768)
			l->no = (linenumbertype)linen;
		else {
			outstrint("line numbers < 32768, at ",linen);
			free(lines);
			return -1;
		}
	}
	script = strchr(script, '\n');
	script++;
  }
  if(!nlines)
  {
    outstr("Can't read program\n");
    free(lines);
	return -1;
  }

  nvariables = 0;
  variables = 0;

  dimvariables = 0;
  ndimvariables = 0;

  return 0;
}

BSTATIC int computedimsize(DIMVAR *dv)
{
	int ii, size = 1;
    for(ii=0;ii<dv->ndims;ii++)
	  size *= dv->dim[ii];
	return size;
}

/*
  frees all the memory we have allocated
*/
BSTATIC void cleanup(void)
{
  int i;
  int ii;
  int size;
  
  for(i=0;i<nvariables;i++) {
      VARIABLE *v = &variables[i];
	  if(v->type == STRID) {
		  void *s = v->d.sval;
		  if (s) free(s);
	  }
  }
  if(variables)
	  free(variables);
  variables = 0;
  nvariables = 0;

  for(i=0;i<ndimvariables;i++)
  {
    DIMVAR *d = &dimvariables[i];
    if(d->type == STRID)
	{
	  void *v = d->d.str;
	  if(v)
	  {
		size = computedimsize(d);
		for(ii=0;ii<size;ii++) {
		  void *v2 = d->d.str[ii];
		  if (v2) free(v2);
		}
		free(v);
	  }
	}
	else {
	  void *v = d->d.dval;
	  if (v) free(v);
	}
  }

  if(dimvariables)
	free(dimvariables);
 
  dimvariables = 0;
  ndimvariables = 0;

  if(lines)
	free(lines);

  lines = 0;
  nlines = 0;
  
}

BSTATIC void seterroroutofmemory()
{
	seterror(ERR_OUTOFMEMORY);
}

/*
  error report function.
  for reporting errors in the user's script.
  checks the global errorflag.
  writes to fperr.
  Params: lineno - the line on which the error occurred
*/
BSTATIC void reporterror(linenumbertype lineno)
{
  switch(errorflag)
  {
    case ERR_CLEAR:
	  ASSERTDEBUG(basicassert(0,"ERR_CLEAR"));
	  break;
	case ERR_SYNTAX:
	  outstr("Syntax error");
	  break;
	case ERR_OUTOFMEMORY:
	  outstr("Out of memory");
	  break;
	case ERR_IDTOOLONG:
	  outstr("Identifier too long");
	  break;
	case ERR_NOSUCHVARIABLE:
	  outstr("No such variable");
	  break;
	case ERR_BADSUBSCRIPT:
	  outstr("Bad subscript");
	  break;
	case ERR_TOOMANYDIMS:
	  outstr("Too many dimensions");
	  break;
	case ERR_TOOMANYINITS:
	  outstr("Too many initialisers");
	  break;
	case ERR_BADTYPE:
	  outstr("Illegal type");
	  break;
	case ERR_TOOMANYFORS:
	  outstr("Too many nested fors");
	  break;
	case ERR_NONEXT:
	  outstr("For without next");
	  break;
	case ERR_NOFOR:
	  outstr("Next without for");
	  break;
	case ERR_DIVIDEBYZERO:
	  outstr("Divide by zero ");
	  break;
#ifdef USEFLOATS
	case ERR_NEGLOG:
	  outstr("Negative LOG");
	  break;
	case ERR_NEGSQRT:
	  outstr("Negative SQRT");
	  break;
	case ERR_BADSINCOS:
	  outstr("SIN or COS out of range");
	  break;
#endif
	case ERR_EOF:
	  outstr("End of file");
	  break;
	case ERR_TYPEMISMATCH:
	  outstr("Type mismatch");
	  break;
	case ERR_INPUTTOOLONG:
	  outstr("Input too long");
	  break;
	case ERR_BADVALUE:
	  outstr("Bad value");
	  break;
	case ERR_NOTINT:
	  outstr("Not an int");
	  break;
	case ERR_TOOMANYGOSUB:
	  outstr("Too many GOSUB");
	  break;
	case ERR_NORETURN:
	  outstr("RETURN without GOSUB");
	  break;
	default:
	  outstr("ERROR");
	  break;
  }
  outstrint(" line # ",lineno);
}

/*
  binary search for a line
  Params: no - line number to find
  Returns: index of the line, or -1 on fail.
*/
BSTATIC int findline(linenumbertype no)
{
  int high;
  int low;
  int mid;

  low = 0;
  high = nlines-1;
  while(low <= high)
  {
    mid = (high + low)/2;
	if(lines[mid].no > no)
	  high = mid - 1;
	else if(lines[mid].no < no)
	  low = mid + 1;
	else return mid;
  }
  return -1;
}

/*
  Parse a line. High level parse function
*/
BSTATIC linenumbertype line(void)
{
  linenumbertype answer = 0;

  token = gettoken();
  if (token == VALUE) match(VALUE);

  switch(token)
  {
    case PRINT:
	  match(PRINT);
	  doprint();
	  break;
	case SHORTPRINT:
	  match(SHORTPRINT);
	  doprint();
	  break;
#ifdef PEEKPOKE
	case POKE:
	  dopoke();
	  break;
#endif
    case SETPIN:
	case OUTD:
	case OUTDAC:
	  dotwoset();
	  break;
	case PWM:
	case TONE:
	  dothreeset();
	  break;
	case CLRSCR:
	  match(CLRSCR);
	  clrscr();
	  break;
	case CLREOL:
	  match(CLREOL);
	  clreol();
	  break;
	case BOLD:
	  dobold();
	  break;
    case LOCATE:
	  dolocate();
	  break;
    case LET:
  	  match(LET);
	  dolet();
	  break;
	case DIM:
	  dodim();
	  break;
	case ONERROR:
	  doonerror();
	  break;
	case IF:
	  answer = doif();
	  break;
	case END:
      match(END);
	  answer = -1;
	  break;
	case GOTO:
	  answer = dogoto();
	  break;
	case GOSUB:
	  answer = dogosub();
	  break;
	case RETURN:
	  answer = doreturn();
	  break;
	case INPUT:
	  doinput();
	  break;
	case REM:
	  dorem();
	  return 0;
	  break;
	case FOR:
	  answer = dofor();
	  break;
	case NEXT:
	  answer = donext();
	  break;
	default:
	  dolet();
	  break;
  }

  if(token != EOS)
  {
	const char *str = skipspaceslf(string);
	if(*str != '\n') {
	  seterror(ERR_SYNTAX);
	}
  }
  return answer;
}

/*
  BOLD statement
*/
BSTATIC void dobold(void)
{
  numtype a;
  
  match(BOLD);
  a = expr();
  if (!errorflag) {
	if (a != 0) highvideo();
		else lowvideo();
  }
}

/*
  LOCATE statement
*/
BSTATIC void dolocate(void)
{
  unsigned int y,x;
  
  match(LOCATE);
  y = (unsigned int)expr();
  match(COMMA);
  x = (unsigned int)expr();
  if (!errorflag) gotoxy(x,y);
}

/*
  two parameter statements
*/
BSTATIC void dotwoset()
{
  tokennum t = token;
  unsigned int adr, dat;
  
  match(t);
  adr = integer(expr());
  match(COMMA);
  dat = integer(expr());
  if (!errorflag) {
	switch (t)
	{
		case SETPIN: setpin(adr,dat); break;
		case OUTD:   outd(adr,dat); break;
		case OUTDAC: outdac(adr,dat); break;
	}
  }
}

BSTATIC void dothreeset()
{
  tokennum t = token;
  unsigned int adr, dat1, dat2;
  
  match(t);
  adr = integer(expr());
  match(COMMA);
  dat1 = integer(expr());
  match(COMMA);
  dat2 = integer(expr());
  if (!errorflag) {
	switch (t)
	{
		case PWM:    pwm(adr,dat1,dat2); break;
		case TONE:   tone(adr,dat1,dat2); break;
	}
  }
}

#ifdef PEEKPOKE
/*
  the POKE statement
*/
BSTATIC void dopoke(void)
{
  unsigned int adr, dat;
  
  match(POKE);
  adr = integer(expr());
  match(COMMA);
  dat = integer(expr());
  if (!errorflag) *((unsigned int *)adr) = dat;
}
#endif

/*
  the PRINT statement
*/
BSTATIC void doprint(void)
{
  while(1)
  {
    if(isstring(token))
	{
	  STRINGARRAY *str;
      str = stringexpr();
	  if(str)
	  {
	    int i;
		for (i=0;i<str->len;i++)
			outchar(STRINGOF(str)[i]);
        free(str);
	  }
	}
	else
	{
	  numtype x = expr();
	  outnum(x);
	}
	if(token == COMMA)
	{
	  /*outchar(' '); */
	  match(COMMA);
	}
	else
	  break;
  }
  if(token == SEMICOLON)
  {
	match(SEMICOLON);
	outflush();
  }
  else
	outchar('\n');
}

/*
  the LET statement
*/
BSTATIC void dolet(void)
{
  LVALUE lv;
  STRINGARRAY *temp;

  lvalue(&lv);
  match(EQUALS);
  switch(lv.type)
  {
    case FLTID:
	  *lv.d.dval = expr();
	  break;
    case STRID:
	  temp = *lv.d.sval;
	  *lv.d.sval = stringexpr();
	  if(temp)
		free(temp);
	  break;
	default:
	  break;
  }
}

/*
  the DIM statement
*/
BSTATIC void dodim(void)
{
  int ndims = 0;
  numtype dims[MAXDIMS+1];
  dimsize intdims[MAXDIMS+1];  
  char name[IDLENGTH];
  int len;
  DIMVAR *dimvar;
  void *v;
  int i;
  int size = 1;

  match(DIM);

  switch(token)
  {
    case DIMFLTID:
	case DIMSTRID:
      getid(string, name, &len);
	  match(token);
	  dims[ndims++] = expr();
	  while(token == COMMA)
	  {
	    match(COMMA);
	    dims[ndims++] = expr();
		if(ndims > MAXDIMS)
		{
		  seterror(ERR_TOOMANYDIMS);
		  return;
		}
	  } 
	  match(CPAREN);
	  for(i=0;i<ndims;i++)
	  {
	    if(dims[i] < 0 || dims[i] > MAXDIMSIZE || dims[i] != (int) dims[i])
		{
		  seterror(ERR_BADSUBSCRIPT);
		  return;
		}
		intdims[i] = ((dimsize)dims[i]);
	  }
	  dimvar=dimension(name, ndims, intdims);
	  break;
	default:
	    seterror(ERR_SYNTAX);
	    return;
  }
  if(dimvar == 0)
  {
	/* out of memory */
	seterroroutofmemory();
	return;
  }

  if(token == EQUALS)
  {
    match(EQUALS);

	size = computedimsize(dimvar);
	switch(dimvar->type)
	{
      case FLTID:
		i = 0;
	    dimvar->d.dval[i++] = expr();
		while(token == COMMA && i < size)
		{
		  match(COMMA);
		  dimvar->d.dval[i++] = expr();
		  if(errorflag)
			break;
		}
		break;
	  case STRID:
		i = 0;
		v = dimvar->d.str[i];
		if (v) free (v);
		dimvar->d.str[i++] = stringexpr();

		while(token == COMMA && i < size)
		{
		  match(COMMA);
		  v = dimvar->d.str[i];
		  if (v) free(v);
		  dimvar->d.str[i++] = stringexpr();
		  if(errorflag)
			break;
		}
		break;
	}
	
	if(token == COMMA)
	  seterror(ERR_TOOMANYINITS);
  }

}

/*
  the IF statement.
  if jump taken, returns new line no, else returns 0
*/
BSTATIC linenumbertype doif(void)
{
  int condition;
  linenumbertype jumpthen, jumpelse = 0;

  match(IF);
  condition = boolexpr();
  match(THEN);
  jumpthen = integer( expr() );
  if (token == ELSE) {
	 match(ELSE);
	 jumpelse = integer( expr() );
  }
  return condition ? jumpthen : jumpelse;
}

/*
  the GOTO satement
  returns new line number
*/
BSTATIC linenumbertype dogoto(void)
{
  match(GOTO);
  return integer( expr() );
}

/*
  the GOTO satement
  returns new line number
*/
BSTATIC void doonerror(void)
{
  match(ONERROR);
  onerrorline = integer( expr() );
}

BSTATIC linenumbertype dogosub(void)
{
  linenumbertype toline;

  match(GOSUB);
  toline = integer ( expr() );
  if (ngosub >= MAXGOSUB) {
	  seterror(ERR_TOOMANYGOSUB);
	  return -1;
  }
  gosubstack[ngosub++] = getnextline();
  return toline;
}

BSTATIC linenumbertype doreturn(void)
{
  match(RETURN);
  if (ngosub <= 0) {
	  seterror(ERR_NORETURN);
	  return -1;
  }
  return gosubstack[--ngosub];
}

/*
  The FOR statement.

  Pushes the for stack.
  Returns line to jump to, or -1 to end program

*/
BSTATIC linenumbertype dofor(void)
{
  LVALUE lv;
  char id[IDLENGTH];
  char nextid[IDLENGTH];
  int len;
  numtype initval;
  numtype toval;
  numtype stepval;
  int answer;

  match(FOR);
  getid(string, id, &len);

  lvalue(&lv);
  if(lv.type != FLTID)
  {
    seterror(ERR_BADTYPE);
	return -1;
  }
  match(EQUALS);
  initval = expr();
  match(TO);
  toval = expr();
  if(token == STEP)
  {
    match(STEP);
	stepval = expr();
  }
  else
    stepval = ((numtype)1);

  *lv.d.dval = initval;

  if(nfors > MAXFORS - 1)
  {
	seterror(ERR_TOOMANYFORS);
	return -1;
  }
  if(((stepval < 0) && (initval < toval)) || ((stepval > 0) && (initval > toval)))
  {
	const char *savestring = string;
	while ((++curline) < nlines) 
	{
	  string = lines[curline].str;
      errorflag = 0;
	  token = gettoken();
	  if (token == VALUE) 
		 match(VALUE); 
	  if (token == NEXT)
	  {
	    match(NEXT);
		if(token == FLTID || token == DIMFLTID)
		{
          getid(string, nextid, &len);
		  if(!strcmp(id, nextid))
		  {
			answer = getnextline();
			string = savestring;
			token = gettoken();
			return answer ? answer : -1;
		  }
		}
	  } 
	}
	seterror(ERR_NONEXT);
	return -1;
  }
  else
  {
	FORLOOP *f = &forstack[nfors];
	strcpy(f->id, id);
	f->nextline = getnextline();
	f->step = stepval;
	f->toval = toval;
	nfors++;
    return 0;
  }
}

/*
  the NEXT statement
  updates the counting index, and returns line to jump to
*/
BSTATIC linenumbertype donext(void)
{
  char id[IDLENGTH];
  int len;
  LVALUE lv;
  FORLOOP *f;

  match(NEXT);

  if(nfors)
  {
    getid(string, id, &len);
    lvalue(&lv);
	if(lv.type != FLTID)
	{
      seterror(ERR_BADTYPE);
	  return -1;
	}
	f = &forstack[nfors-1];
    if(strcmp(id, f->id)) {
		seterror(ERR_NOFOR);
		return -1;
	} 
    *lv.d.dval += f->step;
	if( (f->step < 0 && *lv.d.dval < f->toval) ||
		(f->step > 0 && *lv.d.dval > f->toval) )
	{
	  nfors--;
	  return 0;
	}
	else
	{
      return f->nextline;
	}
  }
  else
  {
    seterror(ERR_NOFOR);
	return -1;
  }
}


/*
  the INPUT statement
*/
BSTATIC void doinput(void)
{
  LVALUE lv;
  char buf[80];
  int err;

  match(INPUT);
  lvalue(&lv);

  switch(lv.type)
  {
  case FLTID:
	err = innum(lv.d.dval);
	if (err < 0)
	{
       seterror(ERR_BADVALUE);
	   return;
	}
	break;
  case STRID:
	if(*lv.d.sval)
	{
	  free(*lv.d.sval);
	  *lv.d.sval = 0;
	}
    err = instrn(buf,sizeof(buf)-1);
	if (err < 0)
	{
	  seterror(ERR_INPUTTOOLONG);
	  return;
	}
	*lv.d.sval = stringarraychar(buf);
	if(!*lv.d.sval)
	{
      seterroroutofmemory();
	  return;
	}
	break;
  default:
	  return;
  }
}

/*
  the REM statement.
  Note is unique as the rest of the line is not parsed

*/
BSTATIC void dorem(void)
{
  match(REM);
  return;
}

/*
  Get an lvalue from the environment
  Params: lv - structure to fill.
  Notes: missing variables (but not out of range subscripts)
         are added to the variable list.
*/
BSTATIC void lvalue(LVALUE *lv)
{
  char name[IDLENGTH];
  int len;
  VARIABLE *var;
  DIMVAR *dimvar;
  dimsize index[MAXDIMS];
  void *valptr = 0;
  int type;
  int i;
  
  lv->type = ERROR;
  lv->d.sval = 0;

  switch(token)
  {
    case FLTID:
	  getid(string, name, &len);
	  match(FLTID);
	  var = findvariable(name);
	  if(!var)
		var = addfloat(name);
	  if(!var)
	  {
	    seterroroutofmemory();
		return;
	  }
	  lv->type = FLTID;
	  lv->d.dval = &var->d.dval;
	  break;
    case STRID:
	  getid(string, name, &len);
	  match(STRID);
	  var = findvariable(name);
	  if(!var)
		var = addstring(name);
	  if(!var)
	  {
	    seterroroutofmemory();
		return;
	  }
	  lv->type = STRID;
	  lv->d.sval = &var->d.sval;
	  break;
	case DIMFLTID:
	case DIMSTRID:
	  type = (token == DIMFLTID) ? FLTID : STRID;
	  getid(string, name, &len);
	  match(token);
	  dimvar = finddimvar(name);
	  if(dimvar)
	  {
		i=0;
		while (i<dimvar->ndims)
		{
			index[i] = integer( expr() );
			if (++i != dimvar->ndims)
				match(COMMA);
		}
		if (errorflag == 0)
			valptr = getdimvar(dimvar, index);
		match(CPAREN);
	  }
	  else
	  {
	    seterror(ERR_NOSUCHVARIABLE);
        return;
      }
	  if(valptr)
	  {
		lv->type = type;
	    if(type == FLTID)
	      lv->d.dval = valptr;
	    else if(type == STRID)
	      lv->d.sval = valptr;
		else
		  ASSERTDEBUG(basicassert(0,"bad lv->type"));
	  }
	  break;
	default:
	  seterror(ERR_SYNTAX);
  }
}

/*
  parse a boolean expression
  consists of expressions or strings and relational operators,
  and parentheses
*/
BSTATIC int boolexpr(void)
{
  int left;
  int right;
  
  left = boolfactor();

  while(1)
  {
    switch(token)
	{
	  case AND:
        match(AND);
		right = boolexpr();
		return (left && right) ? 1 : 0;
	  case OR:
	    match(OR);
		right = boolexpr();
		return (left || right) ? 1 : 0;
	  default:
		return left;
	}
  }
}

/*
  boolean factor, consists of expression relop expression
    or string relop string, or ( boolexpr() )
*/
BSTATIC int boolfactor(void)
{
  int answer;
  numtype left;
  numtype right;
  int op;
  STRINGARRAY *strleft;
  STRINGARRAY *strright;
  int cmp;

  switch(token)
  {
    case OPAREN:
	  match(OPAREN);
	  answer = boolexpr();
	  match(CPAREN);
	  break;
	default:
	  if(isstring(token))
	  {
	    strleft = stringexpr();
		op = relop();
		strright = stringexpr();
		if(!strleft || !strright)
		{
		  if(strleft)
		    free(strleft);
		  if(strright)
		    free(strright);
		  return 0;
		}
		cmp = stringarraycmp(strleft, strright);
		switch(op)
		{
		  case ROP_EQ:
			  answer = cmp == 0 ? 1 : 0;
			  break;
		  case ROP_NEQ:
			  answer = cmp == 0 ? 0 : 1;
			  break;
		  case ROP_LT:
			  answer = cmp < 0 ? 1 : 0;
			  break;
		  case ROP_LTE:
			  answer = cmp <= 0 ? 1 : 0;
			  break;
		  case ROP_GT:
			  answer = cmp > 0 ? 1 : 0;
			  break;
		  case ROP_GTE:
			  answer = cmp >= 0 ? 1 : 0;
			  break;
		  default:
			answer = 0;
		}
		free(strleft);
		free(strright);
	  }
	  else
	  {
	    left = expr();
		op = relop();
		right = expr();
		switch(op)
		{
		  case ROP_EQ:
			  answer = (left == right) ? 1 : 0;
			  break;
		  case ROP_NEQ:
			  answer = (left != right) ? 1 : 0;
			  break;
		  case ROP_LT:
			  answer = (left < right) ? 1 : 0;
			  break;
		  case ROP_LTE:
			  answer = (left <= right) ? 1 : 0;
			  break;
		  case ROP_GT:
			  answer = (left > right) ? 1 : 0;
			  break;
		  case ROP_GTE:
			  answer = (left >= right) ? 1 : 0;
			  break;
		  default:
			 errorflag = 1;
			 return 0;

		}
	  }
	  
  }

  return answer;
}

/*
  get a relational operator
  returns operator parsed or ERROR
*/
BSTATIC int relop(void)
{
  switch(token)
  {
    case EQUALS:
	  match(EQUALS);
	  return ROP_EQ;
    case GREATER:
	  match(GREATER);
	  if(token == EQUALS)
	  {
        match(EQUALS);
		return ROP_GTE;
	  }
	  return ROP_GT; 
	case LESS:
      match(LESS);
	  if(token == EQUALS)
	  {
	    match(EQUALS);
		return ROP_LTE;
	  }
	  else if(token == GREATER)
	  {
	    match(GREATER);
		return ROP_NEQ;
	  }
	  return ROP_LT;
	default:
	  seterror(ERR_SYNTAX);
	  return ERROR;
  }
}

/*
  parses an expression
*/
BSTATIC numtype expr(void)
{
  numtype left;
  numtype right;

  left = term();

  while(1)
  {
    switch(token)
	{
	case PLUS:
	  match(PLUS);
	  right = term();
	  left += right;
	  break;
	case MINUS:
	  match(MINUS);
      right = term();
	  left -= right;
	  break;
	default:
	  return left;
	}
  }
}

/*
  parses a term 
*/
BSTATIC numtype term(void)
{
  numtype left;
  numtype right;

  left = factor();
  
  while(1)
  {
    switch(token)
	{
	case MULT:
	  match(MULT);
	  right = factor();
	  left *= right;
	  break;
	case DIV:
	  match(DIV);
	  right = factor();
	  if(right != ((numtype)0))
	    left /= right;
	  else
		seterror(ERR_DIVIDEBYZERO);
	  break;
	case MOD:
	  match(MOD);
	  right = factor();
#ifdef USEFLOATS
	  left = fmod(left, right);
#else
	  left = left % right;
#endif
	  break;
	case BITOR:
	  match(BITOR);
	  right = factor();
	  left = (numtype) (((unsigned int)left) | ((unsigned int)right));
	  break;
	case BITAND:
	  match(BITAND);
	  right = factor();
	  left = (numtype) (((unsigned int)left) & ((unsigned int)right));
	  break;
	case BITXOR:
	  match(BITXOR);
	  right = factor();
	  left = (numtype) (((unsigned int)left) ^ ((unsigned int)right));
	  break;
	default:
	  return left;
	}
  }

}

/*
  parses a factor
*/
BSTATIC numtype factor(void)
{
  numtype answer = 0;
  STRINGARRAY *str;
  int len;

  switch(token)
  {
    case OPAREN:
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  break;
	case VALUE:
	  answer = getvalue(string, &len);
	  match(VALUE);
	  break;
	case BITNOT:
	  match(BITNOT);
	  answer = (numtype) (~((unsigned int) factor()));
	  break;
	case MINUS:
	  match(MINUS);
	  answer = -factor();
	  break;
	case FLTID:
	  answer = variable();
	  break;
	case DIMFLTID:
	  answer = dimvariable();
	  break;
#ifdef USEFLOATS
	case PI:
	  answer = 3.14159265359;
	  match(PI);
	  break;
	case SIN:
	  match(SIN);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  answer = sin(answer);
	  break;
	case COS:
	  match(COS);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  answer = cos(answer);
	  break;
	case TAN:
	  match(TAN);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  answer = tan(answer);
	  break;
	case LOG:
	  match(LOG);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  if(answer > 0)
	    answer = log(answer);
	  else
		seterror(ERR_NEGLOG);
	  break;
	case EXP:
	  match(EXP);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
      answer = exp(answer);
	  break;
	case POW:
      match(POW);
	  match(OPAREN);
	  answer = expr();
	  match(COMMA);
      answer = pow(answer, expr());
	  match(CPAREN);
	  break;
	case SQRT:
	  match(SQRT);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  if(answer >= ((numtype)0))
		answer = sqrt(answer);
	  else
		seterror(ERR_NEGSQRT);
	  break;
    case ASIN:
	  match(ASIN);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  if(answer >= -1 && answer <= 1)
	    answer = asin(answer);
	  else
		seterror(ERR_BADSINCOS);
	  break;
    case ACOS:
	  match(ACOS);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  if(answer >= ((numtype)(-1)) && answer <= ((numtype)1))
		answer = acos(answer);
	  else
	    seterror(ERR_BADSINCOS);
	  break;
    case ATAN:
	  match(ATAN);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  answer = atan(answer);
	  break;
#endif
	case ABS:
	  match(ABS);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
#ifdef USEFLOATS
	  answer = fabs(answer);
#else
	  answer = answer >= 0 ? answer : -answer;
#endif
	  break;
	case INKEY:
	  match(INKEY);
	  answer = inkey();
	  break;
#ifdef PEEKPOKE
	case PEEK:
	  match(PEEK);
	  match(OPAREN);
	  {
        unsigned int adr = ((unsigned int)expr());	  
		if (!errorflag)
			answer = (numtype) (*((unsigned int *)adr));
	  }
	  match(CPAREN);
	  break;
#endif
    case LEN:
	  match(LEN);
	  match(OPAREN);
	  str = stringexpr();
	  match(CPAREN);
	  if(str)
	  {
	    answer = str->len;
	    free(str);
	  }
	  else
		answer = 0;
	  break;
    case ASCII:
	  match(ASCII);
	  match(OPAREN);
	  str = stringexpr();
	  if (token == COMMA) {
		 match(COMMA);
		 len = ((unsigned int)expr()) - 1;
	  } else len = 0;
	  match(CPAREN);
	  answer = -1;
	  if (str) {
		if ((len >= 0) && (len < str->len))
			answer = (STRINGOF(str))[len];
		free(str);
	  }
	  break;
	case ERR:
	  match(ERR);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  answer = (answer != 0) ? errorline : lasterrorflag;
	  break;
    case INT:
	  match(INT);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
#ifdef USEFLOATS
	  answer = floor(answer);
#endif
	  break;
    case RND:
	  match(RND);
	  match(OPAREN);
	  answer = expr();
	  match(CPAREN);
	  answer = integer(answer);
#ifdef USEFLOATS
	  if(answer > 1)
		answer = floor(rand()/(RAND_MAX + 1.0) * answer);
	  else if(answer == 1)
		answer = rand()/(RAND_MAX + 1.0);
	  else
	  {
		if(answer < 0)
		  srand( (unsigned) -answer);
		answer = 0;
	  }
#else
	  if(answer > 1)
		answer = rand() % answer;
	  else if(answer == 1)
		answer = rand();
	  else
	  {
		if(answer < 0)
		  srand( (unsigned) -answer);
		answer = 0;
	  }
#endif
	  break;
    case VAL:
	  match(VAL);
	  match(OPAREN);
	  str = stringexpr();
	  match(CPAREN);
	  if(str)
	  {
#ifdef USEFLOATS
	    answer = strtod(STRINGOF(str), 0);
#else
	    answer = mystrtol(STRINGOF(str), 0);
#endif
		free(str);
	  }
	  else
		answer = 0;
	  break;
	case VALLEN:
	{ 
	  stringchar *end;
	  match(VALLEN);
	  match(OPAREN);
	  str = stringexpr();
	  match(CPAREN);
	  if(str)
	  {
#ifdef USEFLOATS
	    strtod(STRINGOF(str), &end);
#else
		mystrtol(STRINGOF(str), &end);
#endif
		answer = end - STRINGOF(str);
		free(str);
	  }
	  else
		answer = ((numtype)0);
	  break;
	}
	case INSTR:
	  answer = instr();
	  break;
	case IND:
	case INADC:
	  {
	    tokennum t = token;
		match(t);
		match(OPAREN);
		answer = expr();
		match(CPAREN);
		if (!errorflag) {
			answer = (t == IND) ? ind(answer) : inadc(answer);
		}
		break;
	  }
	default:
	  if(isstring(token))
		seterror(ERR_TYPEMISMATCH);
	  else
	    seterror(ERR_SYNTAX);
	  break;
  }
  return answer;
}

/*
  calcualte the INSTR() function.
*/
BSTATIC numtype instr(void)
{
  STRINGARRAY *str;
  STRINGARRAY *substr;
  numtype answer = 0;
  int offset;

  match(INSTR);
  match(OPAREN);
  str = stringexpr();
  match(COMMA);
  substr = stringexpr();
  match(COMMA);
  offset = integer( expr() );
  offset--;
  match(CPAREN);

  if(!str || ! substr)
  {
    if(str)
	  free(str);
	if(substr)
	  free(substr);
	return 0;
  }

  answer = strstrarray(str, substr, offset)+1;

  free(str);
  free(substr);

  return answer;
}
/*
  get the value of a scalar variable from string
  matches FLTID
*/
BSTATIC numtype variable(void)
{
  VARIABLE *var;
  char id[IDLENGTH];
  int len;

  getid(string, id, &len);
  match(FLTID);
  var = findvariable(id);
  if (var->type == FLTID)
    return var->d.dval;
  else
  {
	seterror(ERR_NOSUCHVARIABLE);
	return ((numtype)0);
  }
}

/*
  get value of a dimensioned variable from string.
  matches DIMFLTID
*/
BSTATIC numtype dimvariable(void)
{
  DIMVAR *dimvar;
  char id[IDLENGTH];
  int len;
  dimsize index[MAXDIMS];
  int i;
  numtype *answer;

  getid(string, id, &len);
  match(DIMFLTID);
  dimvar = finddimvar(id);
  if(!dimvar)
  {
    seterror(ERR_NOSUCHVARIABLE);
	return ((numtype)0);
  }

  if(dimvar)
  {
	  i=0;
	  while (i<dimvar->ndims)
	  {
		  index[i] = integer( expr() );
		  if (++i != dimvar->ndims)
			  match(COMMA);
	  }
	answer = getdimvar(dimvar, index);
	match(CPAREN);
  }

  if(answer)
	return *answer;

  return ((numtype)0);

}

/*
  find a scalar variable invariables list
  Params: id - id to get
  Returns: pointer to that entry, 0 on fail
*/
BSTATIC VARIABLE *findvariable(const char *id)
{
  VARIABLE *v = variables;
  VARIABLE *vend = &variables[nvariables];

  while (v<vend) {
	  if(!strcmp(v->id, id)) 
		return v;
	  v++;
  }
  return 0;
}

/*
  get a dimensioned array by name
  Params: id (includes opening parenthesis)
  Returns: pointer to array entry or 0 on fail
*/
BSTATIC DIMVAR *finddimvar(const char *id)
{
  DIMVAR *v = dimvariables;
  DIMVAR *vend = &dimvariables[ndimvariables];

  while (v<vend) {
	if(!strcmp(v->id, id))
	  return v;
	v++;
  }
  return 0;
}

/*
  dimension an array.
  Params: id - the id of the array (include leading ()
          ndims - number of dimension (1-5)
		  ... - integers giving dimension size, 
*/
BSTATIC DIMVAR *dimension(const char *id, int ndims, dimsize *intdims)
{
  DIMVAR *dv;
  int size ;
  int oldsize;
  int i;
  numtype *dtemp;
  STRINGARRAY **stemp;

  if(ndims > MAXDIMS)
	return 0;

  dv = finddimvar(id);
  if(!dv)
	dv = adddimvar(id);
  if(!dv)
  {
    seterroroutofmemory();
	return 0;
  }

  oldsize = dv->ndims ? computedimsize(dv) : 0;

  size = 1;
  for(i=0;i<ndims;i++)
    size *= intdims[i];

  switch(dv->type)
  {
    case FLTID:
      dtemp = realloc(dv->d.dval, size * sizeof(numtype));
      if(dtemp)
        dv->d.dval = dtemp;
	  else
	  {
		seterroroutofmemory();
	    return 0;
	  }
      for(i=oldsize;i<size;i++)
		  dv->d.dval[i] = ((numtype)0);
	  break;
	case STRID:
	  if(dv->d.str)
	  {
	    for(i=size;i<oldsize;i++) {
		  stemp = &dv->d.str[i];
		  if(*stemp)
		  {
			free(*stemp);
		    *stemp = 0;
		  }
		}
	  }
	  stemp = realloc(dv->d.str, size * sizeof(STRINGARRAY *));
	  if(stemp)
	  {
		dv->d.str = stemp;
	    for(i=oldsize;i<size;i++)
		  dv->d.str[i] = 0;
	  }
	  else
	  {
		 for(i=0;i<oldsize;i++) {
	      stemp = &dv->d.str[i];
		  if(*stemp)
		  {
            free(*stemp);
		    *stemp = 0;
		  }
		 }
	    seterroroutofmemory();
		return 0;
	  }
	  break;
	default:
	  ASSERTDEBUG(basicassert(0,"bad dv->type"));
  }

  for(i=0;i<MAXDIMS;i++)
	dv->dim[i] = intdims[i];
  dv->ndims = ndims;

  return dv;
}

/*
  get the address of a dimensioned array element.
  works for both string and real arrays.
  Params: dv - the array's entry in variable list
          ... - integers telling which array element to get
  Returns: the address of that element, 0 on fail
*/ 
BSTATIC void *getdimvar(DIMVAR *dv, dimsize *index)
{
  int i, ind;
  void *answer = 0;

  for(i=0;i<dv->ndims;i++)
    if(index[i] > dv->dim[i] || index[i] < 1)
	{
	  seterror(ERR_BADSUBSCRIPT);
	  return 0;
	}
    ind = index[dv->ndims-1]-1;
  for (i=(dv->ndims-1);i>0;) {
	  i--;
	  ind = ind*dv->dim[i] + (index[i]-1);
  }
  if(dv->type == FLTID)
	  answer = &dv->d.dval[ind];
  else if (dv->type == STRID)
	  answer = &dv->d.str[ind]; 
  return answer;
}

#ifndef NEXTLG
#define NEXTLG 1
#endif

BSTATIC int nextlargest(int n)
{
   const int ng = ((1 << NEXTLG)-1);
   return  ((n+ng)&(~ng));
}

BSTATIC VARIABLE *addnewvar(void)
{
  VARIABLE *vars;
  int nv = nvariables + 1;

  if (nextlargest(nvariables) != nextlargest(nv)) {
	vars = realloc(variables, nextlargest(nv) * sizeof(VARIABLE));
	if (!vars) {
		seterroroutofmemory();
		return 0;
	}
	variables = vars;
  }
  nvariables = nv;
  return &variables[nvariables-1];
}

/*
  add a real varaible to our variable list
  Params: id - id of varaible to add.
  Returns: pointer to new entry in table
*/
BSTATIC VARIABLE *addfloat(const char *id)
{
  VARIABLE *v = addnewvar();

  if (!v)
	  return 0;
  strcpy(v->id, id);
  v->d.dval = ((numtype)0);
  v->type = FLTID;
  return v;
}

/*
  add a string variable to table.
  Params: id - id of variable to get (including trailing $)
  Retruns: pointer to new entry in table, 0 on fail.       
*/
BSTATIC VARIABLE *addstring(const char *id)
{
  VARIABLE *v = addnewvar();

  if (!v)
	  return 0;
  strcpy(v->id, id);
  v->d.sval = 0;
  v->type = STRID;
  return v;
}

/*
  add a new array to our symbol table.
  Params: id - id of array (include leading ()
  Returns: pointer to new entry, 0 on fail.
*/
BSTATIC DIMVAR *adddimvar(const char *id)
{
  DIMVAR *vars, *v;
  int nv = ndimvariables + 1;

  if (nextlargest(ndimvariables) != nextlargest(nv)) {
 	  vars = realloc(dimvariables, nextlargest(nv) * sizeof(DIMVAR));
	  if (!vars) {
		seterroroutofmemory();
		return 0;
	  }
	  dimvariables = vars;
  }
  v = &dimvariables[ndimvariables];
  strcpy(v->id, id);
  v->d.dval = 0;
  v->d.str = 0;
  v->ndims = 0;
  v->type = strchr(id, '$') ? STRID : FLTID;
  ndimvariables = nv;
  return v;
}

/*
  high level string parsing function.
  Returns: a malloced pointer, or 0 on error condition.
  caller must free!
*/
BSTATIC STRINGARRAY *stringexpr(void)
{
  STRINGARRAY *left;
  STRINGARRAY *right;
  STRINGARRAY *temp;

  switch(token)
  {
    case DIMSTRID:
	  left = stringarraydup(stringdimvar());
	  break;
    case STRID:
      left = stringarraydup(stringvar());
	  break;
	case QUOTE:
	  left = stringliteral();
	  break;
	case CHRSTRING:
	  left = chrstring();
	  break;
	case STRSTRING:
	  left = strstring();
	  break;
	case HEXSTRING:
	  left = hexstring();
	  break;
	case LEFTSTRING:
	  left = leftstring();
	  break;
	case RIGHTSTRING:
	  left = rightstring();
	  break;
	case MIDSTRING:
	  left = midstring();
	  break;
    case STRINGSTRING:
	  left = stringstring();
	  break;
	default:
	  if(!isstring(token))
		seterror(ERR_TYPEMISMATCH);
	  else
	    seterror(ERR_SYNTAX);
	  return createstringarray(0);
  }

  if(!left)
  {
    seterroroutofmemory();
    return 0;
  }

  switch(token)
  {
    case PLUS:
	  match(PLUS);
	  right = stringexpr();
	  if(right)
	  {
	    temp = stringarrayconcat(left, right);
	    free(right);
		if(temp)
		{
		  free(left);
          left = temp;
		}
		else
		  seterroroutofmemory();
	  }
	  else
		seterroroutofmemory();
	  break;
	default:
	  return left;
  }

  return left;
}

/*
  parse the CHR$ token
*/
BSTATIC STRINGARRAY *chrstring(void)
{
  numtype x;
  STRINGARRAY s, *answer;
  
  match(CHRSTRING);
  match(OPAREN);
  x = integer( expr() );
  match(CPAREN);

  s.len = 1;
  s.beginstring[0] = x;

  answer = stringarraydup(&s);

  if(!answer)
	seterroroutofmemory();

  return answer;
}

/*
  parse the STR$ token
*/
BSTATIC STRINGARRAY *hexstring(void)
{
  numtype x;
  STRINGARRAY *answer;

  match(HEXSTRING);
  match(OPAREN);
  x = expr();
  match(CPAREN);

  answer = stringarraychar(myitoahex((int)x));
  if(!answer)
	seterroroutofmemory();
  return answer;
}

/*
  parse the STR$ token
*/
BSTATIC STRINGARRAY *strstring(void)
{
  numtype x;
  STRINGARRAY *answer;

  match(STRSTRING);
  match(OPAREN);
  x = expr();
  match(CPAREN);

#ifdef USEFLOATS
  answer = stringarraychar(mydtoa(x));
#else
  answer = stringarraychar(myitoa(x));
#endif
  if(!answer)
	seterroroutofmemory();
  return answer;
}

/*
  parse the LEFT$ token
*/
BSTATIC STRINGARRAY *leftstring(void)
{
  STRINGARRAY *str;
  STRINGARRAY *answer;
  int x;
  
  match(LEFTSTRING);
  match(OPAREN);
  str = stringexpr();
  match(COMMA);
  x = integer( expr() );
  match(CPAREN);
  
  if(!str)
	return 0;

  answer = stringarrayduppart(str,0,x);
  free(str);
  if(!answer)
	seterroroutofmemory();
  return answer;
}

/*
  parse the RIGHT$ token
*/
BSTATIC STRINGARRAY *rightstring(void)
{
  STRINGARRAY *str;
  STRINGARRAY *answer;
  int x;

  match(RIGHTSTRING);
  match(OPAREN);
  str = stringexpr();
  match(COMMA);
  x = integer( expr() );
  match(CPAREN);
  if(!str)
	return 0;

  x = str->len - x;
  answer = stringarrayduppart(str,x < 0 ? 0 : x,str->len);
  free(str);
  if(!answer)
	seterroroutofmemory();
  return answer;
}

/*
  parse the MID$ token
*/
BSTATIC STRINGARRAY *midstring(void)
{
  STRINGARRAY *str;
  STRINGARRAY *answer;
  int x;
  int len;

  match(MIDSTRING);
  match(OPAREN);
  str = stringexpr();
  match(COMMA);
  x = integer( expr() );
  match(COMMA);
  len = integer( expr() );
  match(CPAREN);

  if(!str)
	return 0;

  if(len == -1)
	len = str->len;
  
  answer = stringarrayduppart(str,x-1,len);
  free(str);
  if(!answer)
	seterroroutofmemory();
  return answer;
}

/*
  parse the string$ token
*/
BSTATIC STRINGARRAY *stringstring(void)
{
  STRINGARRAY *str;
  STRINGARRAY *answer;
  int N;
  int i;

  match(STRINGSTRING);
  match(OPAREN);
  N = integer( expr() );
  match(COMMA);
  str = stringexpr();
  match(CPAREN);

  if(!str)
	return 0;

  if(N < 1)
  {
    free(str);
	answer = createstringarray(0);
	if(answer == NULL)
	  seterroroutofmemory();
	return answer;
  }
  answer = createstringarray( N * str->len);
  if(answer == NULL)
  {
    free(str);
	seterroroutofmemory();
	return 0;
  }
  for(i=0; i < N; i++)
    memmove(&answer->beginstring[str->len*i],str->beginstring,str->len);
  free(str);
  return answer;
}

/*
  read a dimensioned string variable from input.
  Returns: pointer to string (not malloced) 
*/
BSTATIC STRINGARRAY *stringdimvar(void)
{
  char id[IDLENGTH];
  int len;
  DIMVAR *dimvar;
  STRINGARRAY **answer;
  dimsize index[MAXDIMS];
  int i;

  getid(string, id, &len);
  match(DIMSTRID);
  dimvar = finddimvar(id);

  if(dimvar)
  {
	i=0;
	while (i<dimvar->ndims) {
		index[i] = integer( expr() );
		if (++i != dimvar->ndims)
			match(COMMA);
	}
	answer = getdimvar(dimvar, index);
	match(CPAREN);
  }
  else
	seterror(ERR_NOSUCHVARIABLE);

  if(!errorflag)
	if(*answer)
      return *answer;
	 
  return EMPTYSTRING;
}

/*
  parse a string variable.
  Returns: pointer to string (not malloced) 
*/
BSTATIC STRINGARRAY *stringvar(void)
{
  char id[IDLENGTH];
  int len;
  VARIABLE *var;

  getid(string, id, &len);
  match(STRID);
  var = findvariable(id);
  if(var)
  {
    if(var->type == STRID)
	  return var->d.sval;
	return EMPTYSTRING;
  }
  seterror(ERR_NOSUCHVARIABLE);
  return EMPTYSTRING;
}

/*
  parse a string literal
  Returns: malloced string literal
  Notes: newlines aren't allwed in literals, but blind
         concatenation across newlines is. 
*/
BSTATIC STRINGARRAY *stringliteral(void)
{
  int len = 1;
  STRINGARRAY *answer = NULL;
  STRINGARRAY *substr;
  STRINGARRAY *temp;
  char *end;

  while(token == QUOTE)
  {
    string = skipspaces(string);
    end = mystrend(string, '"');
    if(end)
	{
      len = end - string;
      substr = createstringarray(len);
	  if(!substr)
	  {
	    seterroroutofmemory();
	    return answer;
	  }
	  mystrgrablit(substr, string);
	  if(answer)
	  {
		temp = stringarrayconcat(answer, substr);
	    free(substr);
		free(answer);
		answer = temp;
		if(answer == NULL)
		{
	      seterroroutofmemory();
		  return NULL;
		}
	  }
	  else
	    answer = substr;
	  string = end;
	}
	else
	{
	  seterror(ERR_SYNTAX);
	  return answer;
	}

	match(QUOTE);
  }
  return answer;
}

#ifdef USEFLOATS
/*
  cast a numtype to an integer, triggering errors if out of range
*/
BSTATIC int integer(numtype x)
{
  if( x < INT_MIN || x > INT_MAX )
	seterror( ERR_BADVALUE );
  if( x != floor(x) )
	seterror( ERR_NOTINT );
  return (int) x;
}
#endif

/*
  check that we have a token of the passed type 
  (if not set the errorflag)
  Move parser on to next token. Sets token and string.
*/
BSTATIC void match(int tok)
{
  if(token != tok)
  {
	seterror(ERR_SYNTAX);
	return;
  }
  string = skipspaces(string);
  string += tokenlen(string, token);
  token = gettoken();
  if(token == ERROR)
	seterror(ERR_SYNTAX);
}

/*
  set the errorflag.
  Params: errorcode - the error.
  Notes: ignores error cascades
*/
BSTATIC void seterror(int errorcode)
{
  if(errorflag == 0 || errorcode == 0)
	errorflag = errorcode;
}

/*
  get the next line number
  Params: str - pointer to parse string
  Returns: line no of next line, 0 if end
  Notes: goes to newline, then finds
         first line starting with a digit.
*/
BSTATIC linenumbertype getnextline(void)
{
  int nextn = curline+1;
  if (nextn >= nlines)
		return 0;
  return lines[nextn].no;
}

BSTATIC int isspecialtoken(tokennum c)
{
	if ((c >= (TOKENBASE+1)) && (c <= (TOKENBASE + TOKENLISTENTRIES)))
		return 1;
	return ((c==QUOTE)||(c==BITAND)||(c==OPAREN)||(c==CPAREN)||
	        (c==MULT)||(c==PLUS)||(c==COMMA)||(c==MINUS)||
			(c==DIV)||(c==SEMICOLON)||(c==LESS)||(c==EQUALS)||
			(c==GREATER)||(c==BITOR)||(c==BITNOT)||(c==BITXOR)||
			(c==SHORTPRINT));
}

void inituntokenizestate(untokstat *utk, char *str)
{
	utk->s = str;
	utk->toknum = 0;
}

int untokenizecode(untokstat *utk)
{
	int c;
	if (utk->toknum == 0) {
		c = *(utk->s)++;
		if ((c >= (TOKENBASE+1)) && (c <= (TOKENBASE + TOKENLISTENTRIES))) {
			utk->toknum = c;
			utk->charnum = 0;
		}
	}
	if ((utk->toknum >= (TOKENBASE+1)) && (utk->toknum <= (TOKENBASE + TOKENLISTENTRIES))) 
	{
		tokenlist *t = &tl[utk->toknum-(TOKENBASE+1)];
		c = t->tokenname[utk->charnum++];
		if ((utk->charnum == t->length) || (utk->charnum == -t->length))
			utk->toknum=0;
	}
	return c;
}

void inittokenizestate(tokstat *tk)
{
	tk->notlastspace = tk->inquote = 0;
}

void tokenizeline(char *str, char **end, tokstat *tk, addbasictoken abt, void *v)
{
  tokenlist *t;
  int high, low, mid, c, ctok, ctokl;

  while (str < *end)
  {
	if (tk->inquote) {
		(*abt)(*str,v);
		if (*str == '\"') {
			if (*(++str) == '\"')
				(*abt)(*str++,v);
			else 
				tk->inquote = 0;
		} else 
			tk->inquote = (*str++ != '\n');
	} else {
		ctok = *str;
		ctokl = 1;
		if (ctok == '\"') {
			tk->inquote = 1;
		} else if (!tk->notlastspace) {
			low = 0;
			high = TOKENLISTENTRIES - 1;
			while (low <= high)
			{
				mid = (high + low)/2;
				t = &tl[mid];
				c = strncasecmp(str, t->tokenname, t->length > 0 ? t->length : -t->length);
				if (c < 0)
					high = mid - 1;
				else if (c > 0)
					low = mid + 1;
				else {
						if (t->length < 0) 
						{
							if (isalnum(str[-t->length])) 
								low = mid + 1;
							else {
									ctok = mid+(TOKENBASE+1);
									ctokl = -t->length;
									break;
							}
						} else {
							ctok = mid+(TOKENBASE+1);
							ctokl = t->length;
							break;
						}
					}
				}
			}
		str += ctokl;
		(*abt)(ctok,v);
		tk->notlastspace = isalnum(ctok);
	}
  }
  *end = str;
}


/*
  get a token from the string
  Params: str - string to read token from
  Notes: ignores white space between tokens
*/
BSTATIC tokennum gettoken(void)
{
  char *str = skipspaces(string);
  if(isdigit(*str)) {
    return VALUE;
  }
  if (*str==0) {
	  return EOS;
  }
  if (isspecialtoken(*str)) {
	 return *str;
  }
  if(isalpha(*str))
  {
	while(isalnum(*str))
	  str++;
	switch(*str)
	{
	  case '$':
		return str[1] == '(' ? DIMSTRID : STRID;
	  case '(':
		return DIMFLTID;
	  default:
		return FLTID;
	}
  }
  return ERROR;
}

/*
  get the length of a token.
  Params: str - pointer to the string containing the token
          token - the type of the token read
  Returns: length of the token, or 0 for EOL to prevent
           it being read past.
*/
BSTATIC int tokenlen(const char *str, tokennum token)
{
  int len;
  char buff[IDLENGTH];

  if (token == EOS)
	  return 0;
  if (isspecialtoken(token))
      return 1;
  if (token == VALUE) {
	  getvalue(str, &len);
	  return len;
  }
  if ((token == STRID) || (token == DIMSTRID) || (token == DIMFLTID) || (token == FLTID)) {
	  getid(str, buff, &len);
	  return len;
  }
  ASSERTDEBUG(basicassert(0,"tokenlen"));
  return 0;
}

/*
  test if a token represents a string expression
  Params: token - token to test
  Returns: 1 if a string, else 0
*/
BSTATIC int isstring(tokennum token)
{
  if(token == STRID || token == QUOTE || token == DIMSTRID 
	  || token == CHRSTRING || token == STRSTRING || token == HEXSTRING
	  || token == LEFTSTRING || token == RIGHTSTRING 
	  || token == MIDSTRING || token == STRINGSTRING)
	return 1;
  return 0;
}

/*
  get a numerical value from the parse string
  Params: str - the string to search
          len - return pinter for no chars read
  Retuns: the value of the string.
*/
BSTATIC numtype getvalue(const char *str, int *len)
{
  numtype answer;
  char *end;

#ifdef USEFLOATS
  answer = strtod(str, &end);
#else
  answer = mystrtol(str, &end);
#endif
  *len = end - str;
  ASSERTDEBUG(basicassert(end != str,"getvalue")); 
  return answer;
}

/*
  getid - get an id from the parse string:
  Params: str - string to search
          out - id output [IDLENGTH chars max ]
		  len - return pointer for id length
  Notes: triggers an error if id > (IDLENGTH-1) chars
         the id includes the $ and ( qualifiers.
*/
BSTATIC void getid(const char *str, char *out, int *len)
{
  int nread = 0;
  str = skipspaces(str);
  ASSERTDEBUG(basicassert(isalpha(*str),"getid"));
  while(isalnum(*str))
  {
	if(nread < (IDLENGTH-1))
	  out[nread++] = *str++;
	else
	{
      seterror(ERR_IDTOOLONG);
	  break;
	}
  }
  if(*str == '$')
  {
	if(nread < (IDLENGTH-1))
	  out[nread++] = *str++;
	else
	 seterror(ERR_IDTOOLONG);
  }
  if(*str == '(')
  {
	if(nread < (IDLENGTH-1))
	  out[nread++] = *str++;
	else
	  seterror(ERR_IDTOOLONG);
  }
  out[nread] = 0;
  *len = nread;
}

/*
  grab a literal from the parse string.
  Params: dest - destination string
          src - source string
  Notes: strings are in quotes, numtype quotes the escape
*/
BSTATIC void mystrgrablit(STRINGARRAY *s, const char *src)
{
  stringchar *dest = STRINGOF(s);
  
  ASSERTDEBUG(basicassert(*src == '"',"mystrgrablit"));
  src++;
    
  while(*src)
  {
	if(*src == '"')
	{
	  if(src[1] == '"')
	  {
		*dest++ = *src;
	    src++;
	    src++;
	  }
	  else
		break;
	}
	else
     *dest++ = *src++;
  }
  
  s->len = dest - STRINGOF(s);
  STRINGOF(s)[s->len] = 0;
}

/*
  find where a source string literal ends
  Params: src - string to check (must point to quote)
          quote - character to use for quotation
  Returns: pointer to quote which ends string
  Notes: quotes escape quotes
*/
BSTATIC char *mystrend(const char *str, char quote)
{
  ASSERTDEBUG(basicassert(*str == quote,"mystrend"));
  str++;

  while(*str)
  {
    while(*str != quote)
	{
	  if(*str == '\n' || *str == 0)
		return 0;
	  str++;
	}
    if(str[1] == quote)
	  str += 2;
	else
	  break;
  }

  return (char *) (*str? str : 0);
}

/*
  Count the instances of ch in str
  Params: str - string to check
          ch - character to count
  Returns: no time chs occurs in str. 
*/
BSTATIC int mystrcount(const char *str, char ch)
{
  int answer = 0;

  while(*str)
  {
    if(*str++ == ch)
	  answer++;
  }

  return answer;
}

BSTATIC STRINGARRAY *createstringarray(int len)
{
	STRINGARRAY *s = (STRINGARRAY *)malloc(LENOFSTRINGARRAY(len));
	if (s != NULL) {
		s->len = len;
		s->beginstring[len] = 0;
	}
	return s;
}

/*
  concatenate two strings
  Params: str - firsts string
          cat - second string
  Returns: malloced string.
*/
BSTATIC STRINGARRAY *stringarrayconcat(STRINGARRAY *s1, STRINGARRAY *s2)
{
  STRINGARRAY *answer;

  answer = createstringarray(s1->len + s2->len);
  if (answer == NULL)
		return NULL;
  memmove(answer->beginstring, s1->beginstring, s1->len);
  memmove(&answer->beginstring[s1->len], s2->beginstring, s2->len);
  return answer;
}

BSTATIC int stringarraycmp(STRINGARRAY *s1, STRINGARRAY *s2)
{
  int lencmp = s1->len > s2->len ? s2->len : s1->len;
  int cmp = memcmp(s1->beginstring,s2->beginstring,lencmp);
  if (cmp != 0)
	return cmp;
  if (s1->len == s2->len)
	return 0;
  return (s1->len > s2->len ? 1 : -1);
}

BSTATIC int strstrarray(STRINGARRAY *str, STRINGARRAY *substr, int offset)
{
   int i=offset > 0 ? offset : 0, endof = str->len - substr->len, j;
   while (i<=endof)
   {
	  j=0;
	  while (j<substr->len) {
		  if (str->beginstring[i+j] != substr->beginstring[j])
			break;
		 j++;
	  }
	  if (j == substr->len)
		return i;
	  i++;
   }
   return -1;
}

BSTATIC STRINGARRAY *stringarraydup(STRINGARRAY *str)
{
	STRINGARRAY *s;
	s = createstringarray(str->len);
	if (s != NULL) 
		memmove(s->beginstring,str->beginstring,str->len);
	return s;
}

BSTATIC STRINGARRAY *stringarraychar(const char *str)
{
	int len;

	len = strlen(str);
	STRINGARRAY *s = createstringarray(len);
	if (s != NULL)
		memmove(s->beginstring, str, len);
	return s;
}

BSTATIC STRINGARRAY *stringarrayduppart(STRINGARRAY *str, int offset, int len)
{
	STRINGARRAY *s;
	int end;

	if (offset < 0)
		offset = 0;
	if (offset > str->len)
		offset = str->len;
	end = offset + len;
	if (end < offset)
		end = offset;
	if (end > str->len)
		end = str->len;
	end = end - offset;
	s = createstringarray(end);
	if (s != NULL) {
		if (end > 0)
			memmove(s->beginstring, &str->beginstring[offset], end);
	}
	return s;
}
