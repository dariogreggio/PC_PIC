// G.Dar extension 1/12/2007

 #include <xc.h>

 #include "../pc_pic_cpu.h"

//#include "minibasic.h"
#include "iohw.h"






/* subroutines for I/O */

static char getmask(unsigned char port, unsigned char pin) {

	if(port<2 || port > 8)		// LATB...LATG
		return -1;
	if(pin < 1 || pin > 32)
		return -1;
  
	pin--;

  return 1 << pin;
	}

void setpin(unsigned char port, unsigned char pin, unsigned char mode) {
  char mask;

  mask = getmask(port,pin);
	if(mask<0)
		return;
	port--;

	if(mode)		// input
		*((unsigned char *)(&TRISB+port)) &= ~mask;
	else
		*((unsigned char *)(&TRISB+port)) |= mask;

	}

void outd(unsigned char port, unsigned char pin, unsigned char value) {
  char mask;

  mask = getmask(port,pin);
	if(mask<0)
		return;
	port--;

	if(value)
	  *((unsigned char *)(&LATB+port)) |= mask;
	else
		*((unsigned char *)(&LATB+port)) &= ~mask;
	}

 #define CPUCLKMHZ 200
 #define FREQSCAL ((1250000*CPUCLKMHZ)/60)
/* you probably have to fiddle with FREQSCAL to get the frequency conversion
    right since its just a software loop, the speed of which will depend on exactly
    where in the flash/RAM the code is executing from */
/* AGGIUSTARE per PIC! */

void tone(unsigned char port, unsigned char pin, unsigned int val2) {
  unsigned int i,j;
  unsigned int val1;
  char mask;

  mask = getmask(port,pin);
	if(mask<0)
		return;

  val2 = FREQSCAL / val2;
  val1 = (val1*1000) / val2;
  for(i=0; i<val1; i++) {
		for(j=0; j<val2; j++) 
		  *((unsigned char *)(&LATB+port)) |= mask;
		for(j=0; j<val2; j++)
			*((unsigned char *)(&LATB+port)) &= ~mask;
		}
	}

void outdac(unsigned char pin, unsigned int value) {
	static char inited = 0;


  switch(pin) {
		case 0:			// usa CVREF
			CVRCON=value;
			break;
		case 1:			// usa PWM
      OC1RS=value;
			break;
		case 2:			// usa I2C DAC
//			StartI2C1();
//			MasterWriteI2C1(0x90 /*10010000b*/);				// indirizzo del TC1320
//			MasterWriteI2C1(0);						// scrivo comando
//			MasterWriteI2C1(value);				// scrivo dato
//			IdleI2C1();
// 			StopI2C1();  
			break;
		case 3:			// usa SPI DAC
// reset CS ...
//      SPI1CON1Lbits.MODE16=1;     
      SPI1STATbits.SPIROV = 0;  // Reset overflow bit
      SPI1BUF = ((unsigned int)value << 4) | 0x3 /*status*/;     // Write word to SPI buffer
//      SPI1CON1Lbits.MODE16=0;
// set CS ...
			break;
		}
  
	}

#define TCR_CNT_EN		0x00000001
#define TCR_RESET		0x00000002
#define TCR_PWM_EN		0x00000008

#define PWMMR0I			1 << 0
#define PWMMR0R			1 << 1
#define PWMMR0S			1 << 2
#define PWMMR1I			1 << 3
#define PWMMR1R			1 << 4
#define PWMMR1S			1 << 5
#define PWMMR2I			1 << 6
#define PWMMR2R			1 << 7
#define PWMMR2S			1 << 8
#define PWMMR3I			1 << 9
#define PWMMR3R			1 << 10
#define PWMMR3S			1 << 11
#define PWMMR4I			1 << 12
#define PWMMR4R			1 << 13
#define PWMMR4S			1 << 14
#define PWMMR5I			1 << 15
#define PWMMR5R			1 << 16
#define PWMMR5S			1 << 17
#define PWMMR6I			1 << 18
#define PWMMR6R			1 << 19
#define PWMMR6S			1 << 20

#define PWMSEL2			1 << 2
#define PWMSEL3			1 << 3
#define PWMSEL4			1 << 4
#define PWMSEL5			1 << 5
#define PWMSEL6			1 << 6
#define PWMENA1			1 << 9
#define PWMENA2			1 << 10
#define PWMENA3			1 << 11
#define PWMENA4			1 << 12
#define PWMENA5			1 << 13
#define PWMENA6			1 << 14

#define LER0_EN			1 << 0
#define LER1_EN			1 << 1
#define LER2_EN			1 << 2
#define LER3_EN			1 << 3
#define LER4_EN			1 << 4
#define LER5_EN			1 << 5
#define LER6_EN			1 << 6

void pwm(unsigned char pin, unsigned int val1, unsigned int val2) {
	static char inited = 0;


  if(!inited) {
		if(pin==1) {
      CFGCONbits.OCACLK=0;      // sceglie timer per PWM
      OC1CON = 0x0006;      // TimerX ossia Timer2; PWM mode no fault; Timer 16bit, TimerX
      OC1R    = 500;		 // su PIC32 � read-only!
      OC1RS   = 1000;   // 50%, relativo a PR2 del Timer2
      OC1CONbits.ON = 1;   // on
#warning FARE PPS!
      CFGCONbits.IOLOCK = 0;      // PPS Unlock
      RPD5Rbits.RPD5R = 12;        // Assign RPD5 as OC1, pin 53
      CFGCONbits.IOLOCK = 1;      // PPS Lock
      }
		else if(pin==2) {
      CFGCONbits.OCACLK=0;      // sceglie timer per PWM
      OC1CON = 0x0006;      // TimerX ossia Timer2; PWM mode no fault; Timer 16bit, TimerX
      OC1R    = 500;		 // su PIC32 � read-only!
      OC1RS   = 1000;   // 50%, relativo a PR2 del Timer2
      OC1CONbits.ON = 1;   // on
#warning FARE PPS!
      CFGCONbits.IOLOCK = 0;      // PPS Unlock
      RPD5Rbits.RPD5R = 12;        // Assign RPD5 as OC1, pin 53
      CFGCONbits.IOLOCK = 1;      // PPS Lock
      }
		else
			return;
		inited = 1;
	  }
	if(pin==1)
    OC1RS=val2;
	else if(pin==2)
    OC1RS=val2;



	}

unsigned char ind(unsigned char port, unsigned char pin) {
  char mask;

  mask = getmask(port,pin);
	if(mask<0)
		return -1;
	port--;

  return *((unsigned char *)(&PORTB+port)) & mask;
	}

unsigned int inadc(unsigned char channel) {
  static char inited = 0;


  if(!inited) {

  // PB3DIV=0x800a;    // boh divido per 10 NO! sono gi� attivi di default e impostati a 1/2 = 100MHz
  // e cmq ci vuole una sequenza di sblocco...
  // Set Peripheral Bus 2 Clock to SYSCLK/DIV_4
  /*SYSKEY = 0x00000000; // Start unlock sequence
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;
  while(PB2DIVbits.PBDIVRDY == 0)  ;
  PB2DIVbits.PBDIV = GetSystemClock() / GetPeripheral2Clock() - 1;
  PB2DIVbits.ON = 1;
  SYSKEY = 0x33333333;*/
 
  ADCCON1=0;    // AICPMPEN=0, siamo sopra 2.5V
  CFGCONbits.IOANCPEN=0;    // idem
  ADCCON2=0;
  ADCCON3=0;
  
  //Configure Analog Ports
  ADCCON3bits.VREFSEL = 0; //Set Vref to VREF+/-

  ANSELBbits.ANSB4 = 1;

  ADCCMPEN1=0x00000000;
  ADCCMPEN2=0x00000000;
  ADCCMPEN3=0x00000000;
  ADCCMPEN4=0x00000000;
  ADCCMPEN5=0x00000000;
  ADCCMPEN6=0x00000000;
  ADCFLTR1=0x00000000;
  ADCFLTR2=0x00000000;
  ADCFLTR3=0x00000000;
  ADCFLTR4=0x00000000;
  ADCFLTR5=0x00000000;
  ADCFLTR6=0x00000000;
    
  ADCTRGMODE=0;

  ADCTRG1=0;
  ADCTRG2=0;
  ADCTRG2bits.TRGSRC4=1;      // software trigger

  ADCIMCON1bits.DIFF4 = 0; // single ended, unsigned
  ADCIMCON1bits.SIGN4 = 0; // 
   
  // Initialize warm up time register
  ADCANCON = 0;
  ADCANCONbits.WKUPCLKCNT = 5; // Wakeup exponent = 32 * TADx

  ADCEIEN1 = 0;
    
//    ADCCON2bits.ADCDIV = 64; // per SHARED: 2 TQ * (ADCDIV<6:0>) = 6 * TQ = TAD
    
  ADCCON3bits.ADCSEL = 0;   //0=periph clock 3; 1=SYSCLK
  ADCCON3bits.CONCLKDIV = 4; // 100MHz, sotto � poi diviso 2 per il canale, = max 50MHz come da doc
  ADCCON3bits.DIGEN4 = 1;
  ADCCON3bits.ADINSEL = 4;

  ADC4TIMEbits.SELRES=0b11;        // 12 bits
  ADC4TIMEbits.ADCDIV=4;       // 
  ADC4TIMEbits.SAMC=6;        // 
    
  ADCCSS1 = 0; // Clear all bits
  ADCCSS2 = 0;
  ADCCSS1bits.CSS4 = 1;

  ADC0CFG=0;
  ADC4CFG=DEVADC4;

  ADCCON1bits.ON = 1;   //Enable AD
    
  // Wait for voltage reference to be stable 
  while(!ADCCON2bits.BGVRRDY); // Wait until the reference voltage is ready
  //while(ADCCON2bits.REFFLT); // Wait if there is a fault with the reference voltage

  // Enable clock to the module.
  ADCCON3bits.DIGEN4 = 1; // Enable ADC4
  ADCANCONbits.ANEN4 = 1; // Enable clock, ADC4
  while(!ADCANCONbits.WKRDY4); // Wait until ADC4 is ready
  
  // ADCGIRQEN1bits.AGIEN4=1;     // IRQ (anche ev. per DMA))


		// 1 canale solo... RB4
    inited = 1;
	  } 

	if(channel<1 || channel>1)		// v. sopra
		return -1;

//	SetChanADC10(channel);
	__delay_us(50);

  ADCCON3bits.GSWTRG = 1; // Start software trigger

  while(ADCDSTAT1bits.ARDY4 == 0) // Wait until the measurement run
		ClrWdt();

  return ADCDATA4;

	}

