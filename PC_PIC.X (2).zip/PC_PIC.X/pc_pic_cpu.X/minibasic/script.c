//#include "includes.h"


/*
const char demoscript[]={

"10 PRINT \"hello\"\n"
//"15 END\n"
"20 PRINT \"This is working ok\";\n"
"30 PRINT \"here's the loop\"\n"
"40 FOR i%=1 TO 10\n"
//"50 PRINT i%,INADC(1),IND(4,14),TIMER(1)\n"
"50 PRINT i%,INADC(1),TIMER(1)\n"
//"50 PRINT i%,INADC(1),TIMER(1),TIMER(2),\"dario\"\n"
"60 NEXT i%\n"
"62 SETCOLOR 4\n"
//"65 PRINT \">ultima riga 1234567890123456790\";\n"
"70 SETPIN 2,14,1\n"						//set RB13, (RA7) as output
"80 OUTD 2,14,1\n"						//
"85 REM:OUTD 1,7,0\n"						//

};
*/


const char demoscript[]={
"10 PRINT \"Welcome to the Main Color \": SETCOLOR 12 : PRINT \"test\"\n"   //SETCOLOR 7 : partiva con colore nero... 
"15 cinzia=7\n"
"20 SETCOLOR 3 : RECTANGLE 10,40,35,30\n"
"30 SETCOLOR 5\n"
"40 PRINT \"  Value of Cinzia\",cinzia\n"
"50 SETCOLOR 10\n"
"53 PRINT \" Expression of PI\";pi\n"
"60 MOVETO 100,40 : LINETO 125,42\n"
"70 SETCOLOR 13 : ELLIPSE 50,50,30\n"
"80 SETCOLOR 14 : POINT 100,85	' POINT muove il cursore...\n"    //il TAB lo fa arrabbiare :) gestire?? gestito! 2020
//"80 SETCOLOR 14 : POINT 100,85  ' POINT muove il cursore...\n"
"90 SETCOLOR 2 : SETBKCOLOR 1\n"
"100 LOCATE 0,11 : PRINT \"ciao\"\n"
"110 LOCATE 10,12 : SETBKCOLOR 15 : PRINT \"ciao2\"\n"
};


/*
const char demoscript[]={
"5 REM ON ERROR GOTO 100\n"
"10 FOR i%=1 TO 10\n"
"15 ?i%:NEXT i%\n"
"16 STOP\n"
"20 ' POKE 3978,i%:?i%\n"
"30 REM 3978=0xF8A=LATB su PIC18\n"
"35 PriNT SQR(i%),NOT i%,i% < 2\n"
//"35 PriNT ---SQR(i%),i%,i% < 2,\"a\" < \"b\" \n"
"40 a$= \"    +\"+STR$(i%):?\"len=\";Len(a$):?\n"
"42 ' IF \"pippo\" > \"pluto\" OR 1<2 THEN 70\n"
"45 REM STOP\n"
"47 MID$(a$,2,2)=\"34\"\n"
"48 GOSUB 200\n"
"50 SLEEP 500\n"
"60 TIMER(1)=40\n"
"65 ?TIMER(1)\n"
"70 NEXT i%\n"
"80 DO\n"
"82 ?i%\n"
"83 i%=i%-2\n"
"85 LOOP WHILE i%>5\n"
"99 ?e,pi:RECTANGLE 40,40,80,80:END\n"
"100 ' ?\"Error \",ERR(0),\" at line \";ERR(1)\n"
"200 ?a$; : RETURN\n"		/// mmm virgola o ; a fondo statement non va, il cursore va a capo cmq... ma forse � giusto cos� in Basic
	// e, cmq, se seguiva un : (riga multistatement), stampava uno 0 inesistente e poi va a capo...
	// pare tutto risolto, 29.7.15
"205  RETURN\n"
};
*/

//== Remember  put  \"     for every " in the basic program




/*
//Basic Looping Integer forced % OK
const char demoscript[]={

"10 PRINT \"hello\"\n"
//"15 END\n"
"20 PRINT \"This is working ok\":SLEEP 500: CLS : SETCOLOR 4 \n"   //SLEEP 1000: sleep 1000 sembra far impazzire tutto.. non si blocca ma non prosegue 16/2/20 500 � ok
"30 PRINT \"here's the loop\"\n"
"40 FOR i%=1 TO 5\n"
"50 PRINT i%:SLEEP 250\n" // 250 � ok!
"60 NEXT i%\n"
//"65 GOTO 20\n"
"70 a=10\n"
//"80 ?a\n"
"90 SETCOLOR 2 : PRINT a+1\n"
};
*/


/*
const char demoscript[]={
"5 PRINT \"test 1\"\n"
"10 LET A=15\n"
"20 LET B=10\n"
"25 LET C=3\n"			// se metti C%, o un numero tipo 3.124, si schianta dsPIC
"27 D=4.156\n"			// se metti C%, o un numero tipo 3.124, si schianta dsPIC ALLA FINE PROGRAMMA!
// mmm lo fa solo con 3 decimali.. ne' pi� ne meno... @[]#
//  28.7.15 il problema era in CleanUp, puliva anche la memoria di variabili non stringa...!
"30 PRINT A * B\n"
"40 PRINT A + B\n"
"45 PRINT A / B\n"
"50 PRINT (A/B)/C\n"
"52 LOCATE 15,6\n"
"55 PRINT \"Values->\"\n"
"60 PRINT A\n"
"70 PRINT B\n"
"80 PRINT D\n"
};
*/




/*
//----------------- Floating Point Tester this is OK ---------------
const char demoscript[]={

"10 PRINT \"Welcome to the Main test Routine\"\n"
"20 PRINT \"This is Float Test\"\n"
"30 LET A=1.5\n"
"32 LET C=2.45\n"
"35 LET g=5.67\n"
"36 LET JEFF=1001.237\n"
"37 PRINT \"first number=\",A,\"  Second Number\",C\n"
"40 PRINT \"add both\",A+C\n"
"45 PRINT \"Multiply both\",A*C\n"
"46 PRINT \"Divide both\",A/C\n"
"47 PRINT \"Subtract both\",A-C\n"
//"48 PRINT \"Complex\",(A*C)/JEFF\n"
"49 PRINT \"SQuar\",SQR(A)\n"
//"50 LET D=(A+C)*C\n"			// v. altro script sopra... si schianta se c'� un valore strano da assegnare... 07.15
"51 PRINT \" total of D\",D\n"
"52 PRINT \" Value of JEFF\",JEFF\n"
"53 PRINT \" Expression of JEFF\",JEFF*C+g\n"
"99 STOP\n"
"100 ? \"ciao\"\n"
};
*/


/*
//Looping test OK
const char script[]={
"5 PRINT \"Loop test \"\n"
"10 LET A=15\n"
"20 LET B=22.45665\n"
"22 LET JEFF=22\n"
"25 LET vtemp=3.12445\n"
"40 FOR i=A TO JEFF\n"
"50 PRINT \"Loop Counter\",i\n"
"52 PRINT \"Loop Counter\",i+B\n"
"60 NEXT i\n"
};
*/


/*
//loop test and constants OK
const char script[]={
"5 PRINT \"test Constants and gosub goto\"\n"
"10 LET A=15\n"
"20 LET B=10\n"
"30 PRINT \"hello a\"\n"
"40 PRINT \"hello b\"\n"
"41 GOTO 502\n"
"50 PRINT \"hello c\"\n"
"52 LET S=10\n"
"54 LET Z=3450\n"
"60 PRINT \"hello d\"\n"
"200 PRINT \"hello e\"\n"
"240 GOTO 504\n"
"502 PRINT \"hello f\"\n"
"503 GOTO 54\n"
"504 REM This is a comment \n"
"626 PRINT \"hello g\"\n"

};
*/

/*

//loop while test and float constants OK
const char script[]={
"5 PRINT \"Alternative Test\"\n"
"10 ted=15\n"
"20 bill=10.34\n"
"30 PRINT \"hello a\"\n"
"40 DO\n"
"50 ?bill\n"							\\? can be used as a PRINT statement
"60 bill=bill+20.12\n"
"70 LOOP WHILE bill<100\n"
};

*/
/*
//Input test NO good
const char script[]={
"5 PRINT \"Input a number\"\n"
"10 INPUT jeff\n"
"30 PRINT \"Did you type ->\",jeff\n"
"40 PRINT \"Input a String\"\n"
"50 INPUT ted$\n"
"60 PRINT \"Did you type ->\",ted$\n"
"65 PRINT \"jeff * 400.23 ->\",jeff*400.23\n"
};
*/


/*
//Gosub and goto  test  OK
const char script[]={
"10 PRINT \"HELLO\"\n"
"20 LET A=0\n"
"30 GOSUB 1000\n"
"40 GOTO 2000\n"
"1000 LET A=A+1\n"
"1010 PRINT \"HEY\",A\n"
"1015 GOSUB 1100\n"
"1020 IF A>4 THEN 1040\n"
"1035 GOSUB 1000\n"
"1040 RETURN\n"
"1100 PRINT \"HOH\"\n"
"1110 RETURN\n"
"2000 PRINT \"END\"\n"
};
*/

/*
//ADC test Works but ADC value 0 to 30  not 0 to 1024 maybe bug  KIND OK
const char script[]={
"5 PRINT \"Read ADC0\"\n"
"10 SETPIN 1,1,1\n"						//set RA0 as input
"50 A=INADC(1)\n"						// ##AN0 = 1## for port numbers 1 to max ADC number
"60 PRINT \"ADC(0) Value ->\",A\n"
};
*/

/*
//I/O and delay test Does Not Work Properly
//SLEEP works OK
const char demoscript[]={
"5 PRINT \"I/O and Delay test\"\n"
"10 SETPIN 1,2,0\n"						//set RB0 as Output  Pin,Port,state
"50 OUTD 1,2,1\n"						// RB0=on			Pin,Port,state
"60 PRINT \"RB0 Led ON\"\n"
"70 SLEEP 2000\n"						//wait 2 seconds
"80 OUTD 1,2,0\n"						// RB0=on
"90 PRINT \"RB0 Led OFF\"\n"
"100 SLEEP 2000\n"						//wait 2 seconds
"110 OUTD 1,2,1\n"						// RB0=on
"120 PRINT \"RB0 Led ON\"\n"
};
*/

const char midiscript[]={
//"10 MIDI$=\"3\"\n"
//"15 FOR i=1 TO 4 : MIDI$=CHR$(64+i) : NEXT\n"
//"10 ? &\"23\"\n"
"10 CLS \n"
"20 FOR i=1 TO 4: MIDI$=CHR$(64+i) : NEXT \n"
"30 ?TIME$() \n"
"50 GOTO 10\n"
  };
