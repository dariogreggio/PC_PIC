#ifndef _ee_h
#define _ee_h

void editor(void);

#define ESTATIC static
#define EDITORTITLE "Minibasic"

typedef int (*readfile)(void *v);
typedef int (*writefile)(int c, void *v);

extern readfile rf;
extern void *rf_ptr;
extern writefile wf;
extern void *wf_ptr;

#endif /* _ee_h */
