/* PC/PIC Motherboard, CPU module
 * GD/C 30/8/21
 * 
 * A: � la SDcard, E: la pen-drive e C: l'hard disc (ev. B: il floppy)
 */

// PIC32MZ2048EFG100 Configuration Bit Settings

// 'C' source line config statements
#pragma config USERID =     0x4B47

// DEVCFG3
#pragma config FMIIEN = OFF             // Ethernet RMII/MII Enable (RMII Enabled)
#pragma config FETHIO = OFF             // Ethernet I/O Pin Select (Alternate Ethernet I/O)
#pragma config PGL1WAY = ON             // Permission Group Lock One Way Configuration (Allow only one reconfiguration)
#pragma config PMDL1WAY = ON            // Peripheral Module Disable Configuration (Allow only one reconfiguration)
#pragma config IOL1WAY = ON             // Peripheral Pin Select Configuration (Allow only one reconfiguration)
#if defined(USA_USB_SLAVE_CDC)
//#pragma config FUSBIDIO = ON            // USB USBID Selection (Controlled by the USB Module)
#pragma config FUSBIDIO = OFF           // ma � pure ACS... (v.override)
#else
#pragma config FUSBIDIO = OFF           // USB USBID Selection (NOT Controlled by the USB Module )
#endif

// DEVCFG2
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
/* Default SYSCLK = 200 MHz (8MHz FRC / FPLLIDIV * FPLLMUL / FPLLODIV) */
// la scheda DM32 usa 24MHz crystal o Oscillator... anche io :)
#pragma config FPLLIDIV = DIV_3         // System PLL Input Divider (2x Divider)
#pragma config FPLLRNG = RANGE_5_10_MHZ// System PLL Input Range (34-68 MHz Input x FRC ??)
#pragma config FPLLICLK = PLL_POSC       // System PLL Input Clock Selection (POSC is input to the System PLL)
#pragma config FPLLMULT = MUL_50       // System PLL Multiplier (PLL Multiply by 50)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (32x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)
/*#pragma config FPLLIDIV = DIV_2         // System PLL Input Divider (2x Divider)
#pragma config FPLLRNG = RANGE_8_16_MHZ// System PLL Input Range (8-16 MHz Input )
#pragma config FPLLICLK = PLL_POSC       // System PLL Input Clock Selection (POSC is input to the System PLL)
#pragma config FPLLMULT = MUL_33       // System PLL Multiplier (PLL Multiply by 33)
#warning provare overclock! (se va con usb...)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (2x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)
*/
//#pragma config UPLLEN = ON      // USB PLL Enable (USB PLL is enabled)
#else
#pragma config FPLLIDIV = DIV_1         // System PLL Input Divider (1x Divider)
#pragma config FPLLRNG = RANGE_5_10_MHZ// System PLL Input Range (5-10 MHz Input)
#pragma config FPLLICLK = PLL_FRC       // System PLL Input Clock Selection (FRC is input to the System PLL)
#pragma config FPLLMULT = MUL_54       // System PLL Multiplier (PLL Multiply by 54)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (2x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)
#endif

// DEVCFG1
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#pragma config FNOSC = SPLL           // Oscillator Selection Bits (S PLL)
#pragma config POSCMOD = HS            // Primary Oscillator Configuration (Primary osc enabled)
#pragma config OSCIOFNC = OFF           // CLKO Output Signal Active on the OSCO Pin (Disabled)
#else
#pragma config FNOSC = FRCDIV           // Oscillator Selection Bits (Fast RC Osc w/Div-by-N (FRCDIV))
#pragma config POSCMOD = OFF            // Primary Oscillator Configuration (Primary osc disabled) x FRC
#pragma config OSCIOFNC = ON           // CLKO Output Signal Active on the OSCO Pin (Enabled)
#endif
#pragma config DMTINTV = WIN_127_128    // DMT Count Window Interval (Window/Interval value is 127/128 counter value)
#pragma config FSOSCEN = OFF             // Secondary Oscillator Enable (disable SOSC)
#pragma config IESO = ON                // Internal/External Switch Over (Enabled)
#pragma config FCKSM = CSECME           // Clock Switching and Monitor Selection (Clock Switch Enabled, FSCM Enabled)
#pragma config WDTPS = PS2048          // Watchdog Timer Postscaler (1:2048)
  // circa 1 secondi, 8.9.19
#pragma config WDTSPGM = STOP           // Watchdog Timer Stop During Flash Programming (WDT stops during Flash programming)
#pragma config WINDIS = NORMAL          // Watchdog Timer Window Mode (Watchdog Timer is in non-Window mode)
#pragma config FWDTEN = ON             // Watchdog Timer Enable (WDT Enabled)
#pragma config FWDTWINSZ = WINSZ_25     // Watchdog Timer Window Size (Window size is 25%)
#pragma config DMTCNT = DMT31           // Deadman Timer Count Selection (2^31 (2147483648))
#pragma config FDMTEN = OFF             // Deadman Timer Enable (Deadman Timer is disabled)

// DEVCFG0
#pragma config DEBUG = OFF              // Background Debugger Enable (Debugger is disabled)
#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
#pragma config ICESEL = ICS_PGx1        // ICE/ICD Comm Channel Select (Communicate on PGEC1/PGED1)
#pragma config TRCEN = OFF              // Trace Enable (Trace features in the CPU are disabled)
#pragma config BOOTISA = MIPS32         // Boot ISA Selection (Boot code and Exception code is MIPS32)
#pragma config FECCCON = OFF_UNLOCKED   // Dynamic Flash ECC Configuration (ECC and Dynamic ECC are disabled (ECCCON bits are writable))
#pragma config FSLEEP = OFF             // Flash Sleep Mode (Flash is powered down when the device is in Sleep mode)
#pragma config DBGPER = PG_ALL          // Debug Mode CPU Access Permission (Allow CPU access to all permission regions)
#pragma config SMCLR = MCLR_NORM        // Soft Master Clear Enable bit (MCLR pin generates a normal system Reset)
#pragma config SOSCGAIN = GAIN_2X       // Secondary Oscillator Gain Control bits (2x gain setting)
#pragma config SOSCBOOST = ON           // Secondary Oscillator Boost Kick Start Enable bit (Boost the kick start of the oscillator)
#pragma config POSCGAIN = GAIN_2X       // Primary Oscillator Gain Control bits (2x gain setting)
#pragma config POSCBOOST = ON           // Primary Oscillator Boost Kick Start Enable bit (Boost the kick start of the oscillator)
#pragma config EJTAGBEN = NORMAL        // EJTAG Boot (Normal EJTAG functionality)

// DEVCP0
#pragma config CP = OFF                 // Code Protect (Protection Disabled)

// SEQ3

// DEVADC0

// DEVADC1

// DEVADC2

// DEVADC3

// DEVADC4

// DEVADC7


#include <xc.h>
#include "Pc_pic_cpu.h"


#if defined(USA_USB_HOST)
#include "usbfsconfig.h"
#include "../harmony_pic32mz/usb_host.h"
#include "../harmony_pic32mz/usb_common.h"
#if defined(USA_USB_HOST_UVC)
#include "../harmony_pic32mz/usb_host_uvc.h"
#endif
#if defined(USA_USB_HOST_MSD)
#include "../harmony_pic32mz/usb_host_msd.h"
#include "../harmony_pic32mz/usb_host_scsi.h"
#endif
#endif
#if defined(USA_USB_SLAVE_CDC)
#include "../harmony_pic32mz/usb_chapter_9.h"
#include "../harmony_pic32mz/usb_device.h"
#include "../harmony_pic32mz/usb_cdc.h"
#include "../harmony_pic32mz/usb_device_cdc.h"
#endif
#include "harmony_app.h"
#include <stdio.h>
#include <stdint.h>
#ifdef USA_WIFI
#include "at_winc1500.h"
#endif
#ifdef USA_ETHERNET
//#include "stacktsk.h"   // messo in .h ...
#endif

#include "fat_sd/fsconfig.h"
#include "fat_sd/fsio.h"

#include "fat_ide/idefat.h"
#include "fat_ide/fdc.h"



const char _PC_PIC_CPU_C[]= {"PIC32MZ2048EFG100 PC_PIC_CPU - 28/6/2022\r\n\r\n"};
const char Copyr1[]="(C) Dario's Automation 2021,2022 - G.Dar\xd\xa";

SIZE Screen,ScreenText;

#ifdef USA_WIFI
#define USA_TELNET 1
Ipv4Addr myIp,acceptedIp;
BYTE myRSSI;
WORD acceptedPort;
uint8_t internetBuffer[256];
WORD internetBufferLen=0;
SOCKET UDPclientSocket=INVALID_SOCKET,DNSclientSocket=INVALID_SOCKET;
BYTE rxBuffer[1536];
SOCKET TCPlistenSocket=INVALID_SOCKET, TCPacceptedSocket=INVALID_SOCKET;
#ifdef USA_TELNET
SOCKET TelnetSocket=INVALID_SOCKET,TelnetAcceptedSocket=INVALID_SOCKET;
#endif
uint8_t bTCPIsfinished=0;
void dnsResolveCallback(uint8_t* pu8HostName, uint32_t u32ServerIP);
int16_t sendEx(SOCKET sock, void *pvSendBuffer, uint32_t u32SendLength);
void tcpStartServer(uint16_t);
static void clientSocketEventHandler(SOCKET, BYTE, void *);
static void wifi_cb(BYTE u8MsgType, void *pvMsg);
#endif
#ifdef USA_ETHERNET   // in effetti, unificare con ATWINC ecc
int16_t sendEx2(TCP_SOCKET sock, void *pvSendBuffer, uint32_t u32SendLength);
#endif


#define DMA_READY __attribute__((coherent)) __attribute__((aligned(16)))    // 
//__attribute__((coherent,aligned(4)))
//#define PMPWaitBusy()   while(PMSTATbits.OBE); // VERIFICARE
#define PMPWaitBusy()   while(PMMODEbits.BUSY); // x Master

volatile unsigned long videoFrameCnt;
volatile unsigned long now=315532800UL;   // 1/1/1980 per MSDOS :)
volatile unsigned char second_10;
signed char timeZone;
// Days on each month for regular and leap years
const unsigned char days_month[2][12] = {
  { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
  { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
	};
const char wdays[7][4] = {
  "Mon","Tue","Wed","Thu","Fri","Sat","Sun"
  };
static const char months[13][4] = {
  "   ", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  };
int isleap(int year);
volatile BYTE eventReceived=0;

extern BYTE doEcho,errorLevel;
extern char prompt[16];
extern signed char currDrive;
struct KEYPRESS keypress;
BYTE ledStatus;
WORD keyboardBuffer[8];
BYTE keyboardBufferRead,keyboardBufferWrite;
BYTE rs232Buffer[8];
BYTE rs232BufferRead,rs232BufferWrite;

APP_DATA appData;
struct __attribute__((__packed__)) BIOS_AREA BiosArea;     // mirrorato in EEprom (emulata)
DWORD extRAMtot=0;


#ifdef USA_USB_SLAVE_CDC    
#define APP_READ_BUFFER_SIZE 512

uint8_t DMA_READY readBuffer[APP_READ_BUFFER_SIZE];
uint8_t DMA_READY writeBuffer[APP_READ_BUFFER_SIZE];
//uint8_t DMA_READY USB_Out_Buffer[APP_READ_BUFFER_SIZE];
uint8_t DMA_READY USB_In_Buffer[APP_READ_BUFFER_SIZE];
#endif



#ifdef USA_USB_SLAVE_CDC    
uint16_t NextUSBOut;
uint16_t LastRS232Out;  // Number of characters in the buffer
uint16_t RS232cp;       // current position within the input buffer
volatile unsigned char RS232_Out_Data_Rdy=false;
#endif

BYTE SDcardOK,USBmemOK,HDOK,FDOK;

IDE EIDE;
IDEVolume HDvolume;
FDCDevice FDC;

MINIBASIC minibasicInstance;

extern unsigned int __attribute__((section("_linkergenerated"))) _splim;
extern unsigned int __attribute__((section("_linkergenerated"))) _stack;

int main() {
  int i;
  
  i=RCONbits.WDTO; RCONbits.WDTO=0;
  

#if 0
  i=SYS_FS_StringWildCardCompare83("*.bas", "FROCI.BAS");
  i=SYS_FS_StringWildCardCompare83("*.bas", "FROCI.bas");
  i=SYS_FS_StringWildCardCompare83("*.bas", "FROCI");
  i=SYS_FS_StringWildCardCompare83("*.bas", "FROCI.");
  i=SYS_FS_StringWildCardCompare83("????.bas", "FROCI.bas");
  i=SYS_FS_StringWildCardCompare83("?????.bas", "FROCI.bas");
  i=SYS_FS_StringWildCardCompare83("f*.bas", "FROCI.bas");
  i=SYS_FS_StringWildCardCompare83("f*.*", "FROCI.bas");
  i=SYS_FS_StringWildCardCompare83("F*.*", "froci.bas");
  i=SYS_FS_StringWildCardCompare83("r*.*", "FROCI.bas");
  i=SYS_FS_StringWildCardCompare83("*.t*", "FROCI.bas");
#endif
  
  // Disable all Interrupts
  __builtin_disable_interrupts();
  SYSKEY = 0x00000000;
  SYSKEY = 0xAA996655;    //qua non dovrebbe servire essendo 1� giro (v. IOLWAY
  SYSKEY = 0x556699AA;
  CFGCONbits.IOLOCK = 0;      // PPS Unlock
//  RPD11Rbits.RPD11R = 1;        // Assign RPD11 as U1TX, pin 70
//  U1RXRbits.U1RXR = 3;        // Assign RPD10 as U1RX, pin 69
  RPF2Rbits.RPF2R = 12;        // Assign RPF2 as OC1, pin 57

  RPD3Rbits.RPD3R = 5;        // Assign RPD3 as SDO1, pin 78
  SDI1Rbits.SDI1R = 0;        // Assign RPD2 as SDI1, pin 77

  RPD11Rbits.RPD11R = 8;        // Assign RPD11 as SDO4, pin 70
  SDI4Rbits.SDI4R = 11;      // Assign RPD15 as SDI4, pin 48

#if 0
  RPB0Rbits.RPB0R = 15;        // RefClk3 su pin 57 (RF2)
	REFO3CONbits.RSLP=1;
	REFO3CONbits.ROSEL=1;
	REFO3CONbits.RODIV=1;        // ok 50MHz 27/7/20
	REFO3CONbits.OE=1;
	REFO3CONbits.ON=1;
	TRISFbits.TRISF2=1;
#endif

#ifdef USA_ETHERNET
#ifdef ETH_REFCLK
	v. hwremoter (e pll sopra) - ma sul c.s. non c�... forse collegare a audio o video? per pin liberi
	TRISEbits.TRISEx=1;
  RPE5Rbits.RPE5R = 15;        // RefClk1 su pin 1 (RE5) CLK_ENC volendo
	REFO1CONbits.RSLP=1;
	REFO1CONbits.ROSEL=1;
	REFO1CONbits.RODIV=2;        // ok 25MHz 18/5/22 ma non va lo stesso... forse il Jitter?? in effetti pare un pelo meno di 25MHz, ma non si pu� fare altro - v.sopra 24 : 2 *33 / 2 ... 34 � troppo e 32 � poco
  // ma FUNZIONA cambiando i PLL sopra! 24 : 3 *50 : 2 !! 19/5/22
	REFO1CONbits.OE=1;
	REFO1CONbits.ON=1;
#endif
#endif
  
  CFGCONbits.OCACLK=1;      // sceglie timer per PWM [serve SYSLOCK cmq)
  
  CFGCONbits.IOLOCK = 1;      // PPS Lock
  SYSKEY = 0x00000000;

  
  
#if !defined(USA_USB_HOST) && !defined(USA_USB_SLAVE_CDC)
  OSCTUN=0;
  OSCCONbits.FRCDIV=0;
  
  // Switch to FRCDIV, SYSCLK=8MHz
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  OSCCONbits.NOSC=0x00; // FRC
  OSCCONbits.OSWEN=1;
  SYSKEY=0x33333333;
  while(OSCCONbits.OSWEN) {
    Nop();
    }
    // At this point, SYSCLK is ~8MHz derived directly from FRC
 //http://www.microchip.com/forums/m840347.aspx
  // Switch back to FRCPLL, SYSCLK=200MHz
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  OSCCONbits.NOSC=0x01; // SPLL
  OSCCONbits.OSWEN=1;
  SYSKEY=0x33333333;
  while(OSCCONbits.OSWEN) {
    Nop();
    }
  // At this point, SYSCLK is ~200MHz derived from FRC+PLL
#endif

//***
  mySYSTEMConfigPerformance(0,0);
    
  myINTEnableSystemMultiVectoredInt();
  __delay_ms(1); 

  #if defined(USE_USB_BUS_SENSE_IO)
  tris_usb_bus_sense = INPUT_PIN; // See HardwareProfile.h
  #endif

  #if defined(USE_SELF_POWER_SENSE_IO)
  tris_self_power = INPUT_PIN;	// See HardwareProfile.h
  #endif

  __delay_ms(1000); 
  ClrWdt();

  EEinit();
  { 
    BYTE *p=(BYTE*)&BiosArea;
    int n;
    for(n=0; n<sizeof(BiosArea); n++)
      p[n]=EEread(n);
   }

  UserInit();
  
  Timer_Init();
  PWM_Init();
    

  __delay_ms(1000); 
  ClrWdt();
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#ifndef USBID_OVERRIDE
//  TRISFbits.TRISF3=0;
  LATFbits.LATF3=0;   // per CASINO CON m_ACS!! v. altrove
#warning m_ACS vs USBID!
#endif
  __delay_ms(100); 

  SYS_Initialize(NULL);
#endif

//  putsUART1("sys init\r\n");

  mLED_1_On();
  StdBeep(800);
  ClrWdt();


//#define USA_EXTENDED_RAM  1
#ifdef USA_EXTENDED_RAM  
  BiosArea.useExtRAM;
  CFGEBIAbits.EBIPINEN=1;
  CFGEBIA = 0x800FFFFF;
  {
    uint32_t loop;
//test ext memory loop
#if 0
    volatile uint32_t volatile *addr;
    volatile uint32_t val;
    addr = (volatile uint32_t *volatile)SRAM_ADDR_CS0;
    for(loop=0; loop < RAM_SIZE/4; loop++) {
      val = 0xAA55AA55;
      *addr = val;
      val = *addr;
      if(val != 0xAA55AA55)   // non va nemmeno con volatile... �$%&@#
        // forse bisogna impostare TLB cache ecc..
        break;
      addr++;
      }
#endif
    uint32_t *addr;
    addr = (uint32_t *)SRAM_ADDR_CS0;
    for(loop=0; loop < RAM_SIZE/4; loop++) {
      *addr++ = 0xAA55AA55;
      }
    addr = (uint32_t *)SRAM_ADDR_CS0;
    for(loop=0; loop < RAM_SIZE/4; loop++) {
      if(*addr != 0xAA55AA55)
        break;
      addr++;
      }
    extRAMtot=4*(addr-(uint32_t *)SRAM_ADDR_CS0);
  }
  CFGEBIC = 0x0;
  CFGEBIAbits.EBIPINEN=0;
  CFGEBIA = 0x0;
#else
    extRAMtot=0;
#endif

  
    
  // PRIMA andrebbe controllata signature cmq!!
  if(BiosArea.signature != 0x4447) {
		puts("BIOS data invalid!\r\n");
    StdBeep(100);
    __delay_ms(100);
    StdBeep(100);
    __delay_ms(100);
    BiosArea.signature=0x4447;
    // WriteEE... AreaWrite...
    }
  if(BiosArea.dateTime == 0) {
//    i=1;    // mettere :)
    }
  else {
    now=BiosArea.dateTime;
    }


  if(GetID(VIDEO_CARD) != 'V') {		// 
		// SUONARE!!! in loop eterno?
    StdBeep(500);
    __delay_ms(200);
    StdBeep(500);
    __delay_ms(200);
    StdBeep(500);
    __delay_ms(200);
    StdBeep(500);
    __delay_ms(100);
		}
  if(GetID(AUDIO_CARD) != 'A') {		// 
		puts("Error: audio board not present!");
    i=1;
		}
  if(GetID(SOUTH_BRIDGE) != 'S') {		// 
		puts("Error: south bridge not present!");
    i=1;
		}

  mLED_1_Off();
  ClrWdt();
  
  if(sw1) {   // in caso si inciuccasse tutto :)
    mySYSTEMConfigPerformance(BiosArea.cpuSpeed,BiosArea.cpuCache);
    }
  else {
    BiosArea.videoMode=0;
    }

  /*
  SetVideoMode(MODE_VGA,640,480,8);      //
  if(BiosArea.ethernet) {
    SetAudioMode(SYNTH);
    SetAudioWave(0,TRIANGOLARE,1000,2,8,80,0,0);
    SetAudioWave(1,NESSUNA,10,2,8,100,0,0);
    }
  */
  switch(BiosArea.videoMode) {
    case 0:
    default:    // tanto per
      SetVideoMode(MODE_LCD,160,128,16);
      break;
    case 1:
      SetVideoMode(MODE_VGA,640,480,8);
      break;
    case 2:
      SetVideoMode(MODE_COMPOSITE,640,480,1);
      break;
    case 3:
#warning occhio ris VIDEO legata scheda! :)  
#ifdef USA_ETHERNET   // 
      SetVideoMode(/*MODE_LCD*/MODE_LCD_DMA,480,320,16);
#else
      SetVideoMode(/*MODE_LCD*/MODE_LCD_DMA,480,320,16);
//  SetVideoMode(MODE_LCD_DMA,160,128,16);
#endif
      break;
    }
  

  __delay_ms(1000); 
  ClrWdt();
  SetColors(WHITE,BLACK);
  Cls();
	printf("PC_PIC BIOS v%u.%02u (%s)\r\n",VERNUMH,VERNUML,__DATE__);
	printf("RAM %uKB/%uKB\r\n",(131072L /*v anche command*/+  ((unsigned int)&i) - ((unsigned int)&_splim)) / 1024,
    extRAMtot/1024);
          // _dump_heap_info per info su memoria dinamica...
          //heap_free() in heap_info.c, provare
  puts("\r\nHit DEL to enter Setup...\r\n");
  
  if(BiosArea.serial) {
    SetSerialPort(115200,8,0,1);
    }
  if(BiosArea.parallel) {
    SetParallelPort(1);
    }
  
  CNNEAbits.CNNEA3=0;
  WritePMP(AUDIO_CARD,BIOS_RESET,1);      // per reset WINC... lo metterei PRIMA di init serial/parallel
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  SetJoystick(1);
  SetMidi(1);
//  SetRTCC(1,1,21,21,39,0);
  SetRTCCFromNow(now);
  
#ifdef USA_WIFI
 // si pianta dopo un reboot... nm_bus_init(NULL); non va, ergo mando bios_reset
#endif
  
  if(BiosArea.serial) {
    if(BiosArea.flags.debugMode) {
      __delay_ms(100); 
      WriteSerial('b'); WriteSerial('o'); WriteSerial('o'); WriteSerial('t'); WriteSerial(0x0a);
      }
    }
  
  
  if(!(GetStatus(SOUTH_BRIDGE,NULL) & 0b01000101)) {		// 
		puts("Keyboard not present, hit F1 to continue :)");
    i=1;
    }
  
  KBClear();    // sarebbe inutile ma ci sta :) anche per reboot (forse)

#ifndef USING_SIMULATOR
  if(BiosArea.disc[0]) {
    if(MDD_MediaDetect()) { 		// 
  //  	printf("mounting disk...");
      SDcardOK=FSInit();      // File system
      if(BiosArea.flags.debugMode)
      	printf("SDCard: %u\r\n",SDcardOK);
      }
    else      // sicuri?
      i=1;
    }
  if(BiosArea.disc[1]) {    // faccio cos�, EIDE vs. SD
#if defined(USA_USB_HOST_MSD)
    if(BiosArea.disc[0]) {
      if(SYS_FS_Initialize((const void *)sysFSInit) == SYS_FS_RES_SUCCESS) {
        }
      else {
        if(BiosArea.flags.verboseMode)
          puts("Pen drive not present");
        i=1;    // boh :)
        }
      }
    else
#endif
    {
      HDOK=IDE_init(&EIDE);      // 
      if(HDOK) {
        IDEVolume_IDEVolume(&HDvolume);
        IDEVolume_init(&HDvolume,0);
        }
      else {
        if(BiosArea.flags.verboseMode)
          puts("Hard disc not present");
        i=1;
        }
      }
    }
#endif
  

  minibasicInstance.hWnd=NULL;
  minibasicInstance.irqHandler.handler=0;
  minibasicInstance.threadID=NULL;
  minibasicInstance.Color=0x00ff00; minibasicInstance.ColorBK=0x000000;
  minibasicInstance.ColorPalette=BRIGHTGREEN; minibasicInstance.ColorPaletteBK=BLACK;
  minibasicInstance.errorFlag=0;
  minibasicInstance.nfors=minibasicInstance.ngosubs=minibasicInstance.ndos=minibasicInstance.inBlock=0;
  
extern const char midiscript[];
//      basic(&minibasicInstance,midiscript,0);
      
      
  KBClear();
  
#ifdef USA_WIFI
  //https://microchipsupport.force.com/s/article/How-to-retrieve-the-Connection-Parameters-after-WINC1500-is-connected-to-an-Access-Point-AP

  if(BiosArea.wifi) {
    tstrWifiInitParam param;
    nm_bsp_init();

/*  nm_bsp_reset();   // per warm reset... o si blocca, tipo https://community.atmel.com/comment/3132631
  __delay_ms(200);//non va cmq 22/12/21
	nm_bus_iface_init(NULL); //idem...
 * provo dunque con cmd reset a audio_card...
  nm_warm_reset(); */

//      m_Led0Bit = 1;
    memset((BYTE*)&param, 0, sizeof(param));
    param.pfAppWifiCb = wifi_cb;
	/*initialize the WINC Driver*/
		M2M_INFO("Init WiFi...\n");
    int ret = m2m_wifi_init(&param);
    if(M2M_SUCCESS != ret) {
      if(BiosArea.flags.debugMode)
        puts("Error: WiFi adapter is fault!");
      M2M_ERR("Driver Init Failed <%d>\n",ret);
      i=1;
/*		while(1) {
      mExcep^=1;
      __delay_ms(100);
      }*/
		}
  // Initialize the socket layer.
  socketInit();
  m2m_wifi_connect(BiosArea.wifiName,strlen(BiosArea.wifiName),M2M_WIFI_SEC_WPA_PSK,BiosArea.wifiPasw,
          /*BiosArea.channel*/ M2M_WIFI_CH_ALL /*7*/);
	// Handle the app state machine plus the WINC event handler 
	while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS) {
//      m_Led0Bit^=1;
    ClrWdt();
		}

//    m2m_wifi_set_sleep_mode(M2M_NO_PS,1);
     // SERVE per broadcast??
  
  if(BiosArea.flags.verboseMode)
    puts("WiFi connected.");
	}

#endif

#ifndef USING_SIMULATOR
  __delay_ms(200); 
#endif
  
  TickInit();
#ifdef USA_ETHERNET   // in effetti, unificare con ATWINC ecc
  if(BiosArea.ethernet) {
    if(BiosArea.flags.debugMode)
      SYS_DEBUG_PRINT(SYS_DEBUG_INFO,"ETHERNET INIT...\r\n");
    MPFSInit();
    // Initialize core stack layers (MAC, ARP, TCP, UDP) and application modules (HTTP, SNMP, etc.)
    StackInit();
  //		if(configTerminale.EnablePing)		// questo � complicato da gestire... v. stacktsk
  //			ICMPInit();	
  // gi� in stack init...  	    HTTPInit();
  
      mLED_1 = 0;
    }
#endif
  
  currDrive=0;
  
  handle_events();
  
//  printf("TASTO %02X\r\n",keypress.key);
          
          
  switch(keypress.key) {
    case 0x9a /*'.'*/ /*'\x7f'*/:     // DEL
      puts("Entering Setup...");
      __delay_ms(300);
      if(handleBIOS())
        App_Reset();
      SetColors(WHITE,BLACK);
      Cls();
      break;
    case 0xa3:     // F3    // li lascio (senza citarli) per debug
      for(i=0; i<256; i++) {
        if(i==8 || i==9 /* 10 13 */)
          putchar(' ');
        else
          putchar(i);
        }
      putchar('\n');
      __delay_ms(2000);
      break;
    case 0xa4:     // F4    
      drawRGBCube(Screen.cx/4,Screen.cy/4+Screen.cy/8 /*per centrare Y*/,Screen.cy/2);   // 
      __delay_ms(2000);
      break;
    case 0xa8:     // F8
      puts("Choose Boot disc:");
      if(SDcardOK)
        puts("A");
      puts("B");
      if(HDOK)
        puts("C");
      puts("D");
#if defined(USA_USB_HOST_MSD)
      puts("E");
#endif
      puts("None");
      SetCursorMode(1,1);
      __delay_ms(800);
      i=inputKey();
      switch(tolower(LOBYTE(i))) {
        case 'a':
          setCurrentDrive('A');
          break;
        case 'b':
          setCurrentDrive('B');
          break;
        case 'c':
          setCurrentDrive('C');
          break;
        case 'd':
          setCurrentDrive('D');
          break;
#if defined(USA_USB_HOST_MSD)
        case 'e':
          setCurrentDrive('E');
          break;
#endif
        default:
          currDrive=-1;
          break;
        }
      if(currDrive>0)
        printf("..booting from %c\r\n",currDrive);
      SetCursorMode(0,0);
      break;

    }
  

  KeyboardSetLed(ledStatus=BiosArea.flags.numLockBoot);		// PC-like


#ifdef USA_ETHERNET   // 
//    Cls(); mah...
  SetXYText(0,3);   // e poi non � perfetto, se ci son stati errori ecc:
  puts("                           ");
  SetXYText(0,4);   // ...
  puts("                           ");
  SetXYText(0,1);   //
#else
//  Cls();    // schermo + piccolo!
#endif
  SetCursorMode(1,1);

  if(i && !BiosArea.flags.ignoreErrors) {
		puts("Errors detected, hit F1 to continue or DEL to enter SETUP");
    StdBeep(300);
    __delay_ms(200);
    StdBeep(300);
    __delay_ms(100);
#if 0   // fare
    handle_events();
    if(keypress.key==0x9a /*'.'*/ /*'\x7f'*/) {    // DEL
      puts("Entering Setup...");
      __delay_ms(300);
      if(handleBIOS())
        App_Reset();
      SetColors(WHITE,BLACK);
      Cls();
      }
#endif
    }


  if(BiosArea.password[0]) {
    char bufpasw[10];
    int bufpaswptr;
rifo_pasw:    
    bufpaswptr=0;
    SetXYText(3,6);   // centrare su schermo...
    SetColors(BLACK,RED);
    printf("Enter password: ");
    SetColors(WHITE,RED);
    do {
      handle_events();
      if(isalnum(keypress.key) && bufpaswptr<8) {
        bufpasw[bufpaswptr++]=keypress.key;
        putchar(keypress.key);
        }
      if(keypress.key=='\x8' && bufpaswptr>0)
        bufpasw[--bufpaswptr]=0;
          putchar(' '); // FINIRE!!!
          //suonare...
      } while(keypress.key != '\n');
      if(stricmp(BiosArea.password,bufpaswptr))
        goto rifo_pasw;
    SetColors(WHITE,BLACK);
    }
  
  /*  SetColors(RED,BLACK);
  printf("BIOS %04X\r\n",BiosArea.signature);
  SetColors(WHITE,BLACK);*/
    
  CreateStdVar();
  
  putchar('\n');
  StdBeep(200);

  if(currDrive != -1 && BiosArea.bootDisc) {
    if(!currDrive)
      currDrive=BiosArea.bootDisc+'A'-1;
    currDrive=setCurrentDrive(currDrive);
    makePrompt();
		printf(prompt);
  
    switch(currDrive) {
      case 'A':
        if(SDcardOK) {
          SearchRec rec;
          char buffer[8];

          CreateStdVar2('A');

          if(!FindFirst("AUTOEXEC.BAT", ATTR_MASK ^ ATTR_VOLUME, &rec)) {
          // Maintain state machines of all polled MPLAB Harmony modules.
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
            SYS_Tasks();
#ifdef USA_USB_HOST_MSD
            SYS_FS_Tasks();   // serve, per rapidit�...
#endif
#else
            APP_Tasks();
#endif
#ifdef USA_WIFI		// cmq son gi� in execCmd..
            m2m_wifi_handle_events(NULL);
#endif
#ifdef USA_ETHERNET
            StackTask();
            StackApplications();
#endif
            if(sw1)   // poi usare CTRL o simili..
              execCmdROM("autoexec",NULL);
            }
          }
        break;
      case 'B':
        break;
      case 'C':
        break;
      case 'D':
        break;
      case 'E':
#if defined(USA_USB_HOST_MSD)
    // andare sul disco di boot e cercare AUTOEXEC l�...
#endif
        break;
      }
    
    }
  else {
    makePrompt();
		printf(prompt);
    }



// ------------------MAIN LOOP-----------------------  
  while(1) {
    
    handle_events();
    
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#ifndef USBID_OVERRIDE
    if(appData.state <= APP_STATE_WAIT_FOR_DEVICE_ATTACH) {
      LATFbits.LATF3=0;   // CASINO CON m_ACS!! si pu� fare SOLO DOPO attach o non va...
      }
#warning m_ACS vs USBID!
#endif
#endif
    
    // Maintain state machines of all polled MPLAB Harmony modules.
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
    SYS_Tasks();
#ifdef USA_USB_HOST_MSD
    SYS_FS_Tasks();
#endif
#else
    APP_Tasks();
#endif

#ifdef USA_WIFI
  	m2m_wifi_handle_events(NULL);
#endif
#ifdef USA_ETHERNET
    StackTask();
    StackApplications();
#endif
    
		runCmdInterpreter();

    
//    mLED_1 ^= 1;    // 26KHz 30/11/21 (asimmetrico, v. altri)
    
    ClrWdt();
    }

  }

void _mon_putc(char c) {
  
    CNNEFbits.CNNEF1=0;
  WritePMP(VIDEO_CARD,BIOS_VIDEO_CHAR,c);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
    __delay_us(VIDEO_WAIT);
    CNNEFbits.CNNEF1=1;

#ifdef USA_USB_SLAVE_CDC
  uint32_t timeout;
  if(NextUSBOut < APP_READ_BUFFER_SIZE) {
    writeBuffer[NextUSBOut++] = c;
    }
    
    if(NextUSBOut == APP_READ_BUFFER_SIZE) {
//        if(appData.isWriteComplete = true)
//      appData.writeTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
//      memcpy(writeBuffer,USB_Out_Buffer,APP_READ_BUFFER_SIZE);   // buffer allineati e di % 512!!
//      if(USB_DEVICE_CDC_Write(USB_DEVICE_CDC_INDEX_0, &appData.writeTransferHandle,
//        &writeBuffer, APP_READ_BUFFER_SIZE, USB_DEVICE_CDC_TRANSFER_FLAGS_DATA_COMPLETE) == USB_ERROR_NONE) {
//        NextUSBOut=0;
//        appData.isWriteComplete = false;
//      }
      appData.isWriteComplete = false;
      timeout=0;
      while(appData.isWriteComplete == false && timeout<50000L) {
        SYS_Tasks();    //
        timeout++;
        }
      appData.isWriteComplete == true;
      NextUSBOut=0;
//      return 2;
      }
//    return 1;
#endif
  }

void KBClear(void) {
  
  keypress.key=keypress.modifier=keypress.new=0;
  }
int inputKey(void) {
  int i;
  
  KBClear();
  do {
    __delay_ms(50);
    mLED_1 ^= 1;     //  
    handle_events();
    } while(!keypress.key /*keypress.new se uso new passa pure CTRL... ma da solo... provare!*/);
  i=MAKEWORD(keypress.key,keypress.modifier);
  KBClear();
  return i;
  }
int inputString(char *buf,int size,const char *prompt,BYTE types) {
  char *p=buf;
  int n=0;
  BYTE ch;
  
  KBClear();
  if(prompt)
    print(prompt);
  for(;;) {
    __delay_ms(50);
    handle_events();
    mLED_1 ^= 1;     //  
    if(keypress.key /*keypress.new*/) {
      ch=keypress.key;
      if(tolower(ch)=='c' && keypress.modifier==0b00000001) {
        n=-1;
        break;
        }
      else if(ch>=' ' && ch<='\x7e' && n<size) {
        if(types) {//fare...
          if(isdigit(ch)) {
            }
          if(isalpha(ch)) {
            }
          }
        *p++=ch; *p=0;
        putchar(ch);
        n++;
        }
      else if(ch=='\x8' && n>0) {
        putchar('\x8');
        *--p=0;
        n--;
        }
      if(ch=='\n')
        break;
      KBClear();
      }
    if(n>=size) {
      putchar('\x8');
      n--;
      ErrorBeep(100);
      }
    }
  KBClear();
  return n;
  }
char _mon_getc(void) {
  
#ifdef USA_USB_SLAVE_CDC
  char usb_ch_1; 

  usb_ch_1=USB_In_Buffer[RS232cp++];
  if(RS232cp == LastRS232Out) {
    RS232_Out_Data_Rdy=false;
    RS232cp=0;
    
    appData.isReadComplete=false;
    appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
    USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
      &readBuffer, APP_READ_BUFFER_SIZE);

    }
  
/*
  usb_ch_1=readBuffer[0];
  appData.isReadComplete=false;
  appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
  USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
    &readBuffer, APP_READ_BUFFER_SIZE);
  */
  return usb_ch_1;
  
#else

  handle_events();
  switch(eventReceived) {
    BYTE which;
    case SOUTH_BRIDGE:
      __delay_us(20);
      which=ReadPMP(SOUTH_BRIDGE,BIOS_IRQ_REQUEST);		// 
      __delay_us(20);
      switch(which) {
        case EVENT_KEYBOARD:
          ReadPMPs(SOUTH_BRIDGE,BIOS_KEYBOARD_READ,(BYTE*)&keypress,2);

										// USARE keyboardBuffer, UNIRE con sotto

          keypress.new=1;
          break;
        default:
          break;
        }
      eventReceived=0;
      break;
    default:
      eventReceived=0;
      break;
    }


#endif
  
  return keypress.key;
  }

void UserInit(void) {
	unsigned char i;

  ClrWdt();

  ANSELA=0;
  ANSELB=0;
  ANSELC=0;
  ANSELD=0;
  ANSELE=0;
  ANSELF=0;
  ANSELG=0;

  LATA=0b0000000001000000;		// SCS
  LATB=0b0000000000000000;
  LATC=0b0010000000011000;		// DCS; RD, WR
  LATD=0b0001000000110000;		// ECS, WCS, SDCS
  LATE=0b0000000000000000;
  LATF=0b0000000000001000;		// ACS
  LATG=0b1100000000000001;		// VCS, RCS, EIDE_WINCE_reset
  
#ifdef USA_ETHERNET
  TRISA=0b1100010010001000;       // sw-PGood; AIRQ, SIRQ, EIRQ, DIRQ; BA
#else
  TRISA=0b0100010010001000;       // sw-PGood; AIRQ, SIRQ, EIRQ, DIRQ; BA
#endif
  TRISB=0b0000000000000000;       // BA
  TRISC=0b0000000000000000;
  TRISD=0b0000000000000100;       //  SDI, SDO, SCK, ECS
  TRISE=0b0000000100000000;       // led; SDCD; PMP
#if defined(USA_USB_SLAVE_CDC)
	TRISF=0b0000000000000011;			// USBID; VIRQ, WINCIRQ
#else
//	TRISF=0b0000000000001011;			// USBID; VIRQ, WINCIRQ
	TRISF=0b0000000000000011;			// ma c'� ACS su RF3...
#endif
#ifdef USA_WIFI
#endif
  TRISG=0b0000000000000001;			// DDRQ; BA
//  TRISH=0x0000000000000000;
  

//    InitializeUSART();

 
	mInitAllLEDs();
  mInitAllSwitches();

//  CNPUDbits.CNPUD9=CNPUDbits.CNPUD10=1;   // [I2C tanto per] ev. gli IRQ?
  CNPUA=0b1100010010001000;   // 
//  CNPUB=0b1111111111111111;   // serve?
  CNPUC=0b0100000000000000;   // 
  CNPUD=0b0100000000000100;   // 
  CNPUE=0b0100000111111111;   // altrimenti la PMP fluttua..; SDCD
  CNPUF=0b0000000000000011;   // 
  CNPUG=0b0000000000000001;   // 
#if defined(USA_USB_SLAVE_CDC)
  CNPUFbits.CNPUF3=1;   // USBID; ma forse se ne occupa lo stack USB... ma � ACS qua
#else
//  CNPUFbits.CNPUF3=0;   // USBID; ma forse se ne occupa lo stack USB... ma � ACS qua
//  CNPDFbits.CNPDF3=1;   // USBID; DICE che dev'essere pulldown per host! v. usbhs_host_drv
#endif

  
  
  // init PMP
  PMCON= 0b000000100000001100000000;     // tutti segnali attivi low; (no CS1 & 2 ?????); WR & RD; dual buffer mode 
  PMMODE=0b0000001011111111;             // max wait state; 8bit; no irq; master mode 2
  // cos� fa ~190nS write, 1/12/21; in teoria sarebbero 4+16+2= 22*10nS
  // mettendo il PBCLK2 a 10MHz abbiamo 2uS, a 5 abbiamo 4uS (11/12/21)
//  PMAEN =0b0000000000111111;             // BA0..5
  PMAEN =0b0000000000000000;             // BA0..5 [gestiti in software qua..]
  
  PMCONbits.ON=1;
  
	// bah qua non ci serve, direi
//  IPC32bits.PMPIP=3; IPC32bits.PMPIS=2;
//  IEC4bits.PMPIE=1;




	  IPC30bits.CNFIP=3; IPC30bits.CNFIS=3;
//    CNPUBbits.CNPUB15=1;   // IRQ pullup
    CNENFbits.CNIEF1=0;
    CNNEFbits.CNNEF1=1;
    CNCONFbits.EDGEDETECT=1; CNCONFbits.ON=1;
	  IPC29bits.CNAIP=3; IPC29bits.CNAIS=2;
    CNENAbits.CNIEA3=0;
    CNNEAbits.CNNEA3=1;
    CNENAbits.CNIEA7=0;
    CNNEAbits.CNNEA7=1;
    CNENAbits.CNIEA15=0;
    CNNEAbits.CNNEA15=1;
    CNCONAbits.EDGEDETECT=1; CNCONAbits.ON=1;
	  IPC30bits.CNCIP=3; IPC30bits.CNCIS=1;
    CNENCbits.CNIEC14=0;
    CNNECbits.CNNEC14=1;
    CNCONCbits.EDGEDETECT=1; CNCONCbits.ON=1;
// mettere se serve	  IPC31bits.CNGIP=3; IPC31bits.CNGIS=3;
//	  IPC30bits.CNGIP=3; IPC30bits.CNGIS=0;
//    CNENGbits.CNIEG0=0;
//    CNNEGbits.CNNEG0=1;
//    CNCONGbits.ON=1; CNCONGbits.EDGEDETECT=1;



  IFS3bits.CNAIF=0; // i vari IRQ
  IEC3bits.CNAIE=1; // 
  IFS3bits.CNCIF=0; // 
  IEC3bits.CNCIE=1; // 
  IFS3bits.CNFIF=0; // 
  IEC3bits.CNFIE=1; // 
//  IFS3bits.CNGIF=0; // 
//  IEC3bits.CNGIE=1; // 

  
#ifdef USA_EXTENDED_RAM  
//  EBICS0bits.CSADDR=SRAM_ADDR_CS0 >> 16;
  EBICS0=SRAM_ADDR_CS0;
  EBIMSK0bits.MEMTYPE=0b001; // RAM
  EBIMSK0bits.MEMSIZE=0b00110; // 2MB
  EBIMSK0bits.REGSEL=0; // EBISMT0
  // Memory size is set as 2 MB
  // Memory type is set as SRAM
  // Uses timing numbers in EBISMT0
  EBIMSK0 = 0x00000026;
  EBISMT0bits.RDYMODE=0;
  EBISMT0bits.PAGEMODE=0;
  EBISMT0bits.PAGESIZE=0;
  EBISMT0bits.TPRC=0;
  EBISMT0bits.TBTA=0;
  EBISMT0bits.TWP=0;
  EBISMT0bits.TWR=0;
  EBISMT0bits.TAS=0;
  EBISMT0bits.TRC=0;
  EBIFTRPD=0;   // per Flash, non usato qua
  EBISMCONbits.SMDWIDTH0=0b100;   // 8bits
  //Keep default data width to 16-bits
  EBISMCON = 0x00000000;
  CFGEBIA = 0b00000000000000001111111111111111;
  // Enable address lines [0:17]
  // Controls access of pins shared with PMP
  CFGEBIA = 0x800FFFFF;
	CFGEBIAbits.EBIPINEN=0;
	CFGEBICbits.EBIRDYINV1=0;
	CFGEBICbits.EBIRDYINV2=0;
	CFGEBICbits.EBIRDYINV3=0;
	CFGEBICbits.EBIRDYEN1=0;
	CFGEBICbits.EBIRDYEN2=0;
	CFGEBICbits.EBIRDYEN3=0;
	CFGEBICbits.EBIRDYLVL=0;
// non c'� qua	CFGEBICbits.EBIRPEN=0;
	CFGEBICbits.EBIWEEN=1;
	CFGEBICbits.EBIOEEN=1;
//	CFGEBICbits.EBIBSEN1=0;
	CFGEBICbits.EBICSEN0=0;
	CFGEBICbits.EBIDEN0=1;
	CFGEBICbits.EBIDEN1=0;
  //Enable write enable pin
  //Enable output enable pin
  //Enable byte select pin 0
  //Enable byte select pin 1
  //Enable Chip Select 0
  //Enable data pins [0:15]
  CFGEBIC = 0x00003313;
  // ovviamente, usando la EBI si perde la PMP! (ossia le periferiche)
#endif
  
  }	//end UserInit

enum CACHE_MODE {
  UNCACHED=0x02,
  WB_WA=0x03,
  WT_WA=0x01,
  WT_NWA=0x00,
/* Cache Coherency Attributes */
//#define _CACHE_WRITEBACK_WRITEALLOCATE      3
//#define _CACHE_WRITETHROUGH_WRITEALLOCATE   1
//#define _CACHE_WRITETHROUGH_NOWRITEALLOCATE 0
//#define _CACHE_DISABLE                      2
  };
void mySYSTEMConfigPerformance(BYTE m1,BYTE m2) {
  unsigned int PLLIDIV;
  unsigned int PLLMUL;
  unsigned int PLLODIV;
  double CLK2USEC;
  unsigned int SYSCLK;
  unsigned char PLLODIVVAL[]={
    2,2,4,8,16,32,32,32
    };
	unsigned int cp0;

  PLLIDIV=SPLLCONbits.PLLIDIV+1;
  PLLODIV=PLLODIVVAL[SPLLCONbits.PLLODIV];

  SYSKEY = 0x00000000;
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;

  SPLLCONbits.PLLMULT=(!m1 ? 50 : (m2==1 ? 25 : 12));
  // finire... cambiare GetInstructionClock ecc
  
  PLLMUL=SPLLCONbits.PLLMULT+1;
  SYSCLK=(FOSC*PLLMUL)/(PLLIDIV*PLLODIV);
  CLK2USEC=SYSCLK/1000000.0f;

  if(SYSCLK<=60000000L)
    PRECONbits.PFMWS=0;
  else if(SYSCLK<=120000000L)
    PRECONbits.PFMWS=1;
  else if(SYSCLK<=200000000L)
    PRECONbits.PFMWS=2;
  else if(SYSCLK<=220000000L)
    PRECONbits.PFMWS=3;
  else if(SYSCLK<=252000000L)
    PRECONbits.PFMWS=4;
  else
    PRECONbits.PFMWS=7;

  PRECONbits.PFMSECEN=0;
  PRECONbits.PREFEN=0b10;    // provare 0b10 per prefetch data e code... // 0b01


    PB2DIVbits.ON = 1; // Peripheral Bus 2 Output Clock Enable (Output clock is enabled)
    while(!PB2DIVbits.PBDIVRDY); // Wait until it is ready to write to
    PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_FAST-1; // Peripheral Bus 2 Clock Divisor Control (PBCLK2 is SYSCLK divided by 40) per PMP
    // OCCHIO comanda pure SPI :(

//    PB4DIVbits.ON = 1; // Peripheral Bus 4 Output Clock Enable (Output clock is enabled)
//    while (!PB4DIVbits.PBDIVRDY); // Wait until it is ready to write to
//    PB4DIVbits.PBDIV = 0; // Peripheral Bus 4 Clock Divisor Control (PBCLK4 is SYSCLK divided by 1)
  SYSKEY = 0x00000000;

  cp0 = _mfc0(16, 0);
  cp0 &= ~0x07;		// 03 negli esempi...
  cp0 |= (!m2 ? WB_WA : (m2==1 ? WB_WA : UNCACHED)); // K0 = Cacheable, non-coherent, write-back, write allocate
  _mtc0(16, 0, cp0);  
  //PCACHE_PrefetchEnableSet_MZ
//  SYS_DEVCON_CacheCoherencySet((!m2 ? WB_WA : (m2==1 ? WB_WA : UNCACHED)));
  }
  
void myINTEnableSystemMultiVectoredInt(void) {

  PRISS = 0x76543210;
  INTCONSET = _INTCON_MVEC_MASK /*0x1000*/;    //MVEC
  __builtin_enable_interrupts();
  }


#warning NON C'E' EEPROM!
void EEwrite(int addr,BYTE n) {	// 
  unsigned int i;
  
  i=DataEERead(addr/4);
  switch(addr & 3) {
    case 0:
      i &= 0xffffff00;
      i |= n;
      break;
    case 1:
      i &= 0xffff00ff;
      i |= ((unsigned int)n << 8);
      break;
    case 2:
      i &= 0xff00ffff;
      i |= ((unsigned int)n << 16);
      break;
    case 3:
      i &= 0x00ffffff;
      i |= ((unsigned int)n << 24);
      break;
    }
  DataEEWrite(i,addr/4);
  }
BYTE EEread(int addr) {
  unsigned int i;
  
  i=DataEERead(addr/4);
  switch(addr & 3) {
    case 0:
      return i & 0xff;
      break;
    case 1:
      return (i >> 8) & 0xff;
      break;
    case 2:
      return (i >> 16) & 0xff;
      break;
    case 3:
      return (i >> 24) & 0xff;
      break;
    }
  }

void EEinit(void) {
  
  DataEEInit();
	ClrWdt();
// bah, ma serve??  dataEEFlags.val = 0;
//  Nop();
//  Nop();
  }

/*********************************************************************
 * Function:        void InitAppConfig(void)
 *
 * PreCondition:    MPFSInit() is already called.
 *
 * Input:           None
 *
 * Output:          Write/Read non-volatile config variables.
 *
 * Side Effects:    None
 *
 * Overview:        None
 *
 * Note:            None
 ********************************************************************/
// MAC Address Serialization using a MPLAB PM3 Programmer and 
// Serialized Quick Turn Programming (SQTP). 
// The advantage of using SQTP for programming the MAC Address is it
// allows you to auto-increment the MAC address without recompiling 
// the code for each unit.  To use SQTP, the MAC address must be fixed
// at a specific location in program memory.  Uncomment these two pragmas
// that locate the MAC address at 0x1FFF0.  
#if 0
const static BYTE SerializedMACAddress[6] = {MY_DEFAULT_MAC_BYTE1, MY_DEFAULT_MAC_BYTE2, MY_DEFAULT_MAC_BYTE3, MY_DEFAULT_MAC_BYTE4, MY_DEFAULT_MAC_BYTE5, MY_DEFAULT_MAC_BYTE6};

void InitAppConfig(void) {
	unsigned char vNeedToSaveDefaults = 0;
  
		// Start out zeroing all AppConfig bytes to ensure all fields are 
		// deterministic for checksum generation
		memset((void*)&BiosArea, 0x00, sizeof(BiosArea));
		
		BiosArea.Flags.bIsDHCPEnabled = FALSE /*TRUE*/;
    
		BiosArea.Flags.bInConfigMode = TRUE;
		BiosArea.Flags.bInConfigMode = FALSE;
    
    
		memcpy((void*)&BiosArea.MyMACAddr, (void*)SerializedMACAddress, sizeof(BiosArea.MyMACAddr));
		BiosArea.MyIPAddr.Val = MY_DEFAULT_IP_ADDR_BYTE1 | MY_DEFAULT_IP_ADDR_BYTE2<<8ul | MY_DEFAULT_IP_ADDR_BYTE3<<16ul | MY_DEFAULT_IP_ADDR_BYTE4<<24ul;
		BiosArea.DefaultIPAddr.Val = BiosArea.MyIPAddr.Val;
		BiosArea.MyMask.Val = MY_DEFAULT_MASK_BYTE1 | MY_DEFAULT_MASK_BYTE2<<8ul | MY_DEFAULT_MASK_BYTE3<<16ul | MY_DEFAULT_MASK_BYTE4<<24ul;
		BiosArea.DefaultMask.Val = BiosArea.MyMask.Val;
		BiosArea.MyGateway.Val = MY_DEFAULT_GATE_BYTE1 | MY_DEFAULT_GATE_BYTE2<<8ul | MY_DEFAULT_GATE_BYTE3<<16ul | MY_DEFAULT_GATE_BYTE4<<24ul;
		BiosArea.PrimaryDNSServer.Val = MY_DEFAULT_PRIMARY_DNS_BYTE1 | MY_DEFAULT_PRIMARY_DNS_BYTE2<<8ul  | MY_DEFAULT_PRIMARY_DNS_BYTE3<<16ul  | MY_DEFAULT_PRIMARY_DNS_BYTE4<<24ul;
		BiosArea.SecondaryDNSServer.Val = MY_DEFAULT_SECONDARY_DNS_BYTE1 | MY_DEFAULT_SECONDARY_DNS_BYTE2<<8ul  | MY_DEFAULT_SECONDARY_DNS_BYTE3<<16ul  | MY_DEFAULT_SECONDARY_DNS_BYTE4<<24ul;
	
		// Load the default NetBIOS Host Name
		memcpy(BiosArea.NetBIOSName, (void*)MY_DEFAULT_HOST_NAME, 16);
		FormatNetBIOSName(BiosArea.NetBIOSName);
		BiosArea.httpPort=HTTP_PORT;
		strcpy(BiosArea.nome_admin,"admin");
		strcpy(BiosArea.pasw_admin,"pasw");

	}

void SaveAppConfig() {


  }
#endif
void SaveBios(BYTE m) {
  int i;
  
  switch(m) {   // gestire aree...
  { 
    BYTE *p=(BYTE*)&BiosArea;
//    for(i=0; i<sizeof(BiosArea); i++)
//      EEwrite(i,p[i]);
#warning EEwrite non va!
   }
    }
  
  {
    AreaEEWrite(&BiosArea, sizeof(BiosArea));
  }

  
  }

void __attribute__((used)) __delay_us(unsigned int usec) {
  unsigned int tWait, tStart;

#ifndef USING_SIMULATOR
  tWait=(GetSystemClock()/2000000UL)*usec;
  tStart=_mfc0(9,0);
  while((_mfc0(9,0)-tStart)<tWait)
    ClrWdt();        // wait for the time to pass
#endif
  }

void __attribute__((used)) __delay_ms(unsigned int ms) {
  
#ifndef USING_SIMULATOR
  while(ms--)
    __delay_us(1000);
#endif
  }

void handle_events(void) {
  BYTE which;

  ClrWdt();
  switch(eventReceived) {
    case AUDIO_CARD:
      __delay_us(20);
      which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 
      __delay_us(20);
      switch(which) {
        case EVENT_AUDIOOUT:
          break;
        case EVENT_AUDIOIN:
          break;
        case EVENT_MIDI:
          ReadPMP(AUDIO_CARD,BIOS_AUDIO_READMIDI);		// 
          break;
        case EVENT_JOYSTICK:
          break;
        case EVENT_CLOCK:
          break;
        case EVENT_ALARM:
          printf("\r\nALARM!\r\n"); //:)
          break;
        default:
          break;
        }
      eventReceived=0;
      break;
    case SOUTH_BRIDGE:
      __delay_us(20);
      which=ReadPMP(SOUTH_BRIDGE,BIOS_IRQ_REQUEST);		// 
      __delay_us(20);
      switch(which) {
        case EVENT_KEYBOARD:
          ReadPMPs(SOUTH_BRIDGE,BIOS_KEYBOARD_READ,(BYTE*)&keypress,2);

					// USARE keyboardBuffer

          break;
        case EVENT_RS232:
//          keypress.key=      ReadPMP(SOUTH_BRIDGE,BIOS_SERIAL_CHAR);		//  DEBUG
          {
            char ch=ReadPMP(SOUTH_BRIDGE,BIOS_SERIAL_CHAR);   // qua leggo un byte solo, essendo evento � sicuramente valido e non -1 !

					// USARE rs232Buffer

					if(BiosArea.flags.verboseMode)
              printf("[RS232 %02X]",ch);
						}
          break;
        case EVENT_USB_IN:
          suona_USBin();
          // leggere che tipo di periferica � arrivata...
          break;
        case EVENT_USB_OUT:
          suona_USBout();
          break;
        default:
          break;
        }
      eventReceived=0;
      break;
    case VIDEO_CARD:
//EVENT_VIDEOFRAME
      //videoFrameCnt++;    // fatto in irq!
      eventReceived=0;
      break;
    case 0:
      break;
    default:
      // DIRQ	which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 
//DDRQ	which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 
      eventReceived=0;
      break;
    }

  }


// USB host (harmony madonna puttana) ------------------------------------------
/*******************************************************************************
  Function:
    void APP_Initialize(void)

  Remarks:
    See prototype in app.h.
 */

APP_DATA appData __attribute__((coherent)) __attribute__((aligned(16)));


#if defined(USA_USB_HOST_UVC)
// Specify the Video Stream format details that this application supports
const APP_USB_HOST_UVC_STREAM_FORMAT videoStreamFormat = {
    
  .streamDirection = USB_HOST_UVC_DIRECTION_IN,
  .wWidth=320,
  .wHeight=240,
  .bitPerPixel=32,
  .format=0
/*    .format = USB_AUDIO_FORMAT_PCM,
    .nChannels = 2,
    .bitResolution = 16,
    .subFrameSize = 2,
    .samplingRate = 48000*/
  }; 
#endif

void APP_Initialize(void) {

#if defined(USA_USB_HOST)
  // Place the App state machine in its initial state.
  appData.state =  APP_STATE_BUS_ENABLE;
  appData.deviceIsConnected = false;
#if defined(USA_USB_HOST_UVC)
  APP_VideoDataSetDefault();
#endif
#endif
  
  /* TODO: Initialize your application's state machine and other
   * parameters.
   */
#if defined(USA_USB_SLAVE_CDC)
    // Place the App state machine in its initial state.
    appData.state = APP_STATE_INIT;
    
    // Device Layer Handle
    appData.deviceHandle = USB_DEVICE_HANDLE_INVALID;

    // Device configured status
    appData.isConfigured = false;

    // Initial get line coding state
    appData.getLineCodingData.dwDTERate = 115200;
    appData.getLineCodingData.bParityType =  0;
    appData.getLineCodingData.bParityType = 0;
    appData.getLineCodingData.bDataBits = 8;

    // Read Transfer Handle
    appData.readTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;

    // Write Transfer Handle
    appData.writeTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;

    // Initialize the read complete flag
    appData.isReadComplete = false;

    // Initialize the write complete flag
    appData.isWriteComplete = true;

    // Reset other flags 
    appData.sofEventHasOccurred = false;
#endif

  }

#if defined(USA_USB_HOST_UVC)
void APP_VideoDataSetDefault(void) {
  
  appData.isVideoDeviceAttached = false;
  appData.isVideoInStreamFound = false; 
  appData.isVideoWriteCompleted = false;
  appData.isVideoReadCompleted = false;
  appData.isStreamEnabled = false;
  appData.isStreamInterfaceSetZeroComplete = false;
  appData.isStreamInterfaceSetOneComplete = false;
  appData.requestHandle = USB_HOST_UVC_REQUEST_HANDLE_INVALID;
  appData.transferHandleVideoWrite = USB_HOST_UVC_STREAM_TRANSFER_HANDLE_INVALID;
  appData.transferHandleVideoRead = USB_HOST_UVC_STREAM_TRANSFER_HANDLE_INVALID;

  appData.isMuteSwitchPressed = false; 
  appData.ignoreSwitchPress = true;
  appData.sofEventHasOccurred = false; 
  
  // Set following to true until we start parsing descriptors
  appData.width=0;
  appData.height=0;
  appData.bitsPerPixel=0;



  }
uint8_t videoSamples[3100];     // 3072max su VGA converter, appData.packetSize
#endif


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
#if defined(USA_USB_SLAVE_CDC)
void APP_USBDeviceEventHandler(USB_DEVICE_EVENT event, void *eventData, uintptr_t context);
#endif
#ifdef USA_USB_HOST_MSD
void APP_SYSFSEventHandler(SYS_FS_EVENT event, void *eventData, uintptr_t context);
USB_HOST_EVENT_RESPONSE APP_USBHostEventHandler(USB_HOST_EVENT event, void * eventData, uintptr_t context);
#endif

#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#if defined(USA_ETHERNET)
#define APP_LED_BLINK_COUNT 10000
#define APP_USB_SWITCH_DEBOUNCE_COUNT 30
#else
#define APP_LED_BLINK_COUNT 50000
#define APP_USB_SWITCH_DEBOUNCE_COUNT 150
#endif
#else
#if defined(USA_ETHERNET)
#define APP_LED_BLINK_COUNT 20000
#define APP_USB_SWITCH_DEBOUNCE_COUNT 50
#else
#define APP_LED_BLINK_COUNT 100000
#define APP_USB_SWITCH_DEBOUNCE_COUNT 260
#endif
#endif

void APP_Tasks(void) {
  char buf[16];
//  USB_HOST_UVC_RESULT videoResult;
  static DWORD countLedBlink=0;
  static DWORD divider=0;
  static BYTE test,cnt;
  static BYTE oldState; 
  static BYTE oldY;
  WORD /*bool*/ status = 0;
  
  divider++;
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#if defined(USA_ETHERNET)
  if(divider>50000L || appData.state!=oldState) {
#else
  if(divider>500000L || appData.state!=oldState) {
#endif
#else
#if defined(USA_ETHERNET)
  if(divider>100000L || appData.state!=oldState) {
#else
  if(divider>1000000L || appData.state!=oldState) {
#endif
#endif
//    printf(".appState=%u\r\n",appData.state);
//  putsUART1(buf);
    divider=0;
    
    test=!test;
  
//    WriteSerial(test ? '.' : ' ');
    
//		DrawLine(cnt*2,cnt,80,64, sw1 ? 0xf800 : 0x000f);
		/*if(cnt<128)
			SetVideoMode(MODE_VGA,640,480,8);      //
		else
			SetVideoMode(MODE_LCD_DMA,160,120,16);      //*/
    
		// incorporato SetAudioMode(SYNTH);
	//  SetAudioWave(0,TRIANGOLARE,sw1 /*test*/ ? 2000 : 500,2,8,80,0,0);

		if(!sw1)
//			SetAudioFrequency(0,1200);
//		else
			SetAudioWave(1,TRIANGOLARE /*SINUSOIDALE*/,test ? 2000 : 600,1,8,70,0,0);



//		while(!sw1)
//        ReadPMP(SOUTH_BRIDGE,BIOS_IRQ_REQUEST);		// 

		if(!sw1) {
//	  status=test ? GetID(SOUTH_BRIDGE) : GetID(VIDEO_CARD);
//    else
//	  status=ReadPMP(AUDIO_CARD,BIOS_GETID);
//	  status=PMRDIN;
	  status=test ? GetVersion(SOUTH_BRIDGE) : GetVersion(AUDIO_CARD);
    WriteSerial(test);
    

    
    KeyboardSetLed(oldY);
    
		if(oldY>15) {
			Cls();
			oldY=0;
			}
		printf("%02X, %u,%x\r\n",status,oldY,!!test);
		oldY++;
    }
    cnt++;
    


    if(!sw1)
      OC1CONbits.ON=1;    // PROVE!
    else
      OC1CONbits.ON=0;    // 

    if(!SDcardOK) {
    	if(MDD_MediaDetect()) { 		// 
        SDcardOK=FSInit();      // File system
        if(currDrive==0)
          currDrive=setCurrentDrive(0);
        goto make_prompt;
        }
      }
    else {
    	if(!MDD_MediaDetect()) { 		// 
        MDD_ShutdownMedia();
        SDcardOK=FALSE;
make_prompt:
				if(currDrive=='A')
					currDrive=setCurrentDrive(0);
        makePrompt();
//        putchar('\n'); printf(prompt);
        }
      }
    
    
#ifdef USA_WIFI
		if(!(now % 86400))
			m2m_wifi_get_sytem_time();   // mi sembra carino, a mezzanotte! o meglio una volta al giorno
#endif

    oldState=appData.state;
    }
  
//    mLED_1 ^= 1;     //  ~1.3uS/330KHz 1/12/21
  countLedBlink++;
  if(countLedBlink >= APP_LED_BLINK_COUNT) {
    mLED_1 ^= 1;     //  
    countLedBlink = 0; 

    }


  ClrWdt();
  


  // Check the application's current state.
  switch(appData.state) {
    
#if defined(USA_USB_HOST_MSD)
    case APP_STATE_BUS_ENABLE:
     // Set the event handler and enable the bus 
      SYS_FS_EventHandlerSet(APP_SYSFSEventHandler, (uintptr_t)NULL);
      USB_HOST_EventHandlerSet(APP_USBHostEventHandler, 0);
      USB_HOST_BusEnable(0);
      appData.state = APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE;
//        printf("wait BUS enable\r\n");
//      APP_USB_LED_1=0; 
      break;
            
    case APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE:
      if(USB_HOST_BusIsEnabled(0)) {
        appData.state = APP_STATE_WAIT_FOR_DEVICE_ATTACH;
        }
      break;
       
    case APP_STATE_WAIT_FOR_DEVICE_ATTACH:
      /* Wait for device attach. The state machine will move
       * to the next state when the attach event is received.  */
      if(appData.deviceIsConnected) {
//        printf("wait device attach\r\n");
        appData.state = APP_STATE_DEVICE_CONNECTED;
        }
      break;

    case APP_STATE_DEVICE_CONNECTED:
        /* Device was connected. We can try mounting the disk */
//serve???  SOLO se non c'� AUTOMOUNT!            if(SYS_FS_Mount("/mnt/myDrive") != 0) {
//            appData.state = APP_STATE_OPEN_FILE;
//        printf("device attachED\r\n");
// se � FAT32 e non FAT, NON ARRIVA!! (anche se SCSI l'ha visto, v.)

        
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#ifndef USBID_OVERRIDE
//  TRISFbits.TRISF3=0;
      LATFbits.LATF3=1;   // CASINO CON m_ACS!! dopo un po' si pu� fare
#warning m_ACS vs USBID!
#endif
#endif

      break;

/*
            // Try opening the file for append 
            appData.fileHandle = SYS_FS_FileOpen("/mnt/myDrive1/file.txt", (SYS_FS_FILE_OPEN_APPEND_PLUS));
            if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
                // Could not open the file. Error out

            }
            else {

            // Try writing to the file 
            if(SYS_FS_FileWrite( appData.fileHandle, (const void *) writeData, sizeof(writeData) ) == -1) {
                // Write was not successful. Close the file and error out.
                SYS_FS_FileClose(appData.fileHandle);
                appData.state = APP_STATE_ERROR;

            }
            else {
                // We are done writing. Close the file 
                appData.state = APP_STATE_CLOSE_FILE;
            }

            // Close the file 
            SYS_FS_FileClose(appData.fileHandle);

            // The test was successful. Lets idle. 
            appData.state = APP_STATE_IDLE;
            */

#endif
#if defined(USA_USB_HOST_UVC)

    case APP_STATE_BUS_ENABLE:


        appData.state = APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE; 
      break; 

    case APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE:
        appData.state = APP_STATE_WAIT_FOR_DEVICE_ATTACH;
      break; 
			
    case APP_STATE_WAIT_FOR_DEVICE_ATTACH:

      appData.state = APP_STATE_ZERO_BANDWIDTH_INTERFACE_SET;
      break; 

    case APP_STATE_ZERO_BANDWIDTH_INTERFACE_SET:
        appData.state = APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ZERO; 
      break;

    case APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ZERO:
        appData.state = APP_STATE_WAIT_FOR_SET_PROBE_VIDEO;
      break; 
            
    case APP_STATE_WAIT_FOR_SET_PROBE_VIDEO:
        appData.state = APP_STATE_WAIT_FOR_GET_PROBE_VIDEO;
      break;

    case APP_STATE_WAIT_FOR_GET_PROBE_VIDEO:
        appData.state = APP_STATE_WAIT_FOR_SET_COMMIT_VIDEO;
      break;

    case APP_STATE_WAIT_FOR_SET_COMMIT_VIDEO:
        appData.state = APP_STATE_ENABLE_VIDEO_STREAM; 
      break;

    case APP_STATE_ENABLE_VIDEO_STREAM:
      appData.isStreamInterfaceSetComplete = false;

        appData.state = APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ONE;
      break; 

    case APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ONE:
        appData.state = APP_STATE_START_STREAM_DATA;
        
      break; 

    case APP_STATE_START_STREAM_DATA:
      appData.state = APP_STATE_WAIT_FOR_READ_COMPLETE; 
      break;

    case APP_STATE_WAIT_FOR_READ_COMPLETE:
      /* mettere codice per gestire webcam... */
      appData.state = APP_STATE_WAIT_FOR_READ_COMPLETE; 
      break;
#endif

#if defined(USA_USB_SLAVE_CDC)
    case APP_STATE_INIT:
        // Open the device layer
        appData.deviceHandle = USB_DEVICE_Open(USB_DEVICE_INDEX_0, DRV_IO_INTENT_READWRITE);

        if(appData.deviceHandle != USB_DEVICE_HANDLE_INVALID)            {
            // Register a callback with device layer to get event notification (for endpoint 0)
            USB_DEVICE_EventHandlerSet(appData.deviceHandle, APP_USBDeviceEventHandler, 0);

            appData.state = APP_STATE_WAIT_FOR_CONFIGURATION;
          }
        else            {
            /* The Device Layer is not ready to be opened. We should try again later. */
        }

        break;

    case APP_STATE_WAIT_FOR_CONFIGURATION:
        // Check if the device was configured
        if(appData.isConfigured)            {
            /* If the device is configured then lets start reading */
            appData.state = APP_STATE_SCHEDULE_READ;

            appData.isReadComplete = false;
            appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;

            USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
                    &readBuffer, APP_READ_BUFFER_SIZE);

            if(appData.readTransferHandle == USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID)                {
                appData.state = APP_STATE_ERROR;
                break;
            }
        }
        break;

    case APP_STATE_SCHEDULE_READ:
//            if(APP_StateReset()) {
//                break;
//            }


        //Check if any bytes are waiting in the queue to send to the USB host.
//If any bytes are waiting, and the endpoint is available, prepare to
//send the USB packet to the host.
        if( /*(appData.isWriteComplete==true) && */ (NextUSBOut > 0)) {
//              memcpy(writeBuffer,USB_Out_Buffer,NextUSBOut);   // buffer allineati e di % 512!!
          appData.writeTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
          USB_DEVICE_CDC_Write(USB_DEVICE_CDC_INDEX_0, &appData.writeTransferHandle,
            &writeBuffer, NextUSBOut, USB_DEVICE_CDC_TRANSFER_FLAGS_DATA_COMPLETE);
          appData.isWriteComplete=false;
          NextUSBOut=0;
          }

        /*

if(RS232_Out_Data_Rdy == 0) { // only check for new USB buffer if the old RS232 buffer is
                            // empty.  This will cause additional USB packets to be NAK'd
            USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
                    &readBuffer, APP_READ_BUFFER_SIZE);
memcpy(USB_In_Buffer,readBuffer,APP_READ_BUFFER_SIZE);
LastRS232Out = getsUSBUSART(USB_In_Buffer,64); //until the buffer is free.
if(LastRS232Out > 0) {	
  RS232_Out_Data_Rdy = 1;  // signal buffer full
  RS232cp = 0;  // Reset the current position
  }
}


*/

        break;

#endif
      

    case APP_STATE_ERROR:
      countLedBlink++; 
//        appData.state =  APP_STATE_WAIT_FOR_DEVICE_ATTACH;
      break; 

    case APP_STATE_IDLE:

      /* The application comes here when the demo has completed
       * successfully. Provide LED indication. Wait for device detach
       * and if detached, wait for attach. */

//        mLED_1 ^= 1;
      break;

    // The default state should never be executed.
    default:
      Nop(); 
      break;

    }
	}



// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

#if defined(USA_USB_HOST_UVC)
void APP_ProcessSwitchPress(void) {
  
  /* This function checks if the switch is pressed and then
   * debounces the switch press*/
  if(!sw1) {
      if(appData.ignoreSwitchPress) {
          // This means the key press is in progress
          if(appData.sofEventHasOccurred) {
              // A timer event has occurred. Update the debounce timer
              appData.switchDebounceTimer ++;
              appData.sofEventHasOccurred = false;

              if(appData.switchDebounceTimer == APP_USB_SWITCH_DEBOUNCE_COUNT) {
                  /* Indicate that we have valid switch press. The switch is
                   * pressed flag will be cleared by the application tasks
                   * routine. We should be ready for the next key press.*/
                  appData.isMuteSwitchPressed = true;
                  appData.switchDebounceTimer = 0;
                  appData.ignoreSwitchPress = false;
              }
          }
        }
      else {
        // We have a fresh key press
        appData.ignoreSwitchPress = true;
        appData.switchDebounceTimer = 0;
        }
      }
  else {
      // No key press. Reset all the indicators.
      appData.ignoreSwitchPress = false;
      appData.switchDebounceTimer = 0;
      appData.sofEventHasOccurred = false;
    }

  }
#endif

#ifdef USA_USB_HOST_MSD
USB_HOST_EVENT_RESPONSE APP_USBHostEventHandler(USB_HOST_EVENT event, void * eventData, uintptr_t context) {
  
  switch(event) {
    case USB_HOST_EVENT_DEVICE_UNSUPPORTED:
      break;
    case USB_HOST_EVENT_DEVICE_REJECTED_INSUFFICIENT_POWER:
    case USB_HOST_EVENT_HUB_TIER_LEVEL_EXCEEDED:
    case USB_HOST_EVENT_PORT_OVERCURRENT_DETECTED:
    default: 
      break; 
    }
    
  return(USB_HOST_EVENT_RESPONSE_NONE);
  }

void APP_SYSFSEventHandler(SYS_FS_EVENT event, void *eventData, uintptr_t context) {
  
  switch(event) {
    case SYS_FS_EVENT_MOUNT:
      appData.deviceIsConnected = true;
//      puts("deviceConnected");
      suona_USBin();
      USBmemOK=1;
      if(currDrive==0)
        currDrive=setCurrentDrive(0);
      makePrompt();
//      putchar('\n'); printf(prompt);
      break;

    case SYS_FS_EVENT_UNMOUNT:
      appData.deviceIsConnected = false;
      suona_USBout();
      USBmemOK=0;
      if(currDrive=='E')
        currDrive=setCurrentDrive(0);
      makePrompt();
//      putchar('\n'); printf(prompt);
      break;

    default:
      break;
    }
  }
#endif


// -----------------------------------------------------------------------------
#ifdef USA_WIFI
void wifi_cb(BYTE u8MsgType, void *pvMsg) {
  static /*DAVVERO?? ***** */uint8_t u8ScanResultIdx=0;
  
  switch(u8MsgType) {
      case M2M_WIFI_REQ_DHCP_CONF:
      {
        m2m_wifi_get_connection_info();
        BYTE *pu8IPAddress = (BYTE *)pvMsg;
//        wifi_connected = 1;
        /* Turn LED0 on to declare that IP address received. */
//        m2m_periph_gpio_set_dir(4, 1);    // get_gpio_idx(
//        m2m_periph_gpio_set_val(4, 0);
//        port_pin_set_output_level(LED_0_PIN, false);
//        printf("m2m_wifi_state: M2M_WIFI_REQ_DHCP_CONF: IP is %u.%u.%u.%u\n",
//          pu8IPAddress[0], pu8IPAddress[1], pu8IPAddress[2], pu8IPAddress[3]);
        /*TODO: add socket initialization here. */
        registerSocketCallback(clientSocketEventHandler, dnsResolveCallback);
        tcpStartServer(BiosArea.httpPort);

				m2m_wifi_get_sytem_time();   // va direttamente in now!

//        setStatusLed(LED_NORMALE_CONNESSO_WIFI);
//        advertise(UDPclientSocket);      // 

      }
        break;
      case M2M_WIFI_RESP_CON_STATE_CHANGED:   // https://www.avrfreaks.net/forum/winc1500-connecting-wifi-disconnects-immediately-error-code-1
      {
        tstrM2mWifiStateChanged *strState=(tstrM2mWifiStateChanged *)pvMsg;
        switch(strState->u8CurrState) {
          case M2M_WIFI_DISCONNECTED:
            m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,1);
            close(UDPclientSocket);
            UDPclientSocket=INVALID_SOCKET;
            close(TCPlistenSocket);   // in effetti, chiss� se serve...
            close(TCPacceptedSocket);
            TCPacceptedSocket=TCPlistenSocket=INVALID_SOCKET;
            bTCPIsfinished = 0;
            break;
          case M2M_WIFI_CONNECTED:
            // messo sopra...
            m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,0);
            m2m_wifi_req_curr_rssi();
            break;
          case M2M_WIFI_ROAMED:
            break;
          case M2M_WIFI_UNDEF:
            break;
          }

      }
        break;
      case M2M_WIFI_RESP_CONN_INFO:
      {
        tstrM2MConnInfo *pstrConnInfo = (tstrM2MConnInfo *)pvMsg;

        m2m_periph_gpio_set_dir(M2M_PERIPH_GPIO15,1);    // GP15 su pdf (v. cmq setpin ecc)
        m2m_periph_gpio_set_dir(M2M_PERIPH_GPIO16,1);    // GP16 su pdf 
        m2m_periph_gpio_set_dir(M2M_PERIPH_GPIO18,1);    // GP18 su pdf schema FROCI! (opp. 6 merdeee get_gpio_idx) RIFATTO IO
        m2m_periph_gpio_set_val(M2M_PERIPH_GPIO15,1);
        m2m_periph_gpio_set_val(M2M_PERIPH_GPIO16,1);
        m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,0);

        M2M_INFO("AP Connection Information\r\n*********************************\r\n"); 
        myIp.ip=MAKELONG(MAKEWORD(pstrConnInfo->au8IPAddr[0], pstrConnInfo->au8IPAddr[1]), MAKEWORD(pstrConnInfo->au8IPAddr[2], pstrConnInfo->au8IPAddr[3]));
        M2M_INFO("Local IP Address    : %d.%d.%d.%d\r\n",
          pstrConnInfo->au8IPAddr[0] , pstrConnInfo->au8IPAddr[1], pstrConnInfo->au8IPAddr[2], pstrConnInfo->au8IPAddr[3]);
        M2M_INFO("SSID             : %s\r\n",pstrConnInfo->acSSID);
        M2M_INFO("SEC TYPE         : %d\r\n",pstrConnInfo->u8SecType);
        M2M_INFO("AP MAC Address        : %02x:%02x:%02x:%02x:%02x:%02x\r\n",
          pstrConnInfo->au8MACAddress[0], pstrConnInfo->au8MACAddress[1],pstrConnInfo->au8MACAddress[2],pstrConnInfo->au8MACAddress[3],
          pstrConnInfo->au8MACAddress[4],pstrConnInfo->au8MACAddress[5]);
        M2M_INFO("Signal Strength        : %d\r\n", pstrConnInfo->s8RSSI);
        M2M_INFO("Current Channel        : %d\r\n", pstrConnInfo->u8CurrChannel);   
      }
        break;
    case M2M_WIFI_RESP_GET_SYS_TIME: 
      { 
      tstrSystemTime *mytime = (tstrSystemTime *)pvMsg; 
//      M2M_INFO("wifi_cb:M2M_WIFI_RESP_GET_SYS_TIME \r\n"); 
//      M2M_INFO("My hour %d \r\n",mytime->u8Hour); 
//      M2M_INFO("My min %d \r\n",mytime->u8Minute); 
//      M2M_INFO("My sec %d \r\n",mytime->u8Second); 
      uint16_t y;
      uint16_t m;
      uint16_t d;
      DWORD t;
//https://www.oryx-embedded.com/doc/date__time_8c_source.html
// v. anche DWORD SetNowFromTime(PIC32_DATE date,PIC32_TIME time) {
      
      //Year
      y = mytime->u16Year;
      //Month of year
      m = mytime->u8Month;
      //Day of month
      d = mytime->u8Day;

      //January and February are counted as months 13 and 14 of the previous year
      if(m <= 2) {
        m += 12;
        y -= 1;
        }

      //Convert years to days
      t = (365 * y) + (y / 4) - (y / 100) + (y / 400);
      //Convert months to days
      t += (30 * m) + (3 * (m + 1) / 5) + d;
      //Unix time starts on January 1st, 1970
      t -= 719561;
      //Convert days to seconds
      t *= 86400;
      //Add hours, minutes and seconds
      t += (3600 * mytime->u8Hour) + (60 * mytime->u8Minute) + mytime->u8Second;
      now=t;

      SetRTCC(mytime->u8Day,mytime->u8Month,mytime->u16Year,mytime->u8Hour,mytime->u8Minute,mytime->u8Second);

      } 
      break; 
    case M2M_WIFI_RESP_CURRENT_RSSI:
      myRSSI=*(BYTE *)pvMsg;
      break; 
	  case M2M_WIFI_RESP_SCAN_DONE:
    {
    tstrM2mScanDone *pstrInfo = (tstrM2mScanDone*)pvMsg;
//    printf("Num of AP found %d\n",pstrInfo->u8NumofCh);
    if(pstrInfo->s8ScanState == M2M_SUCCESS) {
      u8ScanResultIdx=0;
      if(pstrInfo->u8NumofCh >= 1) {
        *internetBuffer=0;
        m2m_wifi_req_scan_result(u8ScanResultIdx);
        u8ScanResultIdx++;
        }
      else {
//        printf("No AP Found Rescan\n");
        m2m_wifi_request_scan(M2M_WIFI_CH_ALL);
        }
      }
    else {
//      printf("(ERR) Scan fail with error <%d>\n",pstrInfo->s8ScanState);
      }
      }
    break;
  case M2M_WIFI_RESP_SCAN_RESULT:
    {
    tstrM2mWifiscanResult *pstrScanResult =(tstrM2mWifiscanResult*)pvMsg;
    uint8_t u8NumFoundAPs = m2m_wifi_get_num_ap_found();
/*    printf(">>%02d RI %d SEC %s CH %02d BSSID %02X:%02X:%02X:%02X:%02X:%02X SSID %s\n",
    pstrScanResult->u8index,pstrScanResult->s8rssi,
    pstrScanResult->u8AuthType,
    pstrScanResult->u8ch,
    pstrScanResult->au8BSSID[0], pstrScanResult->au8BSSID[1], pstrScanResult->au8BSSID[2],
    pstrScanResult->au8BSSID[3], pstrScanResult->au8BSSID[4], pstrScanResult->au8BSSID[5],
    pstrScanResult->au8SSID);*/
    strcat(internetBuffer,pstrScanResult->au8SSID); strcat(internetBuffer,";");
    if(u8ScanResultIdx < u8NumFoundAPs) {
      // Read the next scan result
      m2m_wifi_req_scan_result(u8ScanResultIdx);
      u8ScanResultIdx++;
      }
    }
      break;
    default:
      {
      }
      break;
    }
  }

/* Socket event handler.
*/

// This is the DNS callback. The response of gethostbyname is here.
// SE SERVE TCP CONNECT, AMPLIARE!
void dnsResolveCallback(uint8_t* pu8HostName, uint32_t u32ServerIP) {
  struct sockaddr_in strAddr;
  BYTE u8Flags=0;   // boh??
  
  if(u32ServerIP != 0) {
/*    DNSclientSocket = socket(AF_INET,SOCK_STREAM,u8Flags);
    if(DNSclientSocket != INVALID_SOCKET) {
      strAddr.sin_family = AF_INET;
      strAddr.sin_port = _htons(80);
      strAddr.sin_addr.s_addr = u32ServerIP;
      connect(DNSclientSocket, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
      M2M_INFO("DNS fatto\r\n");
      }*/
    *(unsigned long *)internetBuffer=u32ServerIP;
    }
  else {
    M2M_INFO("DNS Resolution Failed\n");
    }
  }

 
/* This function needs to be called from main function. For the callbacks to be invoked correctly, the API
  m2m_wifi_handle_events should be called continuously from main. */
void tcpStartServer(uint16_t u16ServerPort) {
  struct sockaddr_in strAddr;
  
  // Register socket application callbacks.
//  registerSocketCallback(tcpServerSocketEventHandler, NULL);
  if(BiosArea.httpPort) {  // se 0, disattivo!
    // Create the server listen socket.
    TCPlistenSocket = socket(AF_INET, SOCK_STREAM, 0);
    if(TCPlistenSocket != INVALID_SOCKET) {
      strAddr.sin_family = AF_INET;
      strAddr.sin_port = _htons(u16ServerPort);
      strAddr.sin_addr.s_addr = nmi_inet_addr(INADDR_ANY);
      bind(TCPlistenSocket, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
      }
    }
  
#ifdef USA_TELNET
  if(BiosArea.telnetPort) {   // se 0, disattivo!
    TelnetSocket = socket(AF_INET, SOCK_STREAM, 0);
    if(TelnetSocket != INVALID_SOCKET) {
      strAddr.sin_family = AF_INET;
      strAddr.sin_port = _htons(BiosArea.telnetPort);
      strAddr.sin_addr.s_addr = 0; //INADDR_ANY
      bind(TelnetSocket, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
      }
    }
#endif
  }

const char *HTTP_SERVER_OK="HTTP/1.1 200 OK\r\n";
const char *HTTP_SERVER_ERR="HTTP/1.1 404 Not found\r\n";
const char *HTTP_SERVER_HEADER="Server: PC_PIC/1.0\r\nDate: 8/6/2022 12:00:00\r\nContent-type: %s\r\nContent-length: %u\r\n\r\n";
const char *HTTP_SERVER_HEADER2="Server: PC_PIC/1.0\r\nDate: 8/6/2022 12:00:00\r\nContent-type: %s\r\nTransfer-Encoding: chunked\r\n\r\n";
const char *HTTP_SERVER_HEAD2="<html><head><title>PC_PIC WebServer</title><meta http-equiv='refresh' content=60></head>\r\n";
const char *HTTP_SERVER_HEAD="<html><head><title>PC_PIC WebServer</title></head>\r\n";
// mettere <meta http-equiv="refresh" content="30">
const char *HTTP_SERVER_PAGE="<body bgcolor='#00c0d8'><center><h2><img src='logo.gif'> PC_PIC</h2></center><br><br>\r"
#if defined(USA_ETHERNET) && defined(USA_WIFI)
  "<i><a href='/copyright.html'>Versione</a>: %u.%02u; Chip WiFi: %08X, RFrev: %x; Chip Ethernet: %04X; CPU: PIC32MZ 2MB ROM 512KB RAM</i><br>"
#elif defined(USA_WIFI)
  "<i><a href='/copyright.html'>Versione</a>: %u.%02u; Chip WiFi: %08X, RFrev: %x; CPU: PIC32MZ 2MB ROM 512KB RAM</i><br>"
#elif defined(USA_ETHERNET)
  "<i><a href='/copyright.html'>Versione</a>: %u.%02u; Chip Ethernet: %04X; CPU: PIC32MZ 2MB ROM 512KB RAM</i><br>"
#else
  "<i><a href='/copyright.html'>Versione</a>: %u.%02u; CPU: PIC32MZ 2MB ROM 512KB RAM</i><br>"
#endif
  "<a href='/stato.html'>Stato</a><br>\n"
  "<a href='/config.html'>Configurazione</a><br>\n"
  "<a href='/command.html'>Command line</a><br>\n"
  "<a href='/help.html'>Guida</a><br>\n"
#if defined(USA_USB_HOST_MSD)
  "<a href='/files'>SDcard</a> <a href='/files2'>USB PenDrive</a> \n"
#else
  "<a href='/files'>SDcard</a> \n"
#endif
  "<a href='/files3'>Hard disc</a><br>\n"
  "<a href='/provaled.cgi'>test led</a><br>\n"
  "<br><a href='http://cyberdyne.biz.ly'>Home page Dario's Automation</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_STATO_PAGE="<body bgcolor='#00d0b0'><center><b>Stato di PC_PIC</b></center><br><br>\n"
  "RSSI: %u<br>\n"
  "VideoFrame: %u<br>\n"
  "Stato SouthBridge: %08X<br>\n"
  "Peripherals: %08X/%08X/%08X<br>\n"
  "UnixTime: %u<br>\n"
  "Memory: base %uKB/ext %uKB<br>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_DIR_PAGE1="<body text='#F0C0C0' link='#F0F020' vlink='#F0F020' alink='#F0F050' bgcolor='#000000'><center><b>PC_PIC's SDcard Directory </b></center><br><br>\n"
  "<font size=-1><table border=0>"
//  "<tr><th width=240><img src='diamond.gif' alt='Icon'> <a href='?C=0&O=1'>Nome</a></th><th width=180><a href='?C=1&O=0'>Ultima modifica</a></th><th width=170 align=right><a href='?C=2&O=0'>Dimensione</a></th><th><a href='?C=3&O=0'>Descrizione</a></th></tr>\r\n";
  "<tr><th width=240> <a href='?C=0&O=1'>Nome</a></th><th width=180><a href='?C=1&O=0'>Ultima modifica</a></th><th width=170 align=right><a href='?C=2&O=0'>Dimensione</a></th><th><a href='?C=3&O=0'>Descrizione</a></th></tr>\r\n";
const char *HTTP_DIR_PAGE1_="<body text='#F0C0C0' link='#F0F020' vlink='#F0F020' alink='#F0F050' bgcolor='#000000'><center><b>PC_PIC's USB Mass-Memory Directory </b></center><br><br>\n"
  "<font size=-1><table border=0>"
//  "<tr><th width=240><img src='diamond.gif' alt='Icon'> <a href='?C=0&O=1'>Nome</a></th><th width=180><a href='?C=1&O=0'>Ultima modifica</a></th><th width=170 align=right><a href='?C=2&O=0'>Dimensione</a></th><th><a href='?C=3&O=0'>Descrizione</a></th></tr>\r\n";
  "<tr><th width=240> <a href='?C=0&O=1'>Nome</a></th><th width=180><a href='?C=1&O=0'>Ultima modifica</a></th><th width=170 align=right><a href='?C=2&O=0'>Dimensione</a></th><th><a href='?C=3&O=0'>Descrizione</a></th></tr>\r\n";
const char *HTTP_DIR_PAGE1__="<body text='#F0C0C0' link='#F0F020' vlink='#F0F020' alink='#F0F050' bgcolor='#000000'><center><b>PC_PIC's Hard disc Directory </b></center><br><br>\n"
  "<font size=-1><table border=0>"
//  "<tr><th width=240><img src='diamond.gif' alt='Icon'> <a href='?C=0&O=1'>Nome</a></th><th width=180><a href='?C=1&O=0'>Ultima modifica</a></th><th width=170 align=right><a href='?C=2&O=0'>Dimensione</a></th><th><a href='?C=3&O=0'>Descrizione</a></th></tr>\r\n";
  "<tr><th width=240> <a href='?C=0&O=1'>Nome</a></th><th width=180><a href='?C=1&O=0'>Ultima modifica</a></th><th width=170 align=right><a href='?C=2&O=0'>Dimensione</a></th><th><a href='?C=3&O=0'>Descrizione</a></th></tr>\r\n";
//const char *HTTP_DIR_PAGE2="<tr><td width=220> <a href=\"%s\"><img src='item.gif' alt='[   ]' border=0> %s</a> </td><td width=200 align=left>%s %02u/%02u/%04u %02u:%02u</td><td width=170 align=right>%u KB</td><td>%s</td></tr>\r\n";
const char *HTTP_DIR_PAGE2="<tr><td width=220> <a href=\"%s\">%s</a> </td><td width=200 align=left>%s %02u/%02u/%04u %02u:%02u</td><td width=170 align=right>%u KB</td><td>%s</td></tr>\r\n";
const char *HTTP_DIR_PAGE3="</table><font size=0>"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_CONFIG_PAGE="<body bgcolor='#a05040' textcolor='#fff0f0'><center><b>Configurazione PC_PIC</b></center><br><br>\n"
	"<form method=post action='config.cgi'\n>"  // <fieldset>
	"Access point: <input type='text' name='ap' value='%s'>&nbsp;"
	"Password: <input type='text' name='pw' value='%s'><br>\n"
	"Indirizzo IP: <input type='text' name='ip' value='%u.%u.%u.%u'><br>\n"
	"Porte: <input type='text' name='port1' value='%u'> <input type='text' name='port2' value='%u'><br>\n"
	"DHCP: <input type='checkbox' %s name='dhcp'><br>\n"      // sistemare... checked
	"<input type=submit value=\"Imposta\"><br>\n"
	"</form>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_CMD_PAGE="<body bgcolor='#c0c0c0' textcolor='#2f2f2f'><center><b>Command line PC_PIC</b></center><br><br>\n"
	"<form method=post action='cmd.cgi'\n>"
	"<label for='cmd'>Comando:</label><input type='text' size='80' name='cmd' value='VER'><br>\n"
	"<input type=submit value='Esegui'><br>\n"
	"</form>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_PROVALED_PAGE="<body><center><b>Led test</b></center><br><br>\n"
  "fatto<br>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";

const unsigned char HTTP_SITEICON[]={
  0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x30, 0x00, 0x30, 0x00, 0xF7, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0xFF, 0x00, 0x08, 0x31, 0x00, 0x18, 0x63, 0x00, 0x18, 0xE7, 0x00, 0x21, 0x5A, 0x00, 
  0x21, 0x9C, 0x00, 0x31, 0x4A, 0x00, 0x31, 0xCE, 0x00, 0x4A, 0xB5, 0x00, 0x4A, 0xCE, 0x00, 0x4A, 
  0xDE, 0x00, 0x52, 0xCE, 0x00, 0x5A, 0x8C, 0x00, 0x63, 0x9C, 0x00, 0x63, 0xB5, 0x00, 0x63, 0xCE, 
  0x00, 0x63, 0xE7, 0x00, 0x63, 0xFF, 0x00, 0x73, 0xC6, 0x00, 0x7B, 0xCE, 0x00, 0x7B, 0xE7, 0x00, 
  0x9C, 0xE7, 0x00, 0x9C, 0xFF, 0x00, 0xA5, 0xF7, 0x00, 0xB5, 0xFF, 0x00, 0xBD, 0xF7, 0x00, 0xCE, 
  0xFF, 0x00, 0xE7, 0xFF, 0x00, 0xFF, 0xFF, 0x18, 0xAD, 0xFF, 0x18, 0xE7, 0xE7, 0x21, 0x84, 0xC6, 
  0x21, 0x9C, 0xCE, 0x21, 0xA5, 0xEF, 0x21, 0xAD, 0xFF, 0x21, 0xE7, 0xE7, 0x29, 0x9C, 0xDE, 0x29, 
  0xAD, 0xFF, 0x29, 0xB5, 0xFF, 0x31, 0x63, 0x7B, 0x31, 0x63, 0x84, 0x31, 0x6B, 0x7B, 0x31, 0x6B, 
  0x84, 0x31, 0x84, 0xBD, 0x31, 0x8C, 0xBD, 0x31, 0x9C, 0xDE, 0x31, 0xAD, 0xEF, 0x31, 0xAD, 0xFF, 
  0x31, 0xB5, 0xFF, 0x31, 0xCE, 0xCE, 0x39, 0x63, 0x73, 0x39, 0x63, 0x7B, 0x39, 0x6B, 0x84, 0x39, 
  0x6B, 0x8C, 0x39, 0x73, 0x8C, 0x39, 0x8C, 0xBD, 0x39, 0x8C, 0xC6, 0x39, 0x9C, 0xDE, 0x39, 0xA5, 
  0xDE, 0x39, 0xAD, 0xEF, 0x39, 0xB5, 0xFF, 0x39, 0xBD, 0xFF, 0x42, 0x6B, 0x7B, 0x42, 0x6B, 0x94, 
  0x42, 0x73, 0x94, 0x42, 0x84, 0xA5, 0x42, 0x8C, 0xB5, 0x42, 0x8C, 0xBD, 0x42, 0x94, 0xBD, 0x42, 
  0x94, 0xC6, 0x42, 0xA5, 0xDE, 0x42, 0xAD, 0xEF, 0x42, 0xB5, 0xF7, 0x42, 0xB5, 0xFF, 0x42, 0xBD, 
  0xFF, 0x42, 0xC6, 0xC6, 0x4A, 0x63, 0x6B, 0x4A, 0x9C, 0xC6, 0x4A, 0xA5, 0xDE, 0x4A, 0xAD, 0xE7, 
  0x4A, 0xB5, 0xB5, 0x4A, 0xB5, 0xEF, 0x4A, 0xB5, 0xF7, 0x4A, 0xB5, 0xFF, 0x4A, 0xBD, 0xFF, 0x52, 
  0xAD, 0xAD, 0x52, 0xAD, 0xE7, 0x52, 0xB5, 0xEF, 0x52, 0xBD, 0xF7, 0x52, 0xBD, 0xFF, 0x5A, 0x63, 
  0x63, 0x5A, 0x6B, 0x73, 0x5A, 0x6B, 0x7B, 0x5A, 0xAD, 0xAD, 0x5A, 0xBD, 0xFF, 0x5A, 0xC6, 0xFF, 
  0x63, 0x6B, 0x73, 0x63, 0x73, 0x7B, 0x63, 0x73, 0x84, 0x63, 0x73, 0x8C, 0x63, 0x7B, 0x84, 0x63, 
  0x9C, 0x9C, 0x6B, 0x73, 0x7B, 0x6B, 0x73, 0x84, 0x73, 0x73, 0x7B, 0x73, 0x7B, 0x7B, 0x73, 0x7B, 
  0x84, 0x7B, 0x84, 0x84, 0x84, 0x84, 0x84, 0x84, 0x84, 0x8C, 0x8C, 0x73, 0x73, 0x8C, 0x94, 0x94, 
  0x8C, 0x94, 0x9C, 0x94, 0x94, 0x9C, 0x94, 0x9C, 0x9C, 0x94, 0x9C, 0xA5, 0x94, 0xA5, 0xA5, 0x9C, 
  0x63, 0x63, 0x9C, 0x9C, 0x9C, 0x9C, 0x9C, 0xA5, 0x9C, 0xA5, 0xA5, 0x9C, 0xA5, 0xAD, 0xA5, 0xA5, 
  0xA5, 0xA5, 0xA5, 0xAD, 0xA5, 0xAD, 0xAD, 0xA5, 0xAD, 0xB5, 0xAD, 0xAD, 0xAD, 0xAD, 0xAD, 0xB5, 
  0xAD, 0xB5, 0xB5, 0xAD, 0xBD, 0xBD, 0xB5, 0xB5, 0xB5, 0xB5, 0xB5, 0xBD, 0xB5, 0xBD, 0xBD, 0xB5, 
  0xBD, 0xC6, 0xBD, 0xBD, 0xBD, 0xBD, 0xBD, 0xC6, 0xBD, 0xC6, 0xC6, 0xBD, 0xC6, 0xCE, 0xC6, 0xC6, 
  0xC6, 0xC6, 0xC6, 0xCE, 0xC6, 0xCE, 0xCE, 0xC6, 0xCE, 0xD6, 0xC6, 0xCE, 0xDE, 0xC6, 0xD6, 0xD6, 
  0xC6, 0xD6, 0xDE, 0xCE, 0xCE, 0xCE, 0xCE, 0xCE, 0xD6, 0xCE, 0xD6, 0xD6, 0xCE, 0xD6, 0xDE, 0xCE, 
  0xDE, 0xDE, 0xD6, 0xD6, 0xD6, 0xD6, 0xD6, 0xDE, 0xD6, 0xDE, 0xDE, 0xD6, 0xDE, 0xE7, 0xDE, 0xDE, 
  0xDE, 0xDE, 0xDE, 0xE7, 0xDE, 0xE7, 0xE7, 0xDE, 0xE7, 0xEF, 0xE7, 0xE7, 0xE7, 0xE7, 0xE7, 0xEF, 
  0xE7, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF, 0xF7, 0xEF, 0xF7, 0xF7, 0xF7, 0xF7, 0xF7, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x21, 0xF9, 0x04, 
  0x01, 0x00, 0x00, 0x00, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x30, 0x00, 0x30, 0x00, 0x00, 0x08, 
  0xFE, 0x00, 0x01, 0x08, 0x1C, 0x48, 0xB0, 0xA0, 0xC1, 0x83, 0x08, 0x13, 0x2A, 0x5C, 0x38, 0x30, 
  0xD0, 0x1C, 0x47, 0x9F, 0x18, 0x4A, 0x9C, 0x58, 0x10, 0xCE, 0x90, 0x20, 0x65, 0xE8, 0x48, 0x8A, 
  0x48, 0xB1, 0x63, 0x42, 0x38, 0x50, 0xA6, 0x60, 0x71, 0x12, 0x64, 0xCC, 0x1C, 0x49, 0xA0, 0x3C, 
  0xAA, 0x1C, 0x08, 0xE7, 0x4A, 0x96, 0x2C, 0x5A, 0xB2, 0x4C, 0x71, 0x72, 0x23, 0xE3, 0xC6, 0x95, 
  0x1D, 0x5B, 0x6A, 0xF9, 0xA2, 0xA5, 0x67, 0x16, 0x2A, 0x52, 0x8C, 0x94, 0xD4, 0xC8, 0x11, 0xA7, 
  0xC2, 0x96, 0x58, 0xC0, 0xF4, 0x8C, 0x49, 0xA5, 0x29, 0x15, 0x24, 0x46, 0x6A, 0x9E, 0x4C, 0x69, 
  0xF4, 0x60, 0xCB, 0x2C, 0x3C, 0x7D, 0xFE, 0xA4, 0xE2, 0x83, 0x4A, 0x92, 0x24, 0x3C, 0x72, 0xD4, 
  0x24, 0x5A, 0x95, 0xA0, 0xCE, 0x9D, 0x3E, 0x9D, 0x72, 0xFD, 0xDA, 0xA3, 0xED, 0x8B, 0x16, 0x37, 
  0xC8, 0xE4, 0xA1, 0x54, 0x14, 0xE7, 0xD9, 0xA5, 0x2F, 0x9D, 0x2A, 0xF9, 0x9A, 0xA4, 0x07, 0x8C, 
  0x1E, 0x26, 0x60, 0x88, 0x00, 0x51, 0x03, 0x8D, 0x1F, 0x4D, 0x46, 0xEF, 0xC6, 0xFC, 0x59, 0x65, 
  0xAB, 0x8F, 0xBD, 0x6D, 0x4D, 0x98, 0x10, 0x31, 0xD9, 0x44, 0x88, 0x34, 0x94, 0x12, 0x5F, 0x59, 
  0xBA, 0x78, 0x6B, 0x53, 0xBE, 0x80, 0x25, 0x8F, 0x18, 0x21, 0xF9, 0x72, 0x66, 0xBB, 0x50, 0xB0, 
  0x68, 0xCD, 0xEB, 0xD4, 0x47, 0x12, 0xC9, 0xB0, 0x63, 0x97, 0x38, 0x73, 0x7A, 0x25, 0xC8, 0xCE, 
  0x79, 0x1D, 0x87, 0x8E, 0x0D, 0x7B, 0xC4, 0xEC, 0xDA, 0x2A, 0x41, 0xBE, 0x64, 0xFD, 0x73, 0x89, 
  0x0F, 0x18, 0xBC, 0x63, 0x8F, 0xE8, 0xF1, 0x5B, 0xF3, 0xF0, 0xE7, 0xAF, 0x93, 0xF3, 0x06, 0xAC, 
  0x83, 0x76, 0xE2, 0x90, 0x2F, 0x95, 0x64, 0xE9, 0xCB, 0x1B, 0x06, 0x8C, 0x17, 0x80, 0xC3, 0xFE, 
  0x9B, 0x78, 0xE1, 0xC2, 0xBA, 0x5D, 0x21, 0x58, 0xB6, 0xEE, 0x16, 0xCF, 0xDE, 0x84, 0xDF, 0xB6, 
  0xD5, 0x81, 0x7B, 0x04, 0x35, 0x48, 0xCC, 0x0F, 0x1C, 0x2F, 0xBC, 0xBB, 0xDF, 0x1F, 0xFE, 0x6F, 
  0x5B, 0x18, 0x7D, 0xF5, 0x10, 0x5F, 0x59, 0x00, 0x80, 0xF2, 0x87, 0x18, 0x28, 0xB0, 0xC0, 0x03, 
  0x78, 0x7F, 0x01, 0x08, 0x60, 0x5B, 0x10, 0x02, 0xB8, 0x83, 0x79, 0x04, 0x16, 0x58, 0x5F, 0x0D, 
  0x0A, 0xFE, 0x17, 0x60, 0x5B, 0xA0, 0x4D, 0x28, 0x5F, 0x85, 0x06, 0x8A, 0x41, 0x03, 0x0E, 0x3C, 
  0xB0, 0xD5, 0xD7, 0x89, 0x49, 0xE8, 0x80, 0xC6, 0x87, 0x15, 0x0A, 0x64, 0x20, 0x17, 0x23, 0x22, 
  0xB1, 0x17, 0x5F, 0x3E, 0x1C, 0xB1, 0x62, 0x8B, 0x04, 0x7D, 0xA2, 0x89, 0x24, 0x91, 0x44, 0x22, 
  0xC9, 0x21, 0x6E, 0x34, 0xA1, 0x02, 0x11, 0x49, 0x28, 0xD1, 0xD4, 0x11, 0x14, 0xAA, 0x44, 0x4A, 
  0x41, 0xA4, 0x50, 0x22, 0x09, 0x24, 0x8E, 0x44, 0xE9, 0x08, 0x25, 0x94, 0x14, 0x22, 0x08, 0x26, 
  0x74, 0x84, 0x51, 0xC3, 0x10, 0x52, 0x3C, 0x91, 0xE4, 0x44, 0x9F, 0x80, 0x42, 0x49, 0x22, 0x9C, 
  0x70, 0xC2, 0xD1, 0x1E, 0x6C, 0xF8, 0x21, 0x65, 0x94, 0x91, 0x50, 0xE2, 0x48, 0x21, 0x50, 0x56, 
  0x22, 0x49, 0x1F, 0x5D, 0xCC, 0x80, 0x19, 0x45, 0xA0, 0x68, 0xD2, 0x09, 0x23, 0x89, 0x20, 0x72, 
  0x48, 0x22, 0x92, 0x90, 0x69, 0x26, 0x27, 0x7D, 0x9C, 0x91, 0x66, 0x94, 0x8C, 0x44, 0xB2, 0xA6, 
  0x22, 0x89, 0x20, 0xD6, 0x89, 0x24, 0x12, 0x3D, 0x9A, 0x09, 0x25, 0x88, 0x48, 0xC2, 0x08, 0x22, 
  0x98, 0x26, 0xD2, 0x27, 0x22, 0x8C, 0x30, 0xC2, 0x49, 0x26, 0x9F, 0x70, 0x92, 0x87, 0x1A, 0x87, 
  0x4A, 0xA9, 0xC7, 0x19, 0x5B, 0x74, 0xE2, 0x11, 0x22, 0x7A, 0xE4, 0xC1, 0xA7, 0x24, 0xFE, 0x95, 
  0x46, 0x82, 0x29, 0xA6, 0x97, 0x16, 0x22, 0x09, 0x95, 0x83, 0xE6, 0xB1, 0x86, 0x1A, 0x61, 0x6C, 
  0x21, 0x07, 0x8B, 0x13, 0x91, 0x42, 0xC8, 0x1E, 0x7A, 0x38, 0xC2, 0x23, 0x25, 0x9C, 0x70, 0xEA, 
  0xE7, 0xAC, 0x85, 0x24, 0x82, 0x09, 0x25, 0x9A, 0xE8, 0x48, 0x55, 0x85, 0xA2, 0x14, 0x42, 0x6C, 
  0xA2, 0x54, 0x82, 0x82, 0x48, 0x21, 0x97, 0x0E, 0xA2, 0x29, 0x21, 0x88, 0xEC, 0x48, 0xC9, 0xB4, 
  0x2D, 0x56, 0x4B, 0xC7, 0x1F, 0x8C, 0x48, 0xD2, 0xEC, 0xA6, 0xB0, 0x52, 0x72, 0x69, 0x9F, 0x89, 
  0xE8, 0x81, 0x23, 0x41, 0xA0, 0x14, 0x42, 0x87, 0xAB, 0x55, 0x26, 0xC2, 0x88, 0x26, 0x87, 0x6C, 
  0x3B, 0x07, 0x1C, 0x80, 0xD4, 0x35, 0xAF, 0x8B, 0x81, 0xC8, 0xB1, 0x47, 0xBA, 0x84, 0xE4, 0x31, 
  0x07, 0x20, 0xE4, 0x1E, 0x24, 0xC0, 0x00, 0x00, 0x14, 0x30, 0xC0, 0xC4, 0x14, 0x43, 0xEC, 0xD1, 
  0x27, 0x05, 0xFF, 0x21, 0xB0, 0x42, 0x01, 0x00, 0x40, 0x40, 0x00, 0x20, 0x87, 0x1C, 0xF2, 0xC0, 
  0x07, 0x11, 0xE0, 0x71, 0x07, 0x28, 0xA7, 0x9C, 0xF2, 0xC7, 0x26, 0x93, 0x3C, 0x90, 0xC9, 0x04, 
  0xA8, 0x2C, 0x33, 0xCA, 0x04, 0xB4, 0x8C, 0x63, 0xCD, 0x1F, 0x9F, 0xDC, 0x81, 0x1D, 0x32, 0xF0, 
  0x3C, 0x73, 0x07, 0x36, 0x0F, 0x0C, 0xF3, 0x07, 0x1F, 0xD8, 0x11, 0x05, 0xCA, 0x3C, 0xFB, 0x4C, 
  0xB3, 0xCB, 0x26, 0x07, 0xD0, 0x41, 0xD1, 0x32, 0x3C, 0x5D, 0xF4, 0xD1, 0x2A, 0x07, 0xDD, 0x22, 
  0xCC, 0x4F, 0x2B, 0x0D, 0xB5, 0xCC, 0x01, 0xE0, 0x6C, 0x31, 0x81, 0x0B, 0x9C, 0xBC, 0x75, 0xD6, 
  0x51, 0xAB, 0xDC, 0xB1, 0xD0, 0x62, 0x6B, 0xAD, 0x34, 0xCA, 0x67, 0x57, 0x88, 0x33, 0xD6, 0x64, 
  0xA3, 0x4C, 0xB4, 0xD9, 0x4C, 0xEB, 0x3C, 0xF7, 0xCC, 0x20, 0xBB, 0x1C, 0x76, 0x10, 0xCC, 0x3F, 
  0x77, 0x30, 0xB2, 0xCB, 0x1E, 0x7B, 0x2C, 0xF2, 0xE0, 0x80, 0x0B, 0x14, 0x10, 0x00, 0x00, 0x3B
  };
const unsigned char HTTP_DIAMONDICON[]={
  0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x09, 0x00, 0x09, 0x00, 0xF7, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xCC, 0xFF, 0xFF, 0x99, 0xFF, 0xFF, 0x66, 0xFF, 0xFF, 0x33, 0xFF, 0xFF, 0x00, 0xFF, 
  0xCC, 0xFF, 0xFF, 0xCC, 0xCC, 0xFF, 0xCC, 0x99, 0xFF, 0xCC, 0x66, 0xFF, 0xCC, 0x33, 0xFF, 0xCC, 
  0x00, 0xFF, 0x99, 0xFF, 0xFF, 0x99, 0xCC, 0xFF, 0x99, 0x99, 0xFF, 0x99, 0x66, 0xFF, 0x99, 0x33, 
  0xFF, 0x99, 0x00, 0xFF, 0x66, 0xFF, 0xFF, 0x66, 0xCC, 0xFF, 0x66, 0x99, 0xFF, 0x66, 0x66, 0xFF, 
  0x66, 0x33, 0xFF, 0x66, 0x00, 0xFF, 0x33, 0xFF, 0xFF, 0x33, 0xCC, 0xFF, 0x33, 0x99, 0xFF, 0x33, 
  0x66, 0xFF, 0x33, 0x33, 0xFF, 0x33, 0x00, 0xFF, 0x00, 0xFF, 0xFF, 0x00, 0xCC, 0xFF, 0x00, 0x99, 
  0xFF, 0x00, 0x66, 0xFF, 0x00, 0x33, 0xFF, 0x00, 0x00, 0xCC, 0xFF, 0xFF, 0xCC, 0xFF, 0xCC, 0xCC, 
  0xFF, 0x99, 0xCC, 0xFF, 0x66, 0xCC, 0xFF, 0x33, 0xCC, 0xFF, 0x00, 0xCC, 0xCC, 0xFF, 0xCC, 0xCC, 
  0xCC, 0xCC, 0xCC, 0x99, 0xCC, 0xCC, 0x66, 0xCC, 0xCC, 0x33, 0xCC, 0xCC, 0x00, 0xCC, 0x99, 0xFF, 
  0xCC, 0x99, 0xCC, 0xCC, 0x99, 0x99, 0xCC, 0x99, 0x66, 0xCC, 0x99, 0x33, 0xCC, 0x99, 0x00, 0xCC, 
  0x66, 0xFF, 0xCC, 0x66, 0xCC, 0xCC, 0x66, 0x99, 0xCC, 0x66, 0x66, 0xCC, 0x66, 0x33, 0xCC, 0x66, 
  0x00, 0xCC, 0x33, 0xFF, 0xCC, 0x33, 0xCC, 0xCC, 0x33, 0x99, 0xCC, 0x33, 0x66, 0xCC, 0x33, 0x33, 
  0xCC, 0x33, 0x00, 0xCC, 0x00, 0xFF, 0xCC, 0x00, 0xCC, 0xCC, 0x00, 0x99, 0xCC, 0x00, 0x66, 0xCC, 
  0x00, 0x33, 0xCC, 0x00, 0x00, 0x99, 0xFF, 0xFF, 0x99, 0xFF, 0xCC, 0x99, 0xFF, 0x99, 0x99, 0xFF, 
  0x66, 0x99, 0xFF, 0x33, 0x99, 0xFF, 0x00, 0x99, 0xCC, 0xFF, 0x99, 0xCC, 0xCC, 0x99, 0xCC, 0x99, 
  0x99, 0xCC, 0x66, 0x99, 0xCC, 0x33, 0x99, 0xCC, 0x00, 0x99, 0x99, 0xFF, 0x99, 0x99, 0xCC, 0x99, 
  0x99, 0x99, 0x99, 0x99, 0x66, 0x99, 0x99, 0x33, 0x99, 0x99, 0x00, 0x99, 0x66, 0xFF, 0x99, 0x66, 
  0xCC, 0x99, 0x66, 0x99, 0x99, 0x66, 0x66, 0x99, 0x66, 0x33, 0x99, 0x66, 0x00, 0x99, 0x33, 0xFF, 
  0x99, 0x33, 0xCC, 0x99, 0x33, 0x99, 0x99, 0x33, 0x66, 0x99, 0x33, 0x33, 0x99, 0x33, 0x00, 0x99, 
  0x00, 0xFF, 0x99, 0x00, 0xCC, 0x99, 0x00, 0x99, 0x99, 0x00, 0x66, 0x99, 0x00, 0x33, 0x99, 0x00, 
  0x00, 0x66, 0xFF, 0xFF, 0x66, 0xFF, 0xCC, 0x66, 0xFF, 0x99, 0x66, 0xFF, 0x66, 0x66, 0xFF, 0x33, 
  0x66, 0xFF, 0x00, 0x66, 0xCC, 0xFF, 0x66, 0xCC, 0xCC, 0x66, 0xCC, 0x99, 0x66, 0xCC, 0x66, 0x66, 
  0xCC, 0x33, 0x66, 0xCC, 0x00, 0x66, 0x99, 0xFF, 0x66, 0x99, 0xCC, 0x66, 0x99, 0x99, 0x66, 0x99, 
  0x66, 0x66, 0x99, 0x33, 0x66, 0x99, 0x00, 0x66, 0x66, 0xFF, 0x66, 0x66, 0xCC, 0x66, 0x66, 0x99, 
  0x66, 0x66, 0x66, 0x66, 0x66, 0x33, 0x66, 0x66, 0x00, 0x66, 0x33, 0xFF, 0x66, 0x33, 0xCC, 0x66, 
  0x33, 0x99, 0x66, 0x33, 0x66, 0x66, 0x33, 0x33, 0x66, 0x33, 0x00, 0x66, 0x00, 0xFF, 0x66, 0x00, 
  0xCC, 0x66, 0x00, 0x99, 0x66, 0x00, 0x66, 0x66, 0x00, 0x33, 0x66, 0x00, 0x00, 0x33, 0xFF, 0xFF, 
  0x33, 0xFF, 0xCC, 0x33, 0xFF, 0x99, 0x33, 0xFF, 0x66, 0x33, 0xFF, 0x33, 0x33, 0xFF, 0x00, 0x33, 
  0xCC, 0xFF, 0x33, 0xCC, 0xCC, 0x33, 0xCC, 0x99, 0x33, 0xCC, 0x66, 0x33, 0xCC, 0x33, 0x33, 0xCC, 
  0x00, 0x33, 0x99, 0xFF, 0x33, 0x99, 0xCC, 0x33, 0x99, 0x99, 0x33, 0x99, 0x66, 0x33, 0x99, 0x33, 
  0x33, 0x99, 0x00, 0x33, 0x66, 0xFF, 0x33, 0x66, 0xCC, 0x33, 0x66, 0x99, 0x33, 0x66, 0x66, 0x33, 
  0x66, 0x33, 0x33, 0x66, 0x00, 0x33, 0x33, 0xFF, 0x33, 0x33, 0xCC, 0x33, 0x33, 0x99, 0x33, 0x33, 
  0x66, 0x33, 0x33, 0x33, 0x33, 0x33, 0x00, 0x33, 0x00, 0xFF, 0x33, 0x00, 0xCC, 0x33, 0x00, 0x99, 
  0x33, 0x00, 0x66, 0x33, 0x00, 0x33, 0x33, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0xFF, 0xCC, 0x00, 
  0xFF, 0x99, 0x00, 0xFF, 0x66, 0x00, 0xFF, 0x33, 0x00, 0xFF, 0x00, 0x00, 0xCC, 0xFF, 0x00, 0xCC, 
  0xCC, 0x00, 0xCC, 0x99, 0x00, 0xCC, 0x66, 0x00, 0xCC, 0x33, 0x00, 0xCC, 0x00, 0x00, 0x99, 0xFF, 
  0x00, 0x99, 0xCC, 0x00, 0x99, 0x99, 0x00, 0x99, 0x66, 0x00, 0x99, 0x33, 0x00, 0x99, 0x00, 0x00, 
  0x66, 0xFF, 0x00, 0x66, 0xCC, 0x00, 0x66, 0x99, 0x00, 0x66, 0x66, 0x00, 0x66, 0x33, 0x00, 0x66, 
  0x00, 0x00, 0x33, 0xFF, 0x00, 0x33, 0xCC, 0x00, 0x33, 0x99, 0x00, 0x33, 0x66, 0x00, 0x33, 0x33, 
  0x00, 0x33, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0xCC, 0x00, 0x00, 0x99, 0x00, 0x00, 0x66, 0x00, 
  0x00, 0x33, 0xEE, 0x00, 0x00, 0xDD, 0x00, 0x00, 0xBB, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x88, 0x00, 
  0x00, 0x77, 0x00, 0x00, 0x55, 0x00, 0x00, 0x44, 0x00, 0x00, 0x22, 0x00, 0x00, 0x11, 0x00, 0x00, 
  0x00, 0xEE, 0x00, 0x00, 0xDD, 0x00, 0x00, 0xBB, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x88, 0x00, 0x00, 
  0x77, 0x00, 0x00, 0x55, 0x00, 0x00, 0x44, 0x00, 0x00, 0x22, 0x00, 0x00, 0x11, 0x00, 0x00, 0x00, 
  0xEE, 0x00, 0x00, 0xDD, 0x00, 0x00, 0xBB, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x88, 0x00, 0x00, 0x77, 
  0x00, 0x00, 0x55, 0x00, 0x00, 0x44, 0x00, 0x00, 0x22, 0x00, 0x00, 0x11, 0xEE, 0xEE, 0xEE, 0xDD, 
  0xDD, 0xDD, 0xBB, 0xBB, 0xBB, 0xAA, 0xAA, 0xAA, 0x88, 0x88, 0x88, 0x77, 0x77, 0x77, 0x55, 0x55, 
  0x55, 0x44, 0x44, 0x44, 0x22, 0x22, 0x22, 0x11, 0x11, 0x11, 0x00, 0x00, 0x00, 0x21, 0xFF, 0x0B, 
  0x4E, 0x45, 0x54, 0x53, 0x43, 0x41, 0x50, 0x45, 0x32, 0x2E, 0x30, 0x03, 0x01, 0x00, 0x00, 0x00, 
  0x21, 0xFE, 0x1F, 0x47, 0x69, 0x66, 0x42, 0x75, 0x69, 0x6C, 0x64, 0x65, 0x72, 0x20, 0x30, 0x2E, 
  0x33, 0x2E, 0x31, 0x20, 0x62, 0x79, 0x20, 0x59, 0x76, 0x65, 0x73, 0x20, 0x50, 0x69, 0x67, 0x75, 
  0x65, 0x74, 0x00, 0x21, 0xF9, 0x04, 0x05, 0x14, 0x00, 0x66, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 
  0x09, 0x00, 0x09, 0x00, 0x00, 0x08, 0x24, 0x00, 0xCD, 0x08, 0x34, 0xF3, 0x6F, 0xA0, 0xC1, 0x7F, 
  0xD2, 0x0A, 0x1E, 0x94, 0xC6, 0x50, 0x21, 0x41, 0x86, 0x10, 0x0B, 0x22, 0x84, 0x18, 0xF1, 0x21, 
  0x45, 0x87, 0x13, 0x13, 0x1A, 0x7C, 0xE8, 0xF0, 0xA0, 0xC1, 0x80, 0x00, 0x21, 0xF9, 0x04, 0x05, 
  0x14, 0x00, 0x66, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x09, 0x00, 0x00, 0x08, 0x24, 
  0x00, 0xCD, 0x08, 0x34, 0x03, 0x6E, 0xA0, 0x41, 0x70, 0x23, 0x0A, 0x1E, 0x1C, 0xC1, 0x50, 0x21, 
  0x41, 0x86, 0x10, 0x0B, 0x22, 0x84, 0x18, 0xF1, 0x21, 0x45, 0x87, 0x13, 0x13, 0x1A, 0x7C, 0xE8, 
  0xF0, 0xA0, 0xC1, 0x80, 0x00, 0x21, 0xF9, 0x04, 0x05, 0x14, 0x00, 0x66, 0x00, 0x2C, 0x00, 0x00, 
  0x00, 0x00, 0x09, 0x00, 0x09, 0x00, 0x00, 0x08, 0x24, 0x00, 0xCD, 0x08, 0x34, 0x03, 0x6E, 0xA0, 
  0x41, 0x70, 0xB9, 0x0A, 0x1E, 0xCC, 0xC5, 0x50, 0x21, 0x41, 0x86, 0x10, 0x0B, 0x22, 0x84, 0x18, 
  0xF1, 0x21, 0x45, 0x87, 0x13, 0x13, 0x1A, 0x7C, 0xE8, 0xF0, 0xA0, 0xC1, 0x80, 0x00, 0x21, 0xF9, 
  0x04, 0x05, 0x14, 0x00, 0x66, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x09, 0x00, 0x00, 
  0x08, 0x24, 0x00, 0xCD, 0x08, 0x34, 0x03, 0x6E, 0xA0, 0x41, 0x70, 0x00, 0x0A, 0x1E, 0x04, 0xC0, 
  0x50, 0x21, 0x41, 0x86, 0x10, 0x0B, 0x22, 0x84, 0x18, 0xF1, 0x21, 0x45, 0x87, 0x13, 0x13, 0x1A, 
  0x7C, 0xE8, 0xF0, 0xA0, 0xC1, 0x80, 0x00, 0x21, 0xF9, 0x04, 0x05, 0x14, 0x00, 0x66, 0x00, 0x2C, 
  0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x09, 0x00, 0x00, 0x08, 0x28, 0x00, 0xCD, 0x08, 0x34, 0x03, 
  0x6E, 0xA0, 0x41, 0x70, 0x00, 0x0A, 0x1E, 0x04, 0xB0, 0x22, 0x90, 0x42, 0x82, 0x0C, 0x57, 0x34, 
  0x2C, 0x88, 0x50, 0xA2, 0x45, 0x87, 0x10, 0x2F, 0x3E, 0xAC, 0x88, 0xF1, 0x60, 0x47, 0x83, 0x04, 
  0x0D, 0x06, 0x04, 0x00, 0x3B
  };
const unsigned char HTTP_ITEMICON[]={
  0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x0F, 0x00, 0x0B, 0x00, 0xF7, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x84, 0x00, 0x84, 0x84, 0x84, 0x84, 0xC6, 0xC6, 0xC6, 0xFF, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x21, 0xF9, 0x04, 
  0x01, 0x00, 0x00, 0x05, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x0B, 0x00, 0x00, 0x08, 
  0x48, 0x00, 0x0B, 0x08, 0x1C, 0x48, 0x10, 0x00, 0xC1, 0x83, 0x05, 0x09, 0x18, 0x44, 0x98, 0x30, 
  0x80, 0x42, 0x86, 0x02, 0x01, 0x10, 0x70, 0xE8, 0xD0, 0xA0, 0x00, 0x01, 0x05, 0x2E, 0x46, 0x94, 
  0x48, 0xF1, 0x21, 0x42, 0x89, 0x1C, 0x15, 0x1A, 0x1C, 0x20, 0x80, 0x24, 0x46, 0x00, 0x15, 0x15, 
  0x06, 0x58, 0xF8, 0xB1, 0x62, 0x80, 0x95, 0x02, 0x4B, 0x5E, 0xC4, 0x58, 0x00, 0xA5, 0x4D, 0x88, 
  0x03, 0x01, 0xE8, 0xC4, 0x59, 0x70, 0x60, 0x40, 0x00, 0x00, 0x3B
  };

int sendChunk(SOCKET s,const char *str) {
  int i;
  char buf[16];
  WORD tOut;
  
  i= str ? strlen(str) : 0;
  sprintf(buf,"%x\r\n",i);
  sendEx(s, buf, strlen(buf));

  if(str) {  
    sendEx(s, (char *)str, strlen(str));
    }

  strcpy(buf,"\r\n");
  sendEx(s, buf, 2);

// https://www.avrfreaks.net/forum/winc1500-send-more-1-mtu-1400-bytes
//	PROVARE ASPETTARE internetBufferLen...

  return i;
  }

int16_t sendEx(SOCKET sock, void *pvSendBuffer, uint32_t u32SendLength) {
  uint16_t n,n2;
//  WORD tOut;
  int i;
//  uint32_t u32EnableCallbacks=1;

// 	setsockopt(sock, SOL_SOCKET, SO_SET_UDP_SEND_CALLBACK, &u32EnableCallbacks, 4);
#if 0     // non va.. � molto lento (le callback arrivano male, pare un bug) e spesso con -1... 
  do {
    n=min(u32SendLength,SOCKET_BUFFER_MAX_LENGTH);
    if(send(sock, pvSendBuffer, n, 0) == SOCK_ERR_NO_ERROR) {
      tOut=0;
      internetBufferLen=0;
      while(!internetBufferLen && tOut<1000) {
        while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS)
          ClrWdt();
        tOut++;
        __delay_ms(1);
        }
      n=internetBufferLen;
      }
    else
      break;
    pvSendBuffer+=n;
    u32SendLength-=n;
    } while(u32SendLength);
#endif

  n2=0;
  do {
    n=min(u32SendLength,SOCKET_BUFFER_MAX_LENGTH);
rifo:
    if((i=send(sock, pvSendBuffer, n, 0)) == SOCK_ERR_NO_ERROR) {
      // alle volte arriva SOCK_ERR_INVALID -9 in callback... checcazz'�?? parrebbe invalid ovvero magari socket chiuso... ma cmq non uso + la callback
      while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS)
/* bah serve? s�*/
        ClrWdt();
      }
    else {
//      SYS_DEBUG_PRINT(SYS_ERROR_INFO, "sendex: %d\r\n",i);
      while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS)
/* bah serve? s�*/
        ClrWdt();
      switch(i) {
        case SOCK_ERR_BUFFER_FULL:
          goto rifo;
          break;
//        case -3:
        // arriva -3=SOCK_ERR_MAX_TCP_SOCK che non ha senso... di tanto, v. di l�
//          goto rifo;
//          break;
        case SOCK_ERR_INVALID_ARG:    // per socket chiuso... ma il close non arriva cmq se interrompo un download lungo (wireshark dice di s�)
          break;
        default:
          goto fine;
          break;
        }
      }
    pvSendBuffer+=n;
    n2+=n;
    u32SendLength-=n;
    } while(u32SendLength);
    
fine:

  return n2;
  }
#warning fare return 32bit

char *parseParm(const char *s,char *n1,uint32_t nl1,char *n2,uint32_t nl2, 
																		 int q,int m);
int parseNumParm(const char *s,char *parmN, UINT parmNL, char *parmV, UINT parmVL, int q,int autoSkip);
char *parseNamedParm(const char *s, const char *n, char *v, UINT vl);

/* Socket event handler */
void clientSocketEventHandler(SOCKET sock, BYTE u8Msg, void *pvMsg) {
  int ret;
  char *p;
  
  if(sock==UDPclientSocket)
  switch(u8Msg) {
    case SOCKET_MSG_BIND:
		{
			tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg *)pvMsg;
			if(pstrBind && pstrBind->status == 0) {
				// Prepare next buffer reception. 
//				recv(sock, tempBuff, 1536, 0);
        } 
			else {
//				M2M_INFO("socket_cb: bind error!\r\n");
        }
		} 
    case SOCKET_MSG_RECV:
    case SOCKET_MSG_RECVFROM:
    {
      tstrSocketRecvMsg *pstrRecvMsg = (tstrSocketRecvMsg*)pvMsg;

      WORD nRead;

//      m_Led1Bit ^= 1;		// CHECK 
      // qua arrivano circa ogni 10mS... su wireshark/PC/wired dice 500uS...
      

 			if(pstrRecvMsg->s16BufferSize > 0) {
				//get the remote host address and port number
          
//				ret = recvfrom(sock,tempBuff,1024+VBAN_HEADER_SIZE /*1536*/,0 /*TEST_RECV_TIMEOUT*/, NULL, 0);
        // con 1536 il datagram + corto, l'ultimo del pacchetto, arriva in ritardo... pare andare in timeout: bisognerebbe sapere quanto manca...
        // con 1024+header sembra meglio
    		}
      else {
        /* Prepare next buffer reception. */
//        recvfrom(sock, tempBuff, 1024 /*1536*/, 0, NULL, 0);
        }
/*			else			{
//				M2M_INFO("Socket recv Error: %d\n",pstrRx->s16BufferSize);
				ret = close(sock);
      	}*/
invalid_packet:
	;


    }
      break;
    case SOCKET_MSG_SEND:
    case SOCKET_MSG_SENDTO:
      break;
    case SOCKET_MSG_CLOSE: 
      ret = close(sock);
      UDPclientSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
  else if(sock==TCPlistenSocket)
  switch(u8Msg) {
    case SOCKET_MSG_BIND:
      {
      tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg*)pvMsg;
      if(pstrBind->status == 0) {
        listen(TCPlistenSocket, 0);
        }
      else {
        M2M_INFO("Bind Failed\n");
        }
      }
      break;
    case SOCKET_MSG_LISTEN:
      {
      tstrSocketListenMsg *pstrListen = (tstrSocketListenMsg*)pvMsg;
      if(pstrListen->status != 0) {
        M2M_INFO("listen Failed\n");
        }
      }
      break;
    case SOCKET_MSG_ACCEPT:
      {
      // New Socket is accepted.
      tstrSocketAcceptMsg *pstrAccept = (tstrSocketAcceptMsg *)pvMsg;
      if(pstrAccept->sock != INVALID_SOCKET) {
        // Get the accepted socket.
        if(TCPacceptedSocket==INVALID_SOCKET)
          ;

        TCPacceptedSocket = pstrAccept->sock;
        recv(TCPacceptedSocket, rxBuffer, sizeof(rxBuffer), 0);
        }
      else {
        M2M_INFO("Accept Failed\n");
        }
      }
      break;
    case SOCKET_MSG_RECV:

      break;
    case SOCKET_MSG_SEND:
    {
      int sentBytes = *((int16_t*)pvMsg);
//      internetBufferLen=sentBytes;
    }
      break;
    case SOCKET_MSG_CLOSE:
      bTCPIsfinished=TRUE;
      close(TCPlistenSocket);   // in effetti, chiss� se serve...
      close(TCPacceptedSocket);
      TCPacceptedSocket=TCPlistenSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
  else if(sock==TCPacceptedSocket)
  switch(u8Msg) {
    case SOCKET_MSG_RECV:
      {
      tstrSocketRecvMsg *pstrRecvMsg = (tstrSocketRecvMsg*)pvMsg;
      if((pstrRecvMsg->pu8Buffer) /*&& (pstrRecvMsg->s16BufferSize > 0)*/) {
        // Process the received message
        // Perform data exchange
		BYTE acHeadBuffer[256],acSendBuffer[768];

        // Fill in the acSendBuffer with some data here
        // Send some data.
        
        if(!strncmp(pstrRecvMsg->pu8Buffer,"GET",3)) {    // stricmp non c'�... diocheffroci 
          //m2m_stricmp
          if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/stato.html",11)) {
            BYTE retConfig[16];
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_STATO_PAGE,
                    myRSSI,videoFrameCnt,GetStatus(SOUTH_BRIDGE,NULL),  
                    GetConfig(VIDEO_CARD,retConfig),GetConfig(AUDIO_CARD,retConfig),GetConfig(SOUTH_BRIDGE,retConfig),
										now, (((unsigned int)&ret) - ((unsigned int)&_splim)) / 1024, extRAMtot/1024 );
  //          printf("Chip ID : \r\t\t\t%x\r\n", (unsigned int)GET_ATWINC_CHIPID());
  //	printf("RF Revision ID : \r\t\t\t%x\r\n", (unsigned int)nmi_get_rfrevid());
            goto send_refreshed_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/config.html",12)) {
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_CONFIG_PAGE,BiosArea.wifiName,
                    // finire pstrConnInfo->acSSID
                    BiosArea.wifiPasw,
                    myIp.addr[0],myIp.addr[1],myIp.addr[2],myIp.addr[3],
                    BiosArea.httpPort,BiosArea.telnetPort,
                    BiosArea.Flags2.bIsDHCPEnabled ? "checked" : "");
send_standard_page:
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"text/html",strlen(acSendBuffer)+strlen(HTTP_SERVER_HEAD));
            sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
            sendEx(sock, (char *)HTTP_SERVER_HEAD, strlen(HTTP_SERVER_HEAD));
            goto send_standard_body;
    /*	tstrM2MIPConfig conf;

    if (!_init) {
      init();
    }

    conf.u32DNS = (DWORD)dns_server;
    conf.u32Gateway = (DWORD)gateway;
    conf.u32StaticIP = (DWORD)local_ip;
    conf.u32SubnetMask = (DWORD)subnet;
    _dhcp = 0;
    m2m_wifi_enable_dhcp(0); // disable DHCP
    m2m_wifi_set_static_ip(&conf);
    _localip = conf.u32StaticIP;
    _submask = conf.u32SubnetMask;
    _gateway = conf.u32Gateway;*/
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/command.html",13)) {
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_CMD_PAGE);
            goto send_standard_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/files3",7)) { // PRIMA dell'altra ovviamente :)
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER2,"text/html");    // in chunks qua
            sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
            // finire...
            }
#if defined(USA_USB_HOST_MSD)
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/files2",7)) { // PRIMA dell'altra ovviamente :)
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER2,"text/html");    // in chunks qua
            sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
            sendChunk(sock,HTTP_SERVER_HEAD);
            sendChunk(sock,HTTP_DIR_PAGE1_);
            SYS_FS_HANDLE myFileHandle;

            if((myFileHandle=SYS_FS_DirOpen("/")) != SYS_FS_HANDLE_INVALID) {
              SYS_FS_FSTAT stat;
              char buf[32];
              while(SYS_FS_DirSearch(myFileHandle,"*.*",SYS_FS_ATTR_MASK,&stat) == SYS_FS_RES_SUCCESS) {
                strcpy(buf,"/usb/");
                strcat(buf,stat.fname);
                if(stat.fattrib & SYS_FS_ATTR_DIR) {
                  sprintf(acSendBuffer,HTTP_DIR_PAGE2,
                    buf,
                    stat.fname,wdays[((stat.ftime >> 16) & 31)   % 7 /*FINIRE!! serve wday*/],
                    stat.fdate & 31,(stat.fdate >> 5) & 15,(stat.fdate >> 9) + 1980,
                    (stat.ftime >> 11) & 31,(stat.ftime >> 5) & 63,
                    0,"DIR"
                    );
                  }
                else {
                  sprintf(acSendBuffer,HTTP_DIR_PAGE2,
                    buf,
                    stat.fname,wdays[((stat.ftime >> 16) & 31)   % 7 /*FINIRE!! serve wday*/],
                    stat.fdate & 31,(stat.fdate >> 5) & 15,(stat.fdate >> 9) + 1980,
                    (stat.ftime >> 11) & 31,(stat.ftime >> 5) & 63,
                    max(stat.fsize/1024,1),""
                    );
                  }
                sendChunk(sock,acSendBuffer);
                }
              SYS_FS_DirClose(myFileHandle);
              }
            sendChunk(sock,HTTP_DIR_PAGE3);
            sendChunk(sock,NULL);    // end message
            }
#endif
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/files",6)) {
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER2,"text/html");    // in chunks qua
            // https://en.wikipedia.org/wiki/Chunked_transfer_encoding
            sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
            sendChunk(sock,HTTP_SERVER_HEAD);
            sendChunk(sock,HTTP_DIR_PAGE1);

            if(SDcardOK) {
              SearchRec r;

              if(!FindFirst("*.*",ATTR_MASK,&r)) {
                do {
//                strcpy(buf,"/sd/"); fare prefisso pure qua?
//                strcat(buf,stat.fname);
                  if(r.attributes & ATTR_DIRECTORY) {
                    sprintf(acSendBuffer,HTTP_DIR_PAGE2,
		                  r.filename,r.filename,wdays[((r.timestamp >> 16) & 31)   % 7 /*FINIRE!! serve wday*/],
                      (r.timestamp >> 16) & 31,(r.timestamp >> (5+16)) & 15,(r.timestamp >> (9+16)) + 1980,
                      (r.timestamp >> 11) & 31,(r.timestamp >> 5) & 63,
                      0,"DIR"
                      );
                    }
                  else {
                    sprintf(acSendBuffer,HTTP_DIR_PAGE2,
	                    r.filename,r.filename,wdays[((r.timestamp >> 16) & 31)   % 7 /*FINIRE!! serve wday*/],
                      (r.timestamp >> 16) & 31,(r.timestamp >> (5+16)) & 15,(r.timestamp >> (9+16)) + 1980,
                      (r.timestamp >> 11) & 31,(r.timestamp >> 5) & 63,
                      max(r.filesize/1024,1),""
                      );
                    }
                  sendChunk(sock,acSendBuffer);
                  } while(!FindNext(&r));
                }
              }
            sendChunk(sock,HTTP_DIR_PAGE3);
            sendChunk(sock,NULL);    // end message
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/help.html",10)) {
            int i,j;
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            
            *acSendBuffer=0;    // METTERE comando HELP
            strcat(acSendBuffer,"ToDo<br>\r\n"
              "<br><br><a href='/'>Torna indietro</a><br>\n"
              );
            goto send_standard_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/provaled.cgi",13)) {
            BYTE i;
            if(pstrRecvMsg->pu8Buffer[17]=='?') {
              i=pstrRecvMsg->pu8Buffer[18]=='1';
              }
            else {
              m2m_periph_gpio_get_val(M2M_PERIPH_GPIO18,&i);    // v. anche get_gpio_idx
              }
            m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,!i);    // non va dio merda si spegne solo
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            strcpy(acSendBuffer,HTTP_PROVALED_PAGE);
            goto send_standard_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/logo.gif",9)) {
            p=(char *)HTTP_SITEICON; ret=sizeof(HTTP_SITEICON);
            goto send_gif;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/diamond.gif",12)) {
            p=(char *)HTTP_DIAMONDICON; ret=sizeof(HTTP_DIAMONDICON);
            goto send_gif;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/item.gif",9)) {
            p=(char *)HTTP_ITEMICON; ret=sizeof(HTTP_ITEMICON);
send_gif:
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"image/gif",ret);
            sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
            sendEx(sock, p, ret);
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/index.html",11)) {
            goto index_page;
            }
          else if(pstrRecvMsg->pu8Buffer[4]=='/' && pstrRecvMsg->pu8Buffer[5]==' ') {
index_page:
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_SERVER_PAGE,
                    VERNUMH,VERNUML
#ifdef USA_WIFI
                    ,GET_ATWINC_CHIPID(),nmi_get_rfrevid()
#endif
#ifdef USA_ETHERNET
	                  ,ReadReg(EIDLED)
#endif
                    );
send_refreshed_page:
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"text/html",strlen(acSendBuffer)+strlen(HTTP_SERVER_HEAD2));
            sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
            sendEx(sock, (char *)HTTP_SERVER_HEAD2, strlen(HTTP_SERVER_HEAD2));
send_standard_body:
            sendEx(sock, acSendBuffer, strlen(acSendBuffer));
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/copyright.html",15)) {
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            strcpy(acSendBuffer,_PC_PIC_CPU_C);
            goto send_standard_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/cmd.cgi",8)) {
            int i;
            {
              char *p=strstr(pstrRecvMsg->pu8Buffer+4+8+1,"HTTP");    // brutto..
              *p++='\n'; *p=0;
            printf("\r\n%s\r\n",p);
            i=execCmd(p,NULL);    // altro test...
            sprintf(acSendBuffer,"Eseguito %d\r\n",i);
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            }
            goto send_standard_page;
            }
          else {
            p=pstrRecvMsg->pu8Buffer+5; while(p) { if(*p==' ') { *p=0; break; } p++; }
#if defined(USA_USB_HOST_MSD)
            if(!strnicmp(p,"/usb/",5)) {   // gestire!
              if(USBmemOK) {
                }
              }
#endif
            if(SDcardOK) {
              FSFILE *f;
              if(f=FSfopen(pstrRecvMsg->pu8Buffer+5,"r")) {
                sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
                sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"application/octet-stream",f->size);
                sendEx(sock, acHeadBuffer, strlen(acHeadBuffer));
                do {
                  ret=FSfread(acSendBuffer,1,512,f);
                  if(sendEx(sock,acSendBuffer,ret) != 512)
                    break;
                  } while(ret==512);
                FSfclose(f);
                goto invalid_request;   // 

                }
              }
send_non_trovato:
            sendEx(sock, (char *)HTTP_SERVER_ERR, strlen(HTTP_SERVER_ERR));
            strcpy(acSendBuffer,"Non trovato.\r\n");
            goto send_standard_page;
            }
          }
        else if(!strncmp(pstrRecvMsg->pu8Buffer,"POST",4)) {    // stricmp non c'�... diocheffroci
          if(!strncmp(pstrRecvMsg->pu8Buffer+5,"/config.cgi",11)) {
            char *dataptr=strstr(pstrRecvMsg->pu8Buffer,"\r\n\r\n");
            
            if(dataptr) {
              char parmN[32],parmV[32];
              int i,j;
              printf("\r\n%s\r\n",dataptr );

              *parmN=*parmV=0;    // non dovrebbe servire...
              parseParm(dataptr,parmN,32,parmV,32,1,1);
              strncpy(BiosArea.wifiName,parmV,31);  BiosArea.wifiName[31]=0;
              parseParm(dataptr,parmN,32,parmV,32,2,1);
              strncpy(BiosArea.wifiPasw,parmV,31);  BiosArea.wifiPasw[31]=0;
              parseParm(dataptr,parmN,32,parmV,32,3,1);
              BiosArea.MyIPAddr2.Val=nmi_inet_addr(parmV);
//parsare IP              strncpy(BiosArea.MyIPAddr2,parmV,31);
              BiosArea.httpPort=parseNumParm(dataptr,parmN,32,parmV,32,4,1);
              BiosArea.telnetPort=parseNumParm(dataptr,parmN,32,parmV,32,5,1);
              BiosArea.Flags2.bIsDHCPEnabled=parseNumParm(dataptr,parmN,32,parmV,32,6,1);

              SaveBios(1);
              
              App_Reset();    // aggiungere bottone a parte??
              // perch� se no la pagina rimane appesa...
              }
            else
// https://developer.mozilla.org/en-US/docs/Learn/Forms/Sending_and_retrieving_form_data
              goto send_non_trovato; //FARE!
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+5,"/cmd.cgi",8)) {
            int i;
            char *dataptr=strstr(pstrRecvMsg->pu8Buffer,"\r\n\r\n");
            // bisogna cercare il doppio CRLF e poi de-encode i % ecc...
// https://developer.mozilla.org/en-US/docs/Learn/Forms/Sending_and_retrieving_form_data
            
            if(dataptr) {
              //parseParm();
              dataptr=strchr(dataptr,'='); dataptr++;   // dovrebbe esserci "di sicuro" ;) ovvero usare parseParm!
              
              printf("\r\n[REMOTE]%s\r\n",dataptr );
              i=execCmd(dataptr /*pstrRecvMsg->pu8Buffer+5+8+1*/,NULL);    // provare
              putchar('\n'); printf(prompt);
              sprintf(acSendBuffer,"Eseguito %d\r\n",i);
              sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
              goto send_standard_page;
              }
            else
              goto send_non_trovato; //FARE!
            }
          }
        else
          goto invalid_request;   // 
        
        // Recv response from client. bah serve davvero??
        recv(sock, rxBuffer, sizeof(rxBuffer), 0);
        
invalid_request:        
        bTCPIsfinished=1;    // non � il massimo...
         
        // Close the socket when finished.
        if(bTCPIsfinished) {
          close(TCPacceptedSocket);
          TCPacceptedSocket=INVALID_SOCKET;
//          close(TCPlistenSocket);
          }
        }
      }
      break;
    case SOCKET_MSG_SEND:
    {
      int sentBytes = *((int16_t*)pvMsg);
      internetBufferLen=sentBytes;
    }
      break;
    case SOCKET_MSG_CLOSE:    // diofa non c'era!
      bTCPIsfinished=TRUE;
      close(TCPacceptedSocket);
      TCPacceptedSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
      
#ifdef USA_TELNET
  else if(sock==TelnetSocket)
  switch(u8Msg) {
    case SOCKET_MSG_BIND:
      {
      tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg*)pvMsg;
      if(pstrBind->status == 0) {
        listen(TelnetSocket, 0);
        *(unsigned long*)internetBuffer=1;
        }
      else {
//        M2M_INFO("Bind Failed\n");
        }
      }
      break;
    case SOCKET_MSG_LISTEN:
      {
      tstrSocketListenMsg *pstrListen = (tstrSocketListenMsg*)pvMsg;
      if(pstrListen->status != 0) {
        M2M_INFO("listen Failed\n");
        }
      else
        *(unsigned long*)internetBuffer=1;
      }
      break;
    case SOCKET_MSG_ACCEPT:
      {
      // New Socket is accepted.
      tstrSocketAcceptMsg *pstrAccept = (tstrSocketAcceptMsg *)pvMsg;
      if(pstrAccept->sock != INVALID_SOCKET) {
        // Get the accepted socket. 
        if(TelnetAcceptedSocket==INVALID_SOCKET)
          TelnetAcceptedSocket = pstrAccept->sock;
        else
          goto no_sockets_free2;

//        *(unsigned long*)internetBuffer=pstrAccept->sock;
        acceptedIp.ip=pstrAccept->strAddr.sin_addr.s_addr;
        acceptedPort=pstrAccept->strAddr.sin_port;
        *(unsigned long*)internetBuffer=acceptedIp.ip;
        
        if(BiosArea.flags.verboseMode)
          puts("[TELNET WiFi open]");
        
        goto accept_done2;
no_sockets_free2:
        *(unsigned long*)internetBuffer=-1;
accept_done2:
        recv(pstrAccept->sock, rxBuffer, sizeof(rxBuffer), 0);
        }
      else {
        M2M_INFO("Accept Failed\n");
        }
      }
      break;
    case SOCKET_MSG_RECV:
      {
        tstrSocketRecvMsg *pstrRecvMsg = (tstrSocketRecvMsg*)pvMsg;
        if((pstrRecvMsg->pu8Buffer) && (pstrRecvMsg->s16BufferSize > 0)) {
            // Process the received message.
          memcpy(internetBuffer,pstrRecvMsg->pu8Buffer,min(pstrRecvMsg->s16BufferSize,sizeof(internetBuffer)));
          internetBufferLen=min(pstrRecvMsg->s16BufferSize,sizeof(internetBuffer));
          }
      }

      break;
    case SOCKET_MSG_CLOSE:
      close(TelnetSocket);   // in effetti, chiss� se serve...
      close(TelnetAcceptedSocket);
      TelnetSocket=TelnetAcceptedSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
  else if(sock==TelnetAcceptedSocket)
  switch(u8Msg) {
    case SOCKET_MSG_RECV:
      {
      tstrSocketRecvMsg *pstrRecvMsg = (tstrSocketRecvMsg*)pvMsg;

      if((pstrRecvMsg->pu8Buffer) && (pstrRecvMsg->s16BufferSize > 0)) {
        // Process the received message
        // Perform data exchange

//        memcpy(internetBuffer,pstrRecvMsg->pu8Buffer,min(pstrRecvMsg->s16BufferSize,sizeof(internetBuffer)));
//        internetBufferLen=min(pstrRecvMsg->s16BufferSize,sizeof(internetBuffer));
        
#ifdef USA_TELNET
// finire se si vuole... v. anche forgetIvrea/Bitlash
        putchar(*pstrRecvMsg->pu8Buffer);
#endif

        recv(sock, rxBuffer, sizeof(rxBuffer), 0);

        }
      }
      break;
    case SOCKET_MSG_SEND:
    {
      int sentBytes = *((int16_t*)pvMsg);
      internetBufferLen=sentBytes;
    }
      break;
    case SOCKET_MSG_CLOSE:
      close(TelnetAcceptedSocket);		// in effetti, chiss� se serve...
      TelnetAcceptedSocket=INVALID_SOCKET;
      if(BiosArea.flags.verboseMode)
        puts("[TELNET WiFi close]");
      break;
    default:
      break;
    }
#endif
  
  }


#endif

#ifdef USA_ETHERNET   // in effetti, unificare con ATWINC ecc
int16_t sendEx2(TCP_SOCKET sock, void *pvSendBuffer, uint32_t u32SendLength) {
  uint16_t n,n2;
//  WORD tOut;
  int i;

  n2=0;
  do {
    n=min(u32SendLength,1000 /*SOCKET_BUFFER_MAX_LENGTH*/);
    if(TCPIsPutReady(sock) >= n) {
      i=TCPPutArray(sock, pvSendBuffer, n);
      if(!i)
        goto fine;
//      if(i<n)
//        goto fine;
      pvSendBuffer+=i;
      n2+=i;
      u32SendLength-=i;
      
      }
    
    StackTask();    // o TCPTick()
      
    ClrWdt();
    } while(u32SendLength);
    
fine:
// fare TCPFlush(sock) ??
//  TCPFlush(sock);
  return n2;
  }
#endif

BYTE BCD2Hex(const char *);
const char *stristr(const char *,const char *);
char *compattaHex(char *);
const char *tagContentDisposition="Content-Disposition:";
char *parseParm(const char *s,char *n1,uint32_t nl1,char *n2,uint32_t nl2, 
																		 int q,int m) {
	register int i;
	int j,inQuote=0;
	register char *p,*p1;
//gestire ? e & in apici? o no?

	*n1=*n2=0;
	if(!s)
		return NULL;
	if(strchr(s,'/'))						// mi posiziono al '?', se non ci sono gia'... (ossia se arrivo con un link completo
		if(p=strchr(s,'?'))
			s=p+1;												
	if(!*s)
		goto fine;
	if(!q)
		q=1;
	while(q) {
		*n2=0;
		if(p=strchr(s,'=')) {
			j=min(p-s,nl1-1);
			strncpy(n1,s,j);
			n1[j]=0;
			if(p1=strchr(p,'&')) {
				j=min(p1-p-1,nl2-1);
				strncpy(n2,p+1,j);
				n2[j]=0;
				s=p1+1;
				}
			else {
				strncpy(n2,p+1,nl2-1);
				n2[nl2]=0;
				while(*s)
					s++;
//				s=NULL;
				}
			}
		else {
			*n1=0;
			break;
			}
		if(m) {			// se specificato...
			if(*n2)			// ...auto-evito i parm. vuoti...
				q--;
			}
		else
			q--;
		}
fine:
	p=compattaHex(n2);
	return p;
	}

int parseNumParm(const char *s,char *parmN, UINT parmNL, char *parmV, UINT parmVL, int q,int autoSkip) {
	char *p;

	p=parseParm(s,parmN,parmNL,parmV,parmVL,q,autoSkip);
	return p ? atoi(p) : 0;
	}

char *parseNamedParm(const char *s, const char *n, char *v, UINT vl) {
	int i;
	char parmN[256];

	for(i=1; ; i++) {
		parseParm(s,parmN,255,v,vl,i,0);
		if(!*parmN) {
			*v=0;
			break;
			}
		if(!stricmp(parmN,n)) {
			break;
			}
		}
	return v;

	}

char *parseFormParm(const char *s, const char *s2, char *n1, char *v) {
	int i;
	char *p;

	if(!strnicmp(s,tagContentDisposition,20)) {
		if(p=(char *)stristr(s,"form-data;")) {
			p+=11;
			if(!strnicmp(p,"name=",5)) {
				p+=5;
				if(*p=='\"')
					p++;
				strcpy(n1,p);
				if(n1[strlen(n1)-1]=='\"')
					n1[strlen(n1)-1]=0;
				}
			else
				strcpy(n1,p);
			if(s2 && v) {
				strcpy(v,s2);			// per ora cos
				}
			return n1;
			}
		}
	return NULL;
	}

char *compattaHex(char *s) {
	char *p=(char *)s,*s1=(char *)s;
	BYTE i;

	while(*s) {
		switch(*s) {
			case '+':			// rimuove i '+' usati dal CGI per indicare gli spazi...
				*p=' ';
				break;
			case '%':			// rimette a posto le conversioni dei browser...
				s++;
				if(*s) {
					if(isalnum(*s))
						*p=BCD2Hex(s);
					s++;
					}
				else
					s--;		// forza esci...
				break;
			default:
				*p=*s;
				break;
			}
		s++;
		p++;
		}
	*p=0;
	return s1;
	}

BYTE BCD2Hex(const char *s) {
	BYTE i,n;

	n=*s-'0';
	if(n >= 10)
		n-=7;
	n <<= 4;
	s++;
	i=*s-'0';
	if(i >= 10)
		i-=7;
	n+=i;
	return n;
	}

const char *stristr(const char *s1,const char *s2) {
	char s1_[1024],s2_[1024],*p;

	
  int n=strlen(s2);

	while(*s1) {
    if(!strnicmp(s1,s2,n))
      return s1;
    s1++;
    }
	return NULL;


	}


// ----------------------------------------------------------------------------
int SetVideoMode(BYTE mode,uint16_t xres,uint16_t yres,BYTE bpp) {
  BYTE parms[16];
  int i;
  
  parms[0]=mode;
  parms[1]=LOBYTE(xres);
  parms[2]=HIBYTE(xres);
  parms[3]=LOBYTE(yres);
  parms[4]=HIBYTE(yres);
  parms[5]=bpp;
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_MODE,parms,6);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  
  Screen.cx=xres; Screen.cy=yres;
  
  GetConfig(VIDEO_CARD,parms);
  if(!parms[7])   // bah safety :)
    parms[7]=1;
  i=parms[7]*8;   // textsize, poi gestisco
  ScreenText.cy=Screen.cy/i;
  if(xres<256) // IS_ILI, per ora
    i=parms[7]*6;   // textsize, poi gestisco
  else
    i=parms[7]*8;
  ScreenText.cx=Screen.cx/i;
  }

int DrawPixel(uint16_t x1,uint16_t y1,GFX_COLOR c) {
  BYTE parms[8];
  
  parms[0]=LOBYTE(x1);
  parms[1]=HIBYTE(x1);
  parms[2]=LOBYTE(y1);
  parms[3]=HIBYTE(y1);
  parms[4]=LOBYTE(c);
  parms[5]=HIBYTE(c);
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_PIXEL,parms,6);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

int DrawLine(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,GFX_COLOR c) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(x1);
  parms[1]=HIBYTE(x1);
  parms[2]=LOBYTE(y1);
  parms[3]=HIBYTE(y1);
  parms[4]=LOBYTE(x2);
  parms[5]=HIBYTE(x2);
  parms[6]=LOBYTE(y2);
  parms[7]=HIBYTE(y2);
  parms[8]=LOBYTE(c);
  parms[9]=HIBYTE(c);
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_LINE,parms,10);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

int DrawRectangle(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,GFX_COLOR c) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(x1);
  parms[1]=HIBYTE(x1);
  parms[2]=LOBYTE(y1);
  parms[3]=HIBYTE(y1);
  parms[4]=LOBYTE(x2);
  parms[5]=HIBYTE(x2);
  parms[6]=LOBYTE(y2);
  parms[7]=HIBYTE(y2);
  parms[8]=LOBYTE(c);
  parms[9]=HIBYTE(c);
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_RECTANGLE,parms,10);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

int DrawCircle(uint16_t x1,uint16_t y1,uint16_t r,GFX_COLOR c) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(x1);
  parms[1]=HIBYTE(x1);
  parms[2]=LOBYTE(y1);
  parms[3]=HIBYTE(y1);
  parms[4]=LOBYTE(r);
  parms[5]=HIBYTE(r);
  parms[6]=LOBYTE(c);
  parms[7]=HIBYTE(c);
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_CIRCLE,parms,8);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

void Cls(void) {
  
  CNNEFbits.CNNEF1=0;
  WritePMP(VIDEO_CARD,BIOS_VIDEO_CLS, /* metterci il colore di sfondo!*/ 0);
#warning metterci il colore di sfondo! o lo fa il driver video..
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

void SetColors(GFX_COLOR f,GFX_COLOR b) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(f);
  parms[1]=HIBYTE(f);
  parms[2]=LOBYTE(b);
  parms[3]=HIBYTE(b);
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_COLORS,parms,4);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

void SetXYText(uint8_t x,uint8_t y) {
  SetXY(1,x,y);
  }
void SetXY(BYTE mode,uint16_t x,uint16_t y) {
  BYTE parms[16];
  
  parms[0]=mode;
  parms[1]=LOBYTE(x);
  parms[2]=HIBYTE(x);
  parms[3]=LOBYTE(y);
  parms[4]=HIBYTE(y);
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_XY,parms,5);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }

void SetCursorMode(uint8_t state,uint8_t mode) {
  BYTE parms[8];
  
  parms[0]=state;
  parms[1]=mode;
  
  CNNEFbits.CNNEF1=0;
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_CURSOR,parms,2);
  Nop();Nop();
  while(!m_VACK)
    ClrWdt();
  __delay_us(VIDEO_WAIT);
  CNNEFbits.CNNEF1=1;
  }


int SetAudioMode(enum TIPO_WAVE type) {
  BYTE parms[16];
  
  parms[0]=type;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETMODE,parms,1);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }

int SetAudioWave(BYTE channel,enum TIPO_ONDA type,WORD freq,BYTE chan,BYTE bits,BYTE volume,BYTE mode,BYTE effect) {
  BYTE parms[16];
  
  parms[0]=channel;
  parms[1]=type;
  parms[2]=LOBYTE(freq);
  parms[3]=HIBYTE(freq);
  parms[4]=chan;
  parms[5]=bits;
  parms[6]=volume;
  parms[7]=mode;
  parms[8]=effect;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETWAVE,parms,9);
  while(!m_AACK)
#warning magari lasciando il WD? cos� nel caso si resetta...
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }

int SetAudioSamples(BYTE val) {   // per ora 1 per volta..
  BYTE parms[16];
  
  parms[0]=val;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETMODE,parms,1);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }

int SetAudioFrequency(BYTE channel,WORD freq) {
  BYTE parms[16];
  
  parms[0]=channel;
  parms[1]=LOBYTE(freq);
  parms[2]=HIBYTE(freq);
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETFREQUENCY,parms,3);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }

int SetSerialPort(DWORD baud,BYTE bits,BYTE par,BYTE stop) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(LOWORD(baud));
  parms[1]=HIBYTE(LOWORD(baud));
  parms[2]=LOBYTE(HIWORD(baud));
  parms[3]=HIBYTE(HIWORD(baud));
  parms[4]=bits;
  parms[5]=par;
  parms[6]=stop;
  
  CNNEAbits.CNNEA7=0;
  WritePMPs(SOUTH_BRIDGE,BIOS_SERIAL_INIT,parms,7);
  Nop();Nop();Nop();Nop();__delay_us(2);
  while(!m_SACK)
    ClrWdt();
  __delay_us(SOUTHBRIDGE_WAIT);
  CNNEAbits.CNNEA7=1;
  }
  
int SetParallelPort(BYTE mode) {
  BYTE parms[16];
  
  parms[0]=mode;
  
  CNNEAbits.CNNEA7=0;
  WritePMPs(SOUTH_BRIDGE,BIOS_PARALLEL_INIT,parms,1);
  Nop();Nop();Nop();Nop();__delay_us(2);
  while(!m_SACK)
    ClrWdt();
  __delay_us(SOUTHBRIDGE_WAIT);
  CNNEAbits.CNNEA7=1;
  }
  
int SetJoystick(BYTE mode) {
  BYTE parms[16];
  
  parms[0]=mode;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETJOYSTICK,parms,1);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }
  
int ReadJoystick(int8_t q) {
  WORD n;
  BYTE parms[16];
  
  ReadPMPs(AUDIO_CARD,BIOS_AUDIO_READJOYSTICK,(BYTE *)&parms,13);
  // legge traslato, 25/12/21: 149 2 8 0 0 0 176 0 94 JOY.BAS
  // i 3 zeri corrispondono a 1 2 4 JP0 JP1 JP2 e idem 8 quadra con questi, a parte 8 fisso; il resto boh...
  // simulando 200-> leggo 211 212 200 201 202 203 205 207 209
  // ..208 finisce nel dummy, poi 209 210 211 212 200 201 202 203 204 205 206 207
  switch(q) {
    case 0:   // all buttons, packed
      n=parms[0];
      break;
    case 1:
    case 2:
    case 3:
    case 4:
      n=parms[q];   // buttons
      break;
    case -1:
    case -2:
    case -3:
    case -4:
      n=MAKEWORD(parms[3-q*2],parms[4-q*2]);   // analog values
      break;
    }
  return n;
  }

int ReadTemperature(void) {
  WORD n;
  
  ReadPMPs(AUDIO_CARD,BIOS_AUDIO_READTEMPERATURE,(BYTE *)&n,2);
  return n;
  }

int SetMidi(BYTE mode) {
  BYTE parms[16];
  
  parms[0]=mode;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_INITMIDI,parms,1);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }
  
int WriteMidi(BYTE ch) {
  BYTE parms[16];
  
  parms[0]=ch;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_WRITEMIDI,parms,1);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }
  
int ReadMidi(void) {
  BYTE ch;
  
  ch=ReadPMP(AUDIO_CARD,BIOS_AUDIO_READMIDI);
  return ch;
  }

int SetRTCC(BYTE d,BYTE m,uint16_t y,BYTE H,BYTE M,BYTE S) {
  BYTE parms[16];
  
  parms[0]=d;
  parms[1]=m;
  parms[2]=LOBYTE(y);
  parms[3]=HIBYTE(y);
  parms[4]=H;
  parms[5]=M;
  parms[6]=S;
  
  CNNEAbits.CNNEA3=0;
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETCLOCK,parms,7);
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;
  }

int SetRTCCFromNow(DWORD t) {
  PIC32_DATE date;
  PIC32_TIME time;
  
  SetTimeFromNow(t,&date,&time);
  SetRTCC(date.mday,date.mon,date.year,time.hour,time.min,time.sec);
  }

int GetRTCC(BYTE *d,BYTE *m,uint16_t *y,BYTE *H,BYTE *M,BYTE *S) {
  BYTE parms[7];
  
  ReadPMPs(AUDIO_CARD,BIOS_AUDIO_GETCLOCK,(BYTE *)&parms,7);
  *d=parms[0];
  *m=parms[1];
  *y=MAKEWORD(parms[2],parms[3]);
  *H=parms[4];
  *M=parms[5];
  *S=parms[6];
  return 1;
  }


#define DELAY_PMP() {Nop();Nop(); Nop();Nop();}
#define DELAY_PMP_SOUTHBRIDGE() {__delay_us(2);}
// serve una dummy write CON ADDRESS 0? come read?? ev. usare un MSB dell'address o...
void WritePMP(enum BUS bus,BYTE addr,BYTE data) {
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_SLOW-1;
      SYSKEY = 0x00000000;
      m_SCS=0;
      break;
    }
  DELAY_PMP();
  PMPWaitBusy();
//  PMWADDR=addr & 63;
//  PMPWaitBusy();
  LATBbits.LATB15=addr & 0x1 ? 1 : 0; // PMADDR in read non andrebbe comunque...INVECE SI'!
  LATBbits.LATB14=addr & 0x2 ? 1 : 0;
  LATGbits.LATG9=addr & 0x4 ? 1 : 0;
  LATGbits.LATG8=addr & 0x8 ? 1 : 0;
  LATGbits.LATG7=addr & 0x10 ? 1 : 0;
  LATAbits.LATA5=addr & 0x20 ? 1 : 0;
  DELAY_PMP();
    
  PMDOUT=data;   // il FRM dice PMDIN ma PORCODIO non � vero figli del cancro #stuprigeorgepauley
  // ah in un angolo precisa che dipende dal "DUALBUF" di PMCON...
  PMPWaitBusy();
//		__delay_us(1);
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=1;
      break;
    case AUDIO_CARD:
      m_ACS=1;
      break;
    case SOUTH_BRIDGE:
      m_SCS=1;
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_FAST-1;
      SYSKEY = 0x00000000;
      break;
    }
  }

void WritePMPs(enum BUS bus,BYTE addr,BYTE data[],BYTE len) {
  BYTE n;
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_SLOW-1;
      SYSKEY = 0x00000000;
      m_SCS=0;
      break;
    }
  DELAY_PMP();
  PMPWaitBusy();
//  PMWADDR=addr & 63;
//  PMPWaitBusy();
  LATBbits.LATB15=addr & 0x1 ? 1 : 0; // PMADDR in read non andrebbe comunque... INVECE SI'!
  LATBbits.LATB14=addr & 0x2 ? 1 : 0;
  LATGbits.LATG9=addr & 0x4 ? 1 : 0;
  LATGbits.LATG8=addr & 0x8 ? 1 : 0;
  LATGbits.LATG7=addr & 0x10 ? 1 : 0;
  LATAbits.LATA5=addr & 0x20 ? 1 : 0;
  DELAY_PMP();
  
  for(n=0; n<len; n++) {
    PMDOUT=data[n];
    PMPWaitBusy();
//		__delay_us(1);
    }
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=1;
      break;
    case AUDIO_CARD:
      m_ACS=1;
      break;
    case SOUTH_BRIDGE:
      m_SCS=1;
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_FAST-1;
      SYSKEY = 0x00000000;
      break;
    }
  }

BYTE ReadPMP(enum BUS bus,BYTE addr) {
	BYTE data;
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_SLOW-1;
      SYSKEY = 0x00000000;
      m_SCS=0;
      break;
    }
  DELAY_PMP();
  PMPWaitBusy();
  
  LATBbits.LATB15=0;
  LATBbits.LATB14=0;
  LATGbits.LATG9=0;
  LATGbits.LATG8=0;
  LATGbits.LATG7=0;
  LATAbits.LATA5=0;
  DELAY_PMP();
//  PMPWaitBusy();
    
  PMRDIN;    // la dummy read CON ADDRESS 0
  PMPWaitBusy();
  switch(bus) {
    case VIDEO_CARD:
    case AUDIO_CARD:
      break;
    case SOUTH_BRIDGE:
      DELAY_PMP_SOUTHBRIDGE();
      break;
    }
  
//  PMRADDR=addr & 63; // 
  LATBbits.LATB15=addr & 0x1 ? 1 : 0;   // PMADDR in read non andrebbe comunque...INVECE SI'!
  // alla fine, no: guardando il grafico, l'IRQ della PSP si alza DOPO la fine del ciclo read (e pure write) e quindi
  //   PMxADDR non son pi� validi (CHEMMERDA)
  LATBbits.LATB14=addr & 0x2 ? 1 : 0;
  LATGbits.LATG9=addr & 0x4 ? 1 : 0;
  LATGbits.LATG8=addr & 0x8 ? 1 : 0;
  LATGbits.LATG7=addr & 0x10 ? 1 : 0;
  LATAbits.LATA5=addr & 0x20 ? 1 : 0;
  DELAY_PMP();
  
  switch(bus) {
    case VIDEO_CARD:
    case AUDIO_CARD:
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      break;
    case SOUTH_BRIDGE:
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      DELAY_PMP_SOUTHBRIDGE();
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      DELAY_PMP_SOUTHBRIDGE();
      break;
    }
//  PMRADDR=addr & 63; // 
  data=PMRDIN;
  PMPWaitBusy();
//		__delay_us(1);
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=1;
      break;
    case AUDIO_CARD:
      m_ACS=1;
      break;
    case SOUTH_BRIDGE:
      m_SCS=1;
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_FAST-1;
      SYSKEY = 0x00000000;
      break;
    }
	return data;
  }

BYTE ReadPMPs(enum BUS bus,BYTE addr,BYTE *parms,BYTE numItems) {
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_SLOW-1;
      SYSKEY = 0x00000000;
      m_SCS=0;
      break;
    }
  DELAY_PMP();
  PMPWaitBusy();
  LATBbits.LATB15=0;
  LATBbits.LATB14=0;
  LATGbits.LATG9=0;
  LATGbits.LATG8=0;
  LATGbits.LATG7=0;
  LATAbits.LATA5=0;
  DELAY_PMP();
//  PMPWaitBusy();
    
  PMRDIN;    // la dummy read CON ADDRESS 0
  PMPWaitBusy();

  switch(bus) {
    case VIDEO_CARD:
    case AUDIO_CARD:
      break;
    case SOUTH_BRIDGE:
      DELAY_PMP_SOUTHBRIDGE();
      break;
    }
  
  LATBbits.LATB15=addr & 0x1 ? 1 : 0;
  LATBbits.LATB14=addr & 0x2 ? 1 : 0;
  LATGbits.LATG9=addr & 0x4 ? 1 : 0;
  LATGbits.LATG8=addr & 0x8 ? 1 : 0;
  LATGbits.LATG7=addr & 0x10 ? 1 : 0;
  LATAbits.LATA5=addr & 0x20 ? 1 : 0;
  DELAY_PMP();

  switch(bus) {
    case VIDEO_CARD:
    case AUDIO_CARD:
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      break;
    case SOUTH_BRIDGE:
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      DELAY_PMP_SOUTHBRIDGE();
      PMRDIN;    // la dummy read
      PMPWaitBusy();
      break;
    }
//	BOH COS� VA, 29/12/21: non � ben chiaro perch� le read aggiuntive...
  // s�, ci sono 2 "00" in canna, prima del dato buono... 22/6/22
  
	while(numItems--) {
		switch(bus) {
			case VIDEO_CARD:
			case AUDIO_CARD:
				break;
			case SOUTH_BRIDGE:
        DELAY_PMP_SOUTHBRIDGE();
				break;
			}
		*parms++=PMRDIN;
		PMPWaitBusy();
//			__delay_us(1);
		}

  switch(bus) {
    case VIDEO_CARD:
      m_VCS=1;
      break;
    case AUDIO_CARD:
      m_ACS=1;
      break;
    case SOUTH_BRIDGE:
      m_SCS=1;
      SYSKEY = 0x00000000;
      SYSKEY = 0xAA996655;
      SYSKEY = 0x556699AA;
      while(!PB2DIVbits.PBDIVRDY);
      PB2DIVbits.PBDIV = PMP_CLOCK_DIVIDER_FAST-1;
      SYSKEY = 0x00000000;
      break;
    }
	return 1;
  }

DWORD GetID(enum BUS bus) {
  
  return ReadPMP(bus,BIOS_GETID);
  }

DWORD GetConfig(enum BUS bus,BYTE *ret) {
  DWORD p;
  
  switch(bus) {
    case SOUTH_BRIDGE:
      if(ret)
        ReadPMPs(bus,BIOS_GETCONFIG,ret,8);
      else
        ReadPMPs(bus,BIOS_GETCONFIG,(BYTE*)&p,4);
      break;
    case VIDEO_CARD:
      if(ret)
        ReadPMPs(bus,BIOS_GETCONFIG,ret,8);
      else
        ReadPMPs(bus,BIOS_GETCONFIG,(BYTE*)&p,4);
      break;
    case AUDIO_CARD:
      if(ret)
        ReadPMPs(bus,BIOS_GETCONFIG,ret,5);
      else
        ReadPMPs(bus,BIOS_GETCONFIG,(BYTE*)&p,4);
      break;
    }
  if(ret)
    p=MAKELONG(MAKEWORD(ret[0],ret[1]),MAKEWORD(ret[2],ret[3]));
  return p;
  }

DWORD GetStatus(enum BUS bus,BYTE *ret) {
  DWORD p;
  
  switch(bus) {
    case SOUTH_BRIDGE:
      if(ret)
        ReadPMPs(bus,BIOS_GETSTATUS,ret,4);
      else
        ReadPMPs(bus,BIOS_GETSTATUS,(BYTE*)&p,4);
      break;
    case VIDEO_CARD:
      if(ret)
        ReadPMPs(bus,BIOS_GETSTATUS,ret,4);
      else
        ReadPMPs(bus,BIOS_GETSTATUS,(BYTE*)&p,4);
      break;
    case AUDIO_CARD:
      if(ret)
        ReadPMPs(bus,BIOS_GETSTATUS,ret,5);
      else
        ReadPMPs(bus,BIOS_GETSTATUS,(BYTE*)&p,4);
      break;
    }
  if(ret)
    p=MAKELONG(MAKEWORD(ret[0],ret[1]),MAKEWORD(ret[2],ret[3]));
  return p;
  }

DWORD GetVersion(enum BUS bus) {
  WORD ver;
  
  ReadPMPs(bus,BIOS_GETVERSION,(BYTE *)&ver,2);
  return ver;
  }

int print(const char *s) {
  
  while(*s) {
    CNNEFbits.CNNEF1=0;
    WritePMP(VIDEO_CARD,BIOS_VIDEO_CHAR,*s++);
    Nop();Nop();
    while(!m_VACK)
      ClrWdt();
  __delay_us(VIDEO_WAIT);
    CNNEFbits.CNNEF1=1;
    }
  }

int GetVideoTextArea(char *s,int n) {   // finire...
  
  while(n--) {
    *s++=ReadPMP(VIDEO_CARD,BIOS_VIDEO_CHAR);
    }
  }


int WriteSerial(char ch) {
  
  CNNEAbits.CNNEA7=0;
  WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_CHAR,ch);
  Nop();Nop();Nop();Nop();__delay_us(2);
  while(!m_SACK)
    ClrWdt();
  __delay_us(SOUTHBRIDGE_WAIT);
  CNNEAbits.CNNEA7=1;
  }

int ReadSerial(void) {
  int16_t ret;
  
  ReadPMPs(SOUTH_BRIDGE,BIOS_SERIAL_CHAR,(BYTE *)&ret,2);
  return ret;
  }

int WriteParallel(char ch) {
  
  CNNEAbits.CNNEA7=0;
  WritePMP(SOUTH_BRIDGE,BIOS_PARALLEL_CHAR,ch);
  Nop();Nop();Nop();Nop();__delay_us(2);
  while(!m_SACK)
    ClrWdt();
  __delay_us(SOUTHBRIDGE_WAIT);
  CNNEAbits.CNNEA7=1;
  }

int ReadParallel(void) {
  int16_t ret;
  
  ReadPMPs(SOUTH_BRIDGE,BIOS_PARALLEL_CHAR,(BYTE*)&ret,2); // in effetti � solo 1...
  return ret;
  }

int KeyboardSetLed(BYTE n) {
  
  CNNEAbits.CNNEA7=0;
  WritePMP(SOUTH_BRIDGE,BIOS_KEYBOARD_LED,n & 0b111);
  Nop();Nop();Nop();Nop();__delay_us(2);
  while(!m_SACK)
    ClrWdt();
  __delay_us(SOUTHBRIDGE_WAIT);
  CNNEAbits.CNNEA7=1;
  }


#ifdef USA_232
void InitializeUSART(void) {

  U6MODE=0b0000000000001000;    // BRGH=1
  U6STA= 0b0000010000000000;    // TXEN
  unsigned long baudRateDivider = ((GetPeripheralClock()/(4*BAUDRATE))-1);
  U6BRG=baudRateDivider;
  U6MODEbits.ON=1;

	}



char BusyUART1(void) {
  
  return !U6STAbits.TRMT;
  }

void putsUART1(unsigned char *buffer) {

// transmit till NULL character is encountered 

  while(*buffer) {
    while(U6STAbits.UTXBF);  /* wait if the buffer is full */
    U6TXREG = *buffer++;   /* transfer data byte to TX reg */
    }
  }

unsigned int ReadUART1(void) {
  
  if(U6MODEbits.PDSEL == 3)
    return (U6RXREG);
  else
    return (U6RXREG & 0xFF);
  }

void WriteUART1(unsigned int data) {
  
  if(U6MODEbits.PDSEL == 3)
    U6TXREG = data;
  else
    U6TXREG = data & 0xFF;
  }
#endif

void Timer_Init(void) {
  
  T1CON=0;
  T1CONbits.TCS = 0;           // clock from peripheral clock
  T1CONbits.TCKPS = 0b11;      // 1:256 prescaler 
  PR1 = 39062;                 // 10Hz x clock
  
  IPC1bits.T1IP=2;            // set IPL 2, sub-priority 1??
  IPC1bits.T1IS=1;      // v. T8 Tick
  IEC0bits.T1IE=1;            // 
  
  T1CONbits.TON = 1;    // start timer (for clock)
  
  T4CON=0;
  T4CONbits.TCS = 0;            // clock from peripheral clock
  T4CONbits.TCKPS = 0b010;      // 1:4 prescaler 
  T4CONbits.T32 = 0;            // 16bit
  PR4 = 6250;                   // 4KHz x buzzer
  
  T4CONbits.TON = 1;    // start timer (for pwm)
  }
  
void PWM_Init(void) {

// v. init sopra  CFGCONbits.OCACLK=1;      // sceglie timer per PWM ossia Timer6 ;) [serve SYSLOCK cmq)
  
  OC1CON = 0x0006;      // TimerX ossia Timer6; PWM mode no fault; Timer 16bit, TimerX
  OC1R    = 6250/2;		 // su PIC32 � read-only!
  OC1RS   = 6250/2;      // 50%, relativo a PR2 del Timer6
  OC1CONbits.ON=0;    // on

  }


void __ISR(_PMP_VECTOR,IPL3SRS) PMP_ISR(void) {
  
  IFS4CLR = _IFS4_PMPIF_MASK;
  }

void __ISR(_TIMER_1_VECTOR,ipl2SRS) T1_ISR(void) {
  
  second_10++;
  if(second_10>=10) {
    second_10=0;
    now++;
    }

  IFS0CLR = _IFS0_T1IF_MASK;
  }


void __ISR ( _CHANGE_NOTICE_A_VECTOR, IPL3SRS ) CNAInt(void) {
  
  if(m_AIRQ_CN) {
    eventReceived=AUDIO_CARD;
//    m_AIRQ_CN=0;
    CNFACLR=_CNFA_CNFA3_MASK;
    }
  if(m_SIRQ_CN) {
    eventReceived=SOUTH_BRIDGE;
//    m_SIRQ_CN=0;
    CNFACLR=_CNFA_CNFA7_MASK;
    }
  if(m_EIRQ_CN) {
//    m_EIRQ_CN=0;
    CNFACLR=_CNFA_CNFA15_MASK;
    }
  
//  PORTA;    // va bene fatto dopo, o prima o ...?
//  IFS3bits.CNAIF=0;
  IFS3CLR = _IFS3_CNAIF_MASK;
  }

void __ISR ( _CHANGE_NOTICE_C_VECTOR, IPL3SRS ) CNCInt(void) {
  
  
// DIRQ	which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 

//  PORTC;
  CNFC=0;
  IFS3CLR = _IFS3_CNCIF_MASK;
  }

void __ISR ( _CHANGE_NOTICE_F_VECTOR, IPL3SRS ) CNFInt(void) {
  
// VIRQ
  if(m_VIRQ_CN) {
//    eventReceived=VIDEO_CARD;
  //EVENT_VIDEOFRAME
    videoFrameCnt++;
//    m_VIRQ_CN=0;
    CNFFCLR=_CNFF_CNFF1_MASK;
    }
  
#ifdef USA_WIFI
  if(m_WIRQ_CN) {
    extern tpfNmBspIsr gpfIsr;
    if(gpfIsr)
      gpfIsr();
//    m_WIRQ_CN=0;
    CNFFCLR=_CNFF_CNFF0_MASK;
    }

#endif

//  PORTF;
//  CNFF=0;
  IFS3CLR = _IFS3_CNFIF_MASK;
  }

void __ISR ( _CHANGE_NOTICE_G_VECTOR, IPL3SRS ) CNGInt(void) {
  BYTE which;
  
//DDRQ	which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 

//  PORTG;
  CNFG=0;
  IFS3CLR = _IFS3_CNGIF_MASK;
  }


#ifdef USA_USB_SLAVE_CDC
// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************
USB_DEVICE_CDC_EVENT_RESPONSE APP_USBDeviceCDCEventHandler(
    USB_DEVICE_CDC_INDEX index, USB_DEVICE_CDC_EVENT event,
    void *pData, uintptr_t userData) {
    APP_DATA *appDataObject;
    appDataObject = (APP_DATA *)userData;
    USB_CDC_CONTROL_LINE_STATE *controlLineStateData;
    USB_DEVICE_CDC_EVENT_DATA_READ_COMPLETE *eventDataRead; 

    switch(event) {
        case USB_DEVICE_CDC_EVENT_GET_LINE_CODING:
            /* This means the host wants to know the current line
             * coding. This is a control transfer request. Use the
             * USB_DEVICE_ControlSend() function to send the data to host.  */
            USB_DEVICE_ControlSend(appDataObject->deviceHandle,
                    &appDataObject->getLineCodingData, sizeof(USB_CDC_LINE_CODING));
            break;

        case USB_DEVICE_CDC_EVENT_SET_LINE_CODING:
            /* This means the host wants to set the line coding.
             * This is a control transfer request. Use the
             * USB_DEVICE_ControlReceive() function to receive the data from the host */
            USB_DEVICE_ControlReceive(appDataObject->deviceHandle,
                    &appDataObject->setLineCodingData, sizeof(USB_CDC_LINE_CODING));
            break;

        case USB_DEVICE_CDC_EVENT_SET_CONTROL_LINE_STATE:
            /* This means the host is setting the control line state.
             * Read the control line state. We will accept this request for now. */
            controlLineStateData = (USB_CDC_CONTROL_LINE_STATE *)pData;
            appDataObject->controlLineStateData.dtr = controlLineStateData->dtr;
            appDataObject->controlLineStateData.carrier = controlLineStateData->carrier;

            USB_DEVICE_ControlStatus(appDataObject->deviceHandle, USB_DEVICE_CONTROL_STATUS_OK);
            break;

        case USB_DEVICE_CDC_EVENT_SEND_BREAK:
            /* This means that the host is requesting that a break of the
             * specified duration be sent. Read the break duration */
            appDataObject->breakData = ((USB_DEVICE_CDC_EVENT_DATA_SEND_BREAK *)pData)->breakDuration;
            
            /* Complete the control transfer by sending a ZLP  */
            USB_DEVICE_ControlStatus(appDataObject->deviceHandle, USB_DEVICE_CONTROL_STATUS_OK);
            break;

        case USB_DEVICE_CDC_EVENT_READ_COMPLETE:
            // This means that the host has sent some data
            eventDataRead = (USB_DEVICE_CDC_EVENT_DATA_READ_COMPLETE *)pData;
            appDataObject->isReadComplete = true;
            appDataObject->numBytesRead = eventDataRead->length;
            if(RS232_Out_Data_Rdy == false) { // only check for new USB buffer if the old RS232 buffer is
                                          // empty.  This will cause additional USB packets to be NAK'd
              LastRS232Out=eventDataRead->length;
              if(LastRS232Out>0) {	
                memcpy(USB_In_Buffer,readBuffer,LastRS232Out); //until the buffer is free.
                RS232_Out_Data_Rdy = true;  // signal buffer full
                RS232cp = 0;  // Reset the current position
                }
            appData.isReadComplete=false;
            appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
            USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
              &readBuffer, APP_READ_BUFFER_SIZE);
              }
            break;

        case USB_DEVICE_CDC_EVENT_CONTROL_TRANSFER_DATA_RECEIVED:
            /* The data stage of the last control transfer is
             * complete. For now we accept all the data */
            USB_DEVICE_ControlStatus(appDataObject->deviceHandle, USB_DEVICE_CONTROL_STATUS_OK);
            break;

        case USB_DEVICE_CDC_EVENT_CONTROL_TRANSFER_DATA_SENT:
            /* This means the GET LINE CODING function data is valid. We dont
             * do much with this data in this demo. */
            break;

        case USB_DEVICE_CDC_EVENT_WRITE_COMPLETE:
            // This means that the data write got completed. We can schedule the next read.
            appDataObject->isWriteComplete = true;
            NextUSBOut=0;
            break;

        default:
            break;
    }

  return USB_DEVICE_CDC_EVENT_RESPONSE_NONE;
  }
/***********************************************
 * Application USB Device Layer Event Handler.
 ***********************************************/
void APP_USBDeviceEventHandler(USB_DEVICE_EVENT event, void *eventData, uintptr_t context) {
    USB_DEVICE_EVENT_DATA_CONFIGURED *configuredEventData;

    switch(event) {
        case USB_DEVICE_EVENT_SOF:
            /* This event is used for switch debounce. This flag is reset
             * by the switch process routine. */
            appData.sofEventHasOccurred = true;
            break;

        case USB_DEVICE_EVENT_RESET:
            /* Update LED to show reset state */
//            APP_USB_LED_1=1;
//            APP_USB_LED_2=1;    
//            APP_USB_LED_3=1;

            appData.isConfigured = false;
            break;

        case USB_DEVICE_EVENT_CONFIGURED:
            // Check the configuration. We only support configuration 1
            configuredEventData = (USB_DEVICE_EVENT_DATA_CONFIGURED*)eventData;
            if(configuredEventData->configurationValue == 1)             {
                // Update LED to show configured state 
//                APP_USB_LED_1=0;
//                APP_USB_LED_2=0;
//                APP_USB_LED_3=0;

                /* Register the CDC Device application event handler here.
                 * Note how the appData object pointer is passed as the user data */
                USB_DEVICE_CDC_EventHandlerSet(USB_DEVICE_CDC_INDEX_0, APP_USBDeviceCDCEventHandler, (uintptr_t)&appData);

                // Mark that the device is now configured 
                appData.isConfigured = true;

              }
            break;

        case USB_DEVICE_EVENT_POWER_DETECTED:
            // VBUS was detected. We can attach the device 
            USB_DEVICE_Attach(appData.deviceHandle);
            break;

        case USB_DEVICE_EVENT_POWER_REMOVED:
            // VBUS is not available any more. Detach the device. 
            USB_DEVICE_Detach(appData.deviceHandle);
            break;

        case USB_DEVICE_EVENT_SUSPENDED:
            // Switch LED to show suspended state 
//            APP_USB_LED_1=0;
//            APP_USB_LED_2=0;
//            APP_USB_LED_3=0;
            break;

        case USB_DEVICE_EVENT_RESUMED:
        case USB_DEVICE_EVENT_ERROR:
        default:
            break;
    }
  }
#endif

void __attribute__((noreturn)) App_Reset(void) {

  CNNEAbits.CNNEA3=0;
  WritePMP(AUDIO_CARD,BIOS_RESET,1);      // 
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;

	// anche video??
  SetCursorMode(0,0);   // finezza :)

  CNNEAbits.CNNEA3=0;
  WritePMP(SOUTH_BRIDGE,BIOS_RESET,1);      // 
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1;

	Reset();    // o SoftReset?
	}

void __attribute__((noreturn)) SoftReset(void) {
  
#ifndef USING_SIMULATOR
  SYS_INT_Disable();
#endif
  // perform a system unlock sequence, starting critical sequence
  SYSKEY = 0x00000000; //write invalid key to force lock
  SYSKEY = 0xAA996655; //write key1 to SYSKEY
  SYSKEY = 0x556699AA; //write key2 to SYSKEY
  // set SWRST bit to arm reset
  RSWRSTSET = 1;
  // read RSWRST register to trigger reset
  unsigned int dummy;
  dummy = RSWRST;
  // prevent any unwanted code execution until reset occurs
  while(1);
  }

void Sleep(void) {
  // https://www.microchip.com/forums/m1099882.aspx
  // https://www.microchip.com/forums/m991184.aspx
  
  // anche SYS_DEVCON_PowerModeEnter()
  
/*  //Slow down CPU clock
  asm volatile ( "di" );
  SYSKEY = 0x0;
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;
  // SYSCLK divided by 256
  OSCCONbits.PLLODIV = 7; //0.3125 MHz 
  // Wait for stable PLL clock
  while( !OSCCONbits. .SLOCK ); 
  // Sleep mode after WAIT instruction
  OSCCONSET = 0x10;
 
  // Force lock
  SYSKEY = 0x0; 
  asm volatile ( "ei" );
  */

   
  asm volatile("di");
  SYSKEY = 0x0; // Ensure OSCCON is locked
  SYSKEY = 0xAA996655; // Write Key1 to SYSKEY
  SYSKEY = 0x556699AA; // Write Key2 to SYSKEY
  OSCCONbits.SLPEN=1;

  SYSKEY = 0x0; // Ensure OSCCON is locked
        
  asm volatile("ei");
  asm volatile("wait"); 
  
  }


// v. minibasic.c

void SetTimeFromNow(DWORD now,PIC32_DATE *date,PIC32_TIME *time) {
  unsigned int i,y;
  unsigned long j;
  long d;
  
  d= now + ((signed long)timeZone)*3600;         // Correct for TZ/DST offset
  d= d / 86400L;                          // Integer number of days
  // Count the number of days per year taking in account leap years
  // to determine the year number and remaining days
  y=1970;   // unix
  while(d >= (j = isleap(y) ? 366 : 365) ) {
    y++;
    d -= j;
    }
  while(d < 0) {
    y--;
    d += isleap(y) ? 366 : 365;
    }
  i = isleap(y);
  // Count the days for each month in this year to determine the month
  for(date->mon=0; d >= days_month[i][date->mon]; ++date->mon) {
    d -= days_month[i][date->mon];
    }
  
  j= (now + ((signed long)timeZone)*3600) % 86400;     // Fraction of a day
	time->hour=j/3600;
  j %= 3600;                                 // Fraction of hour
  time->min=j/60;
  time->sec=j % 60;

  date->year=y;
  date->mon++;
  date->mday=d+1;
  }
DWORD SetNowFromTime(PIC32_DATE date,PIC32_TIME time) {
  uint16_t y;
  uint16_t m;
  uint16_t d;
  DWORD t;

//https://www.oryx-embedded.com/doc/date__time_8c_source.html
  //Year
  y = date.year;
  //Month of year
  m = date.mon;
  //Day of month
  d = date.mday;

  //January and February are counted as months 13 and 14 of the previous year
  if(m <= 2) {
    m += 12;
    y -= 1;
    }

  //Convert years to days
  t = (365 * y) + (y / 4) - (y / 100) + (y / 400);
  //Convert months to days
  t += (30 * m) + (3 * (m + 1) / 5) + d;
  //Unix time starts on January 1st, 1970
  t -= 719561;
  //Convert days to seconds
  t *= 86400;
  //Add hours, minutes and seconds
  t += (3600 * time.hour) + (60 * time.min) + time.sec;
  now=t;

  return now;
  }

DWORD timeGetTime(void) {
  return now;
#warning FINIRE timeGetTime!!
  }

void suona_USBin(void) {
  
  PR4 = 60000;           // 
  OC1R    = 60000/2;		 // su PIC32 � read-only!
  OC1RS   = 60000/2;      // 50%, relativo a PR2 del Timer6
  OC1CONbits.ON=1;    //
  __delay_ms(200);
  PR4 = 40000;           // 
  OC1R    = 40000/2;
  OC1RS   = 40000/2;
  __delay_ms(150);
  PR4 = 6250;                   // 4KHz x buzzer
  OC1R    = 6250/2;
  OC1RS   = 6250/2;
  OC1CONbits.ON=0;
  }

void suona_USBout(void) {
  
  PR4 = 40000;           // 
  OC1R    = 40000/2;		 // su PIC32 � read-only!
  OC1RS   = 40000/2;      // 50%, relativo a PR2 del Timer6
  OC1CONbits.ON=1;    //
  __delay_ms(200);
  PR4 = 60000;           // 
  OC1R    = 60000/2;
  OC1RS   = 60000/2;
  __delay_ms(150);
  PR4 = 6250;                   // 4KHz x buzzer
  OC1R    = 6250/2;
  OC1RS   = 6250/2;
  OC1CONbits.ON=0;
  }

void StdBeep(WORD ms) {
  
  PR4 = 6250;                   // 4KHz x buzzer
  OC1R    = 6250/2;
  OC1RS   = 6250/2;
  OC1CONbits.ON=1;    //
  __delay_ms(ms); 
  OC1CONbits.ON=0;
  }

void ErrorBeep(WORD ms) {
  
  PR4 = 30000;                   // 1KHz x buzzer
  OC1R    = 30000/2;		 // su PIC32 � read-only!
  OC1RS   = 30000/2;      // 50%, relativo a PR2 del Timer6
  OC1CONbits.ON=1;    //
  __delay_ms(ms); 
  PR4 = 6250;                   // 4KHz x buzzer
  OC1R    = 6250/2;
  OC1RS   = 6250/2;
  OC1CONbits.ON=0;
  }

/*******************************************************************************
  Exception Reason Data


  Remarks:
    These global static items are used instead of local variables in the
    _general_exception_handler function because the stack may not be available
    if an exception has occurred.
*/

// Code identifying the cause of the exception (CP0 Cause register).
static unsigned int _excep_code;

// Address of instruction that caused the exception.
static unsigned int _excep_addr;

// Pointer to the string describing the cause of the exception.
static char *_cause_str;

static enum {
	EXCEP_IRQ = 0,			// interrupt
	EXCEP_AdEL = 4,			// address error exception (load or ifetch)
	EXCEP_AdES,				// address error exception (store)
	EXCEP_IBE,				// bus error (ifetch)
	EXCEP_DBE,				// bus error (load/store)
	EXCEP_Sys,				// syscall
	EXCEP_Bp,				// breakpoint
	EXCEP_RI,				// reserved instruction
	EXCEP_CpU,				// coprocessor unusable
	EXCEP_Overflow,			// arithmetic overflow
	EXCEP_Trap,				// trap (possible divide by zero)
	EXCEP_IS1 = 16,			// implementation specific 1
	EXCEP_CEU,				// CorExtend Unuseable
	EXCEP_C2E				// coprocessor 2
  } _excep_code;

// Array identifying the cause (indexed by _exception_code).
static const char *cause[] = {
    "Interrupt",
    "Undefined",
    "Undefined",
    "Undefined",
    "Load/fetch address error",
    "Store address error",
    "Instruction bus error",
    "Data bus error",
    "Syscall",
    "Breakpoint",
    "Reserved instruction",
    "Coprocessor unusable",
    "Arithmetic overflow",
    "Trap",
    "Reserved",
    "Reserved",
    "Reserved",
    "Reserved",
    "Reserved"
  };



// *****************************************************************************
// *****************************************************************************
// Section: Exception Handling
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void _general_exception_handler ( void )

  Summary:
    Overrides the XC32 _weak_ _general_exception_handler.

  Description:
    This function overrides the XC32 default _weak_ _general_exception_handler.

  Remarks:
    Refer to the XC32 User's Guide for additional information.
 */
void _general_exception_handler(void) {
    /* Mask off Mask of the ExcCode Field from the Cause Register
    Refer to the MIPS Software User's manual */
  
    _excep_code = (_CP0_GET_CAUSE() & 0x0000007C) >> 2;
    _excep_addr = _CP0_GET_EPC();
    _cause_str  = (char *)cause[_excep_code];
//    SYS_DEBUG_PRINT(SYS_ERROR_FATAL, "\n\rGeneral Exception %s (cause=%d, addr=%x).\n\r",
//                    _cause_str, _excep_code, _excep_addr);

//    clearScreenLCD();			// 
//    setColors(WHITE,0);
//    setTextCursor(0,0);
//    gfx_print(_cause_str);
    printf("\n\r%s (cause=%d, addr=%x).\n\r",
                    _cause_str, _excep_code, _excep_addr);

    while(1)    {
//        SYS_DEBUG_BreakPoint();
        Nop();
        Nop();
        __delay_ms(2500);
//      mLED_1^=1;
        mExcep ^= 1;

    }
  }


