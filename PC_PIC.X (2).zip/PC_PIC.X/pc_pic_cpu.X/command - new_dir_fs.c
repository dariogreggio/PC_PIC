/* command[.com] interpreter for PC_PIC
 * DarioG/KatiaG 2021-2022 :)
 v. anche https://github.com/dhansel/ArduinoFDC
 * */

#include <xc.h>
#include <ctype.h>
#include <string.h>
#include "Pc_pic_cpu.h"
#include "harmony_app.h"

#include "at_winc1500.h"
//#include "tcpip stack/stacktsk.h"

#include "fat_sd/fsconfig.h"
#include "fat_sd/fsio.h"

#if defined(USA_USB_HOST_MSD)
#include "../harmony_pic32mz/usb_host_msd.h"
#include "../harmony_pic32mz/usb_host_scsi.h"
#endif

#include "fat_ide/idefat.h"

static const char _PC_PIC_COMMAND_C[]= {"PC_PIC COMMAND - 26/6/2022"};
#define VERNUMH_COMMAND 1
#define VERNUML_COMMAND 1


BYTE doEcho=0,errorLevel,doRedirect=0;
char prompt[16];
extern SIZE Screen,ScreenText;
extern struct KEYPRESS keypress;
extern BYTE SDcardOK,USBmemOK,HDOK,FDOK;
extern IDEVolume HDvolume;
extern volatile unsigned long now;
extern DWORD extRAMtot;

extern SOCKET TCPacceptedSocket;
extern SOCKET TelnetAcceptedSocket;

extern APP_DATA appData;
void *driverAllocated=NULL;

extern unsigned int __attribute__((section("_linkergenerated"))) _splim;
extern unsigned int __attribute__((section("_linkergenerated"))) _stack;

char commandLine[128],lastCommandLine[128];
int commandLineCnt=0;
signed char currDrive;
char currDirectory[16];
static BOOL isPaused=FALSE;

extern WORD keyboardBuffer[8];
extern BYTE rs232Buffer[8];

BYTE nEnvVariables=0;
VARIABLE *envVariables=NULL;   // riciclo quelle del minibasic :)
BYTE nEnvMacros=0;
VARIABLE *envMacros=NULL;   // idem

signed char stackLevel=0;

extern MINIBASIC minibasicInstance;

BOOL hitCtrlC(void);
BOOL isCtrlS(void);
int subDir(char drive,const char *,BYTE,BYTE,WORD *,WORD *,DWORD *);
int subTree(char drive,const char *,BYTE);
void printScreen(void);

#ifdef USA_WIFI
extern Ipv4Addr myIp;
extern uint8_t internetBuffer[256];
static void ping_cb(uint32_t u32IPAddr, uint32_t u32RTT, uint8_t u8ErrorCode);
#endif

char *skipSpaces(const char *s) {
  
  while(*s && isspace(*s))
    s++;
  return (char *)s;
  }

char setCurrentDrive(char drive) {
  char retVal=0;
  
  switch(drive) {
    case 'A':
      if(SDcardOK) {
        retVal='A';
        }
      break;
    case 'B':
      if(FDOK) {
        retVal='B';
        }
      break;
    case 'C':
      if(HDOK) {
        retVal='C';
        }
      break;
    case 'D':
      break;
    case 'E':
      if(USBmemOK) {
        retVal='E';
        }
      break;
    case 0:
      if(SDcardOK) {
        retVal='A';
        }
      else if(HDOK) {
        retVal='C';
        }
#if defined(USA_USB_HOST_MSD)
      else if(USBmemOK) {
        retVal='E';
        }
#endif
      else
        retVal=0;
      break;
    default:
      break;
    }
  return retVal;
  }

void subVolume(char drive,const char *name) {
  
  printf("Volume in drive %c:",toupper(drive));
  if(name) {
    printf(" is %s\r\n",name);
    }
  else {
    puts(" has no label");
    }
  }

void makePrompt(void) {
  
  if(currDrive>0) {
    prompt[0]=currDrive; prompt[1]=':'; 
    prompt[2]='>'; prompt[3]=0;
    }
  else {
    prompt[0]='>'; prompt[1]=0;
    }
  }


VARIABLE *findEnvVariable(const char *id) {
  int i;

  for(i=0; i<nEnvVariables; i++) {
		if(!stricmp(envVariables[i].id, id))
			return &envVariables[i];
    }
  return NULL;
	}
void deleteEnvVariables(void) {
  int i;

  for(i=0; i<nEnvVariables; i++) {
		if(envVariables[i].d.sval)
			free(envVariables[i].d.sval);
    }
  if(envVariables)
    free(envVariables);
  envVariables=NULL;
  nEnvVariables=0;
	}

VARIABLE *findEnvMacro(const char *id) {
  int i;

  for(i=0; i<nEnvMacros; i++) {
		if(!stricmp(envMacros[i].id, id))
			return &envMacros[i];
    }
  return NULL;
	}
void deleteEnvMacros(void) {
  int i;

  for(i=0; i<nEnvMacros; i++) {
		if(envMacros[i].d.sval)
			free(envMacros[i].d.sval);
    }
  if(envMacros)
    free(envMacros);
  envMacros=NULL;
  nEnvMacros=0;
	}

void CreateStdVar(void) {
  
  execCmdROM("SET PROCESSOR_ARCHITECTURE=PIC32",NULL);
  execCmdROM("PROMPT $N:$G",NULL);
#if defined(USA_WIFI) || defined(USA_ETHERNET)
  execCmd2("SET COMPUTERNAME=",BiosArea.NetBIOSName,NULL);
#endif
  }
  
void CreateStdVar2(char drive) {
  char buf[8];
  
  sprintf(buf,"%c:",toupper(drive));
  execCmd2("SET HOMEDRIVE=",buf,NULL);
  execCmd2("PATH ",buf,NULL);
  }
  
BOOL hitCtrlC(void) {

	handle_events();
  // ?? __delay_ms(50)
	return (((tolower(keypress.key)=='c' || keypress.key==0x9f)) && 
          (keypress.modifier & 0b00010001)) ? TRUE : FALSE;  // in DOS con shift lo prende ma con alt no..
  //qui lo lascio passare..
	}

BOOL isCtrlS(void) {

	handle_events();
  // ?? __delay_ms(50)
	if(((tolower(keypress.key)=='s') || (keypress.key==0x9f)) && 
          (keypress.modifier & 0b00010001)) {
    isPaused=!isPaused;
    // accendere scrollock led?     KeyboardSetLed(0b00000100);
    // in DOS pare che qualunque tasto sblocchi.. v. anche more
    KBClear();
    }
  return isPaused;
	}

int execCmdROM(const char *cmd,void *stream) {    // perch� in execCmd scriviamo nella stringa d'origine e fa eccezione PORCODIO MORTEALLAREGINA
  char buf[128];
  
  strncpy(buf,cmd,sizeof(buf)-1);
  buf[sizeof(buf)-1]=0;
  return execCmd(buf,stream);
  }
int execCmd2(const char *cmd,const char *parm,void *stream) {
  char buf[128];
  
  strncpy(buf,cmd,sizeof(buf)-1);
  strncat(buf,parm,127-strlen(buf)-strlen(parm));
  buf[sizeof(buf)-1]=0;
  return execCmd(buf,stream);
  }
int execCmd(const char *cmd,void *stream) {
  int i;
  char *cmdPointer,*parmsPointer;
  
  doRedirect=0;     // fare, cercare > ...
  
  cmdPointer=(char *)cmd;   // per warning...
  
//#warning bisognerebbe skippare spazi all inizio!
  while(*cmdPointer && *cmdPointer == ' ')
    cmdPointer++;
  parmsPointer=cmdPointer;
  
  if(doEcho) {
    if(cmdPointer[0] != '@')
      puts(cmdPointer);
    }
  if(cmdPointer[0] == '@')
    cmdPointer++;

  while(*parmsPointer && *parmsPointer != ' ')
    parmsPointer++;
  if(parmsPointer && *parmsPointer) {
    *parmsPointer++=0;
    parmsPointer=skipSpaces(parmsPointer);
    }
  
  if(cmdPointer[0]==':') {    // label
    }
  else if(cmdPointer[1]==':') {
    switch(toupper(cmdPointer[0])) {
      case 'A':
      case 'B':
      case 'C':
      case 'D':
      case 'E':
        if(setCurrentDrive(toupper(cmdPointer[0]))) {
          currDrive=toupper(cmdPointer[0]);
          makePrompt();
          }
        else {
errore_drive:          
          puts("The system cannot find the drive specified.");
          errorLevel=1;
          }
        break;
      default:
        if(isalpha(cmdPointer[0]))
          goto errore_drive;
        else
          goto unrecognized_command;
        break;
      }
    }
  else if(!stricmp(cmdPointer,"BASIC")) {
    if(*parmsPointer) {
      basic(&minibasicInstance,parmsPointer,1);   // bah tanto per...
      // aggiungere .BAS se non c'�?? o no...
      // ma OCCHIO a eccezione se scrivi in ROM!!        if(!strchr(parmsPointer,'.'))
//                strcat(parmsPointer,".BAS");
//          strncpy(buf,cmd,15);
//    strcat(buf,".BAS");

      }
    else
      minibasic(&minibasicInstance,parmsPointer); // ...in pratica sarebbe uguale
    minibasicInstance.irqHandler.handler=0;
    // ripristino TUTTI i colori cmq :)
    minibasicInstance.Color=0x00ff00; minibasicInstance.ColorBK=0x000000;
    minibasicInstance.ColorPalette=BRIGHTGREEN; minibasicInstance.ColorPaletteBK=BLACK;
    errorLevel=minibasicInstance.errorFlag;
    minibasicInstance.errorFlag=0;
    SetColors(WHITE,BLACK);
    }
  else if(!stricmp(cmdPointer,"WIN")) {

    }
  else if(!stricmp(cmdPointer,"SET")) {
    VARIABLE *vars;
    char *parmsPointer2;
    BOOL foundAssign=FALSE;
    
    if(parmsPointer && *parmsPointer) {
      parmsPointer2=parmsPointer;
      while(*parmsPointer2 && *parmsPointer2 != '=')
        parmsPointer2++;
      if(parmsPointer2 && *parmsPointer2) {
        foundAssign=1;
        *parmsPointer2=0;
        }
      if(vars=findEnvVariable(parmsPointer)) {
        if(foundAssign) {
          parmsPointer2=skipSpaces(parmsPointer2+1);
          if(vars->d.sval)
            free(vars->d.sval);
          if(parmsPointer2 && *parmsPointer2) {
            vars->d.sval=strdup(parmsPointer2);
            }
          else {

            *vars->id=0;
            // MANCA delete variabile... fare ev...

            }
          }
        else {
          printf("%s=%s\r\n",vars->id,vars->d.sval);
          }
        }
      else {
        if(foundAssign) {
          parmsPointer2=skipSpaces(parmsPointer2+1);
          vars = (VARIABLE *)realloc(envVariables, (nEnvVariables + 1) * sizeof(VARIABLE));
          if(vars) {
            envVariables = vars;
            strncpy(envVariables[nEnvVariables].id, parmsPointer, IDLENGTH-1 /*2*/);
            envVariables[nEnvVariables].id[IDLENGTH-1]=0;
            strupr(envVariables[nEnvVariables].id);
            envVariables[nEnvVariables].d.sval = strdup(parmsPointer2);
            envVariables[nEnvVariables].type = STRID;   // fisso ma ok
            nEnvVariables++;
            }
          else {
        //		errore di memoria...
            }
          }
        else
          printf("Environment variable %s not defined\r\n",parmsPointer);
        }
      }
    else {
      for(i=0; i<nEnvVariables; i++) {
        if(*envVariables[i].id)   // fare delete vero, v.sopra
          printf("%s=%s\r\n",envVariables[i].id,envVariables[i].d.sval);
        }
      }
    }
  else if(!stricmp(cmdPointer,"PATH")) {
    char buf[128];
    
    sprintf(buf,"SET PATH=%s",parmsPointer);    // direi che � la cosa pi� ovvia :)
    execCmd(buf,NULL);
    }
  else if(!stricmp(cmdPointer,"CHCP")) {
    // creare tabella mappatura tasti...
    puts("Unimplemented.");
    }
  else if(!stricmp(cmdPointer,"DIR")) {
    int i;
    WORD totfiles,totdirs;
    DWORD totsize;
    char *filter=NULL,mydrive;

    totfiles=0; totdirs=0; totsize=0;
    
    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      filter=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      filter=parmsPointer;
      }
    if(!filter || !*filter)
      filter="*.*";

    switch(mydrive) {
      case 'A':
      {
      SearchRec rec;
      FS_DISK_PROPERTIES disk_properties;
      i=FindFirst(filter, ATTR_VOLUME, &rec);
      subVolume(mydrive,!i ? rec.filename : NULL);    // finire :)

      // if /s usare recurse!
      if(subDir(mydrive,filter,0,0,&totfiles,&totdirs,&totsize)) {

        // stampare...totdirs e totsize
        disk_properties.new_request=1;
        do {
          FSGetDiskProperties(&disk_properties);
          ClrWdt();
          } while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
        if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS) {
          printf("%u file%c %lu KBytes free\r\n",totfiles,totfiles==1 ? ' ' : 's',
                  disk_properties.results.free_clusters*disk_properties.results.sectors_per_cluster*disk_properties.results.sector_size/1024); 
          }
        }
      else {
// non va..        if(FSerror() == CE_NOT_PRESENT || FSerror() == CE_NOT_FORMATTED || FSerror() == CE_BAD_PARTITION) {  // boh... 
        if(FSerror() != CE_FILE_NOT_FOUND) {
no_disc:
          puts("Disk not present");
          }
        else {
no_files:
          puts("File not found");
          }
        errorLevel=1;
        }

      }

        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
      {
        IDEFile root;
        dir_t* p;
        char buf[32];
        uint32_t sn;

        if(!IDEFile_openRoot(&root,&HDvolume)) {
          totfiles=0; totdirs=0; totsize=0;
          
          IDEVolume_fatType(&HDvolume);   // controllare...

// FINIRE con subdir!!
//      if(subDir(mydrive,filter,0, 0/1   &totfiles,&totdirs,&totsize)) {
          
          IDEFile_rewind(&root);
          while((p = IDEFile_readDirCache(&root))) {
            
            if(DIR_IS_VOLUME(p))
              subVolume(mydrive,p->name);    
            printf("Directory of %s\r\n","C:\\");
            
            // done if past last used entry
            if(p->name[0] == DIR_NAME_FREE) 
              break;

            // skip deleted entry and entries for. and  ..
            if(p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') 
              continue;

            // print file name with possible blank fill
            printf("%12s",p->name);

            if(!DIR_IS_SUBDIR(p)) {
              printf("%9u",p->fileSize);
              totsize+=p->fileSize;
              printf(" %02u/%02u/%04u %02u:%02u:%02u\r\n",
                FAT_DAY(p->lastWriteDate),
                FAT_MONTH(p->lastWriteDate),
                FAT_YEAR(p->lastWriteDate),
                FAT_HOUR(p->lastWriteTime),
                FAT_MINUTE(p->lastWriteTime),
                FAT_SECOND(p->lastWriteTime));
              }
            else {
              printf("%9s\r\n","DIR");
              totdirs++;
              }

            // list subdirectory content ifrequested
/*            if((flags & LS_R) && DIR_IS_SUBDIR(p)) {
              uint16_t index = curPosition()/32 - 1;
              IDEFile s;
              if(s.open(this, index, O_READ)) s.ls(flags, indent + 2);
              seekSet(32 * (index + 1));
              }*/

            totfiles++;
						if(hitCtrlC())
							break;
  					while(isCtrlS());
		        }
// e IDEFile_close( ??  #programmatoridelcazzo
          }
      }
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        uint32_t totalSectors,freeSectors;
// unire poi...      i=USBFindFirst( filter, ATTR_MASK ^ ATTR_VOLUME, &rec);
        char buf[32];
        uint32_t sn;
        i=SYS_FS_DriveLabelGet(NULL, buf, &sn);
        subVolume(mydrive,i==SYS_FS_RES_SUCCESS ? buf : NULL);
/*          if(SYS_FS_DirSearch(myFileHandle,"*.*",SYS_FS_ATTR_VOL,&stat) == SYS_FS_RES_SUCCESS) {
            printf("Volume in drive %s is %s\r\n","E:\\",stat.fname);
            SYS_FS_DirClose(myFileHandle);
            }
  // o anche SYS_FS_RESULT SYS_FS_DriveLabelGet(const char* drive, char *buff, uint32_t *sn) {*/
          
                // if /s usare recurse!

        if(subDir(mydrive,filter,0,0,&totfiles,&totdirs,&totsize)) {
          if(SYS_FS_DriveSectorGet(NULL,&totalSectors,&freeSectors)==SYS_FS_RES_SUCCESS)
            printf("%u file%c %lu KBytes free\r\n",totfiles,totfiles==1 ? ' ' : 's',
                  freeSectors* MEDIA_SECTOR_SIZE /* boh dov'�??*//1024); 
          }
        else {
          goto no_files;
          }
      }
        break;
#endif
      }
    }
#ifdef ALLOW_DIRS
  else if(!stricmp(cmdPointer,"TREE")) {
    char *parms,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      parms=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      parms=parmsPointer;
      }
    puts("Folder PATH listing");
    switch(mydrive) {
      case 'A':
      {
        SearchRec rec;
        int i;
        DWORD sn;
        i=FindFirst("*.*", ATTR_VOLUME, &rec);
        subVolume(mydrive,!i ? rec.filename : NULL);
        printf("Volume Serial Number is %04X:%04X\r\n",0,0);    // finire :)
        subTree(mydrive,parms,0);
      }
        break;
      case 'B':
        subTree(mydrive,parms,0);
        break;
      case 'C':
        subTree(mydrive,parms,0);
        break;
      case 'D':
        subTree(mydrive,parms,0);
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        char buf[32];
        uint32_t sn;
        i=SYS_FS_DriveLabelGet(NULL, buf, &sn);
        subVolume(mydrive,i== SYS_FS_RES_SUCCESS ? buf : NULL);
        printf("Volume Serial Number is %04X:%04X\r\n",HIWORD(sn),LOWORD(sn));
#warning NON USA curdir... bisognerebbe passarla se non c � path
        subTree(mydrive,parms,0);
      }
        break;
#endif
      }

    }
#endif
  else if(!stricmp(cmdPointer,"FORMAT")) {
    char *label=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      label=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      label=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
        i=FSformat(1,rand(),"PC_PIC");
        if(i)
          errorLevel=1;
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
// unire...      i=USBFSformat(1,rand(),"PC_PIC");
        if(SYS_FS_DriveFormat(label, SYS_FS_FORMAT_SFD /*boh s�*/, 0) != SYS_FS_RES_SUCCESS)
          errorLevel=1;
      }
        break;
#endif
      }
    }
  else if(!stricmp(cmdPointer,"CHKDSK")) {
    char *parms=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      parms=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      parms=parmsPointer;
      }
    switch(mydrive) {
      case 'A':
      {
        FS_DISK_PROPERTIES disk_properties;
//  BYTE DISKmount(DISK *dsk);
//        BYTE LoadMBR(DISK *dsk)

        disk_properties.new_request=1;
        do {
          FSGetDiskProperties(&disk_properties);
          ClrWdt();
          } while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
        if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS) {
          }
      }
        break;
      case 'B':
        break;
      case 'C':
        break;
      case 'D':
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
      }
        break;
#endif
      }
    printf("disc %c seems to be ok :)",mydrive);    // fare!!
    }
  else if(!stricmp(cmdPointer,"DISKPART")) {
    char *parms=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      parms=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      parms=parmsPointer;
      }
    switch(mydrive) {
      case 'A':
      {
//        FSCreateMBR(unsigned long firstSector, unsigned long numSectors);
//    FSLoadMBR
      }
        break;
      case 'B':
        break;
      case 'C':
        break;
      case 'D':
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        SYS_FS_RESULT SYS_FS_DrivePartition    (
          const char *path, const uint32_t partition[],
          void *work
          );
      }
        break;
#endif
      }
    puts("Unimplemented.");
    }
  else if(!stricmp(cmdPointer,"LABEL")) {
    char *label=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      label=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      label=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
        SearchRec rec;
        int i;
        DWORD sn;
        i=FindFirst("*.*", ATTR_VOLUME, &rec);
        subVolume(mydrive,!i ? rec.filename : NULL);
        printf("Volume Serial Number is %04X:%04X\r\n",0,0);    // finire :)
      // CONSENTIRE cambiamento!
//        printf("Volume label (32 characters, ENTER for none)? ");
//        printf("Delete current volume label (Y/N)? ");
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        char buf[32];
        uint32_t sn;
//unire        i=USBFindFirst(parmsPointer, ATTR_VOLUME, &rec);
        i=SYS_FS_DriveLabelGet(NULL, buf, &sn);
        subVolume(mydrive,i == SYS_FS_RES_SUCCESS ? buf : NULL);
        printf("Volume Serial Number is %04X:%04X\r\n",HIWORD(sn),LOWORD(sn));
//        errorLevel=1;
      }
        break;
#endif
      }

    }
  else if(!stricmp(cmdPointer,"VOL")) {
    char mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      }
    else {
      mydrive=currDrive;
      }

    switch(mydrive) {
      case 'A':
      {
        SearchRec rec;
        int i;
        i=FindFirst("*.*", ATTR_VOLUME, &rec);
        subVolume(mydrive,!i ? rec.filename : NULL);
        printf("Volume Serial Number is %04X:%04X\r\n",0,0);    // finire :)
      // CONSENTIRE cambiamento!
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        char buf[32];
        uint32_t sn;
//unire        i=USBFindFirst(parmsPointer, ATTR_VOLUME, &rec);
        i=SYS_FS_DriveLabelGet(NULL, buf, &sn);
        subVolume(mydrive,i==SYS_FS_RES_SUCCESS ? buf : NULL);
        printf("Volume Serial Number is %04X:%04X\r\n",HIWORD(sn),LOWORD(sn));
//        errorLevel=1;
      }
        break;
#endif
      }

    }
  else if(!stricmp(cmdPointer,"COPY")) {
    char *filename1=NULL,*filename2=NULL,mydrive1,mydrive2;
    
    SetClockVarsNow();

    // GESTIRE CON: !!
    if(strnicmp(parmsPointer,"CON:",4)) {
      mydrive1=127;
      filename1=parmsPointer;
      }
    else if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive1=toupper(parmsPointer[0]);
      filename1=parmsPointer+2;
      }
    else {
      mydrive1=currDrive;
      filename1=parmsPointer;
      }
    while(isalnum(*parmsPointer) || *parmsPointer=='_')
      parmsPointer++;
    parmsPointer=skipSpaces(parmsPointer);
    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive2=toupper(parmsPointer[0]);
      filename2=parmsPointer+2;
      }
    else {
      mydrive2=currDrive;
      filename2=parmsPointer;
      }

    switch(mydrive1) {      // ovviamente gestire MEGLIO tutte le combinazioni!
      case 'A':
        switch(mydrive2) {
          case 'A':
          {
          FSFILE *f1,*f2;
          BYTE ch;

          if((f1 = FSfopen(filename1, "r"))) { 
            if((f2 = FSfopen(filename2, "w"))) { 
              while(FSfread(&ch,1,1,f1)>0) {
                if(!FSfwrite(&ch,1,1,f2)) {

                  errorLevel=1;
                  break;

                  }
                i++;
                }
              FSfclose(f2);
              }
            FSfclose(f1);

            }
          }
          break;
#if defined(USA_USB_HOST_MSD)
          case 'E':
          {
          FSFILE *f1;
          SYS_FS_HANDLE f2;
          BYTE ch;

          if((f1 = FSfopen(filename1, "r"))) { 
            if((f2=SYS_FS_FileOpen(filename2,SYS_FS_FILE_OPEN_WRITE)) != SYS_FS_HANDLE_INVALID) { 
              while(FSfread(&ch,1,1,f1)>0) {
                if(!SYS_FS_FileWrite(f2,&ch,1)) {

                  errorLevel=1;
                  break;

                  }
                i++;
                }
              SYS_FS_FileClose(f2);
              }
            FSfclose(f1);

            }
          }
            break;
#endif
        }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
        switch(mydrive2) {
          case 'A':
          {
          SYS_FS_HANDLE f1;
          FSFILE *f2;
          BYTE ch;

          if((f1=SYS_FS_FileOpen(filename1,SYS_FS_FILE_OPEN_READ)) != SYS_FS_HANDLE_INVALID) { 
            if((f2 = FSfopen(filename2, "w"))) { 
              while(SYS_FS_FileRead(f1,&ch,1)>0) {
                if(!FSfwrite(&ch,1,1,f2)) {

                  errorLevel=1;
                  break;

                  }
                i++;
                }
              FSfclose(f2);
              }
            SYS_FS_FileClose(f1);

            }
          }
          break;
          case 'E':
          {
            SYS_FS_HANDLE f1,f2;
            BYTE ch;

            if((f1=SYS_FS_FileOpen(filename1,SYS_FS_FILE_OPEN_READ)) != SYS_FS_HANDLE_INVALID) { 
              if((f2=SYS_FS_FileOpen(filename2,SYS_FS_FILE_OPEN_WRITE)) != SYS_FS_HANDLE_INVALID) { 
                while(SYS_FS_FileRead(f1,&ch,1)>0) {
                  if(!SYS_FS_FileWrite(f2,&ch,1)) {

                    errorLevel=1;
                    break;

                    }
                  i++;
                  }
                SYS_FS_FileClose(f2);
                }
              SYS_FS_FileClose(f1);

              }
          }
          break;
          }
        break;
#endif
      case 127:   // COPY CON:
        switch(mydrive2) {
          case 'A':
          {
          FSFILE *f2;
          BYTE ch;

          if((f2 = FSfopen(filename2, "w"))) {
            for(;;) {
              KBClear();
              do {
                ch=getchar();   // inputKey ..
                } while(!ch /*keypress.used*/);
              if(ch != 0x1A) {
                if(!FSfwrite(&ch,1,1,f2)) {

                  errorLevel=1;
                  break;

                  }
                i++;
                }
              else {
                FSfclose(f2);
                break;
                }
              }
            }
          }
          break;
#if defined(USA_USB_HOST_MSD)
          case 'E':
          {
          SYS_FS_HANDLE f2;
          BYTE ch;

          if((f2=SYS_FS_FileOpen(filename2,SYS_FS_FILE_OPEN_WRITE)) != SYS_FS_HANDLE_INVALID) { 
            for(;;) {
              KBClear();
              do {
                ch=getchar();
                } while(!ch /*keypress.used*/);
              if(ch != 0x1A) {
                if(!SYS_FS_FileWrite(f2,&ch,1)) {

                  errorLevel=1;
                  break;

                  }
                i++;
                }
              else {
                SYS_FS_FileClose(f2);
                break;
                }
              }
            }
          }
            break;
#endif
        }
        break;
      }
    }
  else if(!stricmp(cmdPointer,"MOVE")) {
    if(SDcardOK) {
#if defined(USA_USB_HOST_MSD)
      if(parmsPointer[1] == ':' && parmsPointer[0] == 'E') {
//        i=USBFindFirst(parmsPointer, ATTR_VOLUME, &rec);
//        printf("Directory of %s","E:\\");    // finire :)
//        if(SYS_FS_FileDirectoryRenameMove(filename1,filename2) != SYS_FS_RES_SUCCESS)
        }
#endif
      }
    else
      goto no_disc;
    }
  else if(!stricmp(cmdPointer,"DEL") || !stricmp(cmdPointer,"ERASE")) {
    char *filename=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      filename=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      filename=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
        if(FSremove(filename))
          errorLevel=1;
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        if(SYS_FS_FileDirectoryRemove(filename) != SYS_FS_RES_SUCCESS)
          errorLevel=1;
      }
        break;
#endif
      }
    }
  else if(!stricmp(cmdPointer,"REN") || !stricmp(cmdPointer,"RENAME")) {
    char *filename1=NULL,*filename2=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      filename1=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      filename1=parmsPointer;
      }
    while(isalnum(*parmsPointer) || *parmsPointer=='_')
      parmsPointer++;
    parmsPointer=skipSpaces(parmsPointer);
    if(parmsPointer[0] && parmsPointer[1] == ':') {
      // dare errore!!
      }
    else {
      filename2=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
      FSFILE *f;

      if((f = FSfopen(filename1, "r"))) { 
        if(FSrename(filename2,f))
          errorLevel=1;//error
        FSfclose(f);
        }
        ;
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        if(SYS_FS_FileDirectoryRenameMove(filename1,filename2) != SYS_FS_RES_SUCCESS)
          errorLevel=1;
      }
        break;
#endif
      }
    }
  else if(!stricmp(cmdPointer,"FC") || !stricmp(cmdPointer,"COMP")) {   // in effetti son diversi ma ok
    char *filename1=NULL,*filename2=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      filename1=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      filename1=parmsPointer;
      }
    puts("Unimplemented.");
    }
  else if(!stricmp(cmdPointer,"FIND")) {
    char *filename1=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      filename1=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      filename1=parmsPointer;
      }
    puts("Unimplemented.");
    }
  else if(!stricmp(cmdPointer,"SORT")) {
    char *filename1=NULL,mydrive;

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      filename1=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      filename1=parmsPointer;
      }
    puts("Unimplemented.");
    }
  
#ifdef ALLOW_DIRS
  else if(!stricmp(cmdPointer,"MD") || !stricmp(cmdPointer,"MKDIR")) {
    char *path,mydrive;
    
    SetClockVarsNow();

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      path=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      path=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
        if(FSmkdir(path)) {
bad_path2:
          puts("Can't create directory.");
          errorLevel=1;
          }
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        if(SYS_FS_DirectoryMake(path) != SYS_FS_RES_SUCCESS)
          goto bad_path2;
        
      }
        break;
#endif
      }
    }
  else if(!stricmp(cmdPointer,"CD") || !stricmp(cmdPointer,"CHDIR")) {
    char *path,mydrive;
    
    SetClockVarsNow();

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      path=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      path=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
        if(*path) {
          if(FSchdir(path))
            goto bad_path;
          }
        else
          puts(FSgetcwd(NULL,0));
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        char buf[64];   // OCCHIO QUA arriva "tutto" incluso mnt/ ecc... e la funz fallisce
        
        if(*path) {
          if(SYS_FS_DirectoryChange(path) != SYS_FS_RES_SUCCESS)
            goto bad_path;
          }
        else {
          if(SYS_FS_CurrentWorkingDirectoryGet(buf,63) == SYS_FS_RES_SUCCESS)
            puts(buf);
          }
        
      }
        break;
#endif
      }
    }
  else if(!stricmp(cmdPointer,"RD") || !stricmp(cmdPointer,"RMDIR")) {
    char *path,mydrive;
    
    SetClockVarsNow();

    if(parmsPointer[0] && parmsPointer[1] == ':') {
      mydrive=toupper(parmsPointer[0]);
      path=parmsPointer+2;
      }
    else {
      mydrive=currDrive;
      path=parmsPointer;
      }

    switch(mydrive) {
      case 'A':
      {
        if(FSrmdir(path,0)) {
bad_path:
          puts("The system cannot find the file specified.");
          errorLevel=1;
          }
      }
        break;
      case 'B':
        goto no_disc;
        break;
      case 'C':
        goto no_disc;
        break;
      case 'D':
        goto no_disc;
        break;
#if defined(USA_USB_HOST_MSD)
      case 'E':
      {
        if(SYS_FS_FileDirectoryRemove(path) != SYS_FS_RES_SUCCESS)
          goto bad_path;
        
      }
        break;
#endif
      }
    }
#endif

  else if(!stricmp(cmdPointer,"CLS")) {
    Cls();
    }
  else if(!stricmp(cmdPointer,"COLOR")) {
    if(*parmsPointer)
      SetColors(textColors[myhextob(*(parmsPointer+1))],textColors[myhextob(*(parmsPointer+0))]); // DOVREBBE CAMBIARE TUTTA LA SCHERMATA!
    else
      SetColors(WHITE,BLACK);
//Example: "COLOR fc" produces light red on bright white
    if(*(parmsPointer+0) == *(parmsPointer+1))
      errorLevel=-1;    // cos� dice windows :)
    }
  else if(!stricmp(cmdPointer,"MODE")) {
    switch(*parmsPointer) {
      case '0':
        SetVideoMode(MODE_VGA,320,240,8);      //
        break;
      case '1':
        SetVideoMode(MODE_VGA,640,480,8);      //
        break;
      case '2':
        SetVideoMode(MODE_COMPOSITE,320,240,8);      //
        break;
      case '3':
        SetVideoMode(MODE_COMPOSITE,640,480,8);      //
        break;
      case '4':
        SetVideoMode(MODE_LCD,160,120,16);      //*/
        break;
      case '5':
        SetVideoMode(MODE_LCD_DMA,160,120,16);      //*/
        break;
      default:
        puts("unsupported mode");
        break;
      }
    }
  else if(!stricmp(cmdPointer,"ECHO")) {
    if(!stricmp(parmsPointer,"OFF"))
      doEcho=0;
    else if(!stricmp(parmsPointer,"ON"))
      doEcho=1;
    else if(!stricmp(parmsPointer,"ERRORLEVEL")) {
      printf("%u\r\n",errorLevel); errorLevel=0;
      }
    else if(*parmsPointer == '%') {
      VARIABLE *vars=NULL;
      char *parmsPointer2=++parmsPointer;
      while(*parmsPointer2 && *parmsPointer2 != '%')
        parmsPointer2++;
      if(parmsPointer2 && *parmsPointer2) {   // se non esiste la var o i "%" non combaciano, stampo literal
        *parmsPointer2=0;
        if(vars=findEnvVariable(parmsPointer))
          printf("%s\r\n",vars->d.sval);
        else
          goto echo_literal2;
        }
      else {
echo_literal2:
        parmsPointer--;
        goto echo_literal;
        }
      }
    else if(*parmsPointer) {
echo_literal:
      printf("%s\r\n",parmsPointer);
      }
    else
      printf("Echo is %s\r\n",doEcho ? "ON" : "OFF");
    }
  else if(!stricmp(cmdPointer,"BEEP")) {    // bah mi sembra bellino :) (in CMD DOS/WIN non c'� ma funzia ECHO CTRL-G)
    StdBeep(250);
    }
  else if(!stricmp(cmdPointer,"EDLIN")) {
    char *filename=NULL,mydrive;
    
    if(parmsPointer && *parmsPointer) {
      if(parmsPointer[0] && parmsPointer[1] == ':') {
        mydrive=toupper(parmsPointer[0]);
        filename=parmsPointer+2;
        }
      else {
        mydrive=currDrive;
        filename=parmsPointer;
        }
      switch(mydrive) {
        case 'A':
        {
        FSFILE *f;

        if((f = FSfopen(filename, "r"))) { 
          
          FSfclose(f);
          }
          ;
        }
          break;
        case 'B':
          break;
        case 'C':
          break;
        case 'D':
          break;
#if defined(USA_USB_HOST_MSD)
        case 'E':
        {
        }
          break;
#endif
        }
      
      //    i=inputKey();

      }
    else {
      puts("File name must be specified");
      errorLevel=1;
      }
    }
  else if(!stricmp(cmdPointer,"REM")) {
    }
  else if(!stricmp(cmdPointer,"PAUSE")) {
    puts("Press any key to continue . . .");
    i=inputKey();
    if(tolower(LOBYTE(i))=='c' && HIBYTE(i)==0b00000001)    // bah, mia idea..
      errorLevel=1;
    else
      errorLevel=0;
    }
  else if(!stricmp(cmdPointer,"CHOICE")) {
    char ch;
    
    print("[Y,N]?");   // finire! https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/choice
    do {
      i=inputKey();
      ch=tolower(LOBYTE(i));
      if(ch=='c' && HIBYTE(i)==0b00000001)
        break;
      if(ch != 'n' && ch != 'y') {
        ErrorBeep(200);
        }
      } while(ch != 'n' && ch != 'y');
    switch(ch) {
      case 'y':
        putchar('Y');
        errorLevel=1;
        break;
      case 'n':
        putchar('N');
        errorLevel=2;
        break;
      default:
        errorLevel=0;   // dice anche 255 se error ma boh
        break;
      }
    putchar('\n');    // serve in questi casi xch� il CR � stato mangiato
    }
  else if(!stricmp(cmdPointer,"BREAK")) {

    }
  else if(!stricmp(cmdPointer,"GOTO")) {
    if(stream) {
      char buf[128];
      FSrewind(stream);
      do {
        FSgets(buf,127,stream);   // finire!
        if(*buf) {
          if(!stricmp(buf,parmsPointer))
            break;
          }
        } while(*buf);
      }
    }
  else if(!stricmp(cmdPointer,"IF")) {
    }
  else if(!stricmp(cmdPointer,"FOR")) {
    }
  else if(!stricmp(cmdPointer,"CALL")) {
    
    execCmd(parmsPointer,stream);   // parametri??
    }
  else if(!stricmp(cmdPointer,"EXIT")) {
    if(stackLevel>0) {
      stackLevel--;
      deleteEnvVariables();
      CreateStdVar();   // andrebbero recuperate quelle del livello sopra...
      CreateStdVar2(currDrive);
      deleteEnvMacros();
      }
    }
  else if(!stricmp(cmdPointer,"CMD") || !stricmp(cmdPointer,"COMMAND")) {
    if(stackLevel<32) {
      stackLevel++;
      deleteEnvVariables();   // andrebbe salvato il set attuale...
      CreateStdVar();
      CreateStdVar2(currDrive);
      deleteEnvMacros();
      printf("PC_PIC Command interpreter %u.%02u\r\n",VERNUMH_COMMAND,VERNUML_COMMAND);
      }
    }
  else if(!stricmp(cmdPointer,"DOSKEY")) {
    VARIABLE *vars;
    char *parmsPointer2;
    BOOL foundAssign=FALSE;
    
    if(parmsPointer && *parmsPointer) {
      parmsPointer2=parmsPointer;
      while(*parmsPointer2 && *parmsPointer2 != '=')
        parmsPointer2++;
      if(parmsPointer2 && *parmsPointer2) {
        foundAssign=1;
        *parmsPointer2=0;
        }
      if(vars=findEnvMacro(parmsPointer)) {
        if(foundAssign) {
          parmsPointer2=skipSpaces(parmsPointer2+1);
          if(vars->d.sval)
            free(vars->d.sval);
          if(parmsPointer2 && *parmsPointer2) {
            vars->d.sval=strdup(parmsPointer2);
            }
          else {

            *vars->id=0;
            // MANCA delete variabile... fare ev...

            }
          }
/*        else {		// si fa con parm / ...
          printf("%s=%s\r\n",vars->id,vars->d.sval);
          }*/
        }
      else {
        if(foundAssign) {
          parmsPointer2=skipSpaces(parmsPointer2+1);
          vars = (VARIABLE *)realloc(envMacros, (nEnvMacros + 1) * sizeof(VARIABLE));
          if(vars) {
            envMacros = vars;
            strncpy(envMacros[nEnvMacros].id, parmsPointer, IDLENGTH-1 /*2*/);
            envMacros[nEnvMacros].id[IDLENGTH-1]=0;
// bah qua no            strupr(envMacros[nEnvMacros].id);
            envMacros[nEnvMacros].d.sval = strdup(parmsPointer2);
            envMacros[nEnvMacros].type = STRID;   // fisso ma ok
            nEnvMacros++;
            }
          else {
        //		errore di memoria...
            }
          }
        else
          puts("Syntax error");
        }
      }
    else {		// qua non � cos�, ci va parm - ma per ora ok!
      for(i=0; i<nEnvMacros; i++) {
        if(*envMacros[i].id)   // fare delete vero, v.sopra
          printf("%s=%s\r\n",envMacros[i].id,envMacros[i].d.sval);
        }
      }
    }

  else if(!stricmp(cmdPointer,"TYPE")) {
    char *p;
    FSFILE *f;
    char buf[16];
    
    if((f = FSfopen(parmsPointer, "r"))) { 
      for(;;) {
        if(FSfread(buf,1,1,f)==1) {
          putchar(*buf);
 					while(isCtrlS()); 
					if(hitCtrlC())
            break;
          
          WriteSerial(*buf);      // TEST!!!
          
          }
        else 
          break;
        }
      FSfclose(f);
      }
    else {
      puts("File not found");
      errorLevel=1;
      }
    }
  else if(!stricmp(cmdPointer,"DUMP")) {
    FSFILE *f;
    char buf[128];
    int i,n,addr;
    
    if((f = FSfopen(parmsPointer, "r"))) { 
      addr=0;
      for(;;) {
        n=FSfread(buf,1,16,f);
        printf("%04X ",addr);
        for(i=0; i<n; i++)
          printf("%02X%c",(BYTE)buf[i],i==7 ? '-' : ' ');
        for(i=0; i<n; i++)
          putchar(isprint(buf[i]) ? buf[i] : '.');
        
        putchar('\n');
          
        if(n<16)
          break;
        addr+=n;
        }
      FSfclose(f);
      }
    else {
      puts("File not found");
      errorLevel=1;
      }
    }
  else if(!stricmp(cmdPointer,"MORE")) {
    char *p,ch;
    FSFILE *f;
    char buf[16];
    WORD line;

    if((f = FSfopen(parmsPointer, "r"))) { 
      line=0;
      for(;;) {
        if(FSfread(buf,1,1,f)==1) {
          putchar(*buf);
 					while(isCtrlS()); 
					if(hitCtrlC())
            break;
          if(*buf == '\n') {
            line++;
            if(line>= ScreenText.cy) {
              printf("-- More (%u%%) --",0);    // fare!
              do {
                i=inputKey();
                ch=tolower(LOBYTE(i));
                if(ch=='c' && HIBYTE(i)==0b00000001)
                  break;
	
                } while(ch != '\n' && ch != ' ');
              switch(ch) {
              // aspettare tasto... CR per una riga o spazio per una pagina
                case '\n':
                  line--;
                  break;
                case ' ':
                  line=0;
                  break;
                }
              putchar('\n');
              }
            }
          }
        else 
          break;
        }
      FSfclose(f);
      putchar('\n');    // serve in questi casi xch� il CR � stato mangiato
      }
    else {
      puts("File not found");
      errorLevel=1;
      }
    }
  else if(!stricmp(cmdPointer,"PRINT")) {
    char *p;    // finire cmq come TYPE
    while(*p) {
      WriteParallel(*p++);
      }
    }
#ifdef USA_WIFI
  else if(!stricmp(cmdPointer,"PING")) {
    uint32_t dstIP;
    WORD tOut,nBytes=32,packets=4,ttl=64;
    DWORD timing[4];

    if(!myIp.ip) {
      puts("Network disconnected.");
      errorLevel=1;
      goto ping_fine;
      }
    dstIP = nmi_inet_addr(parmsPointer);
    if(!dstIP) {
      *(unsigned long*)internetBuffer=0;
      tOut=0;
      gethostbyname((uint8_t*)parmsPointer);
      while(!*(unsigned long*)internetBuffer && tOut<DNS_TIMEOUT) {
        m2m_wifi_handle_events(NULL);
        tOut++;
        __delay_ms(1);
        }
      dstIP=*(unsigned long*)internetBuffer;
      if(dstIP)
        printf("Pinging %s [%u.%u.%u.%u] with %u bytes of data:\r\n",
            parmsPointer,LOBYTE(LOWORD(dstIP)),HIBYTE(LOWORD(dstIP)),LOBYTE(HIWORD(dstIP)),HIBYTE(HIWORD(dstIP)),
            nBytes);
      else {
        printf("Ping request could not find host %s. Please check the name and try again.\r\n",parmsPointer);
        errorLevel=1;
        goto ping_fine;
        }
      }
    else {
      printf("Pinging %u.%u.%u.%u with %u bytes of data:\r\n",
            LOBYTE(LOWORD(dstIP)),HIBYTE(LOWORD(dstIP)),LOBYTE(HIWORD(dstIP)),HIBYTE(HIWORD(dstIP)),
            nBytes);
      }
    errorLevel=0;
    for(i=0; i<packets; i++) {
      *(unsigned long*)internetBuffer=0;
      tOut=0;
      m2m_ping_req(dstIP, ttl, ping_cb);
      while(!*(unsigned long*)internetBuffer && tOut<3000) {
        m2m_wifi_handle_events(NULL);
        tOut++;
        __delay_ms(1);
        }
      printf("Reply from %u.%u.%u.%u: ",
              LOBYTE(LOWORD(dstIP)),HIBYTE(LOWORD(dstIP)),LOBYTE(HIWORD(dstIP)),HIBYTE(HIWORD(dstIP))
              /* o usare internetBuffer+4? bah.. */ );
      switch(*(long*)internetBuffer) {
        case -1:
          timing[i]=-1;
          puts("Destination host unreachable");
          errorLevel=1;
          break;
        case -2:
          timing[i]=-1;
          puts("time-out");
          break;
        default:
          timing[i]=*(unsigned long*)internetBuffer;
          printf("bytes=%u time %ums TTL=%u\r\n",nBytes,timing[i], ttl);    // v. callback
          break;
        }
      }
    
    printf("Ping statistics for %u.%u.%u.%u:\r\n",
            LOBYTE(LOWORD(dstIP)),HIBYTE(LOWORD(dstIP)),LOBYTE(HIWORD(dstIP)),HIBYTE(HIWORD(dstIP)));
    {
    DWORD minTime=1000,maxTime=0,avgTime=0,nRecv=0;
    
    for(i=0; i<packets; i++) {
      if(timing[i] != -1) {
        minTime=min(minTime,timing[i]);
        maxTime=max(maxTime,timing[i]);
        avgTime+=timing[i];
        nRecv++;
        }
      }
    if(nRecv>0)
      avgTime /= nRecv;
    printf("   Packets: Sent = %u, Received = %u, Lost = %u (%u%% loss)\r\n",
      packets,nRecv,packets-nRecv,(100*(packets-nRecv))/packets);
    printf("Approximate round trip times in milli-seconds:\r\n");
    printf("    Minimum = %ums, Maximum = %ums, Average = %ums\r\n",
            minTime,maxTime,avgTime);
    }
ping_fine:
          ;
    }
#endif
  else if(!stricmp(cmdPointer,"IPCONFIG")) {    // /all ecc..
		BYTE nOfIp=0,t;
    puts("PC_PIC IP Configuration\r\n");
#ifdef USA_ETHERNET
    if(!MACIsLinked()) {   // 
      printf("Ethernet adapter [%u]: Media disconnected\r\n",++nOfIp);
      }
    else {
      printf("Ethernet adapter [%u]\r\n",++nOfIp);
      printf("IPv4 Address. . : %u.%u.%u.%u\r\n",
              BiosArea.MyIPAddr.v[0],BiosArea.MyIPAddr.v[1],BiosArea.MyIPAddr.v[2],BiosArea.MyIPAddr.v[3] );
      printf("Subnet Mask . . : %u.%u.%u.%u\r\n",
              BiosArea.DefaultMask.v[0], BiosArea.DefaultMask.v[1], BiosArea.DefaultMask.v[2], BiosArea.DefaultMask.v[3]);
      printf("Default Gateway : %u.%u.%u.%u\r\n",
              BiosArea.MyGateway.v[0], BiosArea.MyGateway.v[1], BiosArea.MyGateway.v[2], BiosArea.MyGateway.v[3]);
      }
    errorLevel=0;
#endif
#ifdef USA_WIFI
    m2m_periph_gpio_get_val(M2M_PERIPH_GPIO18,&t);    // leggo il led!
    if(0 /*t*/) {   // [beh...] v. merda non va
      printf("WiFi adapter     [%u]: Media disconnected\r\n",++nOfIp);
      }
    else {
      printf("WiFi adapter     [%u]\r\n",++nOfIp);
      printf("IPv4 Address. . : %u.%u.%u.%u\r\n",
              myIp.addr[0],myIp.addr[1],myIp.addr[2],myIp.addr[3] );
//      finire..
      printf("Subnet Mask . . : %u.%u.%u.%u\r\n",
#ifdef USA_ETHERNET   // finire ovviamente!!!
              BiosArea.DefaultMask.v[0], BiosArea.DefaultMask.v[1], BiosArea.DefaultMask.v[2], BiosArea.DefaultMask.v[3]);
#else
              0,0,0,0);
#endif
      printf("Default Gateway : %u.%u.%u.%u\r\n",
#ifdef USA_ETHERNET
              BiosArea.MyGateway.v[0], BiosArea.MyGateway.v[1], BiosArea.MyGateway.v[2], BiosArea.MyGateway.v[3]);
#else
              0,0,0,0);
#endif
      }
    errorLevel=0;
#endif
#if !defined(USA_WIFI) && !defined(USA_ETHERNET)
    puts("No network adapter present.");
    errorLevel=1;
#endif
    }
  else if(!stricmp(cmdPointer,"NETSTAT")) {    // / fare
		BYTE t;
    puts("Active connections\r\n");
    puts(" Proto\tLocal Address\tForeign Address\tState\r\n");
    // finire :)
#ifdef USA_ETHERNET
    printf(" TCP\t127.0.0.1:%u\t%u\t%s\r\n",BiosArea.telnetPort,
            0 ,0 ? "ESTABLISHED" : "LISTENING");
    printf(" TCP\t127.0.0.1:%u\t%u\t%s\r\n",81,
            0 ,0 ? "ESTABLISHED" : "LISTENING");
    errorLevel=0;
#endif
#ifdef USA_WIFI
    printf(" TCP\t127.0.0.1:%u\t%u\t%s\r\n",BiosArea.telnetPort,
            0 ,TelnetAcceptedSocket != INVALID_SOCKET ? "ESTABLISHED" : "LISTENING");
    printf(" TCP\t127.0.0.1:%u\t%u\t%s\r\n",BiosArea.httpPort,
            0 ,TCPacceptedSocket != INVALID_SOCKET ? "ESTABLISHED" : "LISTENING");
    printf(" UDP\t127.0.0.1:%u\t%u\t%s\r\n",0,
            0 ,"IDLE" /*boh fare!*/);
    errorLevel=0;
#endif
#if !defined(USA_WIFI) && !defined(USA_ETHERNET)
    puts("No network adapter present.");
    errorLevel=1;
#endif
    }
  else if(!stricmp(cmdPointer,"ROUTE")) {    // / fare
    puts("Unimplemented.");
    }

  else if(!stricmp(cmdPointer,"DATE")) {
    char buf[16];
    PIC32_DATE date;
    PIC32_TIME time;

    SetTimeFromNow(now,&date,&time);
    printf("Current date is: %02u/%02u/%04u\r\n",date.mday,date.mon,date.year);
// v. anche DWORD SetNowFromTime(PIC32_DATE date,PIC32_TIME time) {
//  SetRTCC(mytime->u8Day,mytime->u8Month,mytime->u16Year,mytime->u8Hour,mytime->u8Minute,mytime->u8Second);
    if(inputString(buf,8,"Enter new date: (dd-mm-yy) ",0) >= 8) {
// fare parsing...
      // The system cannot accept the date entered. e rifo
      }
    putchar('\n');
    }
  else if(!stricmp(cmdPointer,"TIME")) {
    char buf[16];
    PIC32_DATE date;
    PIC32_TIME time;

    SetTimeFromNow(now,&date,&time);
    printf("Current time is: %02u:%02u:%02u\r\n",time.hour,time.min,time.sec);
// v. anche DWORD SetNowFromTime(PIC32_DATE date,PIC32_TIME time) {
//  SetRTCC(mytime->u8Day,mytime->u8Month,mytime->u16Year,mytime->u8Hour,mytime->u8Minute,mytime->u8Second);
    if(inputString(buf,8,"Enter new time: ",0) >= 5) {
// fare parsing...
      // The system cannot accept the time entered. e rifo
      }
    putchar('\n');
    }
  else if(!stricmp(cmdPointer,"REBOOT")) {
    puts("Rebooting...");
    
    /* beh non dovrebbe servire
  CNNEAbits.CNNEA3=0;
  WritePMP(AUDIO_CARD,BIOS_RESET,1);      // per reset WINC...
  Nop();Nop();
  while(!m_AACK)
    ClrWdt();
  __delay_us(AUDIO_WAIT);
  CNNEAbits.CNNEA3=1; */

  
    SoftReset();
    }
  else if(!stricmp(cmdPointer,"VER")) {
//		printf(_PC_PIC_COMMAND_C boh
    printf("PC_PIC Command interpreter %u.%02u\r\n",VERNUMH_COMMAND,VERNUML_COMMAND);
    }
  else if(!stricmp(cmdPointer,"MEM")) {
    printf("%u bytes total memory\r\n",1L << 19 /*512KB*/);
    printf("%u bytes available memory\r\n",131072L + /* finire e v. main */
            (((unsigned int)&i) - ((unsigned int)&_splim)));
  // _dump_heap_info per info su memoria dinamica...
  //heap_free() in heap_info.c, provare
    printf("%u bytes total extended memory\r\n",extRAMtot);
    printf("%u bytes available extended memory\r\n",extRAMtot);

    }
  else if(!stricmp(cmdPointer,"PROMPT")) {
    char buf[128];
    
//    strncpy(prompt,parmsPointer,15);   // finire... UNIRE!!
    sprintf(buf,"SET PROMPT=%s",parmsPointer);    // idem � la cosa pi� ovvia :)
    execCmd(buf,NULL);
    }
  else if(!stricmp(cmdPointer,"DEVICE")) {    // per caricare driver o programmi...
    FSFILE *f;
    puts("Partly unimplemented...");
    {
    if((f = FSfopen(parmsPointer, "r"))) { 
      
      if(driverAllocated)
        free(driverAllocated);
      driverAllocated=malloc(f->size);
      if(driverAllocated) {
        if(FSfread(driverAllocated,f->size,1,f) != f->size) {
          puts("Can't load driver");
          }
        // e poi eseguirlo o boh :)
        }
      else {
        free(driverAllocated);
        driverAllocated=NULL;
        }
      FSfclose(f);
      }
    else {
      puts("Program not found");
      errorLevel=1;
      }

    }
    }
  else if(!stricmp(cmdPointer,"HELP")) {
    puts("For more information on a specific command, type HELP command-name");
    puts("BASIC");
    puts("BEEP");
    puts("BREAK");
    puts("CALL");
    puts("CD(CHDIR)");
    puts("CHCP");
    puts("CHOICE");
    puts("CHKDSK");
    puts("CLS");
    puts("CMD");
    puts("COLOR");
    puts("COMP");
    puts("COPY");
    puts("DATE");
    puts("DEVICE");
    puts("DEL(ERASE)");
    puts("DIR");
    puts("DISKPART");
    puts("DOSKEY");
    puts("DUMP");
    puts("ECHO");
    puts("EDLIN");
    puts("EXIT");
    puts("FC");
    puts("FIND");
    puts("FOR");
    puts("FORMAT");
    puts("GOTO");
    puts("HELP");
    puts("IF");
    puts("IPCONFIG");
    puts("LABEL");
    puts("MD(MKDIR)");
    puts("MEM");
    puts("MODE");
    puts("MORE");
    puts("MOVE");
    puts("NETSTAT");
    puts("PATH");
    puts("PAUSE");
    puts("PING");
    puts("PRINT");
    puts("PROMPT");
    puts("REBOOT");
    puts("RD(RMDIR)");
    puts("REM");
    puts("REN(RENAME)");
    puts("ROUTE");
    puts("SET");
    puts("SORT");
    puts("TIME");
    puts("TREE");
    puts("TYPE");
    puts("VER");
    puts("VOL");
    puts("WIN");
    }
  else if(!stricmp(cmdPointer,"SAVEBIOS")) {    // non documentata, e tanto per :) ; fare anche LOAD??
    FSFILE *f;
    SetClockVarsNow();
    if((f = FSfopen("bios.bin", "wb"))) { // solo su SD...
      FSfwrite(&BiosArea,1,sizeof(BiosArea),f);
      FSfclose(f);
      }
    }
  else {      // cerco MACRO e/o BATch sul disco :) (anche BAS??)
    VARIABLE *macro;
    char buf[128];
    if(macro=findEnvMacro(cmd)) {
      strcpy(buf,macro->d.sval);
      execCmd(buf,NULL);   // gestire parametri/$...
      }
    else {
      FSFILE *f;
      
      strncpy(buf,cmd,15);
      strcat(buf,".BAT");
      if((f = FSfopen(buf, "r"))) { 
  //      FSfread(buf,127,1,f);   // finire!
        do {
          FSgets(buf,127,f);   // finire!
          if(*buf)
            execCmd(buf,f);   // passare parametri...

  #ifdef USA_WIFI
          m2m_wifi_handle_events(NULL);
  #endif
  #ifdef USA_ETHERNET
          StackTask();
          StackApplications();
  #endif
      // Maintain state machines of all polled MPLAB Harmony modules.
  #if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
          SYS_Tasks();
  #ifdef USA_USB_HOST_MSD
          SYS_FS_Tasks();
  #endif
  #else
          APP_Tasks();
  #endif

          KBClear();    // mmm... sicuri?
          handle_events();

          if(hitCtrlC())
            break;

          } while(*buf);
        FSfclose(f);
        putchar('\n'); printf(prompt);
        }
      else
unrecognized_command:
        puts("Unrecognized command");
      }
    }

  }
int runCmdInterpreter(void) {
  BYTE ch;
  
  if(keypress.key /*keypress.new*/) {
    // o direttamente getchar()?
    
    if((/*keypress.key=='.' || */ keypress.key==0x9a  /* sia DEL che . direi... NO! */) && 
            ((keypress.modifier & 0xf) | (keypress.modifier >> 4)) == 0b00000101) { // CTRL-ALT-CANC!
      SetCursorMode(0,0);   // finezza :)
      App_Reset();
      }

//  printf("TASTO %02X\r\n",keypress.key);

    switch(keypress.key) {
      case 0xa3: // F3
        strcpy(commandLine,lastCommandLine);
        commandLineCnt=strlen(commandLine);
        printf(commandLine);
//				KBClear();
        break;
      case 0x94: // up, simile a f3 per ora
        strcpy(commandLine,lastCommandLine);
        commandLineCnt=strlen(commandLine);
        printf(commandLine);
//				KBClear();
        break;
      case 0x91: // right
        if(commandLineCnt<=strlen(lastCommandLine)) {
					commandLine[commandLineCnt]=lastCommandLine[commandLineCnt];
					putchar(commandLine[commandLineCnt]);
					commandLine[++commandLineCnt]=0;
					}
//				KBClear();
        break;
      case 0xb8: // PrtSc
        printScreen();
//				KBClear();
        break;
      case 0xb9: // Power ecc
      case 0xba:
      case 0xbb:
        break;
      case 0x9f: // Pause
        isPaused=!isPaused;
    // accendere scrollock led?     KeyboardSetLed(0b00000100);
        break;
        
		// gestire ALT+nnn !
        
      default:
        if((keypress.key>=' ' && keypress.key<=0x7e) ||
          (keypress.key>=0xa0 && keypress.key<=0xff) ||		// direi anche questi.. MA SCARTARE cod. speciali come pause ecc
          keypress.key=='\r' || keypress.key=='\n' || keypress.key==8) {
          ch=keypress.key;

          if(isPaused) {
            isPaused=FALSE;   // DOS pare fare cos�...
    // spegnere scrollock led?     KeyboardSetLed(0b00000000);
            }

          if(commandLineCnt<sizeof(commandLine) /*&& isprint(ch)*/) {
            commandLine[commandLineCnt++]=/*toupper*/(ch);
            switch(ch) {
              default:
                if(isprint(ch)) {
                  if(keypress.modifier & 0b00010001) {
                    putchar('^');
                    putchar(toupper(ch));   // il DOS pare non farlo ma ok!
                    switch(tolower(ch)) {
                      case 'c':
                        putchar('\n');
                        goto skip_all;
                        break;
                      case 's':   // viene mangiato cmq
                        isPaused=!isPaused;
                        break;
                      case 'g':   // beep... pure su PC sembra passare quindi cos� :)
                        StdBeep(250);
                        break;
                      default:
                        commandLine[commandLineCnt-1]=ch & 0x1f;
                        break;
                      }
                    }
                  else
                    putchar(ch);
                  }
            //    WriteSerial(ch);
                break;
              case '\x8':
                // backspace
                commandLine[--commandLineCnt]=0;
                if(commandLineCnt>0) {
                  commandLine[--commandLineCnt]=0;
                  putchar('\x8');
                  }
                break;
              case '\r':
                commandLine[commandLineCnt--]=0;            // pulisco cmq il successivo, in caso di prec. comando lungo..
                commandLine[commandLineCnt]=0;            // tolgo LF
                break;
              case '\n':
                commandLine[--commandLineCnt]=0;            // tolgo CR
                if(commandLineCnt>0) {
                  putchar(ch);

                  strcpy(lastCommandLine,commandLine);

                  execCmd(commandLine,NULL);

skip_all:            
                  commandLineCnt=0;
                  commandLine[0]=0;

                  putchar('\n'); printf(prompt);
                  }
                else {
                  putchar('\n'); printf(prompt);
                  }
                break;
              }
            }
      		}
        break;
      }

    KBClear();
    }
  
  // si dovrebbe leggere lo stato dei led... ogni tanto
          
  return 1;
  }

#ifdef USA_WIFI
/* Ping Callback function definition*/
void ping_cb(uint32_t u32IPAddr, uint32_t u32RTT, uint8_t u8ErrorCode) {
  
  if(!u8ErrorCode){
//    printf("ping_cb: PING_SUCCESS\r\n");
//    printf("ping_cb: Reply from %x IP: RTT= %dms\r\n",u32IPAddr,u32RTT);
    *(BYTE *)(internetBuffer+8)=u8ErrorCode;
    *(long *)(internetBuffer+4)=u32IPAddr;
    *(long *)(internetBuffer+0)=u32RTT;   // boh tanto per, v. function
    }
  else if(u8ErrorCode==1) {
    *(long *)internetBuffer=-1;
//    printf("ping_cb: PING_ERR_DEST_UNREACH\r\n");
    }
  else if (u8ErrorCode==2){
    *(long *)internetBuffer=-2;
//    printf("ping_cb: PING_ERR_TIMEOUT\r\n");
    }
  }  
#endif

int subDir(char drive,const char *path,BYTE level,BYTE recurse,WORD *totfiles,WORD *totdirs,DWORD *totsize) {
  int i,retVal=0;
  
  switch(drive) {
    case 'A':
    {
    SearchRec rec;

    i=FindFirst(path, ATTR_MASK ^ ATTR_VOLUME, &rec);
    printf("Directory of %s%s\r\n","A:",path);
    if(!i) {
      retVal=1;
      do {
        printf("%12s",rec.filename);
        if(rec.attributes & ATTR_DIRECTORY) {
          printf("%9s\r\n","DIR");
          if(recurse)
            subDir(drive,rec.filename,level+1,TRUE,totfiles,totdirs,totsize);
          (*totdirs)++;
          }
        else {
          printf("%9u",rec.filesize);
          *totsize += rec.filesize;
          printf(" %02u/%02u/%04u %02u:%02u:%02u\r\n",
            (rec.timestamp >> 16) & 31,
            (rec.timestamp >> (5+16)) & 15,
            (rec.timestamp >> (9+16)) + 1980,
            (rec.timestamp >> 11) & 31,
            (rec.timestamp >> 5) & 63,
            rec.timestamp & 63);
          }
        (*totfiles)++;
        if(hitCtrlC())
          break;
        while(isCtrlS());
        } while(!FindNext(&rec));

      }
    else {
// non va..        if(FSerror() == CE_NOT_PRESENT || FSerror() == CE_NOT_FORMATTED || FSerror() == CE_BAD_PARTITION) {  // boh... 
      if(FSerror() != CE_FILE_NOT_FOUND) {
no_disc:
        puts("Disk not present");
        }
      else {
no_files:
        puts("File not found");
        }
      errorLevel=1;
      }

    }

      break;
    case 'B':
      goto no_disc;
      break;
    case 'C':
    {
      IDEFile root;
      dir_t* p;
      char buf[32];
      uint32_t sn;

      if(!IDEFile_openRoot(&root,&HDvolume)) {

        retVal=1;
        
        IDEVolume_fatType(&HDvolume);   // controllare...

        IDEFile_rewind(&root);
        while((p = IDEFile_readDirCache(&root))) {

          printf("Directory of %s%s\r\n","C:",path);

          // done if past last used entry
          if(p->name[0] == DIR_NAME_FREE) 
            break;

          // skip deleted entry and entries for. and  ..
          if(p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') 
            continue;
          
          // path / FILTER??

          // print file name with possible blank fill
          printf("%12s",p->name);

          if(!DIR_IS_SUBDIR(p)) {
            printf("%9u",p->fileSize);
            *totsize += p->fileSize;
            printf(" %02u/%02u/%04u %02u:%02u:%02u\r\n",
              FAT_DAY(p->lastWriteDate),
              FAT_MONTH(p->lastWriteDate),
              FAT_YEAR(p->lastWriteDate),
              FAT_HOUR(p->lastWriteTime),
              FAT_MINUTE(p->lastWriteTime),
              FAT_SECOND(p->lastWriteTime));
            }
          else {
            printf("%9s\r\n","DIR");
            if(recurse)
              subDir(drive,p->name,level+1,TRUE,totfiles,totdirs,totsize);
            (*totdirs)++;
            }

          // list subdirectory content ifrequested
/*            if((flags & LS_R) && DIR_IS_SUBDIR(p)) {
            uint16_t index = curPosition()/32 - 1;
            IDEFile s;
            if(s.open(this, index, O_READ)) s.ls(flags, indent + 2);
            seekSet(32 * (index + 1));
            }*/

          (*totfiles)++;
          if(hitCtrlC())
            break;
          while(isCtrlS());
          }
// e IDEFile_close( ??  #programmatoridelcazzo
        }
    }
      break;
    case 'D':
      goto no_disc;
      break;
#if defined(USA_USB_HOST_MSD)
    case 'E':
    {
      SYS_FS_HANDLE myFileHandle;
// unire poi...      i=USBFindFirst( filter, ATTR_MASK ^ ATTR_VOLUME, &rec);
      if((myFileHandle=SYS_FS_DirOpen(path)) != SYS_FS_HANDLE_INVALID) {
        SYS_FS_FSTAT stat;
        
        retVal=1;
        printf("Directory of %s%s\r\n","E:",path);
        while(SYS_FS_DirSearch(myFileHandle,path,SYS_FS_ATTR_MASK,&stat) == SYS_FS_RES_SUCCESS) {
          printf("%12s",stat.fname);
          if(stat.fattrib & SYS_FS_ATTR_DIR) {
            printf("%9s\r\n","DIR");
            if(recurse)
              subDir(drive,stat.fname,level+1,TRUE,totfiles,totdirs,totsize);
            (*totdirs)++;
            }
          else {
            printf("%9u",stat.fsize);
            *totsize += stat.fsize;
            printf(" %02u/%02u/%04u %02u:%02u:%02u\r\n",
              stat.fdate & 31,
              (stat.fdate >> (5)) & 15,
              (stat.fdate >> (9)) + 1980,
              (stat.ftime >> 11) & 31,
              (stat.ftime >> 5) & 63,
              stat.ftime & 63);
            }
          (*totfiles)++;
          if(hitCtrlC())
            break;
          while(isCtrlS());
          }
        SYS_FS_DirClose(myFileHandle);
      }
    }
      break;
#endif
    }
  return retVal;
  }
#warning CTRL-C in queste ricorsive dovrebbe stroncare fino a fuori... longjmp??
int subTree(char drive,const char *path,BYTE level) {
  char hyphens[64],buf[64];
  int totfiles=0;
  
//            printf("entra SUBTREE: %s %u\r\n",path,level);
//            printf("  curdir: %s\r\n",FSgetcwd(NULL,0));
            

  memset(hyphens,'-',level*3);
  hyphens[level*3]=0;
  printf("%s%s%s\r\n",level > 0 ? "+" : "",hyphens,*path ? path : "\\" /*e drive?*/);
  
    
    
            
    strcpy(buf,"*.*");

  
// non concatena se � vuoto...  strcat(buf,"\\*.*");
    
  switch(drive) {
    case 'A':
    {
      SearchRec rec;
      int i;
    
      i=FSchdir(path);    // d� errore alla root, ma ok
//            printf("  CHDIR: %d\r\n",i);
//            printf("    buf: %s\r\n",buf);
      if(!FindFirst(buf, ATTR_DIRECTORY, &rec)) {
        do {
          totfiles++;
          if((rec.filename[0] == '.' && !rec.filename[1])
            || (rec.filename[0] == '.' && rec.filename[1] == '.' && !rec.filename[2]))
            continue;    // qua non accetta dir con '.' iniziale cmq ma in DOS s�
          subTree(drive,rec.filename,level+1);
					if(hitCtrlC())
						break;
					while(isCtrlS());
          } while(!FindNext(&rec));
				if(!totfiles)
					goto no_subfolders;
        }
      else
				goto no_subfolders;

    }
      break;
    case 'B':
      break;
    case 'C':
      {
        IDEFile root;
        dir_t* p;

        if(!IDEFile_openRoot(&root,&HDvolume)) {
          totfiles=0; 
          
//FARE      i=FSchdir(path);    // d� errore alla root, ma ok
          
          IDEVolume_fatType(&HDvolume);   // controllare...
          
          IDEFile_rewind(&root);
          while((p = IDEFile_readDirCache(&root))) {
            // done if past last used entry
            if(p->name[0] == DIR_NAME_FREE) 
              break;
            // skip deleted entry and entries for. and  ..
            if(p->name[0] == DIR_NAME_DELETED || p->name[0] == '.') 
              continue;
            
						totfiles++;
            if(DIR_IS_FILE_OR_SUBDIR(p)) {
              if((p->name[0] == '.' && !p->name[1])
                || (p->name[0] == '.' && p->name[1] == '.' && !p->name[2]))
                continue;    // qua non accetta dir con '.' iniziale cmq ma in DOS s�
							subTree(drive,p->name,level+1);
						// servono asterischi??
							}

            totfiles++;
						if(hitCtrlC())
							break;
  					while(isCtrlS());
		        }
// e IDEFile_close( ??  #programmatoridelcazzo
					if(!totfiles)
						goto no_subfolders;
          }
	      else
					goto no_subfolders;
      }
      break;
    case 'D':
      break;
#if defined(USA_USB_HOST_MSD)
    case 'E':
    {
      SYS_FS_HANDLE myFileHandle;
      char buf[64];
// potrebbe non servire qua..      SYS_FS_DirectoryChange(path);    // 
//      if((myFileHandle=SYS_FS_DirOpen(path)) != SYS_FS_HANDLE_INVALID) {
      
      SYS_FS_DirectoryChange(path);    // 
      if(SYS_FS_CurrentWorkingDirectoryGet(buf,63) != SYS_FS_RES_SUCCESS)
        ;

      if((myFileHandle=SYS_FS_DirOpen(buf)) != SYS_FS_HANDLE_INVALID) {
        SYS_FS_FSTAT stat;
        while(SYS_FS_DirSearch(myFileHandle,buf,SYS_FS_ATTR_DIR,&stat) == SYS_FS_RES_SUCCESS) {
          totfiles++;
          if((stat.fname[0] == '.' && !stat.fname[1])
            || (stat.fname[0] == '.' && stat.fname[1] == '.' && !stat.fname[2]))
            continue;    // qua non accetta dir con '.' iniziale cmq ma in DOS s�
          // cmq su USB pare non arrivino...
          subTree(drive,stat.fname,level+1);
					if(hitCtrlC())
						break;
					while(isCtrlS());
          }
        SYS_FS_DirClose(myFileHandle);
//				if(!totfiles)
// qua no					goto no_subfolders;
        }
      else {
  			goto no_subfolders;
				}
      break;
    }
#endif
    }
  if(!level)
    /*putchar('\n')*/ ;
  else {
    switch(drive) {
      case 'A':
        FSchdir("..");
        break;
      case 'C':
        break;
      case 'E':
        // forse non serve , v. sopra
        SYS_FS_DirectoryChange("..");    // 
        break;
      }
    }
  
  return totfiles;
  
no_subfolders:
	puts("No subfolders exist");
  return totfiles;
  }

void printScreen(void) {
  char ch;
  int i;
  char *p="prova";    // per ora cos�! leggere area video char da scheda video...
  
  for(i=0; i<5; i++) {
    ch=p[i];
    // GetVideoTextArea();
    WriteParallel(ch);
    }
  WriteParallel('\n');
// se premo PrtSc da PS2 escono solo 5 char, da USB 6... strano... 23/6/22
	// credo dipenda dal fatto che PrtSc � un tasto doppio e quindi il south perde tempo, per� in effetti il PC dovrebbe aspettare...
  // no ora va, 25/6
  }
