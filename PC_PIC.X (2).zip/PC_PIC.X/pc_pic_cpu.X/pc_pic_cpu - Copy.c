/* PC/PIC Motherboard, CPU module
 * GD/C 30/8/21
 */

// PIC32MZ2048EFG100 Configuration Bit Settings

// 'C' source line config statements
#pragma config USERID =     0x4B47

// DEVCFG3
#pragma config FMIIEN = OFF             // Ethernet RMII/MII Enable (RMII Enabled)
#pragma config FETHIO = OFF             // Ethernet I/O Pin Select (Alternate Ethernet I/O)
#pragma config PGL1WAY = ON             // Permission Group Lock One Way Configuration (Allow only one reconfiguration)
#pragma config PMDL1WAY = ON            // Peripheral Module Disable Configuration (Allow only one reconfiguration)
#pragma config IOL1WAY = ON             // Peripheral Pin Select Configuration (Allow only one reconfiguration)
#if defined(USA_USB_SLAVE_CDC)
//#pragma config FUSBIDIO = ON            // USB USBID Selection (Controlled by the USB Module)
#pragma config FUSBIDIO = OFF           // ma � ACS...
#else
#pragma config FUSBIDIO = OFF           // USB USBID Selection (NOT Controlled by the USB Module )
#endif

// DEVCFG2
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
/* Default SYSCLK = 200 MHz (8MHz FRC / FPLLIDIV * FPLLMUL / FPLLODIV) */
// la scheda DM32 usa 24MHz crystal o Oscillator... anche io :)
#pragma config FPLLIDIV = DIV_3         // System PLL Input Divider (2x Divider)
#pragma config FPLLRNG = RANGE_5_10_MHZ// System PLL Input Range (34-68 MHz Input x FRC ??)
#pragma config FPLLICLK = PLL_POSC       // System PLL Input Clock Selection (POSC is input to the System PLL)
#pragma config FPLLMULT = MUL_50       // System PLL Multiplier (PLL Multiply by 50)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (32x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)
/*#pragma config FPLLIDIV = DIV_2         // System PLL Input Divider (2x Divider)
#pragma config FPLLRNG = RANGE_8_16_MHZ// System PLL Input Range (8-16 MHz Input )
#pragma config FPLLICLK = PLL_POSC       // System PLL Input Clock Selection (POSC is input to the System PLL)
#pragma config FPLLMULT = MUL_33       // System PLL Multiplier (PLL Multiply by 33)
#warning provare overclock! (se va con usb...)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (2x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)
*/
//#pragma config UPLLEN = ON      // USB PLL Enable (USB PLL is enabled)
#else
#pragma config FPLLIDIV = DIV_1         // System PLL Input Divider (1x Divider)
#pragma config FPLLRNG = RANGE_5_10_MHZ// System PLL Input Range (5-10 MHz Input)
#pragma config FPLLICLK = PLL_FRC       // System PLL Input Clock Selection (FRC is input to the System PLL)
#pragma config FPLLMULT = MUL_54       // System PLL Multiplier (PLL Multiply by 54)
#pragma config FPLLODIV = DIV_2        // System PLL Output Clock Divider (2x Divider)
#pragma config UPLLFSEL = FREQ_24MHZ    // USB PLL Input Frequency Selection (USB PLL input is 24 MHz)
#endif

// DEVCFG1
#if defined(USA_USB_HOST) || defined(USA_USB_SLAVE_CDC)
#pragma config FNOSC = SPLL           // Oscillator Selection Bits (S PLL)
#pragma config POSCMOD = HS            // Primary Oscillator Configuration (Primary osc enabled)
#else
#pragma config FNOSC = FRCDIV           // Oscillator Selection Bits (Fast RC Osc w/Div-by-N (FRCDIV))
#pragma config POSCMOD = OFF            // Primary Oscillator Configuration (Primary osc disabled) x FRC
#endif
#pragma config DMTINTV = WIN_127_128    // DMT Count Window Interval (Window/Interval value is 127/128 counter value)
#pragma config FSOSCEN = OFF             // Secondary Oscillator Enable (disable SOSC)
#pragma config IESO = ON                // Internal/External Switch Over (Enabled)
#pragma config OSCIOFNC = ON           // CLKO Output Signal Active on the OSCO Pin (Enabled)
#pragma config FCKSM = CSECME           // Clock Switching and Monitor Selection (Clock Switch Enabled, FSCM Enabled)
#pragma config WDTPS = PS2048          // Watchdog Timer Postscaler (1:2048)
  // circa 1 secondi, 8.9.19
#pragma config WDTSPGM = STOP           // Watchdog Timer Stop During Flash Programming (WDT stops during Flash programming)
#pragma config WINDIS = NORMAL          // Watchdog Timer Window Mode (Watchdog Timer is in non-Window mode)
#pragma config FWDTEN = ON             // Watchdog Timer Enable (WDT Enabled)
#pragma config FWDTWINSZ = WINSZ_25     // Watchdog Timer Window Size (Window size is 25%)
#pragma config DMTCNT = DMT31           // Deadman Timer Count Selection (2^31 (2147483648))
#pragma config FDMTEN = OFF             // Deadman Timer Enable (Deadman Timer is disabled)

// DEVCFG0
#pragma config DEBUG = OFF              // Background Debugger Enable (Debugger is disabled)
#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
#pragma config ICESEL = ICS_PGx1        // ICE/ICD Comm Channel Select (Communicate on PGEC1/PGED1)
#pragma config TRCEN = OFF              // Trace Enable (Trace features in the CPU are disabled)
#pragma config BOOTISA = MIPS32         // Boot ISA Selection (Boot code and Exception code is MIPS32)
#pragma config FECCCON = OFF_UNLOCKED   // Dynamic Flash ECC Configuration (ECC and Dynamic ECC are disabled (ECCCON bits are writable))
#pragma config FSLEEP = OFF             // Flash Sleep Mode (Flash is powered down when the device is in Sleep mode)
#pragma config DBGPER = PG_ALL          // Debug Mode CPU Access Permission (Allow CPU access to all permission regions)
#pragma config SMCLR = MCLR_NORM        // Soft Master Clear Enable bit (MCLR pin generates a normal system Reset)
#pragma config SOSCGAIN = GAIN_2X       // Secondary Oscillator Gain Control bits (2x gain setting)
#pragma config SOSCBOOST = ON           // Secondary Oscillator Boost Kick Start Enable bit (Boost the kick start of the oscillator)
#pragma config POSCGAIN = GAIN_2X       // Primary Oscillator Gain Control bits (2x gain setting)
#pragma config POSCBOOST = ON           // Primary Oscillator Boost Kick Start Enable bit (Boost the kick start of the oscillator)
#pragma config EJTAGBEN = NORMAL        // EJTAG Boot (Normal EJTAG functionality)

// DEVCP0
#pragma config CP = OFF                 // Code Protect (Protection Disabled)

// SEQ3

// DEVADC0

// DEVADC1

// DEVADC2

// DEVADC3

// DEVADC4

// DEVADC7


#include <xc.h>
#include "Pc_pic_cpu.h"


#if defined(USA_USB_HOST)
#include "usbfsconfig.h"
#include "../harmony_pic32mz/usb_host.h"
#include "../harmony_pic32mz/usb_common.h"
#if defined(USA_USB_HOST_UVC)
#include "../harmony_pic32mz/usb_host_uvc.h"
#endif
#if defined(USA_USB_HOST_MSD)
#include "../harmony_pic32mz/usb_host_msd.h"
#include "../harmony_pic32mz/usb_host_scsi.h"
#endif
#endif
#if defined(USA_USB_SLAVE_CDC)
#include "../harmony_pic32mz/usb_chapter_9.h"
#include "../harmony_pic32mz/usb_device.h"
#include "../harmony_pic32mz/usb_cdc.h"
#include "../harmony_pic32mz/usb_device_cdc.h"
#endif
#include "harmony_app.h"
#include <stdio.h>
#include <stdint.h>
#ifdef USA_WIFI
#include "at_winc1500.h"
#endif



static const char _PC_PIC_CPU_C[]= {"PIC32MZ2048EFG100 PC_PIC_CPU - 8/12/2021\r\n\r\n"};
static const char Copyr1[]="(C) Dario's Automation 2021 - G.Dar\xd\xa";

#ifdef USA_WIFI
struct sockaddr_in myIp;
BYTE myRSSI;
SOCKET UDPclientSocket=INVALID_SOCKET,DNSclientSocket=INVALID_SOCKET;
BYTE rxBuffer[256];
SOCKET TCPlistenSocket=INVALID_SOCKET, TCPacceptedSocket=INVALID_SOCKET;
BYTE bIsfinished = 0;
sint16 sendEx(SOCKET, void *, uint16);
void udpClientStart(const char *);
void tcpStartServer(uint16);
void clientSocketEventHandler(SOCKET, BYTE, void *);
void wifi_cb(BYTE u8MsgType, void *pvMsg);
#endif


#define DMA_READY __attribute__((coherent)) __attribute__((aligned(16)))    // 
//__attribute__((coherent,aligned(4)))
//#define PMPWaitBusy()   while(PMSTATbits.OBE); // VERIFICARE
#define PMPWaitBusy()   while(PMMODEbits.BUSY); // x Master

volatile unsigned long vLine;
volatile unsigned long now;
signed char timeZone;

APP_DATA appData;
uint16_t keypress;
BYTE BiosArea[256];     // mirrorato in EEprom (emulata)


#ifdef USA_USB_SLAVE_CDC    
#define APP_READ_BUFFER_SIZE 512

uint8_t DMA_READY readBuffer[APP_READ_BUFFER_SIZE];
uint8_t DMA_READY writeBuffer[APP_READ_BUFFER_SIZE];
//uint8_t DMA_READY USB_Out_Buffer[APP_READ_BUFFER_SIZE];
uint8_t DMA_READY USB_In_Buffer[APP_READ_BUFFER_SIZE];
#endif



#ifdef USA_USB_SLAVE_CDC    
uint16_t NextUSBOut;
uint16_t LastRS232Out;  // Number of characters in the buffer
uint16_t RS232cp;       // current position within the input buffer
volatile unsigned char RS232_Out_Data_Rdy=false;
#endif


int main() {
  int i;
  
  // Disable all Interrupts
  __builtin_disable_interrupts();
//  SYSKEY = 0x00000000;
//  SYSKEY = 0xAA996655;    qua non dovrebbe servire essendo 1� giro (v. IOLWAY
//  SYSKEY = 0x556699AA;
  CFGCONbits.IOLOCK = 0;      // PPS Unlock
//  RPD11Rbits.RPD11R = 1;        // Assign RPD11 as U1TX, pin 70
//  U1RXRbits.U1RXR = 3;        // Assign RPD10 as U1RX, pin 69
  RPF2Rbits.RPF2R = 12;        // Assign RPF2 as OC1, pin 57

  RPD3Rbits.RPD3R = 5;        // Assign RPD3 as SDO1, pin 78
  SDI1Rbits.SDI1R = 0;        // Assign RPD2 as SDI1, pin 77


#if 0
  RPB0Rbits.RPB0R = 15;        // RefClk3 su pin 57 (RF2)
	REFO3CONbits.RSLP=1;
	REFO3CONbits.ROSEL=1;
	REFO3CONbits.RODIV=1;        // ok 50MHz 27/7/20
	REFO3CONbits.OE=1;
	REFO3CONbits.ON=1;
	TRISFbits.TRISF2=1;
#endif
  
  SYSKEY = 0x00000000;
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;
  CFGCONbits.OCACLK=1;      // sceglie timer per PWM [serve SYSLOCK cmq)
  SYSKEY = 0x00000000;
  
  CFGCONbits.IOLOCK = 1;      // PPS Lock
//  SYSKEY = 0x00000000;

  
  
#if !defined(USA_USB_HOST) && !defined(USA_USB_SLAVE_CDC)
  OSCTUN=0;
  OSCCONbits.FRCDIV=0;
  
  // Switch to FRCDIV, SYSCLK=8MHz
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  OSCCONbits.NOSC=0x00; // FRC
  OSCCONbits.OSWEN=1;
  SYSKEY=0x33333333;
  while(OSCCONbits.OSWEN) {
    Nop();
    }
    // At this point, SYSCLK is ~8MHz derived directly from FRC
 //http://www.microchip.com/forums/m840347.aspx
  // Switch back to FRCPLL, SYSCLK=200MHz
  SYSKEY=0xAA996655;
  SYSKEY=0x556699AA;
  OSCCONbits.NOSC=0x01; // SPLL
  OSCCONbits.OSWEN=1;
  SYSKEY=0x33333333;
  while(OSCCONbits.OSWEN) {
    Nop();
    }
  // At this point, SYSCLK is ~200MHz derived from FRC+PLL
#endif

//***
  mySYSTEMConfigPerformance();

    
  myINTEnableSystemMultiVectoredInt();
  __delay_ms(1); 

    #if defined(USE_USB_BUS_SENSE_IO)
    tris_usb_bus_sense = INPUT_PIN; // See HardwareProfile.h
    #endif
    
    #if defined(USE_SELF_POWER_SENSE_IO)
    tris_self_power = INPUT_PIN;	// See HardwareProfile.h
    #endif


    EEinit();
    for(i=0; i<sizeof(BiosArea); i++)
      BiosArea[i]=EEread(i);

    UserInit();
    
  Timer_Init();
  PWM_Init();

//    TRISBbits.TRISB5=1;     // USBID v. config qua dovrebbe essere auto-controllato
  SYS_Initialize(NULL);

//  putsUART1("sys init\r\n");
  
  /*
  SetVideoMode(MODE_VGA,640,480,8);      //BiosArea...
  SetAudioMode(SYNTH);
  SetAudioWave(0,TRIANGOLARE,1000,2,8,80,0,0);
  SetAudioWave(1,NESSUNA,10,2,8,100,0,0);
  SetSerialPort(115200,8,0,1);
  SetParallelPort(1);
  SetJoystick(1);
  SetMidi(0);
  SetRTCC(1,1,21,21,39,0);
  */
  
  WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_WRITE,'b'); WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_WRITE,'o'); WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_WRITE,'o'); WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_WRITE,'t'); WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_WRITE,0x0a);



//#ifdef USA_WIFI
#if 0
  //https://microchipsupport.force.com/s/article/How-to-retrieve-the-Connection-Parameters-after-WINC1500-is-connected-to-an-Access-Point-AP

	tstrWifiInitParam param;
	nm_bsp_init();
   
//      m_Led0Bit = 1;
	m2m_memset((BYTE*)&param, 0, sizeof(param));
	param.pfAppWifiCb = wifi_cb;
	/*initialize the WINC Driver*/
		M2M_INFO("Init WiFi...\n");
	int ret = m2m_wifi_init(&param);
	if(M2M_SUCCESS != ret){
		M2M_ERR("Driver Init Failed <%d>\n",ret);
		while(1) {
//      m_Led0Bit^=1;
      __delay_ms(40);
      }
		}
  m2m_wifi_connect("wlan_greggio",12,M2M_WIFI_SEC_WPA_PSK,"dariog20",M2M_WIFI_CH_ALL /*7*/);
	// Handle the app state machine plus the WINC event handler 
	while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS) {
//      m_Led0Bit^=1;
    ClrWdt();
		}
 

    m2m_wifi_set_sleep_mode(M2M_NO_PS,1);
     // SERVE per broadcast??

  // Initialize the socket layer.
  socketInit();

#endif
  

  while(1) {
    // Maintain state machines of all polled MPLAB Harmony modules.
    SYS_Tasks();
#ifdef USA_USB_HOST_MSD
    SYS_FS_Tasks();
#endif

		runCmdInterpreter();
    
//    mLED_1 ^= 1;    // 26KHz 30/11/21 (asimmetrico, v. altri)
    
    ClrWdt();
    }

  }

void _mon_putc(char c) {
  
  WritePMP(VIDEO_CARD,BIOS_VIDEO_CHAR,c);
  
#ifdef USA_USB_SLAVE_CDC
  uint32_t timeout;
  if(NextUSBOut < APP_READ_BUFFER_SIZE) {
    writeBuffer[NextUSBOut++] = c;
    }
    
    if(NextUSBOut == APP_READ_BUFFER_SIZE) {
//        if(appData.isWriteComplete = true)
//      appData.writeTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
//      memcpy(writeBuffer,USB_Out_Buffer,APP_READ_BUFFER_SIZE);   // buffer allineati e di % 512!!
//      if(USB_DEVICE_CDC_Write(USB_DEVICE_CDC_INDEX_0, &appData.writeTransferHandle,
//        &writeBuffer, APP_READ_BUFFER_SIZE, USB_DEVICE_CDC_TRANSFER_FLAGS_DATA_COMPLETE) == USB_ERROR_NONE) {
//        NextUSBOut=0;
//        appData.isWriteComplete = false;
//      }
      appData.isWriteComplete = false;
      timeout=0;
      while(appData.isWriteComplete == false && timeout<50000L) {
        SYS_Tasks();    //
        timeout++;
        }
      appData.isWriteComplete == true;
      NextUSBOut=0;
//      return 2;
      }
//    return 1;
#endif
  }

char _mon_getc(void) {
  
#ifdef USA_USB_SLAVE_CDC
  char usb_ch_1; 

  usb_ch_1=USB_In_Buffer[RS232cp++];
  if(RS232cp == LastRS232Out) {
    RS232_Out_Data_Rdy=false;
    RS232cp=0;
    
    appData.isReadComplete=false;
    appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
    USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
      &readBuffer, APP_READ_BUFFER_SIZE);

    }
  
/*
  usb_ch_1=readBuffer[0];
  appData.isReadComplete=false;
  appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
  USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
    &readBuffer, APP_READ_BUFFER_SIZE);
  */
  return usb_ch_1;
#endif
  
  return keypress;
  }

void UserInit(void) {
	unsigned char i;

  ClrWdt();

  ANSELA=0;
  ANSELB=0;
  ANSELC=0;
  ANSELD=0;
  ANSELE=0;
  ANSELF=0;
  ANSELG=0;

  LATA=0b0000000001000000;		// SCS
  LATB=0b0000000000000000;
  LATC=0b0010000000011000;		// DCS; RD, WR
  LATD=0b0001000000110000;		// ECS, WCS, SDCS
  LATE=0b0000000000000000;
  LATF=0b0000000000001000;		// ACS
  LATG=0b1100000000000001;		// VCS, RCS, EIDE_WINCE_reset
  
  TRISA=0b1100010010001000;       // sw-PGood; AIRQ, SIRQ, EIRQ, DIRQ
  TRISB=0b0000000000000000;       // 
  TRISC=0b0000000000000000;
  TRISD=0b0000000000000100;       //  SDI, SDO, SCK
  TRISE=0b0000000100000000;       // led; SDCD; PMP
#if defined(USA_USB_SLAVE_CDC)
	TRISF=0b0000000000000011;			// USBID; VIRQ, WINCIRQ
#else
//	TRISF=0b0000000000001011;			// USBID; VIRQ, WINCIRQ
	TRISF=0b0000000000000011;			// ma c'� ACS su RF3...
#endif
  TRISG=0b0000000000000001;			// DDRQ
//  TRISH=0x0000000000000000;
  

//    InitializeUSART();

 
	mInitAllLEDs();
  mInitAllSwitches();

//  CNPUDbits.CNPUD9=CNPUDbits.CNPUD10=1;   // [I2C tanto per] ev. gli IRQ?
  CNPUA=0b1100010010001000;   // 
//  CNPUB=0b1111111111111111;   // serve?
  CNPUC=0b0100000000000000;   // 
  CNPUD=0b0100000000000100;   // 
  CNPUE=0b0100000011111111;   // altrimenti la PMP fluttua..
  CNPUF=0b0000000000000011;   // 
  CNPUG=0b0000000000000001;   // 
#if defined(USA_USB_SLAVE_CDC)
  CNPUFbits.CNPUF3=1;   // USBID; ma forse se ne occupa lo stack USB...
#else
  CNPUFbits.CNPUF3=0;   // USBID; ma forse se ne occupa lo stack USB...
  CNPDFbits.CNPDF3=1;   // USBID; DICE che dev'essere pulldown per host! v. usbhs_host_drv
#endif



	  IPC30bits.CNFIP=3; IPC30bits.CNFIS=3;
//    CNPUBbits.CNPUB15=1;   // IRQ pullup
    CNENFbits.CNIEF1=0;
    CNNEFbits.CNNEF1=1;
    CNCONFbits.ON=1; CNCONFbits.EDGEDETECT=1;
	  IPC29bits.CNAIP=3; IPC29bits.CNAIS=3;
    CNENAbits.CNIEA3=0;
    CNNEAbits.CNNEA3=1;
    CNENAbits.CNIEA7=0;
    CNNEAbits.CNNEA7=1;
    CNENAbits.CNIEA15=0;
    CNNEAbits.CNNEA15=1;
    CNCONAbits.ON=1; CNCONAbits.EDGEDETECT=1;
	  IPC30bits.CNCIP=3; IPC30bits.CNCIS=3;
    CNENCbits.CNIEC14=0;
    CNNECbits.CNNEC14=1;
    CNCONCbits.ON=1; CNCONCbits.EDGEDETECT=1;
// mettere se serve	  IPC31bits.CNGIP=3; IPC31bits.CNGIS=3;
//    CNENGbits.CNIEG0=0;
//    CNNEGbits.CNNEG0=1;
//    CNCONGbits.ON=1; CNCONGbits.EDGEDETECT=1;

//  Timer_Init(50000);



// init PMP
  PMCON= 0b000000100000001100000000;     // tutti segnali attivi low; (no CS1 & 2 ?????); WR & RD; dual buffer mode 
  PMMODE=0b0000001011111111;             // max wait state; 8bit; no irq; master mode 2
  // cos� fa ~190nS write, 1/12/21; in teoria sarebbero 4+16+2= 22*10nS
  PMAEN =0b0000000000111111;             // BA0..5
  
  PMCONbits.ON=1;
  
	// bah qua non ci serve, direi
//  IPC32bits.PMPIP=3; IPC32bits.PMPIS=2;
//  IEC4bits.PMPIE=1;


  IFS3bits.CNAIF=0; // i vari IRQ
  IEC3bits.CNAIE=1; // 
  IFS3bits.CNCIF=0; // 
  IEC3bits.CNCIE=1; // 
  IFS3bits.CNFIF=0; // 
  IEC3bits.CNFIE=1; // 
//  IFS3bits.CNGIF=0; // 
//  IEC3bits.CNGIE=1; // 

 
  }	//end UserInit

void mySYSTEMConfigPerformance(void) {
  unsigned int PLLIDIV;
  unsigned int PLLMUL;
  unsigned int PLLODIV;
  float CLK2USEC;
  unsigned int SYSCLK;
  unsigned char PLLODIVVAL[]={
    2,2,4,8,16,32,32,32
    };
	unsigned int cp0;

  PLLIDIV=SPLLCONbits.PLLIDIV+1;
  PLLMUL=SPLLCONbits.PLLMULT+1;
  PLLODIV=PLLODIVVAL[SPLLCONbits.PLLODIV];

  SYSCLK=(FOSC*PLLMUL)/(PLLIDIV*PLLODIV);
  CLK2USEC=SYSCLK/1000000.0f;

  SYSKEY = 0x00000000;
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;

  if(SYSCLK<=60000000L)
    PRECONbits.PFMWS=0;
  else if(SYSCLK<=120000000L)
    PRECONbits.PFMWS=1;
  else if(SYSCLK<=210000000L)
    PRECONbits.PFMWS=2;
  else if(SYSCLK<=252000000L)
    PRECONbits.PFMWS=4;
  else
    PRECONbits.PFMWS=7;

  PRECONbits.PFMSECEN=0;    // non c'� nella versione "2019" ...
  PRECONbits.PREFEN=0x1;

  SYSKEY = 0x00000000;

    // PBnDIV se servisse!
//    PB4DIVbits.ON = 1; // Peripheral Bus 4 Output Clock Enable (Output clock is enabled)
//    while (!PB4DIVbits.PBDIVRDY); // Wait until it is ready to write to
//    PB4DIVbits.PBDIV = 0; // Peripheral Bus 4 Clock Divisor Control (PBCLK4 is SYSCLK divided by 1)

  // Set up caching
#warning VERIFICARE CACHING trovato in giro!
  cp0 = _mfc0(16, 0);
  cp0 &= ~0x07;
  cp0 |= 0b011; // K0 = Cacheable, non-coherent, write-back, write allocate
  _mtc0(16, 0, cp0);  

  }

void myINTEnableSystemMultiVectoredInt(void) {

  PRISS = 0x76543210;
  INTCONSET = _INTCON_MVEC_MASK /*0x1000*/;    //MVEC
  __builtin_enable_interrupts();
  }


#warning NON C'E' EEPROM!
void EEwrite(int addr,BYTE n) {	// 
  unsigned int i;
  
  i=DataEERead(addr/4);
  switch(addr & 3) {
    case 0:
      i &= 0xffffff00;
      i |= n;
      break;
    case 1:
      i &= 0xffff00ff;
      i |= ((unsigned int)n << 8);
      break;
    case 2:
      i &= 0xff00ffff;
      i |= ((unsigned int)n << 16);
      break;
    case 3:
      i &= 0x00ffffff;
      i |= ((unsigned int)n << 24);
      break;
    }
  DataEEWrite(i,addr/4);
  }
BYTE EEread(int addr) {
  unsigned int i;
  
  i=DataEERead(addr/4);
  switch(addr & 3) {
    case 0:
      return i & 0xff;
      break;
    case 1:
      return (i >> 8) & 0xff;
      break;
    case 2:
      return (i >> 16) & 0xff;
      break;
    case 3:
      return (i >> 24) & 0xff;
      break;
    }
  }

void EEinit(void) {
  
  DataEEInit();
	ClrWdt();
// bah, ma serve??  dataEEFlags.val = 0;
//  Nop();
//  Nop();
  }



char commandLine[128],lastCommandLine[128];
int commandLineCnt=0;

int runCmdInterpreter(void) {
  BYTE ch;
  int i;
  char *cmdPointer;
  
  if(keypress) {
    
    ch=keypress;
    
		WritePMP(VIDEO_CARD,BIOS_VIDEO_CHAR,keypress); 
		keypress=0;
    
    cmdPointer=&commandLine[0];   // per warning...
            
    if(commandLineCnt<sizeof(commandLine)) {
      commandLine[commandLineCnt++]=toupper(ch);
      if(ch=='\x8') {
        // backspace
        commandLine[commandLineCnt--]=0;
        }
      else if(ch=='\n') {
        commandLine[commandLineCnt--]=0;            // pulisco cmq il successivo, in caso di prec. comando lungo..
        commandLine[commandLineCnt]=0;            // tolgo LF
        }
      
      strcpy(lastCommandLine,commandLine);
      
      if(!strnicmp(commandLine,"BASIC",5)) {
        minibasic();
        }
      else if(!strnicmp(commandLine,"DIR",3)) {

        }
      else if(!strnicmp(commandLine,"FORMAT",6)) {

        }
      else if(!stricmp(commandLine,"CLS")) {
        WritePMP(VIDEO_CARD,BIOS_VIDEO_CLS,0);
        }
      else if(!strnicmp(commandLine,"ECHO",4)) {
        // gestire on/off
        print(commandLine+6);
        }
      else if(!strnicmp(commandLine,"DATE",4)) {
        char buf[16];
        print("Current date is: ");
        sprintf(buf,"%02u/%02u/%04u\r\n",1,1,1 /* FINIRE */);
        print(buf);
        }
      else if(!strnicmp(commandLine,"TIME",4)) {
        char buf[16];
        print("Current time is: ");
        sprintf(buf,"%02u:%02u:%02u\r\n",1,1,1 /* FINIRE */);
        print(buf);
        }
      else if(!stricmp(commandLine,"REBOOT")) {

        }
      else {      // cercare BATch sul disco :)
        print("Unrecognized command\n");
        }
      
      commandLineCnt=0;
      commandLine[0]=0;
      }
    }
  
  return 1;
  }


void __attribute__((used)) __delay_us(unsigned int usec) {
  unsigned int tWait, tStart;

  tWait=(GetSystemClock()/2000000UL)*usec;
  tStart=_mfc0(9,0);
  while((_mfc0(9,0)-tStart)<tWait)
    ClrWdt();        // wait for the time to pass
  }

void __attribute__((used)) __delay_ms(unsigned int ms) {
  
  for(;ms;ms--)
    __delay_us(1000);
  }

// USB host (harmony madonna puttana) ------------------------------------------
/*******************************************************************************
  Function:
    void APP_Initialize(void)

  Remarks:
    See prototype in app.h.
 */
#define APP_LED_BLINK_COUNT 100000

#define APP_USB_SWITCH_DEBOUNCE_COUNT 260


APP_DATA appData __attribute__((coherent)) __attribute__((aligned(16)));



#if defined(USA_USB_HOST_UVC)
// Specify the Video Stream format details that this application supports
const APP_USB_HOST_UVC_STREAM_FORMAT videoStreamFormat = {
    
  .streamDirection = USB_HOST_UVC_DIRECTION_IN,
  .wWidth=320,
  .wHeight=240,
  .bitPerPixel=32,
  .format=0
/*    .format = USB_AUDIO_FORMAT_PCM,
    .nChannels = 2,
    .bitResolution = 16,
    .subFrameSize = 2,
    .samplingRate = 48000*/
  }; 
#endif

void APP_Initialize(void) {

#if defined(USA_USB_HOST)
  // Place the App state machine in its initial state.
  appData.state =  APP_STATE_BUS_ENABLE;
  appData.deviceIsConnected = false;
#if defined(USA_USB_HOST_UVC)
  APP_VideoDataSetDefault();
#endif
#endif
  
  /* TODO: Initialize your application's state machine and other
   * parameters.
   */
#if defined(USA_USB_SLAVE_CDC)
    // Place the App state machine in its initial state.
    appData.state = APP_STATE_INIT;
    
    // Device Layer Handle
    appData.deviceHandle = USB_DEVICE_HANDLE_INVALID;

    // Device configured status
    appData.isConfigured = false;

    // Initial get line coding state
    appData.getLineCodingData.dwDTERate = 115200;
    appData.getLineCodingData.bParityType =  0;
    appData.getLineCodingData.bParityType = 0;
    appData.getLineCodingData.bDataBits = 8;

    // Read Transfer Handle
    appData.readTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;

    // Write Transfer Handle
    appData.writeTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;

    // Initialize the read complete flag
    appData.isReadComplete = false;

    // Initialize the write complete flag
    appData.isWriteComplete = true;

    // Reset other flags 
    appData.sofEventHasOccurred = false;
#endif

  }

#if defined(USA_USB_HOST_UVC)
void APP_VideoDataSetDefault(void) {
  
  appData.isVideoDeviceAttached = false;
  appData.isVideoInStreamFound = false; 
  appData.isVideoWriteCompleted = false;
  appData.isVideoReadCompleted = false;
  appData.isStreamEnabled = false;
  appData.isStreamInterfaceSetZeroComplete = false;
  appData.isStreamInterfaceSetOneComplete = false;
  appData.requestHandle = USB_HOST_UVC_REQUEST_HANDLE_INVALID;
  appData.transferHandleVideoWrite = USB_HOST_UVC_STREAM_TRANSFER_HANDLE_INVALID;
  appData.transferHandleVideoRead = USB_HOST_UVC_STREAM_TRANSFER_HANDLE_INVALID;

  appData.isMuteSwitchPressed = false; 
  appData.ignoreSwitchPress = true;
  appData.sofEventHasOccurred = false; 
  
  // Set following to true until we start parsing descriptors
  appData.width=0;
  appData.height=0;
  appData.bitsPerPixel=0;



  }
#endif


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
#if defined(USA_USB_SLAVE_CDC)
void APP_USBDeviceEventHandler(USB_DEVICE_EVENT event, void *eventData, uintptr_t context);
#endif

void APP_Tasks(void) {
  char buf[16];
//  USB_HOST_UVC_RESULT videoResult;
  static DWORD countLedBlink = 0,divider=0;
  static BYTE test,cnt;
  static BYTE oldState; 
  DWORD interruptStatus;
  bool status = false; 
  
  divider++;
  if(divider>500000L || appData.state!=oldState) {
//    printf(".appState=%u\r\n",appData.state);
//  putsUART1(buf);
    divider=0;
    
    test=!test;
  
    WritePMP(SOUTH_BRIDGE,BIOS_SERIAL_WRITE,test ? '.' : ' '); 
    
    
  DrawLine(cnt*2,cnt,80,64, sw1 ? 0xf800 : 0x000f);
  /*if(cnt<128)
    SetVideoMode(MODE_VGA,640,480,8);      //
  else
    SetVideoMode(MODE_LCD_DMA,160,120,16);      //*/
    
  // incorporato SetAudioMode(SYNTH);
//  SetAudioWave(0,TRIANGOLARE,sw1 /*test*/ ? 2000 : 500,2,8,80,0,0);
  if(sw1)
    SetAudioFrequency(0,sw1 ? 600 : 2000);
  else
    SetAudioWave(0,SINUSOIDALE,test ? 2000 : 600,1,8,70,0,0);

//  status=ReadPMP(AUDIO_CARD,BIOS_GETID);
  printf("%02X ",status);
    
//    WritePMP(sw1 ? VIDEO_CARD : AUDIO_CARD, cnt, test ? '.' : 'A'); 
//    WritePMP(sw1 ? VIDEO_CARD : AUDIO_CARD, cnt, test ? '1' : '2'); 
    cnt++;
    


    if(!sw1)
      OC1CONbits.ON=1;    // PROVE!
    else
      OC1CONbits.ON=0;    // 
    
    oldState=appData.state;
    }
  
//    mLED_1 ^= 1;     //  ~1.3uS/330KHz 1/12/21
  countLedBlink++;
  if(countLedBlink >= APP_LED_BLINK_COUNT) {
    mLED_1 ^= 1;     //  
    countLedBlink = 0; 
    }


  ClrWdt();
  

#ifdef USA_USB_HOST_MSD
#if 0 // era per minibasic da pendrive
  appData.fileHandle = SYS_FS_FileOpen(script, SYS_FS_FILE_OPEN_READ);
  if(appData.fileHandle == SYS_FS_HANDLE_INVALID) {
    // Could not open the file. Error out
    return -1;
    }
  else {
    char *p;
    int i;
    BYTE *script;
    
    i=SYS_FS_FileSize(appData.fileHandle);
//   	printf((STRINGFARPTR)".. trovato file, %u",i);
    script=scriptAllocated=malloc(i+10 /* patch*/ );
//    SYS_FS_FileRead(appData.fileHandle,script,i);
    p=script;
    while(i--) {
      SYS_FS_FileRead(appData.fileHandle,p,1);
      if(isprint(*p) || *p=='\n')    // tolgo i CR/ecc al volo (sotto non va... v.)
        p++;
      }
    SYS_FS_FileClose(appData.fileHandle);
    }
#endif
#endif


  // Check the application's current state.
  switch(appData.state) {
    
#if defined(USA_USB_HOST_MSD)
#endif
#if defined(USA_USB_HOST_UVC)

    case APP_STATE_BUS_ENABLE:


        appData.state = APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE; 
      break; 

    case APP_STATE_WAIT_FOR_BUS_ENABLE_COMPLETE:
        appData.state = APP_STATE_WAIT_FOR_DEVICE_ATTACH;
      break; 
			
    case APP_STATE_WAIT_FOR_DEVICE_ATTACH:

      appData.state = APP_STATE_ZERO_BANDWIDTH_INTERFACE_SET;
      break; 

    case APP_STATE_ZERO_BANDWIDTH_INTERFACE_SET:
        appData.state = APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ZERO; 
      break;

    case APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ZERO:
        appData.state = APP_STATE_WAIT_FOR_SET_PROBE_VIDEO;
      break; 
            
    case APP_STATE_WAIT_FOR_SET_PROBE_VIDEO:
        appData.state = APP_STATE_WAIT_FOR_GET_PROBE_VIDEO;
      break;

    case APP_STATE_WAIT_FOR_GET_PROBE_VIDEO:
        appData.state = APP_STATE_WAIT_FOR_SET_COMMIT_VIDEO;
      break;

    case APP_STATE_WAIT_FOR_SET_COMMIT_VIDEO:
        appData.state = APP_STATE_ENABLE_VIDEO_STREAM; 
      break;

    case APP_STATE_ENABLE_VIDEO_STREAM:
      appData.isStreamInterfaceSetComplete = false;

        appData.state = APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ONE;
      break; 

    case APP_STATE_WAIT_FOR_VIDEO_STREAM_INTERFACE_SET_ONE:
        appData.state = APP_STATE_START_STREAM_DATA;
        
      break; 

    case APP_STATE_START_STREAM_DATA:
      appData.state = APP_STATE_WAIT_FOR_READ_COMPLETE; 
      break;

    case APP_STATE_WAIT_FOR_READ_COMPLETE:
      /* mettere codice per gestire webcam... */
      appData.state = APP_STATE_WAIT_FOR_READ_COMPLETE; 
      break;
#endif

#if defined(USA_USB_SLAVE_CDC)
    case APP_STATE_INIT:
        // Open the device layer
        appData.deviceHandle = USB_DEVICE_Open(USB_DEVICE_INDEX_0, DRV_IO_INTENT_READWRITE);

        if(appData.deviceHandle != USB_DEVICE_HANDLE_INVALID)            {
            // Register a callback with device layer to get event notification (for endpoint 0)
            USB_DEVICE_EventHandlerSet(appData.deviceHandle, APP_USBDeviceEventHandler, 0);

            appData.state = APP_STATE_WAIT_FOR_CONFIGURATION;
          }
        else            {
            /* The Device Layer is not ready to be opened. We should try again later. */
        }

        break;

    case APP_STATE_WAIT_FOR_CONFIGURATION:
        // Check if the device was configured
        if(appData.isConfigured)            {
            /* If the device is configured then lets start reading */
            appData.state = APP_STATE_SCHEDULE_READ;

            appData.isReadComplete = false;
            appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;

            USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
                    &readBuffer, APP_READ_BUFFER_SIZE);

            if(appData.readTransferHandle == USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID)                {
                appData.state = APP_STATE_ERROR;
                break;
            }
        }
        break;

    case APP_STATE_SCHEDULE_READ:
//            if(APP_StateReset()) {
//                break;
//            }


        //Check if any bytes are waiting in the queue to send to the USB host.
//If any bytes are waiting, and the endpoint is available, prepare to
//send the USB packet to the host.
        if( /*(appData.isWriteComplete==true) && */ (NextUSBOut > 0)) {
//              memcpy(writeBuffer,USB_Out_Buffer,NextUSBOut);   // buffer allineati e di % 512!!
          appData.writeTransferHandle = USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
          USB_DEVICE_CDC_Write(USB_DEVICE_CDC_INDEX_0, &appData.writeTransferHandle,
            &writeBuffer, NextUSBOut, USB_DEVICE_CDC_TRANSFER_FLAGS_DATA_COMPLETE);
          appData.isWriteComplete=false;
          NextUSBOut=0;
          }

        /*

if(RS232_Out_Data_Rdy == 0) { // only check for new USB buffer if the old RS232 buffer is
                            // empty.  This will cause additional USB packets to be NAK'd
            USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
                    &readBuffer, APP_READ_BUFFER_SIZE);
memcpy(USB_In_Buffer,readBuffer,APP_READ_BUFFER_SIZE);
LastRS232Out = getsUSBUSART(USB_In_Buffer,64); //until the buffer is free.
if(LastRS232Out > 0) {	
  RS232_Out_Data_Rdy = 1;  // signal buffer full
  RS232cp = 0;  // Reset the current position
  }
}


*/

        break;

#endif
      

    case APP_STATE_ERROR:
      countLedBlink++; 
//        appData.state =  APP_STATE_WAIT_FOR_DEVICE_ATTACH;
      break; 

    case APP_STATE_IDLE:

      /* The application comes here when the demo has completed
       * successfully. Provide LED indication. Wait for device detach
       * and if detached, wait for attach. */

//        mLED_1 ^= 1;
      break;

    // The default state should never be executed.
    default:
      Nop(); 
      break;

    }
	}



// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

#if defined(USA_USB_HOST_UVC)
void APP_ProcessSwitchPress(void) {
  
  /* This function checks if the switch is pressed and then
   * debounces the switch press*/
  if(!sw1) {
      if(appData.ignoreSwitchPress) {
          // This means the key press is in progress
          if(appData.sofEventHasOccurred) {
              // A timer event has occurred. Update the debounce timer
              appData.switchDebounceTimer ++;
              appData.sofEventHasOccurred = false;

              if(appData.switchDebounceTimer == APP_USB_SWITCH_DEBOUNCE_COUNT) {
                  /* Indicate that we have valid switch press. The switch is
                   * pressed flag will be cleared by the application tasks
                   * routine. We should be ready for the next key press.*/
                  appData.isMuteSwitchPressed = true;
                  appData.switchDebounceTimer = 0;
                  appData.ignoreSwitchPress = false;
              }
          }
        }
      else {
        // We have a fresh key press
        appData.ignoreSwitchPress = true;
        appData.switchDebounceTimer = 0;
        }
      }
  else {
      // No key press. Reset all the indicators.
      appData.ignoreSwitchPress = false;
      appData.switchDebounceTimer = 0;
      appData.sofEventHasOccurred = false;
    }

  }
#endif

#ifdef USA_USB_HOST_MSD
void APP_SYSFSEventHandler(SYS_FS_EVENT event, void *eventData, uintptr_t context) {
  
  switch(event) {
    case SYS_FS_EVENT_MOUNT:
      appData.deviceIsConnected = true;
      break;

    case SYS_FS_EVENT_UNMOUNT:
      appData.deviceIsConnected = false;
      break;

    default:
      break;
    }
  }
#endif


// -----------------------------------------------------------------------------
#ifdef USA_WIFI
void wifi_cb(BYTE u8MsgType, void *pvMsg) {
  
  switch(u8MsgType) {
      case M2M_WIFI_REQ_DHCP_CONF:
      {
        m2m_wifi_get_connection_info();
        BYTE *pu8IPAddress = (BYTE *)pvMsg;
//        wifi_connected = 1;
        /* Turn LED0 on to declare that IP address received. */
//        m2m_periph_gpio_set_dir(4, 1);    // get_gpio_idx(
//        m2m_periph_gpio_set_val(4, 0);
//        port_pin_set_output_level(LED_0_PIN, false);
//        printf("m2m_wifi_state: M2M_WIFI_REQ_DHCP_CONF: IP is %u.%u.%u.%u\n",
//          pu8IPAddress[0], pu8IPAddress[1], pu8IPAddress[2], pu8IPAddress[3]);
        /*TODO: add socket initialization here. */
        registerSocketCallback(clientSocketEventHandler, NULL);
        tcpStartServer(80);
        udpClientStart("192.168.1.2");

				m2m_wifi_get_sytem_time();   // va direttamente in now!

//        setStatusLed(LED_NORMALE_CONNESSO_WIFI);
//        play();
//        advertise(UDPclientSocket);      // 

      }
        break;
      case M2M_WIFI_RESP_CON_STATE_CHANGED:   // https://www.avrfreaks.net/forum/winc1500-connecting-wifi-disconnects-immediately-error-code-1
      {
        tstrM2mWifiStateChanged *strState=(tstrM2mWifiStateChanged *)pvMsg;
        switch(strState->u8CurrState) {
          case M2M_WIFI_DISCONNECTED:
            m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,1);
            close(UDPclientSocket);
            UDPclientSocket=INVALID_SOCKET;
            close(TCPlistenSocket);   // in effetti, chiss� se serve...
            close(TCPacceptedSocket);
            TCPacceptedSocket=TCPlistenSocket=INVALID_SOCKET;
            bIsfinished = 0;
            break;
          case M2M_WIFI_CONNECTED:
            // messo sopra...
            m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,0);
            m2m_wifi_req_curr_rssi();
            break;
          case M2M_WIFI_ROAMED:
            break;
          case M2M_WIFI_UNDEF:
            break;
          }

      }
        break;
      case M2M_WIFI_RESP_CONN_INFO:
      {
        tstrM2MConnInfo *pstrConnInfo = (tstrM2MConnInfo *)pvMsg;

        m2m_periph_gpio_set_dir(M2M_PERIPH_GPIO15,1);    // GP15 su pdf (v. cmq setpin ecc)
        m2m_periph_gpio_set_dir(M2M_PERIPH_GPIO16,1);    // GP16 su pdf 
        m2m_periph_gpio_set_dir(M2M_PERIPH_GPIO18,1);    // GP18 su pdf schema FROCI! (opp. 6 merdeee get_gpio_idx) RIFATTO IO
        m2m_periph_gpio_set_val(M2M_PERIPH_GPIO15,1);
        m2m_periph_gpio_set_val(M2M_PERIPH_GPIO16,1);
        m2m_periph_gpio_set_val(M2M_PERIPH_GPIO18,0);


        printf("AP Connection Information\r\n*********************************\r\n"); 
        myIp.sin_addr.s_addr=MAKELONG(MAKEWORD(pstrConnInfo->au8IPAddr[0], pstrConnInfo->au8IPAddr[1]), MAKEWORD(pstrConnInfo->au8IPAddr[2], pstrConnInfo->au8IPAddr[3]));
        printf("Local IP Address    : %d.%d.%d.%d\r\n",
          pstrConnInfo->au8IPAddr[0] , pstrConnInfo->au8IPAddr[1], pstrConnInfo->au8IPAddr[2], pstrConnInfo->au8IPAddr[3]);
        printf("SSID             : %s\r\n",pstrConnInfo->acSSID);
        printf("SEC TYPE         : %d\r\n",pstrConnInfo->u8SecType);
        printf("AP MAC Address        : %02x:%02x:%02x:%02x:%02x:%02x\r\n",
          pstrConnInfo->au8MACAddress[0], pstrConnInfo->au8MACAddress[1],pstrConnInfo->au8MACAddress[2],pstrConnInfo->au8MACAddress[3],
          pstrConnInfo->au8MACAddress[4],pstrConnInfo->au8MACAddress[5]);
        printf("Signal Strength        : %d\r\n", pstrConnInfo->s8RSSI);
        printf("Current Channel        : %d\r\n", pstrConnInfo->u8CurrChannel);   
      }
        break;
    case M2M_WIFI_RESP_GET_SYS_TIME: 
      { 
      tstrSystemTime *mytime = (tstrSystemTime *)pvMsg; 
//      printf("wifi_cb:M2M_WIFI_RESP_GET_SYS_TIME \r\n"); 
//      printf("My hour %d \r\n",mytime->u8Hour); 
//      printf("My min %d \r\n",mytime->u8Minute); 
//      printf("My sec %d \r\n",mytime->u8Second); 
      uint16_t y;
      uint16_t m;
      uint16_t d;
      DWORD t;
//https://www.oryx-embedded.com/doc/date__time_8c_source.html
      
      //Year
      y = mytime->u16Year;
      //Month of year
      m = mytime->u8Month;
      //Day of month
      d = mytime->u8Day;

      //January and February are counted as months 13 and 14 of the previous year
      if(m <= 2) {
        m += 12;
        y -= 1;
        }

      //Convert years to days
      t = (365 * y) + (y / 4) - (y / 100) + (y / 400);
      //Convert months to days
      t += (30 * m) + (3 * (m + 1) / 5) + d;
      //Unix time starts on January 1st, 1970
      t -= 719561;
      //Convert days to seconds
      t *= 86400;
      //Add hours, minutes and seconds
      t += (3600 * mytime->u8Hour) + (60 * mytime->u8Minute) + mytime->u8Second;
      now=t;

      } 
      break; 
    case M2M_WIFI_RESP_CURRENT_RSSI:
      myRSSI=*(BYTE *)pvMsg;
      break; 
    default:
      {
      }
      break;
    }
  }

/* Socket event handler.
*/

// This is the DNS callback. The response of gethostbyname is here.
void dnsResolveCallback(BYTE* pu8HostName, DWORD u32ServerIP) {
  struct sockaddr_in strAddr;
  BYTE u8Flags=0;   // boh??
  
  if(u32ServerIP != 0) {
    DNSclientSocket = socket(AF_INET,SOCK_STREAM,u8Flags);
    if(DNSclientSocket >= 0) {
      strAddr.sin_family = AF_INET;
      strAddr.sin_port = _htons(80);
      strAddr.sin_addr.s_addr = u32ServerIP;
      connect(DNSclientSocket, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
      M2M_INFO("DNS fatto\r\n");
      }
    }
  else {
    M2M_INFO("DNS Resolution Failed\n");
    }
  }

 
/* This function needs to be called from main function. For the callbacks to be invoked correctly, the API
  m2m_wifi_handle_events should be called continuously from main. */
void tcpStartServer(uint16 u16ServerPort) {
  struct sockaddr_in strAddr;
  
  // Register socket application callbacks.
//  registerSocketCallback(tcpServerSocketEventHandler, NULL);
  // Create the server listen socket.
  TCPlistenSocket = socket(AF_INET, SOCK_STREAM, 0);
  if(TCPlistenSocket >= 0) {
    strAddr.sin_family = AF_INET;
    strAddr.sin_port = _htons(u16ServerPort);
    strAddr.sin_addr.s_addr = 0; //INADDR_ANY
    bind(TCPlistenSocket, (struct sockaddr*)&strAddr, sizeof(struct sockaddr_in));
    }
  }

void udpClientStart(const char *pcServerIP) {
  struct sockaddr_in strAddr;
  BYTE u8Flags=0;   // boh??
  BYTE rxBuffer[100];
  DWORD u32EnableCallbacks=0;
  
  // Register socket application callbacks.
//  registerSocketCallback(udpClientSocketEventHandler, NULL);
  UDPclientSocket = socket(AF_INET,SOCK_DGRAM /*SOCK_STREAM*/,u8Flags);
  if(UDPclientSocket >= 0) {
    uint16 len;
    strAddr.sin_family = AF_INET;
    strAddr.sin_port = _htons(55555);
    strAddr.sin_addr.s_addr = nmi_inet_addr(pcServerIP /* INADDR_ANY */);
    // SOLO SERVER!!  bind(UDPclientSocket,&strAddr,sizeof(struct sockaddr_in));
    //https://sudonull.com/post/91650-Office-lighting-control-over-Wi-Fi-Part-1-Atmel-WINC1500-Wi-Fi-module-Rainbow-Blog
    bind(UDPclientSocket,(struct sockaddr *)&strAddr,sizeof(struct sockaddr_in));
    // Format some message in the acSendBuffer and put its length in len
    
 
  	setsockopt(UDPclientSocket, SOL_SOCKET, SO_SET_UDP_SEND_CALLBACK, &u32EnableCallbacks, 4);
  
    int i=sendto(UDPclientSocket, rxBuffer, 90, 0, (struct sockaddr*)&strAddr,
      sizeof(struct sockaddr_in));
//    i=recvfrom(UDPclientSocket, tempBuff, 1536, 0, NULL, 0);
    
//        m_Led1Bit ^= 1;		// CHECK 

    }
  }

const char *HTTP_SERVER_OK="HTTP/1.1 200 OK\r\n";
const char *HTTP_SERVER_ERR="HTTP/1.1 404 Not found\r\n";
const char *HTTP_SERVER_HEADER="Server: PC_PIC/1.0\r\nDate: 20/9/2021 12:00:00\r\nContent-type: %s\r\nContent-length: %u\r\n\r\n";
const char *HTTP_SERVER_HEAD2="<html><head><title>PC_PIC WebServer</title><meta http-equiv='refresh' content=60></head>\r\n";
const char *HTTP_SERVER_HEAD="<html><head><title>PC_PIC WebServer</title></head>\r\n";
// mettere <meta http-equiv="refresh" content="30">
const char *HTTP_SERVER_PAGE="<body bgcolor='#00c0d8'><center><h2><img src='logo.gif'> PC_PIC</h2></center><br><br>%s %s<br>\r"
  "<i>Versione: %u.%02u; Chip: %08X, RFrev: %x; CPU: PIC32MZ 2048KB ROM 512KB RAM</i><br>\n"
  "<a href='stato.html'>Stato</a><br>\n"
  "<a href='config.html'>Configurazione</a><br>\n"
  "<a href='provaled.cgi'>test led</a><br>\n"
  "<br><a href='http://cyberdyne.biz.ly'>Home page Dario's Automation</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_STATO_PAGE="<body bgcolor='#00d0b0'><center><b>Stato di PC_PIC</b></center><br><br>\n"
  "RSSI: %u<br>\n"
  "UnixTime: %u<br>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_CONFIG_PAGE="<body bgcolor='#a05040' textcolor='#fff0f0'><center><b>Configurazione BestPicPlayer</b></center><br><br>\n"
	"<form method=post action='config.cgi'\n>"
	"Access point: <input type='text' name='ap' value='%s'><br>\n"
	"Indirizzo IP: <input type='text' name='ip' value='%u.%u.%u.%u'><br>\n"
	"Porta: <input type='text' name='port' value='%u'><br>\n"
	"DHCP: <input type='checkbox' checked name='dhcp' value='%u'><br>\n"      // sistemare... checked
	"<input type=submit value=\"Imposta\"><br>\n"
	"</form>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";
const char *HTTP_PROVALED_PAGE="<body><center><b>Led/GPIO test</b></center><br><br>\n"
  "fatto<br>\n"
  "<br><a href='/'>Torna indietro</a><br>\n"
  "</body></html>\r\n";

const unsigned char HTTP_LEDICON[]={
  0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x20, 0x00, 0x20, 0x00, 0xF7, 0x00, 0x00, 0x00, 0x00, 0xFF, 
  0x00, 0x31, 0x31, 0x00, 0x31, 0xCE, 0x00, 0x63, 0x63, 0x00, 0x63, 0x9C, 0x00, 0x63, 0xCE, 0x00, 
  0x63, 0xFF, 0x00, 0x84, 0x84, 0x00, 0x9C, 0xFF, 0x00, 0xCE, 0xFF, 0x00, 0xFF, 0xFF, 0x31, 0x31, 
  0x31, 0x31, 0x31, 0x63, 0x31, 0x63, 0x63, 0x31, 0x63, 0x9C, 0x31, 0x9C, 0x63, 0x31, 0xCE, 0xCE, 
  0x4A, 0x4A, 0x4A, 0x52, 0x52, 0x52, 0x5A, 0x5A, 0x5A, 0x63, 0x63, 0x31, 0x63, 0x63, 0x63, 0x63, 
  0x63, 0x9C, 0x63, 0x63, 0xCE, 0x63, 0x9C, 0x9C, 0x63, 0x9C, 0xCE, 0x73, 0x73, 0x73, 0x84, 0x84, 
  0x84, 0x94, 0x94, 0x94, 0x9C, 0x63, 0x31, 0x9C, 0x63, 0x63, 0x9C, 0x9C, 0x63, 0x9C, 0x9C, 0x9C, 
  0x9C, 0x9C, 0xCE, 0x9C, 0xCE, 0xCE, 0xA5, 0xA5, 0xA5, 0xA5, 0xCE, 0xF7, 0xAD, 0xAD, 0x94, 0xC6, 
  0xC6, 0xC6, 0xCE, 0x63, 0x9C, 0xCE, 0x9C, 0x63, 0xCE, 0x9C, 0x9C, 0xCE, 0xCE, 0x63, 0xCE, 0xCE, 
  0x9C, 0xCE, 0xCE, 0xCE, 0xCE, 0xEF, 0xFF, 0xD6, 0xD6, 0xD6, 0xDE, 0xDE, 0xDE, 0xFF, 0x7B, 0x84, 
  0xFF, 0x9C, 0x9C, 0xFF, 0xCE, 0x9C, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x21, 0xF9, 0x04, 
  0x01, 0x00, 0x00, 0x07, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x20, 0x00, 0x00, 0x08, 
  0xFE, 0x00, 0x0F, 0x08, 0x1C, 0x48, 0xB0, 0xA0, 0xC1, 0x03, 0x03, 0x18, 0x48, 0x18, 0x70, 0xB0, 
  0xA1, 0x43, 0x82, 0x03, 0x1C, 0x58, 0x60, 0xF8, 0xB0, 0xE2, 0x81, 0x06, 0x14, 0x3E, 0xA8, 0x50, 
  0x81, 0x02, 0x83, 0x85, 0x06, 0x16, 0x1D, 0x06, 0xD0, 0x90, 0x42, 0x86, 0x49, 0x93, 0x21, 0x32, 
  0x7C, 0x88, 0x40, 0x31, 0xE4, 0xC0, 0x00, 0x1F, 0x4E, 0xCA, 0x4C, 0xB9, 0x42, 0x06, 0x85, 0x96, 
  0x2E, 0x3B, 0x9C, 0x2C, 0xC1, 0x21, 0x05, 0x87, 0x12, 0x19, 0x32, 0xD4, 0x94, 0x11, 0xC1, 0xA5, 
  0xC0, 0x06, 0x27, 0x57, 0x70, 0xB8, 0xC0, 0xC1, 0x42, 0x53, 0xA6, 0x35, 0x51, 0x80, 0x0C, 0x39, 
  0x20, 0xA6, 0x49, 0x0E, 0x24, 0xB2, 0x6A, 0x25, 0x21, 0x82, 0x83, 0xC9, 0x09, 0x2E, 0x1B, 0xA0, 
  0x30, 0xE9, 0x93, 0x04, 0x88, 0xB3, 0x20, 0x38, 0x80, 0xE8, 0x6A, 0xF2, 0x83, 0xCB, 0x07, 0x27, 
  0x37, 0x60, 0x3D, 0x11, 0xA3, 0x2E, 0x0C, 0x0F, 0x6C, 0x65, 0xA0, 0x78, 0x7B, 0xD2, 0x29, 0x89, 
  0x14, 0x75, 0x63, 0xDC, 0xCD, 0xAB, 0x82, 0xAF, 0x49, 0xBF, 0x80, 0xED, 0xE2, 0xF5, 0x2A, 0xA3, 
  0x70, 0xC8, 0x07, 0x43, 0x65, 0x60, 0x4D, 0xAB, 0x96, 0x03, 0x56, 0xC6, 0x6E, 0xA9, 0x8E, 0xBD, 
  0xDA, 0xA2, 0xB3, 0xE7, 0x16, 0x24, 0x18, 0x53, 0x30, 0x8A, 0x94, 0x33, 0x89, 0x10, 0xA8, 0x43, 
  0x98, 0x08, 0x2D, 0x23, 0xC5, 0x54, 0xCD, 0x9C, 0x3F, 0x77, 0x66, 0x5D, 0xC1, 0xA8, 0xC0, 0x05, 
  0x63, 0x39, 0xB4, 0x30, 0x91, 0x3A, 0x44, 0xD6, 0x0D, 0x1F, 0x02, 0xD8, 0xBE, 0x8D, 0x42, 0x77, 
  0x8B, 0x17, 0x2E, 0x90, 0x83, 0x96, 0x20, 0x7C, 0xB8, 0xC0, 0x01, 0x15, 0x5A, 0xB8, 0x30, 0x41, 
  0x7D, 0x35, 0x89, 0xD7, 0xCE, 0xA1, 0x77, 0xAE, 0x6E, 0x1D, 0xFB, 0xF0, 0x01, 0x12, 0xB6, 0x70, 
  0x6A, 0x0D, 0xC1, 0xC0, 0x39, 0x44, 0x07, 0xE8, 0xD3, 0xA3, 0xC7, 0x69, 0xDE, 0xA8, 0x00, 0x02, 
  0x02, 0xE2, 0xCB, 0x27, 0xD0, 0x7E, 0x60, 0x7C, 0x04, 0x0A, 0xF2, 0xE7, 0x47, 0x60, 0xA0, 0x00, 
  0x7D, 0xE7, 0xF2, 0x09, 0xA0, 0xC0, 0x06, 0x10, 0x40, 0xA0, 0x5F, 0x02, 0x08, 0xFC, 0xE7, 0x1C, 
  0x01, 0x04, 0x18, 0xA0, 0x80, 0x07, 0x0A, 0x40, 0xB0, 0xC1, 0x06, 0xFB, 0x29, 0x68, 0x1B, 0x83, 
  0x0E, 0x42, 0xF8, 0xA0, 0x7E, 0x0A, 0x00, 0x10, 0xDF, 0x70, 0x18, 0x6E, 0x28, 0xA2, 0x02, 0x09, 
  0x08, 0x30, 0x5C, 0x80, 0x09, 0x88, 0x68, 0x20, 0x89, 0x05, 0x98, 0x07, 0x5F, 0x01, 0x1C, 0x92, 
  0x88, 0x40, 0x01, 0x26, 0x9A, 0xF7, 0x9E, 0x01, 0x38, 0xE6, 0xE8, 0x9F, 0x85, 0xB6, 0x05, 0x04, 
  0x00, 0x3B
  };

sint16 sendEx(SOCKET sock, void *pvSendBuffer, uint16 u16SendLength) {
  uint16 n,n2;
//  WORD tOut;
  int i;
//  DWORD u32EnableCallbacks=1;

// 	setsockopt(sock, SOL_SOCKET, SO_SET_UDP_SEND_CALLBACK, &u32EnableCallbacks, 4);
#if 0     // non va.. � molto lento (le callback arrivano male, pare un bug) e spesso con -1... 
  do {
    n=min(u16SendLength,SOCKET_BUFFER_MAX_LENGTH);
    if(send(sock, pvSendBuffer, n, 0) == SOCK_ERR_NO_ERROR) {
      tOut=0;
      internetBufferLen=0;
      while(!internetBufferLen && tOut<1000) {
        while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS)
          ClrWdt();
        tOut++;
        __delay_ms(1);
        }
      n=internetBufferLen;
      }
    else
      break;
    pvSendBuffer+=n;
    u16SendLength-=n;
    } while(u16SendLength);
#endif

  n2=0;
  do {
    n=min(u16SendLength,SOCKET_BUFFER_MAX_LENGTH);
rifo:
    if((i=send(sock, pvSendBuffer, n, 0)) == SOCK_ERR_NO_ERROR) {
      // alle volte arriva SOCK_ERR_INVALID -9 in callback... checcazz'�?? parrebbe invalid ovvero magari socket chiuso... ma cmq non uso + la callback
      while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS) {
        ClrWdt();
        }
      }
    else {
//      printf("sendex: %d\r\n",i);
      while(m2m_wifi_handle_events(NULL) != M2M_SUCCESS) {
        ClrWdt();
        }
      switch(i) {
        case SOCK_ERR_BUFFER_FULL:
          goto rifo;
          break;
//        case -3:
        // arriva -3=SOCK_ERR_MAX_TCP_SOCK che non ha senso... di tanto, v. di l�
//          goto rifo;
//          break;
        case SOCK_ERR_INVALID_ARG:    // per socket chiuso... ma il close non arriva cmq se interrompo un download lungo (wireshark dice di s�)
          break;
        default:
          goto fine;
          break;
        }
      }
    pvSendBuffer+=n;
    n2+=n;
    u16SendLength-=n;
    } while(u16SendLength);
    
fine:

  return n2;
  }

/* Socket event handler */
void clientSocketEventHandler(SOCKET sock, BYTE u8Msg, void *pvMsg) {
  int ret;
//  BYTE buff[2048];
  
  if(sock==UDPclientSocket)
  switch(u8Msg) {
    case SOCKET_MSG_BIND:
		{
			tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg *)pvMsg;
			if(pstrBind && pstrBind->status == 0) {
				// Prepare next buffer reception. 
//				recv(sock, tempBuff, 1536, 0);
        } 
			else {
//				printf("socket_cb: bind error!\r\n");
        }
		} 
    case SOCKET_MSG_RECV:
    case SOCKET_MSG_RECVFROM:
    {
      tstrSocketRecvMsg *pstrRecvMsg = (tstrSocketRecvMsg*)pvMsg;

      WORD nRead;

//      m_Led1Bit ^= 1;		// CHECK 
      // qua arrivano circa ogni 10mS... su wireshark/PC/wired dice 500uS...
      

 			if(pstrRecvMsg->s16BufferSize > 0) {
				//get the remote host address and port number

          
//				ret = recvfrom(sock,tempBuff,1024+VBAN_HEADER_SIZE /*1536*/,0 /*TEST_RECV_TIMEOUT*/, NULL, 0);
        // con 1536 il datagram + corto, l'ultimo del pacchetto, arriva in ritardo... pare andare in timeout: bisognerebbe sapere quanto manca...
        // con 1024+header sembra meglio
    		}
      else {
        /* Prepare next buffer reception. */
//        recvfrom(sock, tempBuff, 1024 /*1536*/, 0, NULL, 0);
        }
/*			else			{
//				printf("Socket recv Error: %d\n",pstrRx->s16BufferSize);
				ret = close(sock);
      	}*/
invalid_packet:
	;


    }
      break;
    case SOCKET_MSG_SEND:
    case SOCKET_MSG_SENDTO:
      break;
    case SOCKET_MSG_CLOSE: 
      ret = close(sock);
      UDPclientSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
  else if(sock==TCPlistenSocket)
  switch(u8Msg) {
    case SOCKET_MSG_BIND:
      {
      tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg*)pvMsg;
      if(pstrBind->status == 0) {
        listen(TCPlistenSocket, 0);
        }
      else {
        printf("Bind Failed\n");
        }
      }
      break;
    case SOCKET_MSG_LISTEN:
      {
      tstrSocketListenMsg *pstrListen = (tstrSocketListenMsg*)pvMsg;
      if(pstrListen->status != 0) {
        M2M_INFO("listen Failed\n");
        }
      }
      break;
    case SOCKET_MSG_ACCEPT:
      {
      // New Socket is accepted.
      tstrSocketAcceptMsg *pstrAccept = (tstrSocketAcceptMsg *)pvMsg;
      if(pstrAccept->sock >= 0) {
        // Get the accepted socket.
        if(TCPacceptedSocket==INVALID_SOCKET)
          ;

        TCPacceptedSocket = pstrAccept->sock;
        recv(TCPacceptedSocket, rxBuffer, sizeof(rxBuffer), 0);
        }
      else {
        M2M_INFO("Accept Failed\n");
        }
      }
      break;
    case SOCKET_MSG_RECV:

      break;
    case SOCKET_MSG_SEND:
    {
      int sentBytes = *((sint16*)pvMsg);
//      internetBufferLen=sentBytes;
    }
    case SOCKET_MSG_CLOSE:
      bIsfinished=TRUE;
      close(TCPlistenSocket);   // in effetti, chiss� se serve...
      close(TCPacceptedSocket);
      TCPacceptedSocket=TCPlistenSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
  else if(sock==TCPacceptedSocket)
  switch(u8Msg) {
    case SOCKET_MSG_RECV:
      {
      tstrSocketRecvMsg *pstrRecvMsg = (tstrSocketRecvMsg*)pvMsg;
      if((pstrRecvMsg->pu8Buffer) /*&& (pstrRecvMsg->s16BufferSize > 0)*/) {
        // Process the received message
        // Perform data exchange
        BYTE acHeadBuffer[256],acSendBuffer[512];
        // Fill in the acSendBuffer with some data here
        // Send some data.
        
        if(!strncmp(pstrRecvMsg->pu8Buffer,"GET",3)) {    // stricmp non c'�... diocheffroci 
          //m2m_stricmp
          if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/stato.html",11)) {
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_STATO_PAGE,
                    myRSSI,
										now);
  //          printf("Chip ID : \r\t\t\t%x\r\n", (unsigned int)nmi_get_chipid());
  //	printf("RF Revision ID : \r\t\t\t%x\r\n", (unsigned int)nmi_get_rfrevid());
            goto send_refreshed_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/config.html",12)) {
            sendEx(sock, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_CONFIG_PAGE,"wlan_greggio",   // finire pstrConnInfo->acSSID
                    LOBYTE(LOWORD(myIp.sin_addr.s_addr)),
                    HIBYTE(LOWORD(myIp.sin_addr.s_addr)),
                    LOBYTE(HIWORD(myIp.sin_addr.s_addr)),
                    HIBYTE(HIWORD(myIp.sin_addr.s_addr)),
                    80,
                    1 /*dhcp*/);
send_standard_page:
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"text/html",strlen(acSendBuffer)+strlen(HTTP_SERVER_HEAD));
            sendEx(TCPacceptedSocket, acHeadBuffer, strlen(acHeadBuffer));
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_HEAD, strlen(HTTP_SERVER_HEAD));
            goto send_standard_body;
            /*	tstrM2MIPConfig conf;

    if (!_init) {
      init();
    }

    conf.u32DNS = (DWORD)dns_server;
    conf.u32Gateway = (DWORD)gateway;
    conf.u32StaticIP = (DWORD)local_ip;
    conf.u32SubnetMask = (DWORD)subnet;
    _dhcp = 0;
    m2m_wifi_enable_dhcp(0); // disable DHCP
    m2m_wifi_set_static_ip(&conf);
    _localip = conf.u32StaticIP;
    _submask = conf.u32SubnetMask;
    _gateway = conf.u32Gateway;*/
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/provaled.cgi",13)) {
            BYTE i;
            if(pstrRecvMsg->pu8Buffer[17]=='?') {
              i=pstrRecvMsg->pu8Buffer[18]=='1';
              }
            else {
              m2m_periph_gpio_get_val(3,&i);    // v. anche get_gpio_idx
              }
            m2m_periph_gpio_set_val(3,!i);    // non va dio merda si spegne solo
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            strcpy(acSendBuffer,HTTP_PROVALED_PAGE);
            goto send_standard_page;
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/logo.gif",9)) {
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"image/gif",sizeof(HTTP_LEDICON));
            sendEx(TCPacceptedSocket, acHeadBuffer, strlen(acHeadBuffer));
            sendEx(TCPacceptedSocket, (char *)HTTP_LEDICON, sizeof(HTTP_LEDICON));
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/index.html",11)) {
            goto index_page;
            }
          else if(pstrRecvMsg->pu8Buffer[4]=='/' && pstrRecvMsg->pu8Buffer[5]==' ') {
index_page:
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            sprintf(acSendBuffer,HTTP_SERVER_PAGE,
                    nmi_get_chipid(),nmi_get_rfrevid());
send_refreshed_page:
            sprintf(acHeadBuffer,HTTP_SERVER_HEADER,"text/html",strlen(acSendBuffer)+strlen(HTTP_SERVER_HEAD2));
            sendEx(TCPacceptedSocket, acHeadBuffer, strlen(acHeadBuffer));
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_HEAD2, strlen(HTTP_SERVER_HEAD2));
send_standard_body:
            sendEx(TCPacceptedSocket, acSendBuffer, strlen(acSendBuffer));
            }
          else if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/copyright.html",15)) {
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_OK, strlen(HTTP_SERVER_OK));
            strcpy(acSendBuffer,_PC_PIC_CPU_C);
            goto send_standard_page;
            }
          else {
send_non_trovato:
            sendEx(TCPacceptedSocket, (char *)HTTP_SERVER_ERR, strlen(HTTP_SERVER_ERR));
            strcpy(acSendBuffer,"Non trovato.\r\n");
            goto send_standard_page;
            }
          }
        else if(!strncmp(pstrRecvMsg->pu8Buffer,"POST",4)) {    // stricmp non c'�... diocheffroci
          if(!strncmp(pstrRecvMsg->pu8Buffer+4,"/config.cgi",11)) {
goto send_non_trovato; //FARE!
            }
          }
        else
          goto invalid_request;   // 
        
        // Recv response from client. bah serve davvero??
        recv(TCPacceptedSocket, rxBuffer, sizeof(rxBuffer), 0);
        
invalid_request:        
        bIsfinished=1;    // non � il massimo...
         
        // Close the socket when finished.
        if(bIsfinished) {
          close(TCPacceptedSocket);
          TCPacceptedSocket=INVALID_SOCKET;
//          close(TCPlistenSocket);
          }
        }
      }
      break;
    case SOCKET_MSG_CLOSE:    // diofa non c'era!
      bIsfinished=TRUE;
      close(TCPacceptedSocket);
      TCPacceptedSocket=INVALID_SOCKET;
      break;
    default:
      break;
    }
      
  }


#endif



int SetVideoMode(BYTE mode,uint16_t xres,uint16_t yres,BYTE bpp) {
  BYTE parms[16];
  
  parms[0]=mode;
  parms[1]=LOBYTE(xres);
  parms[2]=HIBYTE(xres);
  parms[3]=LOBYTE(yres);
  parms[4]=HIBYTE(yres);
  parms[5]=bpp;
  
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_MODE,parms,6);
  while(!m_VIRQ)
    ClrWdt();
  }

int DrawLine(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,GFX_COLOR c) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(x1);
  parms[1]=HIBYTE(x1);
  parms[2]=LOBYTE(y1);
  parms[3]=HIBYTE(y1);
  parms[4]=LOBYTE(x2);
  parms[5]=HIBYTE(x2);
  parms[6]=LOBYTE(y2);
  parms[7]=HIBYTE(y2);
  parms[8]=LOBYTE(c);
  parms[9]=HIBYTE(c);
  
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_LINE,parms,10);
  while(!m_VIRQ)
    ClrWdt();
  }

int DrawRectangle(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,GFX_COLOR c) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(x1);
  parms[1]=HIBYTE(x1);
  parms[2]=LOBYTE(y1);
  parms[3]=HIBYTE(y1);
  parms[4]=LOBYTE(x2);
  parms[5]=HIBYTE(x2);
  parms[6]=LOBYTE(y2);
  parms[7]=HIBYTE(y2);
  parms[8]=LOBYTE(c);
  parms[9]=HIBYTE(c);
  
  WritePMPs(VIDEO_CARD,BIOS_VIDEO_RECTANGLE,parms,10);
  while(!m_VIRQ)
    ClrWdt();
  }

int SetAudioMode(BYTE type) {
  BYTE parms[16];
  
  parms[0]=type;
  
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETMODE,parms,1);
  while(!m_AIRQ)
    ClrWdt();
  }

int SetAudioWave(BYTE channel,BYTE type,WORD freq,BYTE chan,BYTE bits,BYTE volume,BYTE mode,BYTE effect) {
  BYTE parms[16];
  
  parms[0]=channel;
  parms[1]=type;
  parms[2]=LOBYTE(freq);
  parms[3]=HIBYTE(freq);
  parms[4]=chan;
  parms[5]=bits;
  parms[6]=volume;
  parms[7]=mode;
  parms[8]=effect;
  
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETWAVE,parms,9);
  while(!m_AIRQ)
#warning magari lasciando il WD? cos� nel caso si resetta...
    ClrWdt();
  }

int SetAudioFrequency(BYTE channel,WORD freq) {
  BYTE parms[16];
  
  parms[0]=channel;
  parms[1]=LOBYTE(freq);
  parms[2]=HIBYTE(freq);
  
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETFREQUENCY,parms,3);
  while(!m_AIRQ)
    ClrWdt();
  }

int SetSerialPort(DWORD baud,BYTE bits,BYTE par,BYTE stop) {
  BYTE parms[16];
  
  parms[0]=LOBYTE(LOWORD(baud));
  parms[1]=HIBYTE(LOWORD(baud));
  parms[2]=LOBYTE(HIWORD(baud));
  parms[3]=HIBYTE(HIWORD(baud));
  parms[4]=bits;
  parms[5]=par;
  parms[6]=stop;
  
  WritePMPs(SOUTH_BRIDGE,BIOS_SERIAL_INIT,parms,7);
  }
  
int SetParallelPort(BYTE mode) {
  BYTE parms[16];
  
  parms[0]=mode;
  
  WritePMPs(SOUTH_BRIDGE,BIOS_PARALLEL_INIT,parms,1);
//  while(!m_SIRQ)
    ClrWdt();
  }
  
int SetJoystick(BYTE mode) {
  BYTE parms[16];
  
  parms[0]=mode;
  
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETJOYSTICK,parms,1);
  while(!m_AIRQ)
    ClrWdt();
  }
  
int SetMidi(BYTE mode) {
  BYTE parms[16];
  
  parms[0]=mode;
  
  WritePMPs(SOUTH_BRIDGE,BIOS_AUDIO_INITMIDI,parms,1);
  while(!m_AIRQ)
    ClrWdt();
  }
  
int SetRTCC(BYTE d,BYTE m,uint16_t y,BYTE H,BYTE M,BYTE S) {
  BYTE parms[16];
  
  parms[0]=d;
  parms[1]=m;
  parms[2]=LOBYTE(y);
  parms[3]=HIBYTE(y);
  parms[4]=H;
  parms[5]=M;
  parms[6]=S;
  
  WritePMPs(AUDIO_CARD,BIOS_AUDIO_SETCLOCK,parms,7);
  while(!m_AIRQ)
    ClrWdt();
  }

void WritePMP(enum BUS bus,BYTE addr,BYTE data) {
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      m_SCS=0;
      break;
    }
		__delay_us(1);
  PMWADDR=addr & 63;
  PMDOUT=data;   // il FRM dice PMDIN ma PORCODIO non � vero figli del cancro #stuprigeorgepauley
  // ah in un angolo precisa che dipende dal "DUALBUF" di PMCON...
  PMPWaitBusy();
		__delay_us(1);
  m_VCS=m_ACS=m_SCS=1;    // ottimizzare PIC32
  }

void WritePMPs(enum BUS bus,BYTE addr,BYTE data[],BYTE len) {
  BYTE n;
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      m_SCS=0;
      break;
    }
  PMWADDR=addr & 63;
		__delay_us(1);
  for(n=0; n<len; n++) {
    PMDOUT=data[n];
    PMPWaitBusy();
		__delay_us(1);
    }
  m_VCS=m_ACS=m_SCS=1;    // ottimizzare PIC32
  }

BYTE ReadPMP(enum BUS bus,BYTE addr) {
	BYTE data;
  
  switch(bus) {
    case VIDEO_CARD:
      m_VCS=0;
      break;
    case AUDIO_CARD:
      m_ACS=0;
      break;
    case SOUTH_BRIDGE:
      m_SCS=0;
      break;
    }
  PMRADDR=addr & 63; // o viceversa??? addr=PMRADDR
		__delay_us(1);
  data=PMDIN;
//  PMPWaitBusy();
		__delay_us(1);
  m_VCS=m_ACS=m_SCS=1;    // ottimizzare PIC32
	return data;
  }

int print(char *s) {
  
  while(*s)
    WritePMP(VIDEO_CARD,BIOS_VIDEO_CHAR,*s++);
  }



#ifdef USA_232
void InitializeUSART(void) {

  U6MODE=0b0000000000001000;    // BRGH=1
  U6STA= 0b0000010000000000;    // TXEN
  unsigned long baudRateDivider = ((GetPeripheralClock()/(4*BAUDRATE))-1);
  U6BRG=baudRateDivider;
  U6MODEbits.ON=1;

	}



char BusyUART1(void) {
  
  return !U6STAbits.TRMT;
  }

void putsUART1(unsigned char *buffer) {

// transmit till NULL character is encountered 

  while(*buffer) {
    while(U6STAbits.UTXBF);  /* wait if the buffer is full */
    U6TXREG = *buffer++;   /* transfer data byte to TX reg */
    }
  }

unsigned int ReadUART1(void) {
  
  if(U6MODEbits.PDSEL == 3)
    return (U6RXREG);
  else
    return (U6RXREG & 0xFF);
  }

void WriteUART1(unsigned int data) {
  
  if(U6MODEbits.PDSEL == 3)
    U6TXREG = data;
  else
    U6TXREG = data & 0xFF;
  }
#endif

void Timer_Init(void) {
  
  T4CON=0;
  T4CONbits.TCS = 0;            // clock from peripheral clock
  T4CONbits.TCKPS = 0b010;      // 1:4 prescaler 
  T4CONbits.T32 = 0;            // 16bit
  PR4 = 6250;                   // 4KHz x buzzer
  
  T4CONbits.TON = 1;    // start timer (for pwm)
  }
  
void PWM_Init(void) {

// v. init sopra  CFGCONbits.OCACLK=1;      // sceglie timer per PWM ossia Timer6 ;) [serve SYSLOCK cmq)
  
  OC1CON = 0x0006;      // TimerX ossia Timer6; PWM mode no fault; Timer 16bit, TimerX
  OC1R    = 6250/2;		 // su PIC32 � read-only!
  OC1RS   = 6250/2;      // 50%, relativo a PR2 del Timer6
  OC1CONbits.ON=0;    // on

  }



void __ISR(_PMP_VECTOR,ipl3SRS) PMP_ISR(void) {
  
  IFS4CLR = _IFS4_PMPIF_MASK;
  }


void __ISR ( _CHANGE_NOTICE_A_VECTOR, IPL3SRS ) CNAInt(void) {
  BYTE which;
  
  if(m_AIRQ_CN) {
    which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 
    switch(which) {
      case 0:
        break;
      }
    m_AIRQ_CN=0;
    }
  if(m_SIRQ_CN) {
    which=ReadPMP(SOUTH_BRIDGE,BIOS_IRQ_REQUEST);		// 
    switch(which) {
      case 0:
        keypress=ReadPMP(SOUTH_BRIDGE,BIOS_KEYBOARD_READ);		// FINIRE
        break;
      }
    m_SIRQ_CN=0;
    }
  if(m_EIRQ_CN) {
    m_EIRQ_CN=0;
    }
  
  PORTA;    // va bene fatto dopo, o prima o ...?
  IFS3bits.CNAIF=0;
  }

void __ISR ( _CHANGE_NOTICE_C_VECTOR, IPL3SRS ) CNCInt(void) {
  BYTE which;
  
// DIRQ	which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 

  PORTC;
  CNFC=0;
  IFS3bits.CNCIF=0;
  }

void __ISR ( _CHANGE_NOTICE_F_VECTOR, IPL3SRS ) CNFInt(void) {
  
// VIRQ
  vLine++;

  PORTF;
  CNFF=0;
  IFS3bits.CNFIF=0;
  }

void __ISR ( _CHANGE_NOTICE_G_VECTOR, IPL3SRS ) CNGInt(void) {
  BYTE which;
  
//DDRQ	which=ReadPMP(AUDIO_CARD,BIOS_IRQ_REQUEST);		// 

  PORTG;
  CNFG=0;
  IFS3bits.CNGIF=0;
  }


#ifdef USA_USB_SLAVE_CDC
// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************
USB_DEVICE_CDC_EVENT_RESPONSE APP_USBDeviceCDCEventHandler(
    USB_DEVICE_CDC_INDEX index, USB_DEVICE_CDC_EVENT event,
    void *pData, uintptr_t userData) {
    APP_DATA *appDataObject;
    appDataObject = (APP_DATA *)userData;
    USB_CDC_CONTROL_LINE_STATE *controlLineStateData;
    USB_DEVICE_CDC_EVENT_DATA_READ_COMPLETE *eventDataRead; 

    switch(event) {
        case USB_DEVICE_CDC_EVENT_GET_LINE_CODING:
            /* This means the host wants to know the current line
             * coding. This is a control transfer request. Use the
             * USB_DEVICE_ControlSend() function to send the data to host.  */
            USB_DEVICE_ControlSend(appDataObject->deviceHandle,
                    &appDataObject->getLineCodingData, sizeof(USB_CDC_LINE_CODING));
            break;

        case USB_DEVICE_CDC_EVENT_SET_LINE_CODING:
            /* This means the host wants to set the line coding.
             * This is a control transfer request. Use the
             * USB_DEVICE_ControlReceive() function to receive the data from the host */
            USB_DEVICE_ControlReceive(appDataObject->deviceHandle,
                    &appDataObject->setLineCodingData, sizeof(USB_CDC_LINE_CODING));
            break;

        case USB_DEVICE_CDC_EVENT_SET_CONTROL_LINE_STATE:
            /* This means the host is setting the control line state.
             * Read the control line state. We will accept this request for now. */
            controlLineStateData = (USB_CDC_CONTROL_LINE_STATE *)pData;
            appDataObject->controlLineStateData.dtr = controlLineStateData->dtr;
            appDataObject->controlLineStateData.carrier = controlLineStateData->carrier;

            USB_DEVICE_ControlStatus(appDataObject->deviceHandle, USB_DEVICE_CONTROL_STATUS_OK);
            break;

        case USB_DEVICE_CDC_EVENT_SEND_BREAK:
            /* This means that the host is requesting that a break of the
             * specified duration be sent. Read the break duration */
            appDataObject->breakData = ((USB_DEVICE_CDC_EVENT_DATA_SEND_BREAK *)pData)->breakDuration;
            
            /* Complete the control transfer by sending a ZLP  */
            USB_DEVICE_ControlStatus(appDataObject->deviceHandle, USB_DEVICE_CONTROL_STATUS_OK);
            break;

        case USB_DEVICE_CDC_EVENT_READ_COMPLETE:
            // This means that the host has sent some data
            eventDataRead = (USB_DEVICE_CDC_EVENT_DATA_READ_COMPLETE *)pData;
            appDataObject->isReadComplete = true;
            appDataObject->numBytesRead = eventDataRead->length;
            if(RS232_Out_Data_Rdy == false) { // only check for new USB buffer if the old RS232 buffer is
                                          // empty.  This will cause additional USB packets to be NAK'd
              LastRS232Out=eventDataRead->length;
              if(LastRS232Out>0) {	
                memcpy(USB_In_Buffer,readBuffer,LastRS232Out); //until the buffer is free.
                RS232_Out_Data_Rdy = true;  // signal buffer full
                RS232cp = 0;  // Reset the current position
                }
            appData.isReadComplete=false;
            appData.readTransferHandle =  USB_DEVICE_CDC_TRANSFER_HANDLE_INVALID;
            USB_DEVICE_CDC_Read(USB_DEVICE_CDC_INDEX_0, &appData.readTransferHandle, 
              &readBuffer, APP_READ_BUFFER_SIZE);
              }
            break;

        case USB_DEVICE_CDC_EVENT_CONTROL_TRANSFER_DATA_RECEIVED:
            /* The data stage of the last control transfer is
             * complete. For now we accept all the data */
            USB_DEVICE_ControlStatus(appDataObject->deviceHandle, USB_DEVICE_CONTROL_STATUS_OK);
            break;

        case USB_DEVICE_CDC_EVENT_CONTROL_TRANSFER_DATA_SENT:
            /* This means the GET LINE CODING function data is valid. We dont
             * do much with this data in this demo. */
            break;

        case USB_DEVICE_CDC_EVENT_WRITE_COMPLETE:
            // This means that the data write got completed. We can schedule the next read.
            appDataObject->isWriteComplete = true;
            NextUSBOut=0;
            break;

        default:
            break;
    }

  return USB_DEVICE_CDC_EVENT_RESPONSE_NONE;
  }
/***********************************************
 * Application USB Device Layer Event Handler.
 ***********************************************/
void APP_USBDeviceEventHandler(USB_DEVICE_EVENT event, void *eventData, uintptr_t context) {
    USB_DEVICE_EVENT_DATA_CONFIGURED *configuredEventData;

    switch(event) {
        case USB_DEVICE_EVENT_SOF:
            /* This event is used for switch debounce. This flag is reset
             * by the switch process routine. */
            appData.sofEventHasOccurred = true;
            break;

        case USB_DEVICE_EVENT_RESET:
            /* Update LED to show reset state */
//            APP_USB_LED_1=1;
//            APP_USB_LED_2=1;    
//            APP_USB_LED_3=1;

            appData.isConfigured = false;
            break;

        case USB_DEVICE_EVENT_CONFIGURED:
            // Check the configuration. We only support configuration 1
            configuredEventData = (USB_DEVICE_EVENT_DATA_CONFIGURED*)eventData;
            if(configuredEventData->configurationValue == 1)             {
                // Update LED to show configured state 
//                APP_USB_LED_1=0;
//                APP_USB_LED_2=0;
//                APP_USB_LED_3=0;

                /* Register the CDC Device application event handler here.
                 * Note how the appData object pointer is passed as the user data */
                USB_DEVICE_CDC_EventHandlerSet(USB_DEVICE_CDC_INDEX_0, APP_USBDeviceCDCEventHandler, (uintptr_t)&appData);

                // Mark that the device is now configured 
                appData.isConfigured = true;

              }
            break;

        case USB_DEVICE_EVENT_POWER_DETECTED:
            // VBUS was detected. We can attach the device 
            USB_DEVICE_Attach(appData.deviceHandle);
            break;

        case USB_DEVICE_EVENT_POWER_REMOVED:
            // VBUS is not available any more. Detach the device. 
            USB_DEVICE_Detach(appData.deviceHandle);
            break;

        case USB_DEVICE_EVENT_SUSPENDED:
            // Switch LED to show suspended state 
//            APP_USB_LED_1=0;
//            APP_USB_LED_2=0;
//            APP_USB_LED_3=0;
            break;

        case USB_DEVICE_EVENT_RESUMED:
        case USB_DEVICE_EVENT_ERROR:
        default:
            break;
    }
  }
#endif

void __attribute__((noreturn)) SoftReset(void) {
  
    SYS_INT_Disable();
    // perform a system unlock sequence, starting critical sequence
    SYSKEY = 0x00000000; //write invalid key to force lock
    SYSKEY = 0xAA996655; //write key1 to SYSKEY
    SYSKEY = 0x556699AA; //write key2 to SYSKEY
    // set SWRST bit to arm reset
    RSWRSTSET = 1;
    // read RSWRST register to trigger reset
    unsigned int dummy;
    dummy = RSWRST;
    // prevent any unwanted code execution until reset occurs
    while(1);
  }

void Sleep(void) {
  // https://www.microchip.com/forums/m1099882.aspx
  // https://www.microchip.com/forums/m991184.aspx
  
  // anche SYS_DEVCON_PowerModeEnter()
  
/*  //Slow down CPU clock
  asm volatile ( "di" );
  SYSKEY = 0x0;
  SYSKEY = 0xAA996655;
  SYSKEY = 0x556699AA;
  // SYSCLK divided by 256
  OSCCONbits.PLLODIV = 7; //0.3125 MHz 
  // Wait for stable PLL clock
  while( !OSCCONbits. .SLOCK ); 
  // Sleep mode after WAIT instruction
  OSCCONSET = 0x10;
 
  // Force lock
  SYSKEY = 0x0; 
  asm volatile ( "ei" );
  */

   
  asm volatile("di");
  SYSKEY = 0x0; // Ensure OSCCON is locked
  SYSKEY = 0xAA996655; // Write Key1 to SYSKEY
  SYSKEY = 0x556699AA; // Write Key2 to SYSKEY
  OSCCONbits.SLPEN=1;

  SYSKEY = 0x0; // Ensure OSCCON is locked
        
  asm volatile("ei");
  asm volatile("wait"); 
  
  }




