/* 
 * File:   interrupt.c
 * Author: katia ;) (e vediamo)
 *
 * Created on 30/8/21
 * 
 * 
 */

#include <xc.h>
#include "pc_pic_video.h"
#include <sys/attribs.h>
#include <sys/kmem.h>

#include "Adafruit_ST7735.h"


extern volatile unsigned int Timer;
extern volatile DWORD vLine;
extern BYTE DMA_READY videoRAM[640L*480];  
extern WORD verticalLines,horizontalPixels;
extern enum VIDEO_MODE videoMode;

#define PMPWaitBusy()   //while(!PMSTATbits.OBE);     // VERIFICARE, credo non serva su slave...



void __ISR(_UART1_RX_VECTOR,IPL4SRS) UART1_ISR(void) {
  
//  LATDbits.LATD4 ^= 1;    // LED to indicate the ISR.
  char curChar = U1RXREG;
  IFS3bits.U1RXIF = 0;  // Clear the interrupt flag!
  }

void __ISR(_DMA0_VECTOR,ipl5SRS) DMA_ISR(void) {
#warning PROVARE IPL7!!
  static BYTE myVSync=1;

/*  LATDINV=0X000F;     		// CHECK Timing!		min=160nS... v. timer
  DCH0INTCLR = _DCH0INT_CHSDIF_MASK;
  IFS4CLR = _IFS4_DMA0IF_MASK;  // Clear the interrupt flag!
  return;*/

  switch(videoMode) {
    case MODE_VGA:       // VGA
      if(myVSync) {
        if(vLine>=_height) {   // 
          vLine=0;
    //      VVSync=0;
    //      VIRQ = 0;
          LATDCLR=VIRQ_MASK | VVSYNC_MASK;
          myVSync=0;
          }
        }
      else {
        if(vLine>=50) {   // 10% circa
          vLine=0;
    //      VVSync=1;
    //      VIRQ = 1;
          LATDSET=VIRQ_MASK | VVSYNC_MASK;
          myVSync=1;
          }
        }

#ifdef PATCH_VGA 
      if(DCH0SSIZ==45 /* 17% circa */) {
        DCH0SSIZ=_width;
#ifndef USING_SIMULATOR
        DCH0SSA = KVA_TO_PA(((BYTE*)&videoRAM)+vLine*_width);  // transfer source physical address
#else
        DCH0SSA = &videoRAM;  // transfer source physical address
#endif
        vLine++;
        LATDSET=VHSYNC_MASK;
        }
      else {
        DCH0SSIZ=45;
        LATDCLR=VHSYNC_MASK;
        }
#else
      if(DCH0SSIZ==90 /* 17% circa */) {
        DCH0SSIZ=_width;
//        VHSync=1;
#ifndef USING_SIMULATOR
        DCH0SSA = KVA_TO_PA(((BYTE*)&videoRAM)+vLine*_width);  // transfer source physical address
#else
        DCH0SSA = &videoRAM;  // transfer source physical address
#endif
        vLine++;
        LATDSET=VHSYNC_MASK;
        }
      else {
        DCH0SSIZ=90;
//        VHSync=0;     // 125uS con 640x480 e Timer1=40
        LATDCLR=VHSYNC_MASK;
        // 82uS con T1=25; 64 con 20
        }
#endif
      break;
      
    case MODE_COMPOSITE:       // composito
      if(myVSync) {
        if(vLine>=_height) {   // 
          vLine=0;
          LATDCLR=VIRQ_MASK | VVSYNC_MASK;
          myVSync=0;
          }
        }
      else {
        if(vLine>=24) {   // 10% circa
          vLine=0;
          LATDSET=VIRQ_MASK | VVSYNC_MASK;
          myVSync=1;
          }
        }
      if(DCH0SSIZ==28 /* 18% circa */) {
        DCH0SSIZ=_width;
#ifndef USING_SIMULATOR
        DCH0SSA = KVA_TO_PA(((BYTE*)&videoRAM)+vLine*_width);  // transfer source physical address
#else
        DCH0SSA = &videoRAM;  // transfer source physical address
#endif
        vLine++;
        LATDSET=VHSYNC_MASK;
        }
      else {
        DCH0SSIZ=28;
        LATDCLR=VHSYNC_MASK;
        }
      break;

    case MODE_LCD:       // LCD SPI
      DCH0SSIZ=_width*4;    // TRUCCHETTO per avere un VIRQ ogni 50Hz circa! @160pixel
#ifndef USING_SIMULATOR
      DCH0SSA = KVA_TO_PA(((BYTE*)&videoRAM));  // qua "finto" cmq
#else
      DCH0SSA = &videoRAM;  // 
#endif
      
              LATDINV=VHSYNC_MASK;
              

      vLine++;
      if(myVSync) {
        if(vLine>=_height) {   // 
          vLine=0;
          LATDCLR=VIRQ_MASK;
          myVSync=0;
          }
        }
      else {
        if(vLine>=40) {   // 10% circa
          vLine=0;
          LATDSET=VIRQ_MASK;
          myVSync=1;
          }
        }
      break;

    case MODE_NONE:
      // spegnere video!
    default:
      break;
    }

/* 
 * SVGA Signal 800 x 600 @ 60 Hz timing

General timing
Screen refresh rate	60 Hz
Vertical refresh	37.878787878788 kHz
Pixel freq.	40.0 MHz
Horizontal timing (line)
Polarity of horizontal sync pulse is positive.

Scanline part	Pixels	Time [�s]
Visible area	800	  20
Front porch	  40	  1
Sync pulse	  128	  3.2
Back porch	  88	  2.2
Whole line	  1056	26.4
Vertical timing (frame)
Polarity of vertical sync pulse is positive.

Frame part	Lines	Time [ms]
Visible area	600	15.84
Front porch	  1	  0.0264
Sync pulse	  4	  0.1056
Back porch	  23	0.6072
Whole frame  	628	16.5792

Horizonal Timing

Horizonal Dots         640     640     640        
Vertical Scan Lines    350     400     480
Horiz. Sync Polarity   POS     NEG     NEG
A (us)                 31.77   31.77   31.77     Scanline time
B (us)                 3.77    3.77    3.77      Sync pulse lenght 
C (us)                 1.89    1.89    1.89      Back porch
D (us)                 25.17   25.17   25.17     Active video time
E (us)                 0.94    0.94    0.94      Front porch

         ______________________          ________
________|        VIDEO         |________| VIDEO (next line)
    |-C-|----------D-----------|-E-|
__   ______________________________   ___________
  |_|                              |_|
  |B|
  |---------------A----------------|

Vertical Timing

Horizonal Dots         640     640     640
Vertical Scan Lines    350     400     480
Vert. Sync Polarity    NEG     POS     NEG      
Vertical Frequency     70Hz    70Hz    60Hz
O (ms)                 14.27   14.27   16.68     Total frame time
P (ms)                 0.06    0.06    0.06      Sync length
Q (ms)                 1.88    1.08    1.02      Back porch
R (ms)                 11.13   12.72   15.25     Active video time
S (ms)                 1.2     0.41    0.35      Front porch

         ______________________          ________
________|        VIDEO         |________|  VIDEO (next frame)
    |-Q-|----------R-----------|-S-|
__   ______________________________   ___________
  |_|                              |_|
  |P|
  |---------------O----------------|

		

* "VGA industry standard" 640x480 pixel mode

General characteristics

Clock frequency 25.175 MHz
Line  frequency 31469 Hz
Field frequency 59.94 Hz

One line

  8 pixels front porch
 96 pixels horizontal sync
 40 pixels back porch
  8 pixels left border
640 pixels video
  8 pixels right border
---
800 pixels total per line

One field

  2 lines front porch
  2 lines vertical sync
 25 lines back porch
  8 lines top border
480 lines video
  8 lines bottom border
---
525 lines total per field              

Other details

Sync polarity: H negative, V negative
Scan type: non interlaced.

 * PAL/Composite
Bandwidth 	5 MHz[5]
Horizontal sync polarity 	Negative
Total time for each line 	64 ?s[6][7]
Front porch (A) 	1.65 +0.4?0.1 ?s
Sync pulse length (B) 	4.7�0.20 ?s
Back porch (C) 	5.7�0.20 ?s
Active video (D) 	51.95 +0.4?0.1 ?s
(Total horizontal sync time 12.05 �s)

After 0.9 �s a 2.25�0.23 ?s colour burst of 10�1 cycles is sent. Most rise/fall times are in 250�50 ns range. Amplitude is 100% for white level, 30% for black, and 0% for sync.[6] The CVBS electrical amplitude is Vpp 1.0 V and impedance of 75 ?.[8]
The composite video (CVBS) signal used in systems M and N before combination with a sound carrier and modulation onto an RF carrier.

The vertical timings are:
Parameter 	Value
Vertical lines 	312.5 (625 total)
Vertical lines visible 	288 (576 total)
Vertical sync polarity 	Negative (burst)
Vertical frequency 	50 Hz
Sync pulse length (F) 	0.576 ms (burst)[9]
Active video (H) 	18.4 ms
(Total vertical sync time 1.6 ms) 
*/


        
  DCH0INTCLR = _DCH0INT_CHSDIF_MASK;

  
  IFS4CLR = _IFS4_DMA0IF_MASK;  // Clear the interrupt flag!
  }

void __ISR(_DMA1_VECTOR,ipl2SRS) DMA1_ISR(void) {   // per LCD SPI in DMA

  if(DCH1INTbits.CHSHIF) {
    LATDCLR=VIRQ_MASK;
    DCH1INTCLR = _DCH1INT_CHBCIF_MASK | _DCH1INT_CHSHIF_MASK;
    }
  else if(DCH1INTbits.CHBCIF) {
    LATDSET=VIRQ_MASK;
    DCH1INTCLR = _DCH1INT_CHBCIF_MASK | _DCH1INT_CHSHIF_MASK;
    vLine++;
    if(vLine>=_height)
      vLine=0;
    m_SPICSBit = 1; 
    SPI1CONbits.MODE16=0;
    lcd_dirty=0;
    }
  IFS4CLR = _IFS4_DMA1IF_MASK;  // Clear the interrupt flag!
  }

void __ISR(_TIMER_1_VECTOR,ipl5SRS) TMR1_ISR(void) {
  BYTE *p=videoRAM;    // PROVA velocit� visto che DMA fa schifo
  int i;

  if(PR1 == 5500) {
    for(i=0; i<640; i++) {   // dice 2566 istruzioni... ~12.83uS con LATB e 1926 (9.63uS) con (BYTE*)LATB
      *(BYTE *)&LATB = i;// *p++;
      Nop();Nop();Nop();Nop();Nop();Nop();    // con queste siamo circa a 25.6uS, poi c'� il porch[amadonn] :D = 6~
      //5125 istruzioni
      }
    LATDCLR=VHSYNC_MASK;
    PR1=1000;
    }
  else {
    LATDSET=VHSYNC_MASK;
    PR1=5500;
    vLine++;
    }

  IFS0CLR = _IFS0_T1IF_MASK;
  }


void __ISR(_TIMER_2_VECTOR,ipl2SRS) TMR2_ISR(void) {
  
  Timer++;
//  LATF ^= 0xffff;     // test timing 3.2mS con PR2=10000 e PS=64 (Fclock periferiche/timer=200MHz!)
  IFS0CLR = _IFS0_T2IF_MASK;
  }

volatile BYTE commandParms[128],commandReceived;
void __ISR(_PMP_VECTOR,ipl3SRS) PMP_ISR(void) {
  BYTE addr,reg;
  static BYTE parmN=0,oldReg=0;
  
  // ovviamente VERIFICARE! se si usa IRQ anche altrove (raster irq)
//  addr=PMADDR & 63;   // in slave mode mi sa che non va, ma non importa
  addr=(PORTG >> 4) & 0b00111100;
  addr |= (PORTB >> 14) & 0b00000011;    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
  
//  while(!PMSTATbits.IBF)
//    ClrWdt();
  
  reg=addr;
  if(reg != oldReg) {
    oldReg=reg;
    parmN=0;
    }


  if(PMSTATbits.IBF) {
    if(commandReceived) {
      PMDIN;
      IFS4CLR = _IFS4_PMPIF_MASK;
      return;
      }
    switch(reg) {
      case 0:
        commandReceived=BIOS_INVALID;
        commandParms[parmN]=PMDIN;
        oldReg=parmN=0;
        break;
      case 4:
				???
        break;
      case BIOS_VIDEO_MODE:
        commandParms[parmN++]=PMDIN;
        if(parmN>=6) {
          commandReceived=BIOS_VIDEO_MODE;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_CLS:
        commandReceived=BIOS_VIDEO_CLS;
        oldReg=parmN=0;
        m_IRQ=0;
        break;
      case BIOS_VIDEO_COLORS:
        commandParms[parmN++]=PMDIN;
        if(parmN>=4) {
          commandReceived=BIOS_VIDEO_COLORS;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_XY:
        commandParms[parmN++]=PMDIN;
        if(parmN>=4) {
          commandReceived=BIOS_VIDEO_XY;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_PIXEL:
        commandParms[parmN++]=PMDIN;
        if(parmN>=6) {
          commandReceived=BIOS_VIDEO_PIXEL;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_LINE:
        commandParms[parmN++]=PMDIN;
        if(parmN>=10) {
          commandReceived=BIOS_VIDEO_LINE;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_RECTANGLE:
        commandParms[parmN++]=PMDIN;
        if(parmN>=10) {
          commandReceived=BIOS_VIDEO_RECTANGLE;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_CIRCLE:
        commandParms[parmN++]=PMDIN;
        if(parmN>=8) {
          commandReceived=BIOS_VIDEO_CIRCLE;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_VIDEO_CHAR:
        commandParms[parmN++]=PMDIN;
        if(parmN>=7) {
          commandReceived=BIOS_VIDEO_CHAR;
          oldReg=parmN=0;
          m_IRQ=0;
          }
        break;
      case BIOS_RESET:
          m_IRQ=0;
				while(1);		// pu� servire!
        break;
      default:
        PMDIN;
        commandReceived=BIOS_INVALID;
        oldReg=parmN=0;
        break;
      }

    if(PMSTATbits.IBOV) {
      oldReg=parmN=0;
      commandReceived=0;
      PMSTATbits.IBOV=0;
      m_IRQ=1;
      }
    }
      
  if(PMSTATbits.OB0E /*1*/ /*WR*/) {
    TRISE &= ~0b0000000011111111;   // serve o � automatico?
    switch(reg) {
      case BIOS_GETID:
        PMDOUT='V';
        PMPWaitBusy();
        break;
      case BIOS_GETCONFIG:
        PMDOUT=VERNUML;
        PMPWaitBusy();
        break;
      case 2:
        PMDOUT=VERNUMH;
        PMPWaitBusy();
        break;
      case BIOS_IRQ_REQUEST:
        PMPWaitBusy();
        break;
      default:
				PMDOUT=reg;
  //      PMPWaitBusy();
        parmN=0;
        break;
      }
		parmN++;      // finireeeee
		parmN &= 15;
    
    TRISE |= 0b0000000011111111;   // serve o � automatico?
    }
  
  
  IFS4CLR = _IFS4_PMPIF_MASK;
  }

/*******************************************************************************
  Exception Reason Data


  Remarks:
    These global static items are used instead of local variables in the
    _general_exception_handler function because the stack may not be available
    if an exception has occurred.
*/

// Code identifying the cause of the exception (CP0 Cause register).
static unsigned int _excep_code;

// Address of instruction that caused the exception.
static unsigned int _excep_addr;

// Pointer to the string describing the cause of the exception.
static char *_cause_str;

// Array identifying the cause (indexed by _exception_code).
static char *cause[] = {
    "Interrupt",
    "Undefined",
    "Undefined",
    "Undefined",
    "Load/fetch address error",
    "Store address error",
    "Instruction bus error",
    "Data bus error",
    "Syscall",
    "Breakpoint",
    "Reserved instruction",
    "Coprocessor unusable",
    "Arithmetic overflow",
    "Trap",
    "Reserved",
    "Reserved",
    "Reserved",
    "Reserved",
    "Reserved"
  };



// *****************************************************************************
// *****************************************************************************
// Section: Exception Handling
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void _general_exception_handler ( void )

  Summary:
    Overrides the XC32 _weak_ _generic_exception_handler.

  Description:
    This function overrides the XC32 default _weak_ _generic_exception_handler.

  Remarks:
    Refer to the XC32 User's Guide for additional information.
 */
void _general_exception_handler(void) {
    /* Mask off Mask of the ExcCode Field from the Cause Register
    Refer to the MIPs Software User's manual */
  
    _excep_code = (_CP0_GET_CAUSE() & 0x0000007C) >> 2;
    _excep_addr = _CP0_GET_EPC();
    _cause_str  = cause[_excep_code];
//    SYS_DEBUG_PRINT(SYS_ERROR_FATAL, "\n\rGeneral Exception %s (cause=%d, addr=%x).\n\r",
//                    _cause_str, _excep_code, _excep_addr);

    clearScreenLCD();			// 
    setColors(WHITE,0);
    setTextCursor(0,0);
    gfx_print(_cause_str);

    while(1)    {
//        SYS_DEBUG_BreakPoint();
        Nop();
        Nop();
        __delay_ms(2500);
//      mLED_1^=1;
    }
  }


