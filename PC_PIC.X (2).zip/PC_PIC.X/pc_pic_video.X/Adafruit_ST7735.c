#include <xc.h>
#include "Adafruit_ST77xx.h"
#include "Adafruit_ST7735.h"
//#include "swspi.h"
#include "../harmony_pic32mz/system_config.h"
#include <stdio.h>


uint8_t tabcolor,rotation;
UINT8	sleep;
UINT8	_initError;


// CONSTRUCTORS ************************************************************

/*!
    @brief  Instantiate Adafruit ST7735 driver with software SPI
    @param  cs    Chip select pin #
    @param  dc    Data/Command pin #
    @param  mosi  SPI MOSI pin #
    @param  sclk  SPI Clock pin #
    @param  rst   Reset pin # (optional, pass -1 if unused)
*/
int Adafruit_ST7735_SW(int8_t cs, int8_t dc, int8_t mosi,
  int8_t sclk, int8_t rst) {
  
  return Adafruit_ST77xx_1(ST7735_TFTWIDTH_128,
    ST7735_TFTHEIGHT_160, cs, dc, mosi, sclk, rst, -1);
  }

/*!
    @brief  Instantiate Adafruit ST7735 driver with default hardware SPI
    @param  cs   Chip select pin #
    @param  dc   Data/Command pin #
    @param  rst  Reset pin # (optional, pass -1 if unused)
*/
int Adafruit_ST7735_HW(int8_t cs, int8_t dc, int8_t rst) {
  
  return Adafruit_ST77xx_2(ST7735_TFTWIDTH_128, ST7735_TFTHEIGHT_160, cs, dc, rst);
  }


// SCREEN INITIALIZATION ***************************************************

// Rather than a bazillion writecommand() and writedata() calls, screen
// initialization commands and arguments are organized in these tables
// stored in PROGMEM.  The table may look bulky, but that's mostly the
// formatting -- storage-wise this is hundreds of bytes more compact
// than the equivalent code.  Companion function follows.

static const uint8_t PROGMEM
  Bcmd[] = {                        // Init commands for 7735B screens
    18,                             // 18 commands in list:
    ST77XX_SWRESET,   ST_CMD_DELAY, //  1: Software reset, no args, w/delay
      50,                           //     50 ms delay
    ST77XX_SLPOUT,    ST_CMD_DELAY, //  2: Out of sleep mode, no args, w/delay
      255,                          //     255 = max (500 ms) delay
    ST77XX_COLMOD,  1+ST_CMD_DELAY, //  3: Set color mode, 1 arg + delay:
      0x05,                         //     16-bit color
      10,                           //     10 ms delay
    ST7735_FRMCTR1, 3+ST_CMD_DELAY, //  4: Frame rate control, 3 args + delay:
      0x00,                         //     fastest refresh
      0x06,                         //     6 lines front porch
      0x03,                         //     3 lines back porch
      10,                           //     10 ms delay
    ST77XX_MADCTL,  1,              //  5: Mem access ctl (directions), 1 arg:
      0x08,                         //     Row/col addr, bottom-top refresh
    ST7735_DISSET5, 2,              //  6: Display settings #5, 2 args:
      0x15,                         //     1 clk cycle nonoverlap, 2 cycle gate
                                    //     rise, 3 cycle osc equalize
      0x02,                         //     Fix on VTL
    ST7735_INVCTR,  1,              //  7: Display inversion control, 1 arg:
      0x0,                          //     Line inversion
    ST7735_PWCTR1,  2+ST_CMD_DELAY, //  8: Power control, 2 args + delay:
      0x02,                         //     GVDD = 4.7V
      0x70,                         //     1.0uA
      10,                           //     10 ms delay
    ST7735_PWCTR2,  1,              //  9: Power control, 1 arg, no delay:
      0x05,                         //     VGH = 14.7V, VGL = -7.35V
    ST7735_PWCTR3,  2,              // 10: Power control, 2 args, no delay:
      0x01,                         //     Opamp current small
      0x02,                         //     Boost frequency
    ST7735_VMCTR1,  2+ST_CMD_DELAY, // 11: Power control, 2 args + delay:
      0x3C,                         //     VCOMH = 4V
      0x38,                         //     VCOML = -1.1V
      10,                           //     10 ms delay
    ST7735_PWCTR6,  2,              // 12: Power control, 2 args, no delay:
      0x11, 0x15,
    ST7735_GMCTRP1,16,              // 13: Gamma Adjustments (pos. polarity), 16 args + delay:
      0x09, 0x16, 0x09, 0x20,       //     (Not entirely necessary, but provides
      0x21, 0x1B, 0x13, 0x19,       //      accurate colors)
      0x17, 0x15, 0x1E, 0x2B,
      0x04, 0x05, 0x02, 0x0E,
    ST7735_GMCTRN1,16+ST_CMD_DELAY, // 14: Gamma Adjustments (neg. polarity), 16 args + delay:
      0x0B, 0x14, 0x08, 0x1E,       //     (Not entirely necessary, but provides
      0x22, 0x1D, 0x18, 0x1E,       //      accurate colors)
      0x1B, 0x1A, 0x24, 0x2B,
      0x06, 0x06, 0x02, 0x0F,
      10,                           //     10 ms delay
    ST77XX_CASET,   4,              // 15: Column addr set, 4 args, no delay:
      0x00, 0x02,                   //     XSTART = 2
      0x00, 0x81,                   //     XEND = 129
    ST77XX_RASET,   4,              // 16: Row addr set, 4 args, no delay:
      0x00, 0x02,                   //     XSTART = 1
      0x00, 0x81,                   //     XEND = 160
    ST77XX_NORON,     ST_CMD_DELAY, // 17: Normal display on, no args, w/delay
      10,                           //     10 ms delay
    ST77XX_DISPON,    ST_CMD_DELAY, // 18: Main screen turn on, no args, delay
      255 },                        //     255 = max (500 ms) delay

  Rcmd1[] = {                       // 7735R init, part 1 (red or green tab)
    15,                             // 15 commands in list:
    ST77XX_SWRESET,   ST_CMD_DELAY, //  1: Software reset, 0 args, w/delay
      150,                          //     150 ms delay
    ST77XX_SLPOUT,    ST_CMD_DELAY, //  2: Out of sleep mode, 0 args, w/delay
      255,                          //     500 ms delay
    ST7735_FRMCTR1, 3,              //  3: Framerate ctrl - normal mode, 3 arg:
      0x01, 0x2C, 0x2D,             //     Rate = fosc/(1x2+40) * (LINE+2C+2D)
    ST7735_FRMCTR2, 3,              //  4: Framerate ctrl - idle mode, 3 args:
      0x01, 0x2C, 0x2D,             //     Rate = fosc/(1x2+40) * (LINE+2C+2D)
    ST7735_FRMCTR3, 6,              //  5: Framerate - partial mode, 6 args:
      0x01, 0x2C, 0x2D,             //     Dot inversion mode
      0x01, 0x2C, 0x2D,             //     Line inversion mode
    ST7735_INVCTR,  1,              //  6: Display inversion ctrl, 1 arg:
      0x07,                         //     No inversion
    ST7735_PWCTR1,  3,              //  7: Power control, 3 args, no delay:
      0xA2,
      0x02,                         //     -4.6V
      0x84,                         //     AUTO mode
    ST7735_PWCTR2,  1,              //  8: Power control, 1 arg, no delay:
      0xC5,                         //     VGH25=2.4C VGSEL=-10 VGH=3 * AVDD
    ST7735_PWCTR3,  2,              //  9: Power control, 2 args, no delay:
      0x0A,                         //     Opamp current small
      0x00,                         //     Boost frequency
    ST7735_PWCTR4,  2,              // 10: Power control, 2 args, no delay:
      0x8A,                         //     BCLK/2,
      0x2A,                         //     opamp current small & medium low
    ST7735_PWCTR5,  2,              // 11: Power control, 2 args, no delay:
      0x8A, 0xEE,
    ST7735_VMCTR1,  1,              // 12: Power control, 1 arg, no delay:
      0x0E,
    ST77XX_INVOFF,  0,              // 13: Don't invert display, no args
    ST77XX_MADCTL,  1,              // 14: Mem access ctl (directions), 1 arg:
      0xC8,                         //     row/col addr, bottom-top refresh
    ST77XX_COLMOD,  1,              // 15: set color mode, 1 arg, no delay:
      0x05 },                       //     16-bit color

  Rcmd2green[] = {                  // 7735R init, part 2 (green tab only)
    2,                              //  2 commands in list:
    ST77XX_CASET,   4,              //  1: Column addr set, 4 args, no delay:
      0x00, 0x02,                   //     XSTART = 0
      0x00, 0x7F+0x02,              //     XEND = 127
    ST77XX_RASET,   4,              //  2: Row addr set, 4 args, no delay:
      0x00, 0x01,                   //     XSTART = 0
      0x00, 0x9F+0x01 },            //     XEND = 159

  Rcmd2red[] = {                    // 7735R init, part 2 (red tab only)
    2,                              //  2 commands in list:
    ST77XX_CASET,   4,              //  1: Column addr set, 4 args, no delay:
      0x00, 0x00,                   //     XSTART = 0
      0x00, 0x7F,                   //     XEND = 127
    ST77XX_RASET,   4,              //  2: Row addr set, 4 args, no delay:
      0x00, 0x00,                   //     XSTART = 0
      0x00, 0x9F },                 //     XEND = 159

  Rcmd2green144[] = {               // 7735R init, part 2 (green 1.44 tab)
    2,                              //  2 commands in list:
    ST77XX_CASET,   4,              //  1: Column addr set, 4 args, no delay:
      0x00, 0x00,                   //     XSTART = 0
      0x00, 0x7F,                   //     XEND = 127
    ST77XX_RASET,   4,              //  2: Row addr set, 4 args, no delay:
      0x00, 0x00,                   //     XSTART = 0
      0x00, 0x7F },                 //     XEND = 127

  Rcmd2green160x80[] = {            // 7735R init, part 2 (mini 160x80)
    2,                              //  2 commands in list:
    ST77XX_CASET,   4,              //  1: Column addr set, 4 args, no delay:
      0x00, 0x00,                   //     XSTART = 0
      0x00, 0x4F,                   //     XEND = 79
    ST77XX_RASET,   4,              //  2: Row addr set, 4 args, no delay:
      0x00, 0x00,                   //     XSTART = 0
      0x00, 0x9F },                 //     XEND = 159

  Rcmd3[] = {                       // 7735R init, part 3 (red or green tab)
    4,                              //  4 commands in list:
    ST7735_GMCTRP1, 16      ,       //  1: Gamma Adjustments (pos. polarity), 16 args + delay:
      0x02, 0x1c, 0x07, 0x12,       //     (Not entirely necessary, but provides
      0x37, 0x32, 0x29, 0x2d,       //      accurate colors)
      0x29, 0x25, 0x2B, 0x39,
      0x00, 0x01, 0x03, 0x10,
    ST7735_GMCTRN1, 16      ,       //  2: Gamma Adjustments (neg. polarity), 16 args + delay:
      0x03, 0x1d, 0x07, 0x06,       //     (Not entirely necessary, but provides
      0x2E, 0x2C, 0x29, 0x2D,       //      accurate colors)
      0x2E, 0x2E, 0x37, 0x3F,
      0x00, 0x00, 0x02, 0x10,
    ST77XX_NORON,     ST_CMD_DELAY, //  3: Normal display on, no args, w/delay
      10,                           //     10 ms delay
    ST77XX_DISPON,    ST_CMD_DELAY, //  4: Main screen turn on, no args w/delay
      100 };                        //     100 ms delay

/**************************************************************************/
/*!
    @brief  Initialization code common to all ST7735B displays
*/
/**************************************************************************/
void Adafruit_ST7735_initB(void) {
  
  commonInit(Bcmd);
  setRotation_st7735(0);
  }

/**************************************************************************/
/*!
    @brief  Initialization code common to all ST7735R displays
    @param  options  Tab color from adafruit purchase
*/
/**************************************************************************/
void Adafruit_ST7735_initR(uint8_t options) {
  
  commonInit(Rcmd1);

    // colstart, rowstart left at default '0' values
    displayInit(Rcmd2red);

  displayInit(Rcmd3);

  // Black tab, change MADCTL color filter
  if((options == INITR_BLACKTAB) || (options == INITR_MINI160x80)) {
    uint8_t data = 0xC0;
    sendCommand(ST77XX_MADCTL, &data, 1);
    }

  if(options == INITR_HALLOWING) {
    // Hallowing is simply a 1.44" green tab upside-down:
    tabcolor = INITR_144GREENTAB;
    setRotation_st7735(2);
    }
  else {
    tabcolor = options;
    setRotation_st7735(1 /*0*/);
    }
  }

// OTHER FUNCTIONS *********************************************************

/**************************************************************************/
/*!
    @brief  Set origin of (0,0) and orientation of TFT display
    @param  m  The index for rotation, from 0-3 inclusive
*/
/**************************************************************************/
void setRotation_st7735(uint8_t m) {    // ce n'� anche una in ST77xx...
  uint8_t madctl = 0;

  rotation = m & 3; // can't be higher than 3

  // For ST7735 with GREEN TAB (including HalloWing)...
  if((tabcolor == INITR_144GREENTAB) || (tabcolor == INITR_HALLOWING)) {
    // ..._rowstart is 3 for rotations 0&1, 1 for rotations 2&3
    _rowstart = (rotation < 2) ? 3 : 1;
    }

  switch(rotation) {
    case 0:
      if((tabcolor == INITR_BLACKTAB) || (tabcolor == INITR_MINI160x80)) {
        madctl = ST77XX_MADCTL_MX | ST77XX_MADCTL_MY | ST77XX_MADCTL_RGB;
        }
      else {
        madctl = ST77XX_MADCTL_MX | ST77XX_MADCTL_MY | ST7735_MADCTL_BGR;
        }


       _height = ST7735_TFTHEIGHT_160;
       _width  = ST7735_TFTWIDTH_128;

     _xstart   = _colstart;
     _ystart   = _rowstart;
     break;
     
    case 1:
      if((tabcolor == INITR_BLACKTAB) || (tabcolor == INITR_MINI160x80)) {
        madctl = ST77XX_MADCTL_MY | ST77XX_MADCTL_MV | ST77XX_MADCTL_RGB;
        } 
      else {
        madctl = ST77XX_MADCTL_MY | ST77XX_MADCTL_MV | ST7735_MADCTL_BGR;
        }


       _width  = ST7735_TFTHEIGHT_160;
       _height = ST7735_TFTWIDTH_128;

      _ystart   = _colstart;
      _xstart   = _rowstart;
      break;
     
    case 2:
      if ((tabcolor == INITR_BLACKTAB) || (tabcolor == INITR_MINI160x80)) {
        madctl = ST77XX_MADCTL_RGB;
        }
      else {
        madctl = ST7735_MADCTL_BGR;
        }


       _height = ST7735_TFTHEIGHT_160;
       _width  = ST7735_TFTWIDTH_128;

      _xstart   = _colstart;
      _ystart   = _rowstart;
      break;
     
    case 3:
      if((tabcolor == INITR_BLACKTAB) || (tabcolor == INITR_MINI160x80)) {
        madctl = ST77XX_MADCTL_MX | ST77XX_MADCTL_MV | ST77XX_MADCTL_RGB;
        } 
      else {
        madctl = ST77XX_MADCTL_MX | ST77XX_MADCTL_MV | ST7735_MADCTL_BGR;
        }


       _width  = ST7735_TFTHEIGHT_160;
       _height = ST7735_TFTWIDTH_128;

     _ystart   = _colstart;
     _xstart   = _rowstart;
     break;
    }

  sendCommand(ST77XX_MADCTL, &madctl, 1);
  }


void drawPixelLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {

	if(boundaryCheck(x,y)) 
		return;
	if((x < 0) || (y < 0)) 
		return;
	//setAddr(x,y,x+1,y+1);
	Pixel(x, y, color);
	}


void drawFastVLine(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T h, GFX_COLOR color) {

	// Rudimentary clipping
	if(boundaryCheck(x,y))
		return;
	if(((y + h) - 1) >= _height) 
		h = _height-y;
//	setAddr(x,y,x,(y+h)-1);
	VLine(x, y, h, color);
	}

BOOL boundaryCheck(UGRAPH_COORD_T x,UGRAPH_COORD_T y) {

	if((x >= _width) || (y >= _height)) 
		return TRUE;
	return FALSE;
	}

void drawFastHLine(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, GFX_COLOR color) {

	// Rudimentary clipping
	if(boundaryCheck(x,y)) 
		return;
	if(((x+w) - 1) >= _width)  
		w = _width-x;
//	setAddr(x,y,(x+w)-1,y);
	HLine(x, y, w, color);
	}


// fill a rectangle
void fillRectLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h, GFX_COLOR color) {

	if(boundaryCheck(x,y)) 
		return;
	if(((x + w) - 1) >= _width)  
		w = _width  - x;
	if(((y + h) - 1) >= _height) 
		h = _height - y;
  START_WRITE();
  if(!IS_ILI()) {
    setAddrWindow_st7735(x,y,w,h);
    for(y=h; y>0; y--) {
      for(x=w; x>1; x--) {
        writedata16(color);
        }
      writedata16(color);
      }
    }
  else {
    setAddrWindow_ili9488(x,y,w,h);
    for(y=h; y>0; y--) {
      for(x=w; x>1; x--) {
        write16BitColor(color);
        }
      write16BitColor(color);
      }
    }
  END_WRITE();
	}

inline void writeFillRectPreclipped(UGRAPH_COORD_T x, UGRAPH_COORD_T y,
  UGRAPH_COORD_T w, UGRAPH_COORD_T h, GFX_COLOR color) {
  
  if(!IS_ILI()) {
    setAddrWindow_st7735(x, y, w, h);
    writeColor(color, (uint32_t)w * h);
    }
  else {
    setAddrWindow_ili9488(x, y, w, h);
    write16BitColor(color);
    }
  }

void drawLineLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, GFX_COLOR color) {
	BOOL steep;
	GRAPH_COORD_T dx,dy;
	GRAPH_COORD_T err;
	GRAPH_COORD_T ystep;
	GRAPH_COORD_T xbegin;

	if(y0==y1) {
		if(x1>x0) {
			drawFastHLine(x0, y0, x1-x0+1, color);
			} 
		else if(x1 < x0) {
			drawFastHLine(x1, y0, x0-x1+1, color);
			} 
		else {
			drawPixel(x0, y0, color);
			}
		return;
		} 
	else if(x0==x1) {
		if(y1>y0) {
			drawFastVLine(x0, y0, y1-y0+1, color);
			} 
		else {
			drawFastVLine(x0, y1, y0-y1+1, color);
			}
		return;
		}

	steep = abs(y1-y0) > abs(x1-x0);
	if(steep) {
		_swap(&x0, &y0);
		_swap(&x1, &y1);
		}
	if(x0>x1) {
		_swap(&x0, &x1);
		_swap(&y0, &y1);
		}

	dx = x1-x0;
	dy = abs(y1-y0);

	err = dx/2;

	if(y0<y1) {
		ystep = 1;
		} 
	else {
		ystep = -1;
		}

	
	xbegin = x0;
	if(steep) {
		for(; x0<=x1; x0++) {
			err -= dy;
			if(err < 0) {
				INT16 len = x0-xbegin;
				if(len) {
					VLine(y0, xbegin, len + 1, color);
					} 
				else {
					Pixel(y0, x0, color);
					}
				xbegin = x0+1;
				y0 += ystep;
				err += dx;
				}
			}
		if(x0 > xbegin + 1) {
			VLine(y0, xbegin, x0 - xbegin, color);
			}
		} 
	else {
		for(; x0<=x1; x0++) {
			err -= dy;
			if(err < 0) {
				INT16 len = x0-xbegin;
				if(len) {
					HLine(xbegin, y0, len+1, color);
					} 
				else {
					Pixel(x0, y0, color);
					}
				xbegin = x0+1;
				y0 += ystep;
				err += dx;
				}
			}
		if(x0 > xbegin+1) {
			HLine(xbegin, y0, x0-xbegin, color);
			}
		}
//	writecommand(CMD_NOP);
	}


void drawRectLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h, GFX_COLOR color) {

	HLine(x, y, w, color);
	HLine(x, y+h-1, w, color);
	VLine(x, y, h, color);
	VLine(x+w-1, y, h, color);
//	writecommand(CMD_NOP);
	}

void fillScreenLCD(GFX_COLOR color) {
	UGRAPH_COORD_T px,py;
  struct __attribute((packed)) PIXEL_3_4 {
    union __attribute((packed)) {
      struct __attribute((packed)) { uint8_t b2,r1,g1,b1; };
      uint32_t d1;
      };
    union __attribute((packed)) {
      struct __attribute((packed)) { uint8_t g3,b3,r2,g2; };
      uint32_t d2;
      };
    union __attribute((packed)) {
      struct __attribute((packed)) { uint8_t r4,g4,b4,r3; };
      uint32_t d3;
      };
    } p34;

  START_WRITE();
  if(!IS_ILI()) {
  	setAddrWindow_st7735(0,0,_width,_height);
    for(py=0; py<_height; py++) {
      for(px=0; px<_width; px++) {
        writedata16(color);
        ClrWdt();
        }
      }
    }
  else {
    p34.r1=p34.r2=p34.r3=p34.r4=(color & 0xF800) >> 8;
//    p34.r1=1;p34.r2=2;p34.r3=3;p34.r4=4;
    p34.g1=p34.g2=p34.g3=p34.g4=(color & 0x07E0) >> 3;
//    p34.g1=0x11;p34.g2=0x12;p34.g3=0x13;p34.g4=0x14;
    p34.b1=p34.b2=p34.b3=p34.b4=(color & 0x001F) << 3;
//    p34.b1=0x21;p34.b2=0x22;p34.b3=0x23;p34.b4=0x24;
  	setAddrWindow_ili9488(0,0,_width,_height);
    for(py=0; py<_height; py++) {
      for(px=0; px<_width/4; px++) {
//        write16BitColor(color);
        
        SPI_DC_HIGH();
        SPI_CS_LOW();
/*per risparmiare pure il MODE :)
  SPI1CONbits.MODE32=1;     // 
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = l;     // Write character to SPI buffer
  while(SPI1STATbits.SPIBUSY)
    ClrWdt();
  SPI1BUF;
  */

        SPI_WRITE32(p34.d1);
        SPI_WRITE32(p34.d2);
        SPI_WRITE32(p34.d3);
        SPI_CS_HIGH();

        }
      ClrWdt();
      }
    }
  END_WRITE();
//	writecommand(CMD_NOP);
	}

void __attribute__((always_inline)) HLine(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, GFX_COLOR color) {

  START_WRITE();
  if(!IS_ILI()) {
  	setAddrWindow_st7735(x, y, w, 1);
  	do { writedata16(color); } while (--w > 0);
    }
  else {
  	setAddrWindow_ili9488(x, y, w, 1);
  	do { write16BitColor(color); } while (--w > 0);
    }
  END_WRITE();
	}

void __attribute__((always_inline)) VLine(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T h, GFX_COLOR color) {

  START_WRITE();
  if(!IS_ILI()) {
  	setAddrWindow_st7735(x, y, 1, h);
  	do { writedata16(color); } while (--h > 0);
    }
  else {
  	setAddrWindow_ili9488(x, y, 1, h);
  	do { write16BitColor(color); } while (--h > 0);
    }
  END_WRITE();
	}
		
void __attribute__((always_inline)) Pixel(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {

  START_WRITE();
  if(!IS_ILI()) {
    setAddrWindow_st7735(x, y, 1, 1);
  	writedata16(color);
    }
  else {
    setAddrWindow_ili9488(x, y, 1, 1);
  	write16BitColor(color);
    }
  END_WRITE();
	}

/*!
    @brief  Draw a single pixel to the display at requested coordinates.
            Not self-contained; should follow a START_WRITE() call.
    @param  x      Horizontal position (0 = left).
    @param  y      Vertical position   (0 = top).
    @param  color  16-bit pixel color in '565' RGB format.
*/
void writePixel(int16_t x, int16_t y, GFX_COLOR color) {
  
  if((x >= 0) && (x < _width) && (y >= 0) && (y < _height)) {
    START_WRITE();
    if(!IS_ILI()) {
      setAddrWindow_st7735(x, y, 1, 1);
      SPI_WRITE16(color);
      }
    else {
      setAddrWindow_ili9488(x, y, 1, 1);
    	write16BitColor(color);
      }
    END_WRITE();
    }
  }

void writePixels(uint16_t *colors, uint32_t len, BOOL block, BOOL bigEndian) {

  if(!len) 
    return; // Avoid 0-byte transfers

  // All other cases (bitbang SPI or non-DMA hard SPI or parallel),
  // use a loop with the normal 16-bit data write function:
  while(len--) {
    SPI_WRITE16(*colors++);
    }
  
  }

/*!
    @brief  Issue a series of pixels, all the same color. Not self-
            contained; should follow START_WRITE() and setAddrWindow_st7735() calls.
    @param  color  16-bit pixel color in '565' RGB format.
    @param  len    Number of pixels to draw.
*/
void writeColor(GFX_COLOR color, uint32_t len) {

  if(!len) 
    return; // Avoid 0-byte transfers

  uint8_t hi = color >> 8, lo = color;
  uint16_t b;

  do {
    uint32_t pixelsThisPass = len;
    if(pixelsThisPass > 20000) 
      pixelsThisPass = 20000;
    len -= pixelsThisPass;
//    yield(); // Periodic yield() on long fills
    while(pixelsThisPass--) {
      SPI_WRITE16(color);
      }
    } while(len);
  }


void writedata16(UINT16 d) {

#ifndef USING_SIMULATOR
  m_LCDDCBit=1;
	m_SPICSBit=0;
  SPI_WRITE16(d);
	m_SPICSBit=1;
#endif
	} 

void homeAddress(void) {
	
  if(!IS_ILI())
    setAddrWindow_st7735(0,0,_width,_height);
  else
    setAddrWindow_ili9488(0,0,_width,_height);
	}


void setCursorLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y) {

	if(boundaryCheck(x,y)) 
		return;
//	setAddrWindow_st7735(0,0,x,y);
	cursor_x = x;
	cursor_y = y;
	}

void _swap(UGRAPH_COORD_T *a, UGRAPH_COORD_T *b) {
	UGRAPH_COORD_T t = *a; 
	*a = *b; 
	*b = t; 
	}

void sendCommand(uint8_t commandByte, uint8_t *dataBytes, uint8_t numDataBytes) {
  int i;
  
  SPI_CS_LOW();
  
  SPI_DC_LOW(); // Command mode
  spiWrite(commandByte); // Send the command byte
  
  SPI_DC_HIGH();
  for(i=0; i<numDataBytes; i++) {
    spiWrite(*dataBytes++); // Send the data bytes
    }
  
  SPI_CS_HIGH();
  }

uint8_t readcommand8_st7735(uint8_t commandByte, uint8_t index) {
  uint8_t result;
  
  START_WRITE();
  SPI_DC_LOW();     // Command mode
  spiWrite(commandByte);
  SPI_DC_HIGH();    // Data mode
  do {
    result = spiRead();
    } while(index--); // Discard bytes up to index'th
  END_WRITE();
  return result;
  }



void begin_st7735(void) {

	sleep = 0;
	_initError = 0b00000000;

	SPISDOTris=0;				// SDO � output
	SPISCKTris=0;				// SCK � output
	SPICSTris=0;
	LCDDCTris=0;

  }


