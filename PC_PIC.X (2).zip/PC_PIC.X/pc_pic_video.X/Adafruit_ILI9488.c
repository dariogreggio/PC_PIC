/***************************************************
  STM32 Support added by Jaret Burkett at OSHlab.com

  This is our library for the Adafruit ILI9488 Breakout and Shield
  ----> http://www.adafruit.com/products/1651

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution

	GD 2022
 ****************************************************/

#include "pc_pic_video.h"
#include "Adafruit_ST77xx.h"
//#include "swspi.h"
#include "../harmony_pic32mz/system_config.h"
#include <stdio.h>
#include "Adafruit_ILI9488.h"




// If the SPI library has transaction support, these functions
// establish settings and protect from interference from other
// libraries.  Otherwise, they simply do nothing.
#ifdef SPI_HAS_TRANSACTION
static inline void spi_begin(void) __attribute__((always_inline));
static inline void spi_begin(void) {
#if defined (ARDUINO_ARCH_ARC32)
  // max speed!
  SPI.beginTransaction(SPISettings(16000000, MSBFIRST, SPI_MODE0));
#else
    // max speed!
  SPI.beginTransaction(SPISettings(24000000, MSBFIRST, SPI_MODE0));
#endif
}
static inline void spi_end(void) __attribute__((always_inline));
static inline void spi_end(void) {
  SPI.endTransaction();
}
#else
#define spi_begin()
#define spi_end()
#endif


// Constructor when using software SPI.  All output pins are configurable.
int Adafruit_ILI9488_SW(int8_t cs, int8_t dc, int8_t mosi,
				   int8_t sclk, int8_t rst, int8_t miso) {
  
  Adafruit_GFX(ILI9488_TFTWIDTH, ILI9488_TFTHEIGHT);
/*  _cs   = cs;
  _dc   = dc;
  _mosi  = mosi;
  _miso = miso;
  _sclk = sclk;
  _rst  = rst;*/
	}


// Constructor when using hardware SPI.  Faster, but must use SPI pins
// specific to each board type (e.g. 11,13 for Uno, 51,52 for Mega, etc.)
int Adafruit_ILI9488_HW(int8_t cs, int8_t dc, int8_t rst) {
  
  Adafruit_GFX(ILI9488_TFTWIDTH, ILI9488_TFTHEIGHT);

/*  _cs   = cs;
  _dc   = dc;
  _rst  = rst;
  _mosi  = _sclk = 0;
  */
	}


// Rather than a bazillion writeCommand() and writeData() calls, screen
// initialization commands and arguments are organized in these tables
// stored in PROGMEM.  The table may look bulky, but that's mostly the
// formatting -- storage-wise this is hundreds of bytes more compact
// than the equivalent code.  Companion function follows.
#define DELAY 0x80


// Companion code to the above tables.  Reads and issues
// a series of LCD commands stored in PROGMEM byte array.
#if 0   // riciclo quella di ST7735
void commandList(uint8_t *addr) {
  uint8_t  numCommands, numArgs;
  uint16_t ms;

  numCommands = pgm_read_byte(addr++);   // Number of commands to follow
  while(numCommands--) {                 // For each command...
    cmd = pgm_read_byte(addr++);         // Read command
    writeCommand(pgm_read_byte(addr++)); //   Read, issue command
    numArgs  = pgm_read_byte(addr++);    //   Number of args to follow
    ms       = numArgs & DELAY;          //   If hibit set, delay follows args
    numArgs &= ~DELAY;                   //   Mask out delay bit
    while(numArgs--)	                   //   For each argument...
      writeData(pgm_read_byte(addr++));  //     Read, issue argument

    if(ms) {
      ms = pgm_read_byte(addr++); // Read post-command delay time (ms)
      if(ms == 255) 
        ms = 500;     // If 255, delay for 500 ms
      __delay_ms(ms);
			}
		}
	}
#endif


void Adafruit_ili9488_begin(uint32_t freq) {
  
  if(!freq) {
    freq = SPI_DEFAULT_FREQ;
    }
  _freq = freq;

	_initError = 0b00000000;

	SPISDOTris=0;				// SDO � output
	SPISCKTris=0;				// SCK � output
	SPICSTris=0;
	LCDDCTris=0;

  initSPI(freq, spiMode);
  }

void writeCommandCS(uint8_t cmd) {
  
  SPI_DC_LOW();
  SPI_CS_LOW();
  spiWrite(cmd);
  SPI_CS_HIGH();
  }
  
static const uint8_t initcmd[] = {
  
  // FINIRE! con num cmd, num args, delay ecc
  ILI9488_GMCTRP1,	15, 0x00,	0x03,	0x09,	0x08,	0x16,	0x0A,	0x3F,
    0x78,	0x4C,	0x09,	0x0A,	0x08,	0x16,	0x1A,	0x0F,      //Set Gamma Positive

	ILI9488_GMCTRN1,	15, 0x00,	0x16,	0x19,	0x03,	0x0F,	0x05,	0x32,
    0x45,	0x46,	0x04,	0x0E,	0x0D,	0x35,	0x37,	0x0F,      //Set Gamma Negative

	ILI9488_PWCTR1,  2,	0x17  /*Vreg1out*/, 0x15  /*Verg2out*/,      //Power Control 1

	ILI9488_PWCTR2,  1, 0x41   /*VGH,VGL*/,  //Power Control 2

	ILI9488_VMCTR1, 3, 0x00, 0x12 /*Vcom*/, 0x80, /*0x00  ne manca uno, pare...*/    //Power Control 3

	ILI9488_MADCTL,   MADCTL_MV | MADCTL_RGB /*0x48*/,   //Memory Access

	ILI9488_PIXFMT,  0x66 /*0x66 18bit*/,    // Interface Pixel Format

	ILI9488_IFMODE,  0x80 /*SDO NOT USE*/,   // Interface Mode Control

	ILI9488_FRMCTR1, 0xA0 /*60Hz*/,      //Frame rate

	ILI9488_INVCTR,  0x02 /*2-dot*/,    //Display Inversion Control
	
	ILI9488_DFUNCTR, 3, 0x02 /*MCU*/, 0x02 /*Source,Gate scan direction*/, 0x3B,   //Display Function Control  RGB/MCU Interface Control
	//3� parm... NL https://www.instructables.com/Arduino-and-35-Inch-320x480-TFT-LCD-ILI9488-SPI-In/

	ILI9488_SETIMAGE, 0x00  /* Disable 24 bit data */,    // Set Image Function
	
	ILI9488_ADJCTRL3, 4, 0xA9,	0x51,	0x2C,	0x82  /* D7 stream, loose*/,      // Adjust Control 3

  ILI9488_SLPOUT,    //Exit Sleep

  ILI9488_DISPON,    //Display on
  0x00                                   // End of list
};

void displayInit_ili9488(void) {

  Adafruit_ili9488_begin(0);
  
#if defined(m_LCDRSTBit)
  m_LCDRSTBit=1;
  __delay_ms(100);
  m_LCDRSTBit=0;
  __delay_ms(100);
  m_LCDRSTBit=1;
  __delay_ms(200);
#else
  __delay_ms(200);
#endif

  /*
  uint8_t x = readcommand8_ili9488(ILI9488_RDMODE);
  Serial.print("\nDisplay Power Mode: 0x"); Serial.println(x, HEX);
  x = readcommand8_ili9488(ILI9488_RDMADCTL);
  Serial.print("\nMADCTL Mode: 0x"); Serial.println(x, HEX);
  x = readcommand8_ili9488(ILI9488_RDPIXFMT);
  Serial.print("\nPixel Format: 0x"); Serial.println(x, HEX);
  x = readcommand8_ili9488(ILI9488_RDIMGFMT);
  Serial.print("\nImage Format: 0x"); Serial.println(x, HEX);
  x = readcommand8_ili9488(ILI9488_RDSELFDIAG);
  Serial.print("\nSelf Diagnostic: 0x"); Serial.println(x, HEX);
*/
  //if(cmdList) commandList(cmdList);

  // writeCommand(0xEF);
  // writeData(0x03);
  // writeData(0x80);
  // writeData(0x02);
  //
  // writeCommand(0xCF);
  // writeData(0x00);
  // writeData(0XC1);
  // writeData(0X30);
  //
  // writeCommand(0xED);
  // writeData(0x64);
  // writeData(0x03);
  // writeData(0X12);
  // writeData(0X81);
  //
  // writeCommand(0xE8);
  // writeData(0x85);
  // writeData(0x00);
  // writeData(0x78);
  //
  // writeCommand(0xCB);
  // writeData(0x39);
  // writeData(0x2C);
  // writeData(0x00);
  // writeData(0x34);
  // writeData(0x02);
  //
  // writeCommand(0xF7);
  // writeData(0x20);
  //
  // writeCommand(0xEA);
  // writeData(0x00);
  // writeData(0x00);
  //
  // writeCommand(ILI9488_PWCTR1);    //Power control
  // writeData(0x23);   //VRH[5:0]
  //
  // writeCommand(ILI9488_PWCTR2);    //Power control
  // writeData(0x10);   //SAP[2:0];BT[3:0]
  //
  // writeCommand(ILI9488_VMCTR1);    //VCM control
  // writeData(0x3e); //¶Ô±È¶Èµ÷½Ú
  // writeData(0x28);
  //
  // writeCommand(ILI9488_VMCTR2);    //VCM control2
  // writeData(0x86);  //--
  //
  // writeCommand(ILI9488_MADCTL);    // Memory Access Control
  // writeData(0x48);
  //
  // writeCommand(ILI9488_PIXFMT);
  // writeData(0x55);
  //
  // writeCommand(ILI9488_FRMCTR1);
  // writeData(0x00);
  // writeData(0x18);
  //
  // writeCommand(ILI9488_DFUNCTR);    // Display Function Control
  // writeData(0x08);
  // writeData(0x82);
  // writeData(0x27);
  //
  // writeCommand(0xF2);    // 3Gamma Function Disable
  // writeData(0x00);
  //
  // writeCommand(ILI9488_GAMMASET);    //Gamma curve selected
  // writeData(0x01);
  //
  // writeCommand(ILI9488_GMCTRP1);    //Set Gamma
  // writeData(0x0F);
  // writeData(0x31);
  // writeData(0x2B);
  // writeData(0x0C);
  // writeData(0x0E);
  // writeData(0x08);
  // writeData(0x4E);
  // writeData(0xF1);
  // writeData(0x37);
  // writeData(0x07);
  // writeData(0x10);
  // writeData(0x03);
  // writeData(0x0E);
  // writeData(0x09);
  // writeData(0x00);
  //
  // writeCommand(ILI9488_GMCTRN1);    //Set Gamma
  // writeData(0x00);
  // writeData(0x0E);
  // writeData(0x14);
  // writeData(0x03);
  // writeData(0x11);
  // writeData(0x07);
  // writeData(0x31);
  // writeData(0xC1);
  // writeData(0x48);
  // writeData(0x08);
  // writeData(0x0F);
  // writeData(0x0C);
  // writeData(0x31);
  // writeData(0x36);
  // writeData(0x0F);

//  if(initcmd) 
//    displayInit(initcmd);

#if 1
#warning FARE COMMANDLIST gli idioti qua non l han fatta (e rimuovere writecommandcs)
  writeCommandCS(ILI9488_GMCTRP1);        //Set Gamma Positive
	writeData(0x00);
	writeData(0x03);
	writeData(0x09);
	writeData(0x08);
	writeData(0x16);
	writeData(0x0A);
	writeData(0x3F);
	writeData(0x78);
	writeData(0x4C);
	writeData(0x09);
	writeData(0x0A);
	writeData(0x08);
	writeData(0x16);
	writeData(0x1A);
	writeData(0x0F);

	writeCommandCS(ILI9488_GMCTRN1);      //Set Gamma Negative
	writeData(0x00);
	writeData(0x16);
	writeData(0x19);
	writeData(0x03);
	writeData(0x0F);
	writeData(0x05);
	writeData(0x32);
	writeData(0x45);
	writeData(0x46);
	writeData(0x04);
	writeData(0x0E);
	writeData(0x0D);
	writeData(0x35);
	writeData(0x37);
	writeData(0x0F);

	writeCommandCS(ILI9488_PWCTR1);      //Power Control 1
	writeData(0x17);    //Vreg1out
	writeData(0x15);    //Verg2out

	writeCommandCS(ILI9488_PWCTR2);      //Power Control 2
	writeData(0x41);    //VGH,VGL

	writeCommandCS(ILI9488_VMCTR1);      //Power Control 3
	writeData(0x00);
	writeData(0x12);    //Vcom
	writeData(0x80);
//	writeData(0x00);    ne manca uno, pare...

	writeCommandCS(ILI9488_MADCTL);     //Memory Access
	writeData(MADCTL_MV | MADCTL_RGB /*0x48*/);    // tipo ST77XX_MADCTL_MX | ST77XX_MADCTL_MY | ST77XX_MADCTL_RGB;

	writeCommandCS(ILI9488_PIXFMT);     // Interface Pixel Format
	writeData(0x66 /*0x66 18bit*/); 	  //16 bit NON di pu� :( (serve I/F parallela, pare..) quindi 0x55 e 0x56 non vanno, 66 e 65 vanno a 24bit (v. pixel)

	writeCommandCS(ILI9488_IFMODE);     // Interface Mode Control
	writeData(0x80);              //SDO NOT USE

	writeCommandCS(ILI9488_FRMCTR1);    //Frame rate
	writeData(0xA0);    //60Hz

	writeCommandCS(ILI9488_INVCTR);     //Display Inversion Control
	writeData(0x02);    //2-dot

	writeCommandCS(ILI9488_DFUNCTR);    //Display Function Control  RGB/MCU Interface Control
	writeData(0x02);    //MCU
	writeData(0x02);    //Source,Gate scan direction
	writeData(0x3B);    //in teoria dice che c'� un 3� parm... NL https://www.instructables.com/Arduino-and-35-Inch-320x480-TFT-LCD-ILI9488-SPI-In/

	writeCommandCS(ILI9488_SETIMAGE);   // Set Image Function
	writeData(0x00);    // Disable 24 bit data

	writeCommandCS(ILI9488_ADJCTRL3);   // Adjust Control 3
	writeData(0xA9);
	writeData(0x51);
	writeData(0x2C);
	writeData(0x82);    // D7 stream, loose


  writeCommandCS(ILI9488_SLPOUT);    //Exit Sleep
  __delay_ms(120);
  writeCommandCS(ILI9488_DISPON);    //Display on
#endif
  
  }

void setScrollArea(UGRAPH_COORD_T topFixedArea, UGRAPH_COORD_T bottomFixedArea){

  writeCommandCS(ILI9488_VSCRDEF); // Vertical scroll definition
  writeData(topFixedArea >> 8);
  writeData(topFixedArea);
  writeData((_height - topFixedArea - bottomFixedArea) >> 8);
  writeData(_height - topFixedArea - bottomFixedArea);
  writeData(bottomFixedArea >> 8);
  writeData(bottomFixedArea);
	}

void scroll(uint16_t pixels){

  writeCommandCS(ILI9488_VSCRSADD); // Vertical scrolling start address
  writeData(pixels >> 8);
  writeData(pixels);
	}

void setAddrWindow_ili9488(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h) {

  x += _xstart;
  y += _ystart;
  uint32_t xa = ((uint32_t)x << 16) | (x+w-1);
  uint32_t ya = ((uint32_t)y << 16) | (y+h-1); 
  
  writeCommandCS(ILI9488_CASET); // Column addr set
  writeData32(xa);

  writeCommandCS(ILI9488_PASET); // Row addr set
  writeData32(ya);

  writeCommandCS(ILI9488_RAMWR); // write to RAM
	}

int drawImage_ili9488(const uint16_t* img, UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h) {
  uint16_t o;
  uint16_t b;
  uint16_t i;

  // rudimentary clipping (drawChar w/big text requires this)
  if((x >= _width) || (y >= _height)) 
    return;
  if((x + w - 1) >= _width)  
    w = _width  - x;
  if((y + h - 1) >= _height) 
    h = _height - y;

  setAddrWindow_ili9488(x, y, x+w-1, y+h-1);

  // uint8_t hi = color >> 8, lo = color;

  SPI_DC_HIGH();
  SPI_CS_LOW();
  uint8_t linebuff[w*3+1];
  uint16_t pixels = w*h;
  // uint16_t count = 0;
  uint32_t count = 0;
  for(i=0; i < h; i++) {
    uint16_t pixcount = 0;
    for(o=0; o < w; o++) {
      uint8_t b1 = img[count++];
      uint8_t b2 = img[count++];
      uint16_t color = b1 << 8 | b2;
      linebuff[pixcount] = (((color & 0xF800) >> 11)* 255) / 31;
      pixcount++;
      linebuff[pixcount] = (((color & 0x07E0) >> 5) * 255) / 63;
      pixcount++;
      linebuff[pixcount] = ((color & 0x001F)* 255) / 31;
      pixcount++;
			} // for row
    for(b=0; b < w*3; b++)
      spiWrite(linebuff[b]);

		}// for col
  SPI_CS_HIGH();

	}


void pushColor(GFX_COLOR color) {

  SPI_DC_HIGH();
  SPI_CS_LOW();

  // spiWrite(color >> 8);
  // spiWrite(color);
  // spiWrite(0); // added for 24 bit
  write16BitColor(color);

  SPI_CS_HIGH();

	}

void pushColors(uint16_t *data, uint8_t len, BOOL first) {
  uint16_t color;
  uint8_t  buff[len*3+1];
  uint16_t count = 0;
  uint8_t lencount = len;
  uint16_t b;

  SPI_CS_LOW();
  if(first == TRUE) { // Issue GRAM write command only on first call
    SPI_DC_HIGH();
		}
  while(lencount--) {
    color = *data++;
    buff[count] = (((color & 0xF800) >> 11)* 255) / 31;
    count++;
    buff[count] = (((color & 0x07E0) >> 5) * 255) / 63;
    count++;
    buff[count] = ((color & 0x001F)* 255) / 31;
    count++;
		}
  for(b=0; b < len*3; b++)
    spiWrite(buff[b]);

  SPI_CS_HIGH();

	}

void write16BitColor(GFX_COLOR color) {
  struct __attribute((packed)) {
    union __attribute((packed)) {
      struct __attribute((packed)) { uint8_t dummy,r1,g1,b1; };
      uint32_t d;
      };
    } p34;

//  uint8_t r = (color & 0xF800) >> 8;
//  uint8_t g = (color & 0x07E0) >> 3;
//  uint8_t b = (color & 0x001F) << 3;

  p34.r1=(color & 0xF800) >> 8;
  p34.g1=(color & 0x07E0) >> 3;
  p34.b1=(color & 0x001F) << 3;

  SPI_DC_HIGH();
  SPI_CS_LOW();
//  spiWrite(b);
//  spiWrite(g);
//  spiWrite(r);
#define Color565ToRGB(color)    ((DWORD)( ((color & 0xf800) >> 8) | ((DWORD)(color & 0x07e0) << 5) | ((DWORD)(color & 0x001f) << 19) ))
//  SPI_WRITE16();
//  spiWrite(r);
  // 
  SPI_WRITE32(p34.d);   // sembra andare... non so quanto sia meglio (si spreca il tempo di 8 bit=~300nS=60istruzioni) ma ok
	// a guardare bene le righe horizz van male... boh?
  // forse non c'� abbastanza ritardo dopo CS e quindi i pixel si accavallano
  SPI_CS_HIGH();
  
  

	}

int drawPixel_ili9488(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {

  if((x < 0) ||(x >= _width) || (y < 0) || (y >= _height)) 
		return;

  setAddrWindow_ili9488(x,y,x+1,y+1);

  SPI_DC_HIGH();
  SPI_CS_LOW();

  // spiWrite(color >> 8);
  // spiWrite(color);
  // spiWrite(0); // added for 24 bit
  write16BitColor(color);

  SPI_CS_HIGH();

	}


void drawFastVLine_ili9488(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T h,
  GFX_COLOR color) {

  // Rudimentary clipping
  if((x >= _width) || (y >= _height)) return;

  if((y+h-1) >= _height)
    h = _height-y;

  setAddrWindow_ili9488(x, y, x, y+h-1);

//  uint8_t hi = color >> 8, lo = color;

  SPI_DC_HIGH();
  SPI_CS_LOW();

  while(h--) {
    // spiWrite(hi);
    // spiWrite(lo);
    // spiWrite(0); // added for 24 bit
    write16BitColor(color);

		}

  SPI_CS_HIGH();

	}


void drawFastHLine_ili9488(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w,
  GFX_COLOR color) {

  // Rudimentary clipping
  if((x >= _width) || (y >= _height)) 
		return;
  if((x+w-1) >= _width)  
		w = _width-x;
  setAddrWindow_ili9488(x, y, x+w-1, y);

  // uint8_t hi = color >> 8, lo = color;
  SPI_DC_HIGH();
  SPI_CS_LOW();
  while (w--) {
    // spiWrite(hi);
    // spiWrite(lo);
    // spiWrite(0); // added for 24 bit
    write16BitColor(color);
		}
  SPI_CS_HIGH();
	}

void fillScreen(GFX_COLOR color) {

  fillRect(0, 0,  _width, _height, color);
	}

// fill a rectangle
void fillRect(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h,
  GFX_COLOR color) {

  // rudimentary clipping (drawChar w/big text requires this)
  if((x >= _width) || (y >= _height)) 
		return;
  if((x + w - 1) >= _width)  
		w = _width  - x;
  if((y + h - 1) >= _height) 
		h = _height - y;

  setAddrWindow_ili9488(x, y, x+w-1, y+h-1);

  // uint8_t hi = color >> 8, lo = color;

  SPI_DC_HIGH();
  SPI_CS_LOW();
  for(y=h; y>0; y--) {
    for(x=w; x>0; x--) {
      // spiWrite(hi);
      // spiWrite(lo);
      // spiWrite(0); // added for 24 bit
      write16BitColor(color);
			}
		}
  SPI_CS_HIGH();

	}


void setRotation_ili9488(uint8_t m) {

  writeCommandCS(ILI9488_MADCTL);
  rotation = m % 4; // can't be higher than 3
  switch(rotation) {
    case 0:
      writeData(MADCTL_MX | MADCTL_BGR);
      _width  = ILI9488_TFTWIDTH;
      _height = ILI9488_TFTHEIGHT;
      break;
    case 1:
      writeData(MADCTL_MV | MADCTL_BGR);
      _width  = ILI9488_TFTHEIGHT;
      _height = ILI9488_TFTWIDTH;
      break;
    case 2:
      writeData(MADCTL_MY | MADCTL_BGR);
      _width  = ILI9488_TFTWIDTH;
      _height = ILI9488_TFTHEIGHT;
      break;
    case 3:
      writeData(MADCTL_MX | MADCTL_MY | MADCTL_MV | MADCTL_BGR);
      _width  = ILI9488_TFTHEIGHT;
      _height = ILI9488_TFTWIDTH;
      break;
		}
	}


void invertDisplay(BOOL i) {

  writeCommandCS(i ? ILI9488_INVON : ILI9488_INVOFF);
	}



uint8_t readcommand8_ili9488(uint8_t c, uint8_t index) {

  SPI_DC_LOW(); // command
  SPI_CS_LOW();
	spiWrite(0xD9);  // woo sekret command?
  SPI_DC_HIGH();   // data
	spiWrite(0x10 + index);
  SPI_CS_HIGH();

  SPI_DC_LOW();
//??	digitalWrite(_sclk, 0);
  SPI_CS_LOW();
	spiWrite(c);

  SPI_DC_HIGH();
	uint8_t r = spiRead();
  SPI_CS_HIGH();
  
	return r;
	}



/*

 uint16_t readcommand16(uint8_t c) {
 digitalWrite(_dc, LOW);
 if (_cs)
 digitalWrite(_cs, LOW);

 spiWrite(c);
 pinMode(_sid, INPUT); // input!
 uint16_t r = spiread();
 r <<= 8;
 r |= spiread();
 if (_cs)
 digitalWrite(_cs, HIGH);

 pinMode(_sid, OUTPUT); // back to output
 return r;
 }

 uint32_t ILI9488::readcommand32(uint8_t c) {
 digitalWrite(_dc, LOW);
 if (_cs)
 digitalWrite(_cs, LOW);
 spiWrite(c);
 pinMode(_sid, INPUT); // input!

 dummyclock();
 dummyclock();

 uint32_t r = spiread();
 r <<= 8;
 r |= spiread();
 r <<= 8;
 r |= spiread();
 r <<= 8;
 r |= spiread();
 if (_cs)
 digitalWrite(_cs, HIGH);

 pinMode(_sid, OUTPUT); // back to output
 return r;
 }

 */

