/* 
 * File:   interrupt.c
 * Author: katia ;) (e vediamo)
 *
 * Created on 30/8/21
 * 
 * 
 */

#include <xc.h>
#include "pc_pic_video.h"
#include <sys/attribs.h>
#include <sys/kmem.h>



extern volatile unsigned int Timer;
extern volatile WORD vLine;
extern BYTE DMA_READY videoRAM[640L*480];  
extern WORD verticalLines,horizontalPixels;
extern enum VIDEO_MODE videoMode;

#define PMPWaitBusy()   while(!PMSTATbits.OBE);     // VERIFICARE



void __ISR(_UART1_RX_VECTOR,ipl4AUTO) UART1_ISR(void) {
  
//  LATDbits.LATD4 ^= 1;    // LED to indicate the ISR.
  char curChar = U1RXREG;
  IFS3bits.U1RXIF = 0;  // Clear the interrupt flag!
  }

void __ISR(_DMA0_VECTOR,ipl5AUTO) DMA_ISR(void) {
  // in effetti NON SERVE qua :)
  
  
  

//  LATEINV=0X0010;     		// LED4 CHECK Timing!		

  vLine++;
  
  if(vLine>=_height) {   // 
    vLine=0;
    }
  
  switch(videoMode) {
    case MODE_VGA:       // VGA
#ifndef USING_SIMULATOR
      DCH0SSA = KVA_TO_PA(((BYTE*)&videoRAM)+vLine*_width);  // transfer source physical address
#else
      DCH0SSA = &videoRAM;  // transfer source physical address
#endif
//DCH0SSIZ
      VHSync=1;     // 125uS con 640x480 e Timer1=40
      // 82uS con T1=25; 64 con 20
      Nop();Nop();
      VHSync=0;
      break;
    case MODE_COMPOSITE:       // composito
      if(!VHSync)     // FINIRE!
        VHSync=1;
      else
        VHSync=0;
      break;
    case MODE_LCD:       // LCD SPI
      break;
    case MODE_NONE:
      // spegnere video!
    default:
      break;
    }

        
  DCH0INTCLR = _DCH0INT_CHSDIF_MASK /*DCH0INTbits.CHDDIF=0*/;

  
  IFS4CLR = _IFS4_DMA0IF_MASK /*IFS4bits.DMA0IF=0*/;  // Clear the interrupt flag!
  
  }


void __ISR(_TIMER_2_VECTOR,ipl2AUTO) TMR2_ISR(void) {
  
  Timer++;
  LATF ^= 0xffff;     // test timing 3.2mS con PR2=10000 e PS=64 (Fclock periferiche/timer=200MHz!)
  IFS0CLR = _IFS0_T2IF_MASK;
  }

void __ISR(_PMP_VECTOR,ipl3AUTO) PMP_ISR(void) {
  BYTE addr,reg;
  static WORD parms[16];
  static BYTE parmN=0,oldReg=0;
  
  // verificare se � una buona idea scrivere dentro IRQ; inoltre credo si generi IRQ anche su WRite, che per� non importa tanto va perso
//  addr=PMRADDR & 63;
  addr=(PORTG >> 4) & 0b00111100;
  addr |= (PORTB >> 14);    // questi restano buoni come PMA0..1 ev. slave buffered mode, INVERTITI!
  
  reg=addr;
  if(reg != oldReg) {
    oldReg=reg;
    parmN=0;
    }
  if(1 /*WR*/) {
  switch(reg) {
    case 0:
      parms[parmN++]=PMRDIN;
      if(parmN>=4) {
        oldReg=parmN=0;
        }
      break;
    case 4:
      break;
    case BIOS_VIDEO_MODE:
      parms[parmN++]=PMRDIN;
      if(parmN>=6) {
        SetMode(parms[0],MAKEWORD(parms[1],parms[2]),MAKEWORD(parms[3],parms[4]),parms[5]);
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_CLS:
      switch(videoMode) {
        case MODE_VGA:
          screenCLS(0);			// ev. segue colore MAKEWORD(parms[0],parms[1]);
          break;
        case MODE_COMPOSITE:
          screenCLS(0);			// ev. segue colore MAKEWORD(parms[0],parms[1]);
          break;
        case MODE_LCD:
          screenCLS(0);			// ev. segue colore MAKEWORD(parms[0],parms[1]);
          break;
        }
      oldReg=parmN=0;
      break;
    case BIOS_VIDEO_COLORS:
      parms[parmN++]=PMRDIN;
      if(parmN>=4) {
      switch(videoMode) {
        case MODE_VGA:
        setColors(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]));
          break;
        case MODE_COMPOSITE:
        setColors(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]));
          break;
        case MODE_LCD:
        setColors(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]));
          break;
        }
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_XY:
      parms[parmN++]=PMRDIN;
      if(parmN>=4) {
        switch(videoMode) {
          case MODE_VGA:
          setCursor(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]));
            break;
          case MODE_COMPOSITE:
          setCursor(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]));
            break;
          case MODE_LCD:
          setCursor(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]));
            break;
          }
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_PIXEL:
      parms[parmN++]=PMRDIN;
      if(parmN>=6) {
        switch(videoMode) {
          case MODE_VGA:
        drawPixel(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]));
            break;
          case MODE_COMPOSITE:
        drawPixel(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]));
            break;
          case MODE_LCD:
        drawPixelLCD(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]));
            break;
          }
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_LINE:
      parms[parmN++]=PMRDIN;
      if(parmN>=10) {
        switch(videoMode) {
          case MODE_VGA:
        drawLine(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]),MAKEWORD(parms[8],parms[9]));
            break;
          case MODE_COMPOSITE:
        drawLine(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]),MAKEWORD(parms[8],parms[9]));
            break;
          case MODE_LCD:
        drawLineLCD(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]),MAKEWORD(parms[8],parms[9]));
            break;
          }
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_RECTANGLE:
      parms[parmN++]=PMRDIN;
      if(parmN>=10) {
        switch(videoMode) {
          case MODE_VGA:
        drawRectangle(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]),MAKEWORD(parms[8],parms[9]));
            break;
          case MODE_COMPOSITE:
        drawRectangle(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]),MAKEWORD(parms[8],parms[9]));
            break;
          case MODE_LCD:
        drawRectLCD(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]),MAKEWORD(parms[8],parms[9]));
            break;
          }
//        drawBar(parms[0],parms[1],parms[2],parms[3],parms[4]);
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_CIRCLE:
      parms[parmN++]=PMRDIN;
      if(parmN>=8) {
        switch(videoMode) {
          case MODE_VGA:
        drawCircle(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]));
            break;
          case MODE_COMPOSITE:
        drawCircle(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]));
            break;
          case MODE_LCD:
        drawCircleLCD(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),MAKEWORD(parms[4],parms[5]),
                MAKEWORD(parms[6],parms[7]));
            break;
          }
        oldReg=parmN=0;
        }
      break;
    case BIOS_VIDEO_CHAR:
      parms[parmN++]=PMRDIN;
      if(parmN>=7) {
        switch(videoMode) {
          case MODE_VGA:
        writeChar(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),parms[4],
                MAKEWORD(parms[5],parms[6]));
            break;
          case MODE_COMPOSITE:
        writeChar(MAKEWORD(parms[0],parms[1]),MAKEWORD(parms[2],parms[3]),parms[4],
                MAKEWORD(parms[5],parms[6]));
            break;
          case MODE_LCD:
            cwrite(parms[4]);
            break;
          }
        oldReg=parmN=0;
        }
      break;
    }
  }
  else {        // RD
  switch(reg) {
    case BIOS_GETID:
      PMDOUT='V';
      PMPWaitBusy();
      break;
    case BIOS_GETCONFIG:
      PMDOUT=VERNUML;
      PMPWaitBusy();
      break;
    case 2:
      PMDOUT=VERNUMH;
      PMPWaitBusy();
      break;
    case BIOS_IRQ_REQUEST:
      PMPWaitBusy();
      break;
    }
  }
  
  IFS4CLR = _IFS4_PMPIF_MASK;
  }

// ---------------------------------------------------------------------------------------
// declared static in case exception condition would prevent
// auto variable being created
static enum {
	EXCEP_IRQ = 0,			// interrupt
	EXCEP_AdEL = 4,			// address error exception (load or ifetch)
	EXCEP_AdES,				// address error exception (store)
	EXCEP_IBE,				// bus error (ifetch)
	EXCEP_DBE,				// bus error (load/store)
	EXCEP_Sys,				// syscall
	EXCEP_Bp,				// breakpoint
	EXCEP_RI,				// reserved instruction
	EXCEP_CpU,				// coprocessor unusable
	EXCEP_Overflow,			// arithmetic overflow
	EXCEP_Trap,				// trap (possible divide by zero)
	EXCEP_IS1 = 16,			// implementation specific 1
	EXCEP_CEU,				// CorExtend Unuseable
	EXCEP_C2E				// coprocessor 2
  } _excep_code;

static unsigned int _epc_code;
static unsigned int _excep_addr;

void __attribute__((weak)) _general_exception_handler(uint32_t __attribute__((unused)) code, uint32_t __attribute__((unused)) address) {
  }

void __attribute__((nomips16,used)) _general_exception_handler_entry(void) {
  
	asm volatile("mfc0 %0,$13" : "=r" (_epc_code));
	asm volatile("mfc0 %0,$14" : "=r" (_excep_addr));

	_excep_code = (_epc_code & 0x0000007C) >> 2;

  _general_exception_handler(_excep_code, _excep_addr);

	while(1)	{
		// Examine _excep_code to identify the type of exception
		// Examine _excep_addr to find the address that caused the exception
    }
  }


/*SVGA Signal 800 x 600 @ 60 Hz timing

General timing
Screen refresh rate	60 Hz
Vertical refresh	37.878787878788 kHz
Pixel freq.	40.0 MHz
Horizontal timing (line)
Polarity of horizontal sync pulse is positive.

Scanline part	Pixels	Time [�s]
Visible area	800	  20
Front porch	  40	  1
Sync pulse	  128	  3.2
Back porch	  88	  2.2
Whole line	  1056	26.4
Vertical timing (frame)
Polarity of vertical sync pulse is positive.

Frame part	Lines	Time [ms]
Visible area	600	15.84
Front porch	  1	  0.0264
Sync pulse	  4	  0.1056
Back porch	  23	0.6072
Whole frame  	628	16.5792
*/

/*
Horizonal Timing

Horizonal Dots         640     640     640        
Vertical Scan Lines    350     400     480
Horiz. Sync Polarity   POS     NEG     NEG
A (us)                 31.77   31.77   31.77     Scanline time
B (us)                 3.77    3.77    3.77      Sync pulse lenght 
C (us)                 1.89    1.89    1.89      Back porch
D (us)                 25.17   25.17   25.17     Active video time
E (us)                 0.94    0.94    0.94      Front porch

         ______________________          ________
________|        VIDEO         |________| VIDEO (next line)
    |-C-|----------D-----------|-E-|
__   ______________________________   ___________
  |_|                              |_|
  |B|
  |---------------A----------------|

Vertical Timing

Horizonal Dots         640     640     640
Vertical Scan Lines    350     400     480
Vert. Sync Polarity    NEG     POS     NEG      
Vertical Frequency     70Hz    70Hz    60Hz
O (ms)                 14.27   14.27   16.68     Total frame time
P (ms)                 0.06    0.06    0.06      Sync length
Q (ms)                 1.88    1.08    1.02      Back porch
R (ms)                 11.13   12.72   15.25     Active video time
S (ms)                 1.2     0.41    0.35      Front porch

         ______________________          ________
________|        VIDEO         |________|  VIDEO (next frame)
    |-Q-|----------R-----------|-S-|
__   ______________________________   ___________
  |_|                              |_|
  |P|
  |---------------O----------------|

		

"VGA industry standard" 640x480 pixel mode

General characteristics

Clock frequency 25.175 MHz
Line  frequency 31469 Hz
Field frequency 59.94 Hz

One line

  8 pixels front porch
 96 pixels horizontal sync
 40 pixels back porch
  8 pixels left border
640 pixels video
  8 pixels right border
---
800 pixels total per line

One field

  2 lines front porch
  2 lines vertical sync
 25 lines back porch
  8 lines top border
480 lines video
  8 lines bottom border
---
525 lines total per field              

Other details

Sync polarity: H negative, V negative
Scan type: non interlaced.
*/

