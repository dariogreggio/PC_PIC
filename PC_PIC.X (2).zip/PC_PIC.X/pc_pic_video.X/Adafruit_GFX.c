/*
This is the core graphics library for all our displays, providing a common
set of graphics primitives (points, lines, circles, etc.).  It needs to be
paired with a hardware-specific library for each display device we carry
(to handle the lower-level functions).

Adafruit invests time and resources providing this open source code, please
support Adafruit & open-source hardware by purchasing products from Adafruit!

Copyright (c) 2013 Adafruit Industries.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

	GD adapted to Microchip 24/2/2016 (and 2014 too) - porcodio
	(inizialmente pareva che quel display 7735 fosse come il 5110 invece no, ... vabbe' � migliore!)
*/

#include "pc_pic_video.h"
#include "genericTypedefs.h"

#include "Adafruit_GFX.h"

#include "Adafruit_ST7735.h"
#include "Adafruit_ILI9488.h"

#include <string.h>



UGRAPH_COORD_T _width, _height, // Display w/h as modified by current rotation
  cursor_x, cursor_y;
GFX_COLOR textcolor, textbgcolor;
BYTE textsize,textsize_x,textsize_y;
BOOL wrap,_cp437; // If set, 'wrap' text at right edge of display
extern const unsigned char font6x8_basic[];
extern const unsigned char font8x8_basic[];
GFXfont *gfxFont;

void drawBG(void);


//ADAFRUIT_GFX Adafruit_GFX_this;

#ifdef USE_GFX_UI

ADAFRUIT_GFX _gfx;
GRAPH_COORD_T _x, _y;
UGRAPH_COORD_T _w, _h;
UINT8 _textsize;
GFX_COLOR _outlinecolor, _fillcolor, _textcolor;
char _label[10];

BOOL currstate, laststate;
#endif


void Adafruit_GFX(UGRAPH_COORD_T w, UGRAPH_COORD_T h) {

  _width    = w;
  _height   = h;

  cursor_y  = cursor_x    = 0;
  textsize  = 1;
  textcolor = WHITE;
  textcolor = BLACK;
  wrap      = TRUE;
  _cp437    = FALSE;
  gfxFont   = NULL;
	}

// Draw a circle outline
void drawCircleLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T r, GFX_COLOR color) {
  GRAPH_COORD_T f = 1 - r;
  GRAPH_COORD_T ddF_x = 1;
  GRAPH_COORD_T ddF_y = -2 * r;
  GRAPH_COORD_T x = 0;
  GRAPH_COORD_T y = r;

  drawPixelLCD(x0  , y0+r, color);
  drawPixelLCD(x0  , y0-r, color);
  drawPixelLCD(x0+r, y0  , color);
  drawPixelLCD(x0-r, y0  , color);

  while(x<y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    drawPixelLCD(x0 + x, y0 + y, color);
    drawPixelLCD(x0 - x, y0 + y, color);
    drawPixelLCD(x0 + x, y0 - y, color);
    drawPixelLCD(x0 - x, y0 - y, color);
    drawPixelLCD(x0 + y, y0 + x, color);
    drawPixelLCD(x0 - y, y0 + x, color);
    drawPixelLCD(x0 + y, y0 - x, color);
    drawPixelLCD(x0 - y, y0 - x, color);
		}
	}

void drawCircleHelperLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T r, UINT8 cornername, GFX_COLOR color) {
  GRAPH_COORD_T f     = 1 - r;
  GRAPH_COORD_T ddF_x = 1;
  GRAPH_COORD_T ddF_y = -2 * r;
  GRAPH_COORD_T x     = 0;
  GRAPH_COORD_T y     = r;

  while(x<y) {
    if(f >= 0) {
      y--;
      ddF_y += 2;
      f     += ddF_y;
    }
    x++;
    ddF_x += 2;
    f     += ddF_x;
    if(cornername & 0x4) {
      drawPixelLCD(x0 + x, y0 + y, color);
      drawPixelLCD(x0 + y, y0 + x, color);
    	}
    if(cornername & 0x2) {
      drawPixelLCD(x0 + x, y0 - y, color);
      drawPixelLCD(x0 + y, y0 - x, color);
    	}
    if(cornername & 0x8) {
      drawPixelLCD(x0 - y, y0 + x, color);
      drawPixelLCD(x0 - x, y0 + y, color);
    	}
    if(cornername & 0x1) {
      drawPixelLCD(x0 - y, y0 - x, color);
      drawPixelLCD(x0 - x, y0 - y, color);
  	  }
		}
	}

void fillCircleLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T r, GFX_COLOR color) {

  drawFastVLine(x0, y0-r, 2*r+1, color);
  fillCircleHelperLCD(x0, y0, r, 3, 0, color);
	}

// Used to do circles and roundrects
void fillCircleHelperLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T r, UINT8 cornername, GRAPH_COORD_T delta, GFX_COLOR color) {
  GRAPH_COORD_T f     = 1 - r;
  GRAPH_COORD_T ddF_x = 1;
  GRAPH_COORD_T ddF_y = -2 * r;
  GRAPH_COORD_T x     = 0;
  GRAPH_COORD_T y     = r;

  while(x<y) {
    if(f >= 0) {
      y--;
      ddF_y += 2;
      f     += ddF_y;
    	}
    x++;
    ddF_x += 2;
    f     += ddF_x;

    if(cornername & 0x1) {
#warning GESTIRE ST7735 & ILI9488
      drawFastVLine(x0+x, y0-y, 2*y+1+delta, color);
      drawFastVLine(x0+y, y0-x, 2*x+1+delta, color);
    	}
    if(cornername & 0x2) {
      drawFastVLine(x0-x, y0-y, 2*y+1+delta, color);
      drawFastVLine(x0-y, y0-x, 2*x+1+delta, color);
    	}
  	}
	}


// Draw a rounded rectangle
void drawRoundRectLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h, UGRAPH_COORD_T r, GFX_COLOR color) {

  // smarter version
  drawFastHLine(x+r  , y    , w-2*r, color); // Top
  drawFastHLine(x+r  , y+h-1, w-2*r, color); // Bottom
  drawFastVLine(x    , y+r  , h-2*r, color); // Left
  drawFastVLine(x+w-1, y+r  , h-2*r, color); // Right
  // draw four corners
  drawCircleHelperLCD(x+r    , y+r    , r, 1, color);
  drawCircleHelperLCD(x+w-r-1, y+r    , r, 2, color);
  drawCircleHelperLCD(x+w-r-1, y+h-r-1, r, 4, color);
  drawCircleHelperLCD(x+r    , y+h-r-1, r, 8, color);
  
	}

// Fill a rounded rectangle
void fillRoundRectLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h, UGRAPH_COORD_T r, GFX_COLOR color) {

  // smarter version
  fillRectLCD(x+r, y, w-2*r, h, color);

  // draw four corners
  fillCircleHelperLCD(x+w-r-1, y+r, r, 1, h-2*r-1, color);
  fillCircleHelperLCD(x+r    , y+r, r, 2, h-2*r-1, color);
	}

// Draw a triangle
void drawTriangleLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR color) {

  drawLineLCD(x0, y0, x1, y1, color);
  drawLineLCD(x1, y1, x2, y2, color);
  drawLineLCD(x2, y2, x0, y0, color);
	}

// Fill a triangle
void fillTriangleLCD(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR color) {
  GRAPH_COORD_T a, b, y, last;
  GRAPH_COORD_T dx01, dy01, dx02, dy02, dx12, dy12;
  INT32 sa, sb;


  // Sort coordinates by Y order (y2 >= y1 >= y0)
  if(y0 > y1) {
    _swap(&y0,&y1); _swap(&x0,&x1);
 		}
  if(y1 > y2) {
    _swap(&y2,&y1); _swap(&x2,&x1);
  	}
  if(y0 > y1) {
    _swap(&y0,&y1); _swap(&x0,&x1);
	  }

  if(y0 == y2) { // Handle awkward all-on-same-line case as its own thing
    a = b = x0;
    if(x1 < a)      
			a = x1;
    else 
			if(x1 > b) 
				b = x1;
    if(x2 < a)      
			a = x2;
    else 
			if(x2 > b) 
				b = x2;
    drawFastHLine(a, y0, b-a+1, color);
    return;
  	}

    dx01 = x1 - x0;
    dy01 = y1 - y0;
    dx02 = x2 - x0;
    dy02 = y2 - y0;
    dx12 = x2 - x1;
    dy12 = y2 - y1;
    sa   = 0,
    sb   = 0;

  // For upper part of triangle, find scanline crossings for segments
  // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
  // is included here (and second loop will be skipped, avoiding a /0
  // error there), otherwise scanline y1 is skipped here and handled
  // in the second loop...which also avoids a /0 error here if y0=y1
  // (flat-topped triangle).
  if(y1 == y2) 
		last = y1;   // Include y1 scanline
  else         
		last = y1-1; // Skip it

  for(y=y0; y<=last; y++) {
    a   = x0 + sa / dy01;
    b   = x0 + sb / dy02;
    sa += dx01;
    sb += dx02;
    /* longhand:
    a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
    b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    */
    if(a > b) 
			_swap(&a,&b);
    drawFastHLine(a, y, b-a+1, color);
  	}

  // For lower part of triangle, find scanline crossings for segments
  // 0-2 and 1-2.  This loop is skipped if y1=y2.
  sa = dx12 * (y - y1);
  sb = dx02 * (y - y0);
  for(; y<=y2; y++) {
    a   = x1 + sa / dy12;
    b   = x0 + sb / dy02;
    sa += dx12;
    sb += dx02;
    /* longhand:
    a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
    b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    */
    if(a > b) 
			_swap(&a,&b);
    drawFastHLine(a, y, b-a+1, color);
  	}
  
	}

// Draw a 1-bit image (bitmap) at the specified (x,y) position from the
// provided bitmap buffer (must be PROGMEM memory) using the specified
// foreground color (unset bits are transparent).
void drawBitmap(UGRAPH_COORD_T x, UGRAPH_COORD_T y, const UINT8 *bitmap, UGRAPH_COORD_T w, UGRAPH_COORD_T h, UINT16 color) {
  GRAPH_COORD_T i, j, byteWidth = (w+7) / 8;
  UINT8 byte=0;

  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      if(i & 7) 
				byte <<= 1;
      else      
				byte   = pgm_read_byte(bitmap + j * byteWidth + i / 8);
      if(byte & 0x80) 
				drawPixelLCD(x+i, y+j, color);
  	  }
  	}
	}

// Draw a 1-bit image (bitmap) at the specified (x,y) position from the
// provided bitmap buffer (must be PROGMEM memory) using the specified
// foreground (for set bits) and background (for clear bits) colors.
void drawBitmapBG(UGRAPH_COORD_T x, UGRAPH_COORD_T y, const UINT8 *bitmap, UGRAPH_COORD_T w, UGRAPH_COORD_T h, UINT16 color, UINT16 bg) {
  GRAPH_COORD_T i, j, byteWidth = (w + 7) / 8;
  UINT8 byte=0;

  for(j=0; j<h; j++) {
    for(i=0; i<w; i++ ) {
      if(i & 7) 
				byte <<= 1;
      else      
				byte   = pgm_read_byte(bitmap + j * byteWidth + i / 8);
      if(byte & 0x80) 
				drawPixelLCD(x+i, y+j, color);
      else            
				drawPixelLCD(x+i, y+j, bg);
    	}
  	}
	}



size_t cwrite(UINT8 c) {

  if(!gfxFont) { // 'Classic' built-in font

    switch(c) {
      case '\n':
        cursor_y += textsize_y;
        cursor_x  = 0;
        break;
      case '\r':
        break;
      // skip em
      default:
        if(wrap && ((cursor_x + textsize_x) >= _width)) { 	// Heading off edge?
          cursor_x  = 0;            // Reset x to zero
          cursor_y += textsize_y; // Advance y one line
          }
        drawCharLCD(cursor_x, cursor_y, c, textcolor, textbgcolor, textsize);
        cursor_x += textsize_x;
        break;
    	}

  	} 
	else { // Custom font

    switch(c) {
      case '\n':
        cursor_x  = 0;
        cursor_y += (GRAPH_COORD_T)textsize *
                    (UINT8)pgm_read_byte(&gfxFont->yAdvance);
        break;
      case '\r':
        break;
      default:
        {
        UINT8 first = pgm_read_byte(&gfxFont->first);
        if((c >= first) && (c <= (UINT8)pgm_read_byte(&gfxFont->last))) {
          UINT8   c2    = c - pgm_read_byte(&gfxFont->first);
          GFXglyph *glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c2]);
          UINT8   w     = pgm_read_byte(&glyph->width),
                    h     = pgm_read_byte(&glyph->height);
          if((w > 0) && (h > 0)) { // Is there an associated bitmap?
            GRAPH_COORD_T xo = (INT8)pgm_read_byte(&glyph->xOffset); // sic
            if(wrap && ((cursor_x + textsize * (xo + w)) >= _width)) {
              // Drawing character would go off right edge; wrap to new line
              cursor_x  = 0;
              cursor_y += (GRAPH_COORD_T)textsize *
                          (UINT8)pgm_read_byte(&gfxFont->yAdvance);
              }
            drawCharLCD(cursor_x, cursor_y, c, textcolor, textbgcolor, textsize);
            }
          cursor_x += pgm_read_byte(&glyph->xAdvance) * (GRAPH_COORD_T)textsize;
          }
        }
        break;
    	}

  	}

  return 1;
	}

// Draw a character
void drawCharLCD(UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size) {
	INT8 i,j;
	BYTE *fontPtr;

  if(!gfxFont) { // 'Classic' built-in font

    if((x >= _width)            || // Clip right
       (y >= _height)           || // Clip bottom
       ((x + 6 * size - 1) < 0) || // Clip left
       ((y + 8 * size - 1) < 0))   // Clip top
      return;

    if(!_cp437 && (c >= 176)) 
			c++; // Handle 'classic' charset behavior

    if(textsize_x==6)
      fontPtr=(BYTE *)font6x8_basic+((UINT16)c)*8;
    else
      fontPtr=(BYTE *)font8x8_basic+((UINT16)c)*8;
    for(i=0; i<8; i++) {
      UINT8 line;
			line = pgm_read_byte(fontPtr+i);
      for(j=0; j<8; j++, line <<= 1) {
        if(line & 0x80) {
          if(size == 1) 
						drawPixelLCD(x+j, y+i, color);
          else
		        fillRectLCD(x+(j*size), y+(i*size), size, size, color);
        	} 
				else if(bg != color) {
          if(size == 1) 
						drawPixelLCD(x+j, y+i, bg);
          else          
						fillRectLCD(x+(j*size), y+(i*size), size, size, bg);
      	  }
    	  }
  	  }

	  } 
	else { // Custom font
    GFXglyph *glyph;
    UINT8  *bitmap;
    UINT16 bo;
    UINT8  w, h, xa;
    INT8   xo, yo;
    UINT8  xx, yy, bits, bit = 0;
    GRAPH_COORD_T  xo16, yo16;

    // Character is assumed previously filtered by write() to eliminate
    // newlines, returns, non-printable characters, etc.  Calling drawChar()
    // directly with 'bad' characters of font may cause mayhem!

    c -= pgm_read_byte(&gfxFont->first);
    glyph  = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
    bitmap = (UINT8 *)pgm_read_pointer(&gfxFont->bitmap);

    bo = pgm_read_word(&glyph->bitmapOffset);
    w  = pgm_read_byte(&glyph->width),
             h  = pgm_read_byte(&glyph->height),
             xa = pgm_read_byte(&glyph->xAdvance);
    xo = pgm_read_byte(&glyph->xOffset),
             yo = pgm_read_byte(&glyph->yOffset);
    xx, yy, bits, bit = 0;
    xo16, yo16;

    if(size > 1) {
      xo16 = xo;
      yo16 = yo;
   		}

    // Todo: Add character clipping here

    // NOTE: THERE IS NO 'BACKGROUND' COLOR OPTION ON CUSTOM FONTS.
    // THIS IS ON PURPOSE AND BY DESIGN.  The background color feature
    // has typically been used with the 'classic' font to overwrite old
    // screen contents with new data.  This ONLY works because the
    // characters are a uniform size; it's not a sensible thing to do with
    // proportionally-spaced fonts with glyphs of varying sizes (and that
    // may overlap).  To replace previously-drawn text when using a custom
    // font, use the getTextBounds() function to determine the smallest
    // rectangle encompassing a string, erase the area with fillRect(),
    // then draw new text.  This WILL unfortunately 'blink' the text, but
    // is unavoidable.  Drawing 'background' pixels will NOT fix this,
    // only creates a new set of problems.  Have an idea to work around
    // this (a canvas object type for MCUs that can afford the RAM and
    // displays supporting setAddrWindow() and pushColors()), but haven't
    // implemented this yet.

    for(yy=0; yy<h; yy++) {
      for(xx=0; xx<w; xx++) {
        if(!(bit++ & 7)) {
          bits = pgm_read_byte(&bitmap[bo++]);
        	}
        if(bits & 0x80) {
          if(size == 1) {
            drawPixelLCD(x+xo+xx, y+yo+yy, color);
          	} 
					else {
            fillRectLCD(x+(xo16+xx)*size, y+(yo16+yy)*size, size, size, color);
          	}
        	}
        bits <<= 1;
      	}
    	}

  	} // End classic vs custom font
  
	}


void setTextSize(UINT8 s) {

  textsize = (s > 0) ? s : 1;
  
  textsize_x=IS_ILI() ? 8*textsize : 6*textsize;  // per ora, per display piccolo
  textsize_y=8*textsize;
  }

void setTextColor(UINT16 c) {

  // For 'transparent' background, we'll set the bg
  //   to the same as fg instead of using a flag
  textcolor = textbgcolor = c;
	}

void setTextColorBG(WORD c, WORD b) {
  
	textcolor   = c;
  textbgcolor = b; 
	}

void setTextWrap(BOOL w) {

  wrap = w;
	}

UINT8 getRotation(void) {

  return rotation;
	}


// Enable (or disable) Code Page 437-compatible charset.
// There was an error in glcdfont.c for the longest time -- one character
// (#176, the 'light shade' block) was missing -- this threw off the index
// of every character that followed it.  But a TON of code has been written
// with the erroneous character indices.  By default, the library uses the
// original 'wrong' behavior and old sketches will still work.  Pass 'true'
// to this function to use correct CP437 character values in your code.
void cp437(BOOL x) {
  
	_cp437 = x;
	}

void setFont(const GFXfont *f) {

  if(f) {          // Font struct pointer passed in?
    if(!gfxFont) { // And no current font struct?
      // Switching from classic to new font behavior.
      // Move cursor pos down 6 pixels so it's on baseline.
      cursor_y += 6;
    	}
  	} 
	else if(gfxFont) { // NULL passed.  Current font struct defined?
    // Switching from new to classic font behavior.
    // Move cursor pos up 6 pixels so it's at top-left of char.
    cursor_y -= 6;
  	}
  gfxFont = (GFXfont *)f;
	}

// Pass string and a cursor position, returns UL corner and W,H.
void getTextBounds(char *str, UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T *x1, UGRAPH_COORD_T *y1, UGRAPH_COORD_T *w, UGRAPH_COORD_T *h) {
  UINT8 c; // Current character

  *x1 = x;
  *y1 = y;
  *w  = *h = 0;

  if(gfxFont) {

    GFXglyph *glyph;
    UINT8   first = pgm_read_byte(&gfxFont->first),
              last  = pgm_read_byte(&gfxFont->last),
              gw, gh, xa;
    INT8    xo, yo;
    GRAPH_COORD_T   minx = _width, miny = _height, maxx = -1, maxy = -1,
              gx1, gy1, gx2, gy2, ts = (GRAPH_COORD_T)textsize,
              ya = ts * (UINT8)pgm_read_byte(&gfxFont->yAdvance);

    while(1) {
  		c=*str++;
			if(!c)
				break;
      if(c != '\n') { // Not a newline
        if(c != '\r') { // Not a carriage return, is normal char
          if((c >= first) && (c <= last)) { // Char present in current font
            c    -= first;
            glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
            gw    = pgm_read_byte(&glyph->width);
            gh    = pgm_read_byte(&glyph->height);
            xa    = pgm_read_byte(&glyph->xAdvance);
            xo    = pgm_read_byte(&glyph->xOffset);
            yo    = pgm_read_byte(&glyph->yOffset);
            if(wrap && ((x + (((GRAPH_COORD_T)xo + gw) * ts)) >= _width)) {
              // Line wrap
              x  = 0;  // Reset x to 0
              y += ya; // Advance y by 1 line
            }
            gx1 = x   + xo * ts;
            gy1 = y   + yo * ts;
            gx2 = gx1 + gw * ts - 1;
            gy2 = gy1 + gh * ts - 1;
            if(gx1 < minx) 
							minx = gx1;
            if(gy1 < miny) 
							miny = gy1;
            if(gx2 > maxx) 
							maxx = gx2;
            if(gy2 > maxy) 
							maxy = gy2;
            x += xa * ts;
          	}
        	} // Carriage return = do nothing
      	} 
			else { // Newline
        x  = 0;  // Reset x
        y += ya; // Advance y by 1 line
      	}
    	}
    // End of string
    *x1 = minx;
    *y1 = miny;
    if(maxx >= minx) 
			*w  = maxx - minx + 1;
    if(maxy >= miny) 
			*h  = maxy - miny + 1;

  	} 
	else { // Default font
		{
    UGRAPH_COORD_T lineWidth = 0, maxWidth = 0; // Width of current, all lines

    while(1) {
			if(str) {
				c=*str++;
				}
			if(!c)
				break;
      if(c != '\n') { // Not a newline
        if(c != '\r') { // Not a carriage return, is normal char
          if(wrap && ((x + textsize_x) >= _width)) {
            x  = 0;            // Reset x to 0
            y += textsize_y; // Advance y by 1 line
            if(lineWidth > maxWidth) maxWidth = lineWidth; // Save widest line
            lineWidth  = textsize_x; // First char on new line
          	} 
					else { // No line wrap, just keep incrementing X
            lineWidth += textsize_x; // Includes interchar x gap
          	}
        	} // Carriage return = do nothing
      	} 
			else { // Newline
        x  = 0;            // Reset x to 0
        y += textsize_y; // Advance y by 1 line
        if(lineWidth > maxWidth) maxWidth = lineWidth; // Save widest line
        lineWidth = 0;     // Reset lineWidth for new line
      	}
    	}
    // End of string
    if(lineWidth) 
			y += textsize_y; // Add height of last (or only) line
    *w = maxWidth - 1;               // Don't include last interchar x gap
    *h = y - *y1;
		}

  	} // End classic vs custom font
	}


// Return the size of the display (per current rotation)
UGRAPH_COORD_T width(void) {
  
	return _width;
	}

UGRAPH_COORD_T height(void) {
  
	return _height;
	}


/***************************************************************************/
// code for the GFX button UI element

#ifdef USE_GFX_UI
void Adafruit_GFX_Button(void) {
  
	_gfx = 0;
	}

void initButton(ADAFRUIT_GFX gfx, UGRAPH_COORD_T x, UGRAPH_COORD_T y, UINT8 w, UINT8 h,
  UINT16 outline, UINT16 fill, UINT16 textcolor,
  char *label, UINT8 textsize) {

  _x            = x;
  _y            = y;
  _w            = w;
  _h            = h;
  _outlinecolor = outline;
  _fillcolor    = fill;
  _textcolor    = textcolor;
  _textsize     = textsize;
  _gfx          = gfx;
  strncpy(_label, label, 9);
  _label[9] = 0;
	}

void drawButton(BOOL inverted) {
  UINT16 fill, outline, text;

  if(!inverted) {
    fill    = _fillcolor;
    outline = _outlinecolor;
    text    = _textcolor;
  	} 
	else {
    fill    = _textcolor;
    outline = _outlinecolor;
    text    = _fillcolor;
  }

  fillRoundRect(_x - (_w/2), _y - (_h/2), _w, _h, min(_w,_h)/4, fill);
  drawRoundRect(_x - (_w/2), _y - (_h/2), _w, _h, min(_w,_h)/4, outline);

  setCursor(_x - strlen(_label)*3*_textsize, _y-4*_textsize);
  setTextColor(text);
  setTextSize(_textsize);
  gfx_print(_label);
	}

BOOL contains(UGRAPH_COORD_T x, UGRAPH_COORD_T y) {

  if((x < (_x - _w/2)) || (x > (_x + _w/2))) 
		return FALSE;
  if((y < (_y - _h/2)) || (y > (_y + _h/2))) 
		return FALSE;
  return TRUE;
	}

void press(BOOL p) {

  laststate = currstate;
  currstate = p;
	}

BOOL Adafruit_GFX_Button_isPressed() { return currstate; }
BOOL Adafruit_GFX_Button_justPressed() { return (currstate && !laststate); }
BOOL Adafruit_GFX_Button_justReleased() { return (!currstate && laststate); }

#endif


void gfx_print(char *s) {

	while(*s) 
		cwrite(*s++);
	}

//retrocompatibilit� con lcd.c ecc
BYTE LCDInit(void) {		// su SPI

  if(!IS_ILI()) {
  //	TFT_ILI9163C();
    Adafruit_ST7735_SW(0,0,0,0,-1);
    ClrWdt();
    Adafruit_ST7735_initR(INITR_BLACKTAB);
    }
  else {
    Adafruit_ILI9488_SW(0,0,0,0,-1,0);
    displayInit_ili9488();
    }
  
  ClrWdt();
  
	setTextSize(1);
 
#if defined(m_LCDBLBit)
  m_LCDBLBit=1;
#endif
#ifndef USING_SIMULATOR

//	begin();
	fillScreenLCD(LIGHTBLUE);   // bah lascio cmq per test velocit�!!
  
	fillScreenLCD(BLACK);

// init done
	setTextWrap(1);
//	setTextColor2(WHITE, BLACK);

	drawBG();
#endif
  

	return 1;
	}


void drawBG(void) {
	char buffer[32],*p;
  WORD myColors[32]={ GRAY096, GRAY160, GRAY192, GRAY224,
    LIGHTBLUE, BRIGHTBLUE, MAGENTA, BRIGHTMAGENTA,
    LIGHTCYAN, BRIGHTCYAN, LIGHTGREEN, BRIGHTGREEN,
    LIGHTYELLOW, BRIGHTYELLOW, LIGHTORANGE, ORANGE,
    LIGHTRED, BRIGHTRED, LIGHTMAGENTA, BRIGHTMAGENTA,
    WHITE, WHITE, WHITE, WHITE,
    WHITE, WHITE, WHITE, WHITE,
    };
  BYTE c,loop=0;

  // bah agganciare a videoMode e quindi portare fuori da LCD init...
  if(_width>=256)    // come IS_ILI()
    sprintf(buffer,"VideoFW v%u.%02u (VGA,ST7735,ILI9488)",VERNUMH,VERNUML);
  else
    sprintf(buffer,"VideoFW v%u.%02u (VGA,LCD)",VERNUMH,VERNUML);  // se no sta male :)
	drawLineLCD(0,10,_width-1,10,LIGHTGREEN);
  
	setTextSize(1);
  do {
    setTextCursor(0,0);
  
    p=buffer;
    c=loop;
    while(*p) {
      setTextColor(myColors[c++]);
      if(c>strlen(buffer))
        c=0;
      cwrite(*p++);
      }
    __delay_ms(100);
    loop++;
    } while(loop<16);
  
	}


void __attribute__((always_inline)) startWrite(void) {
  
  SPI_CS_LOW();
  }

void __attribute__((always_inline)) endWrite(void) {
  
  SPI_CS_HIGH();
  }

void spiWrite(uint8_t c) {
  
#ifndef USING_SIMULATOR
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = c;     // Write character to SPI buffer
  while(SPI1STATbits.SPIBUSY  /*(SPI1STATbits.SPITBF == 1)*/ /* || (SPI1STATbits.SPIRBF == 0) */ )
    ClrWdt();
  SPI1BUF;
//  while(SPI1STATbits.SPITBF)   // Wait until transmission is started
//    ;
//		}
#endif
  }

void SPI_WRITE16(uint16_t w) {
  
#ifndef USING_SIMULATOR
  SPI1CONbits.MODE16=1;     // 
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = w;     // Write character to SPI buffer
  while(SPI1STATbits.SPIBUSY /*(SPI1STATbits.SPITBF == 1)*/ /* || (SPI1STATbits.SPIRBF == 0) */ )
    ClrWdt();
  SPI1BUF;
  SPI1CONbits.MODE16=0;
#endif
  }

void SPI_WRITE32(uint32_t l) {
  
#ifndef USING_SIMULATOR
  SPI1CONbits.MODE32=1;     // 
  SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  SPI1BUF = l;     // Write character to SPI buffer
  while(SPI1STATbits.SPIBUSY /*(SPI1STATbits.SPITBF == 1)*/ /* || (SPI1STATbits.SPIRBF == 0) */ )
    ClrWdt();
  SPI1BUF;
  SPI1CONbits.MODE32=0; 
#endif
  }

void writeCommand(uint8_t cmd) {
  
  SPI_DC_LOW();
  spiWrite(cmd);
  SPI_DC_HIGH();
  }

void writeData(uint8_t c) {

  SPI_DC_HIGH();
  SPI_CS_LOW();
  spiWrite(c);
  SPI_CS_HIGH();
	}

void writeData32(uint32_t l) {

  SPI_DC_HIGH();
  SPI_CS_LOW();
  SPI_WRITE32(l);
  SPI_CS_HIGH();
	}


/*!
    @brief   Read a single 8-bit value from the display. Chip-select and
             transaction must have been previously set -- this ONLY reads
             the byte. This is another of those functions in the library
             with a now-not-accurate name that's being maintained for
             compatibility with outside code. This function is used even if
             display connection is parallel.
    @return  Unsigned 8-bit value read (always zero if USE_FAST_PINIO is
             not supported by the MCU architecture).
*/
uint8_t spiRead(void) {
  uint8_t  b = 0;
  uint16_t w = 0;
    

  SPI1BUF = 0;     // Write character to SPI buffer
  while(!SPI1STATbits.SPIRBF)   // Wait until transmission is started
    ;
  b=SPI1BUF;
	SPI1STATbits.SPIROV = 0;  // Reset overflow bit
  
  return b;
  }

////////// stuff not actively being used, but kept for posterity ??? ;)
uint8_t readdata(void) {

  SPI_DC_HIGH();
  SPI_CS_LOW();
  uint8_t r = spiRead();
  SPI_CS_HIGH();

  return r;
	}

inline uint16_t __attribute__((always_inline)) readdata16(void) {
  uint16_t i;
// QUA NON C'�!!
  return i;
	} 


