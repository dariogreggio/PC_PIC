/*
 * BREAKTHROUGH 2.0
 * (C) G.Dar 1987-2021 :) !
 * (portions inspired by Windows)
 * 
 * 
 */
 
#include <xc.h>
#include "pc_pic_video.h"
#include "Adafruit_ST7735.h"

extern BYTE DMA_READY videoRAM[800L*600];  

extern enum VIDEO_MODE videoMode;


#define Color565(red, green, blue)    (GFX_COLOR) ((((GFX_COLOR)(red) & 0xF8) << 8) | (((GFX_COLOR)(green) & 0xFC) << 3) | (((GFX_COLOR)(blue) & 0xF8) >> 3))
#define ColorRGB(color)    (DWORD) ( ((color & 0xf800) >> 11) | ((color & 0x07e0) << 3) | ((((DWORD)color) & 0x001f) << 16) )
#define ColorR(color)    ((color & 0xf800) >> 8)        // left-justified, diciamo..
#define ColorG(color)    ((color & 0x07e0) >> 3)
#define ColorB(color)    ((color & 0x001f) << 3)
#define Color565To332(color)    (BYTE) ((WORD)( ((color & 0xe000) >> 8) | ((color & 0x0700) >> 6) | ((color & 0x0018) >> 3) ))
#define Color565To222(color)    (BYTE) ((WORD)( ((color & 0xc000) >> 10) | ((color & 0x0600) >> 7) | ((color & 0x0018) >> 3) ))
#define Color24To565(color)    ((((color >> 16) & 0xFF) / 8) << 11) | ((((color >> 8) & 0xFF) / 4) << 5) | (((color) &  0xFF) / 8)
  //convert 24bit color into packet 16 bit one (credits for this are all mine) GD made a macro!

#include "breakthrough.h"

GFX_COLOR windowForeColor, windowInactiveForeColor, windowBackColor, desktopColor;
extern const unsigned char font[] PROGMEM;
HWND rootWindows=NULL;
WORD maxWindows=1;

const BYTE standardIcon[]={
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff,
  0x00,0xff,0x00,0xff,0x00,0xff,0x00,0xff
  };
static void DrawCharWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size);
static void DrawPixelWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color);
static void DrawLineWindow(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static int DrawRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static int FillRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static int DrawCircleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static BOOL inline BoundaryCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y);
static BOOL inline ZCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y);
static BOOL ncPaint(HWND hWnd,const RECT *rc);
static void calculateClientArea(HWND hWnd,RECT *rc);
static void readClassInfo(DWORD className,_WINDOWPROC **wproc,DWORD *flags);

static BOOL addHeadWindow(HWND);
static BOOL addTailWindow(HWND);
static BOOL insertWindow(HWND,HWND);
static BOOL removeWindow(HWND);
static void SortLinkedList(struct _WINDOW *head);
void list_bubble_sort(struct _WINDOW **head);
LRESULT DefWindowProc(HWND ,unsigned int ,WPARAM ,LPARAM);
LRESULT SendMessage(HWND ,unsigned int ,WPARAM ,LPARAM);
static HWND setActive(HWND hWnd,BOOL state);


//-------------------------windows----------------------------------------------
void InitWindows(GFX_COLOR bgcolor /*DARKBLUE*/) {
  char buf[16];
  
  windowForeColor=BRIGHTCYAN;
  windowInactiveForeColor=GRAY160;
  windowBackColor=DARKGRAY;
  desktopColor=bgcolor;
  rootWindows=NULL;
  maxWindows=1;
  // oppure 
  // rootWindows=CreateWindow("desktop","",WS_ACTIVE | WS_VISIBLE,0,0,_width,_height,NULL,NULL,0);
  // e anche
  // CreateWindow("taskbar","",WS_ACTIVE | WS_VISIBLE,0,_height-_height/16,_width,_height/16,NULL,NULL,0);
  
  switch(videoMode) {
    case MODE_VGA:
      screenCLS(BLACK);
      writeStringXY(4,4,"BREAKTHROUGH 2.0",WHITE);
      break;
    case MODE_COMPOSITE:
      screenCLS(BLACK);
      writeStringXY(4,4,"BREAKTHROUGH 2.0",WHITE);
      break;
    case MODE_LCD:
#ifndef USING_SIMULATOR
      clearScreenLCD();
      setColors(WHITE,desktopColor);    // ok cos�, magari fare un rettangoletto
      setTextSize(2);
      setTextCursor(2,6);
      gfx_print("BREAKTHROUGH");
      setTextCursor(11,8);
      sprintf(buf,"%u.%02u",BREAKTHROUGH_VERSION_H,BREAKTHROUGH_VERSION_L);
      gfx_print(buf);
      setTextSize(1);
      setColors(LIGHTGRAY,desktopColor);
      setTextCursor(7,12);
      gfx_print("(C) 1988-2021");
#endif
      break;
    }
  
  __delay_ms(1000);
  ClrWdt();
#ifndef USING_SIMULATOR
  PaintBackground();
#endif
  ClrWdt();
  // oppure 
  // rootWindows=CreateWindow("desktop","",WS_ACTIVE | WS_VISIBLE,0,0,_width,_height,NULL,NULL,0);
  // e anche
  // CreateWindow("taskbar","",WS_ACTIVE | WS_VISIBLE,0,_height-_height/16,_width,_height/16,NULL,NULL,0);
  }

HWND CreateWindow(const char *lpClassName,const char *lpWindowName,
  DWORD dwStyle,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,UGRAPH_COORD_T nWidth,UGRAPH_COORD_T nHeight,
  HWND hWndParent,HMENU hMenu,void *lpParam) {
  HWND hWnd;

  hWnd=malloc(sizeof(struct _WINDOW));
  if(!hWnd)
    return NULL;
  hWnd->next=NULL;
  hWnd->flags=0;
  hWnd->nonClientArea.top=Y;
  hWnd->nonClientArea.left=X;
  hWnd->nonClientArea.bottom=Y+nHeight;
  hWnd->nonClientArea.right=X+nWidth;
  hWnd->cursorX=hWnd->cursorY=0;
  hWnd->foreColor=WHITE;    // CONTRARIO di windows, almeno per ora :)
  hWnd->backColor=BLACK;
  hWnd->font=(void *)1;
  hWnd->icon=standardIcon;
  if(lpClassName) {
    hWnd->class4[0]=lpClassName[0];
    hWnd->class4[1]=lpClassName[1];
    hWnd->class4[2]=lpClassName[2];
    hWnd->class4[3]=lpClassName[3];
    }
  else
    hWnd->class=0;
  {
  _WINDOWPROC *wproc;DWORD flags;
  readClassInfo(hWnd->class,&wproc,&flags);
  hWnd->windowProc=(_WINDOWPROC *)wproc;
  }
  strncpy(hWnd->caption,lpWindowName,sizeof(hWnd->caption)-1);
  hWnd->caption[sizeof(hWnd->caption)-1]=0;
  hWnd->flags=dwStyle;
  hWnd->tag=lpParam;
  hWnd->menu=hMenu;
  hWnd->parent=hWndParent;
  
  calculateClientArea(hWnd,&hWnd->clientArea);
  hWnd->scrollPosX=hWnd->scrollPosY=0;
  if(hWnd->flags & (WS_HSCROLL | WS_VSCROLL)) {
    hWnd->scrollSizeX=(hWnd->clientArea.right-hWnd->clientArea.left)/3;
    hWnd->scrollSizeY=(hWnd->clientArea.bottom-hWnd->clientArea.top)/3;
    }
  else {
    hWnd->scrollSizeX=hWnd->scrollSizeY=0;
    }
  
  hWnd->zOrder=maxWindows /*(int)HWND_TOP*/;
  if(!SendMessage(hWnd,WM_NCCREATE,0,0))
    goto no_creata;
  if(SendMessage(hWnd,WM_CREATE,0,0 /*CREATESTRUCT*/) < 0) {
no_creata:
    free(hWnd);
    return NULL;
    }
  hWnd->enabled=dwStyle & WS_DISABLED ? 0 : 1;
  if(hWnd->enabled)
    addTailWindow(hWnd);
  else
    addHeadWindow(hWnd);    // cos� rispettiamo lo Z-order subito!
	setActive(hWnd,dwStyle & WS_ACTIVE);
  
  if(dwStyle & WS_VISIBLE) {
    hWnd->visible=1;
    SendMessage(hWnd,WM_NCPAINT,0,0);
    SendMessage(hWnd,WM_PAINT,0,1);
    }

  return hWnd;
  }

static BOOL addTailWindow(HWND hWnd) {   // per insertSorted: https://www.geeksforgeeks.org/given-a-linked-list-which-is-sorted-how-will-you-insert-in-sorted-way/
  HWND myWnd;
  
  maxWindows++;
  if(!rootWindows)
    rootWindows=hWnd;
  else {
    myWnd=rootWindows;
    while(myWnd && myWnd->next) {
      myWnd=myWnd->next;
      }
    myWnd->next=hWnd;
    }
  return 1;
  }
static BOOL addHeadWindow(HWND hWnd) {
  HWND myWnd;
  
  maxWindows++;
  if(!rootWindows)
    rootWindows=hWnd;
  else {
    myWnd=hWnd->next=rootWindows;
    rootWindows=hWnd;
    rootWindows->zOrder=1;    // questa diventa la pi� indietro...
    while(myWnd) {
      myWnd->zOrder++;    // ...e le scrollo tutte avanti di uno
      myWnd=myWnd->next;
      }
    }
  return 1;
  }
static BOOL insertWindow(HWND hWnd,HWND hWndAfter) {
  HWND myWnd,myWnd2;
  
  removeWindow(hWnd);
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd == hWndAfter) {
      myWnd2=hWndAfter->next;
      hWndAfter->next=hWnd;
      hWnd->next=myWnd2;
      maxWindows++;
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;
  }
static BOOL removeWindow(HWND hWnd) {
  HWND myWnd=rootWindows,myWnd2;
  
  while(myWnd) {
    myWnd2=myWnd;
    if(myWnd==hWnd) {
      if(myWnd==rootWindows)
        rootWindows=myWnd->next;
      else
        myWnd2->next=myWnd->next;
      maxWindows--;
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;
  }

LRESULT SendMessage(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  return hWnd->windowProc(hWnd,message,wParam,lParam);   // per ora cos� :)
  }
LRESULT DefWindowProc(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_NCPAINT:
      return ncPaint(hWnd,(RECT *)wParam);
      break;
    case WM_PAINT:
      return InvalidateRect(hWnd,(RECT *)wParam,lParam);
      break;
    case WM_ERASEBKGND:
      return 0;
      break;
    case WM_CHAR:
    { char buf[8];
      buf[0]=wParam; buf[1]=0;
      TextOut(&hWnd->hDC,hWnd->hDC.cursorX,hWnd->hDC.cursorY,buf);
    }
      break;
    case WM_MOUSEMOVE:
      break;
    case WM_LBUTTONDOWN:
      break;
    case WM_TIMER:
      break;
    case WM_HSCROLL:
      break;
    case WM_VSCROLL:
      break;
    case WM_NCCALCSIZE:
      if(wParam) {
        struct NCCALCSIZE_PARAMS *ncp=(struct NCCALCSIZE_PARAMS *)lParam;
        }
      else {
        RECT *rc=(RECT *)lParam;
        calculateClientArea(hWnd,rc);
        }
      break;
    case WM_NCHITTEST:
      break;
    case WM_NCCREATE:
      return 1;
      break;
    case WM_CREATE:
      return 0;
      break;
    case WM_NCDESTROY:
      break;
    case WM_DESTROY:
      break;
    case WM_MOVE:
      //xPos = (int)(short) LOWORD(lParam);   // horizontal position 
      //yPos = (int)(short) HIWORD(lParam);   // vertical position 
      return 0;
      break;
    case WM_SIZE:
      switch(wParam) {
        case SIZE_MAXHIDE:
          break;
        case SIZE_MAXIMIZED:
          break;
        case SIZE_MAXSHOW:
          break;
        case SIZE_MINIMIZED:
          break;
        case SIZE_RESTORED:
          break;
        }
      //UINT width = LOWORD(lParam);
      //UINT height = HIWORD(lParam);
      break;
    case WM_CLOSE:
      DestroyWindow(hWnd);
      break;
    case WM_NCACTIVATE:
      break;
    case WM_ACTIVATE:
// boh??          hWnd->active = wParam == WA_ACTIVE;

      break;
    case WM_DISPLAYCHANGE:
      break;
    case WM_PAINTICON:    // solo windows 3.x :)
      break;
    case WM_SHOWWINDOW:
      break;
    case WM_WINDOWPOSCHANGING:
      return 0;
      break;
    case WM_SETFOCUS:
      break;
    case WM_KILLFOCUS:
      break;
    case WM_SETTEXT:
      SetWindowText(hWnd,(const char *)lParam);
      ncPaint(hWnd,NULL /*area titolo...*/);
      break;
    case WM_ENABLE:
      hWnd->enabled=wParam;
      break;
    case WM_ENDSESSION:
      return 0;
      break;
    case WM_QUERYENDSESSION:
      return TRUE;
      break;
    case WM_QUIT:
      break;

    }
  return 0;
  }

static void calculateClientArea(HWND hWnd,RECT *rc) {
  
  *rc=hWnd->nonClientArea;
  if(hWnd->flags & WS_BORDER) {
    hWnd->clientArea.top++;
    hWnd->clientArea.bottom--;
    hWnd->clientArea.left++;
    hWnd->clientArea.right--;
    if(hWnd->flags & WS_THICKFRAME) {
      hWnd->clientArea.top++;
      hWnd->clientArea.bottom--;
      hWnd->clientArea.left++;
      hWnd->clientArea.right--;
      }
    }
  if(hWnd->flags & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
    hWnd->clientArea.top+=TITLE_HEIGHT;
    }
  if(hWnd->flags & WS_HSCROLL) {
    hWnd->clientArea.bottom-=SCROLL_SIZE;
    }
  else
    hWnd->clientArea.bottom--;    // strana patch... verificare!
  if(hWnd->flags & WS_VSCROLL) {
    hWnd->clientArea.right-=SCROLL_SIZE;
    }
  else
    hWnd->clientArea.right--;    // strana patch... verificare!
  }

static void readClassInfo(DWORD className,_WINDOWPROC **wproc,DWORD *flags) {
  
  switch(className) {
    case WC_BUTTON:
      break;
    case WC_COMBOBOX:
      break;
    case WC_EDIT:
      break;
    case WC_LISTBOX:
      break;
    case WC_SCROLLBAR:
      break;
    case WC_STATIC:
      break;
    default:
      *wproc=(_WINDOWPROC *)DefWindowProc;
      break;
    }
  }

static BOOL ncPaint(HWND hWnd,const RECT *rc) {
  WORD newtop,newbottom,newleft,newright;
  GFX_COLOR itemsColor;
  
#ifndef USING_SIMULATOR
  if(!hWnd) {   // https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
    // non so se vale pure per NCpaint, ma diciamo di s� :)
    PaintBackground();
    HWND myWnd=rootWindows;
    while(myWnd) {
      ncPaint(myWnd,NULL);
      InvalidateRect(myWnd,NULL,0);   // nel mio caso almeno, direi di s� :)
      myWnd=myWnd->next;
      }
    return 1;
    }
  if(rc) {    // per ora non usato... ridisegnamo sempre tutta la window
    newtop=rc->top;
    newbottom=rc->bottom;
    newleft=rc->left;
    newright=rc->right;
    }
  else {
    newtop=hWnd->nonClientArea.top;
    newbottom=hWnd->nonClientArea.bottom;
    newleft=hWnd->nonClientArea.left;
    newright=hWnd->nonClientArea.right;
    }

  if(hWnd->minimized) {
    // FINIRE! disegnare icona dove??
    DrawIcon8(hWnd,8,_height-16,hWnd->icon);
    return;
    }
  if(hWnd->maximized) {
    // FINIRE!
    }
  itemsColor=hWnd->active ? windowForeColor : windowInactiveForeColor;
  // e hWnd->enabled ??
  switch(videoMode) {
    case MODE_LCD:
      fillRectLCD(newleft,newtop,newright-newleft,newbottom-newtop,windowBackColor);
      // ev. provare writeFillRectPreclipped
      if(hWnd->flags & WS_BORDER) {
        drawRectLCD(newleft,newtop,newright-newleft,newbottom-newtop,itemsColor);
        if(hWnd->flags & WS_THICKFRAME) {
          drawRectLCD(newleft+1,newtop+1,newright-1-newleft-1,newbottom-1-newtop-1,
            itemsColor);
          }
        }
      if(hWnd->flags & WS_THICKFRAME) {
        newtop++;
        newbottom--;
        newleft++;
        newright--;
        }
      if(hWnd->flags & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLineLCD(newleft+TITLE_ICON_WIDTH+2,newtop,newleft+TITLE_ICON_WIDTH+2,newtop+TITLE_HEIGHT,
          itemsColor);
        }
      if(hWnd->flags & WS_SYSMENU) {
        fillRectLCD(newleft+2,newtop+2,TITLE_ICON_WIDTH-1,TITLE_ICON_WIDTH-1,itemsColor);
        newleft=newleft+TITLE_ICON_WIDTH+2;
      // metto anche closebox, fisso, a dx? insieme a sysmenu?
        drawLineLCD(newright-3,newtop+3,newright-TITLE_ICON_WIDTH+1,newtop+TITLE_ICON_WIDTH-1,
          itemsColor);
        drawLineLCD(newright-TITLE_ICON_WIDTH+1,newtop+3,newright-3,newtop+TITLE_ICON_WIDTH-1,
          itemsColor);
        drawLineLCD(newright-(TITLE_ICON_WIDTH+1),newtop,newright-(TITLE_ICON_WIDTH+1),newtop+TITLE_HEIGHT,
          itemsColor);
        newright -= TITLE_ICON_WIDTH+1;
        }
      if(hWnd->flags & WS_MAXIMIZEBOX) {
        drawLineLCD(newright-2,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,
          itemsColor);
        drawLineLCD(newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,newright-(TITLE_ICON_WIDTH-1)+1,newtop+TITLE_ICON_WIDTH/2+2,
          itemsColor);
        drawLineLCD(newright-TITLE_ICON_WIDTH,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_HEIGHT,
          itemsColor);
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->flags & WS_MINIMIZEBOX) {
        drawLineLCD(newright-2,newtop+3,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,
          itemsColor);
        drawLineLCD(newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)+1,newtop+3,
          itemsColor);
        drawLineLCD(newright-TITLE_ICON_WIDTH,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_HEIGHT,
          itemsColor);
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->flags & WS_CAPTION) {
        char *s=hWnd->caption;
        setColors(itemsColor, windowBackColor);
        cursor_x=newleft+2; cursor_y=newtop+1;
        while(*s) {   // nonclient area, non uso TextOut...
          cwrite(*s++);
          if(cursor_x>=(newright-6) || cursor_y>(newtop+1))   // 1 sola riga, trim a dx
            break;
          }
        }
      if(rc) {    // ripristino
        newleft=rc->left;
        newright=rc->right;
        }
      else {
        newleft=hWnd->nonClientArea.left;
        newright=hWnd->nonClientArea.right;
        if(hWnd->flags & WS_THICKFRAME) {
          newleft++;
          newright--;
          }
        }
      if(hWnd->flags & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLineLCD(newleft,newtop+TITLE_HEIGHT,newright-1,newtop+TITLE_HEIGHT,itemsColor);
        newtop=newtop+TITLE_HEIGHT;
        }
      if(hWnd->flags & WS_HSCROLL) {
        drawLineLCD(newleft,newbottom-SCROLL_SIZE,newright-1,newbottom-SCROLL_SIZE,
                itemsColor);
        fillRectLCD(newleft+2+hWnd->scrollPosX,newbottom-SCROLL_SIZE+2,hWnd->scrollPosX+hWnd->scrollSizeX,SCROLL_SIZE-4,
                itemsColor);
        }
      if(hWnd->flags & WS_VSCROLL) {
        drawLineLCD(newright-SCROLL_SIZE,newtop,newright-SCROLL_SIZE,newbottom-1,
                itemsColor);
        fillRectLCD(newright-SCROLL_SIZE+2,newtop+2+hWnd->scrollPosY,SCROLL_SIZE-4,hWnd->scrollPosY+hWnd->scrollSizeY,
                itemsColor);
        }
      if(hWnd->flags & WS_SIZEBOX) {
        drawLineLCD(newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom-1,
          itemsColor);
        }

      break;
      
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectFilled(rc,windowBackColor);
      if(hWnd->flags & WS_BORDER) {
        drawRect(rc,itemsColor);
        if(hWnd->flags & WS_THICKFRAME) {
          drawRectangle(newleft+1,newtop+1,newright-1,newbottom-1,itemsColor);
          }
        }
      if(hWnd->flags & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLine(newleft+TITLE_ICON_WIDTH+2,newtop,newleft+TITLE_ICON_WIDTH+2,newtop+TITLE_HEIGHT,
          itemsColor);
        }
      if(hWnd->flags & WS_SYSMENU) {
        drawRectangleFilled(newleft+2,newtop+2,newleft+2+TITLE_ICON_WIDTH,newtop+2+TITLE_ICON_WIDTH,
                itemsColor);
        newleft=newleft+TITLE_ICON_WIDTH+2;
        drawLine(newright-1,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_ICON_WIDTH+1,
          itemsColor);
        drawLine(newright-TITLE_ICON_WIDTH,newtop,newright-1,newtop+TITLE_ICON_WIDTH+1,
          itemsColor);
        }
      if(hWnd->flags & WS_MAXIMIZEBOX) {
        newright=newright-(TITLE_ICON_WIDTH+2);
        }
      if(hWnd->flags & WS_MINIMIZEBOX) {
        newright=newright-(TITLE_ICON_WIDTH+2);
        }
      // mettere anche closebox, fisso, a dx? o va insieme a sysmenu?
      if(hWnd->flags & WS_CAPTION) {
        char *s=hWnd->caption;
       
        cursor_x=newleft+1; cursor_y=newtop+1;
        while(*s) {   // nonclient area, non uso TextOut...
          writeChar(cursor_x,cursor_y,*s,itemsColor); //
   				cursor_x+=8;
          if(cursor_x>=(newright-8) || cursor_y>(newtop+1))   // 1 sola riga, trim a dx
            break;
          s++;
          }
        }
      if(rc) {
        newleft=rc->left;
        newright=rc->right;
        }
      else {
        newleft=hWnd->nonClientArea.left;
        newright=hWnd->nonClientArea.right;
        }
      if(hWnd->flags & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLineLCD(newleft,newtop+TITLE_HEIGHT,newright,newtop+TITLE_HEIGHT,
          itemsColor);
        newtop=newtop+TITLE_HEIGHT;
        }
      if(hWnd->flags & WS_HSCROLL) {
        drawLine(newleft,newbottom-SCROLL_SIZE,newright,newbottom-SCROLL_SIZE,
                itemsColor);
        drawRectangleFilled(newleft+hWnd->scrollPosX+1,newbottom-SCROLL_SIZE+1,newleft+1+hWnd->scrollPosX+hWnd->scrollSizeX,newbottom-1,
                itemsColor);
        }
      if(hWnd->flags & WS_VSCROLL) {
        drawLine(newright-SCROLL_SIZE,newtop,newright-SCROLL_SIZE,newbottom,
                itemsColor);
        drawRectangleFilled(newright-SCROLL_SIZE+1,newtop+hWnd->scrollPosY+1,newright-1,newtop+1+hWnd->scrollPosY+hWnd->scrollSizeY,
                itemsColor);
        }
      if(hWnd->flags & WS_SIZEBOX) {
        drawLine(newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom+1,
          itemsColor);
        }

      break;
    }
#endif
  
  return 1;
  }

BOOL InvalidateRect(HWND hWnd,const RECT *rc,BOOL bErase) {

  if(!hWnd) {   // https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
    PaintBackground();
    HWND myWnd=rootWindows;
    while(myWnd) {
      InvalidateRect(myWnd,NULL,TRUE);
      myWnd=myWnd->next;
      }
    return 1;
    }
  if(!rc) {
    rc=&hWnd->clientArea;
    }
  if(bErase) {    // banalmente, per ora facciam cos�
    if(!SendMessage(hWnd,WM_ERASEBKGND,0,0)) {
#ifndef USING_SIMULATOR
      FillRectangleWindow(&hWnd->hDC,rc->left,rc->top,rc->right-rc->left,rc->bottom-rc->top,
        windowBackColor);
#endif
      }
    }
  return 1;
  }

BOOL EnableWindow(HWND hWnd,BOOL bEnable) {
  
  SendMessage(hWnd,WM_ENABLE,bEnable,0);
  }

BOOL DestroyWindow(HWND hWnd) {

  SendMessage(hWnd,WM_DESTROY,0,0);
  removeWindow(hWnd);
  free(hWnd);
  }

BOOL SetWindowPos(HWND hWnd,HWND hWndInsertAfter,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,
  UGRAPH_COORD_T cx,UGRAPH_COORD_T cy, DWORD uFlags) {
  RECT oldNCarea,oldArea;
  
  if(uFlags) {    // bah, controllare
    WINDOWPOS wpos;
    wpos.hwnd=hWnd;
    wpos.hwndInsertAfter=hWndInsertAfter;
    wpos.x=X;
    wpos.y=Y;
    wpos.cx=cx;
    wpos.cy=cy;
    wpos.flags=uFlags;
    SendMessage(hWnd,WM_WINDOWPOSCHANGING,0,(LPARAM)&wpos);
    }
  if(!(uFlags & SWP_NOACTIVATE)) {
		setActive(hWnd,TRUE);
		}
  if(uFlags & SWP_HIDEWINDOW)
    hWnd->visible=0;
  if(uFlags & SWP_SHOWWINDOW)   // bah :) cmq vince questo
    hWnd->visible=1;
  if(!(uFlags & SWP_NOREPOSITION)) {
    oldNCarea=hWnd->nonClientArea;
    oldArea=hWnd->clientArea;
    if(!(uFlags & SWP_NOMOVE)) {
      hWnd->nonClientArea.left=X;
      hWnd->nonClientArea.top=Y;
      hWnd->clientArea.left+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->clientArea.top+=hWnd->nonClientArea.top-oldNCarea.top;
      }
    if(!(uFlags & SWP_NOSIZE)) {
      hWnd->nonClientArea.right=hWnd->nonClientArea.left+cx;
      hWnd->nonClientArea.bottom=hWnd->nonClientArea.top+cy;
      hWnd->clientArea.right+=hWnd->nonClientArea.right-oldNCarea.right;
      hWnd->clientArea.bottom+=hWnd->nonClientArea.bottom-oldNCarea.bottom;
      }
    else {
      hWnd->nonClientArea.right+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->nonClientArea.bottom+=hWnd->nonClientArea.top-oldNCarea.top;
      hWnd->clientArea.right+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->clientArea.bottom+=hWnd->nonClientArea.top-oldNCarea.top;
      }
    }
  if(!(uFlags & SWP_NOZORDER /* SWP_NOOWNERZORDER che �? */)) {
    switch((int)hWndInsertAfter) {
      case (int)HWND_BOTTOM:
        hWnd->topmost=0;
        hWnd->zOrder=255;   // FINIRE!! cambiare con la prima in lista
        break;
      case (int)HWND_NOTOPMOST:
        hWnd->topmost=0;
        break;
      case (int)HWND_TOP:
        hWnd->topmost=0;
        hWnd->zOrder=1;   // FINIRE!! cercare quella prima, che � l'ultima della lista
        break;
      case (int)HWND_TOPMOST:
        hWnd->topmost=1;
        hWnd->zOrder=1;   // FINIRE!! come sopra direi
        break;
      default:
        insertWindow(hWnd,hWndInsertAfter);
        break;
      }
    list_bubble_sort(&rootWindows);
    }
  if(!(uFlags & SWP_NOREDRAW)) {
    SendMessage(hWnd,WM_PAINT,0,TRUE);
    }
  return 1;
  }

BOOL MoveWindow(HWND hWnd,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,UGRAPH_COORD_T nWidth,UGRAPH_COORD_T nHeight,BOOL bRepaint) {
  
  return SetWindowPos(hWnd,NULL,X,Y,nWidth,nHeight,
    SWP_NOSENDCHANGING | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_NOACTIVATE
    | (bRepaint ? 0 : SWP_NOREDRAW)
    );
  }

BOOL ShowWindow(HWND hWnd,BYTE nCmdShow) {
  
  switch(nCmdShow) {
    case SW_HIDE:
      hWnd->visible=0;
			setActive(hWnd,FALSE);
      break;
    case SW_SHOWNORMAL:
//    case SW_NORMAL:
      hWnd->maximized=0;
      hWnd->minimized=0;
      // prosegue
    case SW_SHOW:
      hWnd->visible=1;
			setActive(hWnd,TRUE);

      break;
    case SW_SHOWMINIMIZED:
      hWnd->visible=1;
			setActive(hWnd,TRUE);
    case SW_MINIMIZE:
      hWnd->minimized=1;
      hWnd->maximized=0;
      break;
    case SW_SHOWMAXIMIZED:
//    case SW_MAXIMIZE:
      hWnd->maximized=1;
      hWnd->minimized=0;
      hWnd->visible=1;
			setActive(hWnd,TRUE);
      break;
    case SW_SHOWNOACTIVATE:
    case SW_SHOWNA:
      hWnd->visible=1;
      hWnd->maximized=hWnd->minimized=0;
      break;
    case SW_SHOWMINNOACTIVE:
      hWnd->visible=1;
			setActive(hWnd,FALSE);
      hWnd->minimized=1;
      hWnd->maximized=0;
      break;
    case SW_RESTORE:
      hWnd->maximized=hWnd->minimized=0;
      break;
    default:
      break;
    }
  return SendMessage(hWnd,WM_PAINT,0,TRUE);
  }

BOOL BringWindowToTop(HWND hWnd) {
  HWND myWnd;
  BYTE temp;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd->zOrder==1) {
      temp=hWnd->zOrder;
      hWnd->zOrder=myWnd->zOrder;
      myWnd->zOrder=temp;
      list_bubble_sort(&rootWindows);
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;   //NON deve accadere
  }

HWND GetTopWindow(HWND hWnd) {
  HWND myWnd,myWnd2;
//  BYTE minZorder=255;
  
  if(hWnd) {    // child windows...
    }
  else {
    myWnd=rootWindows;
    while(myWnd) {
      myWnd2=myWnd;
      myWnd=myWnd->next;
      }
    return myWnd2;
    }
  }

BOOL GetClientRect(HWND hWnd,RECT *lpRect) {
  
  lpRect->left=lpRect->top=0;
  lpRect->right=hWnd->clientArea.right-hWnd->clientArea.left;
  lpRect->bottom=hWnd->clientArea.bottom-hWnd->clientArea.top;
  }

BOOL GetWindowRect(HWND hWnd,RECT *lpRect) {
  
  *lpRect=hWnd->nonClientArea;
  }

HWND setActive(HWND hWnd,BOOL state) {
  HWND myWnd;
  BYTE temp;
  
  if(state) {
    myWnd=rootWindows;
    while(myWnd) {
      if(myWnd != hWnd && myWnd->active) {
        SendMessage(myWnd,WM_ACTIVATE,WA_INACTIVE,(LPARAM)hWnd);
        SendMessage(myWnd,WM_NCPAINT,0,TRUE);
        SendMessage(myWnd,WM_PAINT,0,TRUE);
        temp=hWnd->zOrder;
        hWnd->zOrder=myWnd->zOrder;
        myWnd->zOrder=temp;
        list_bubble_sort(&rootWindows);
        break;
        }
      myWnd=myWnd->next;
      }
    hWnd->active=1;
    SendMessage(hWnd,WM_ACTIVATE,WA_ACTIVE,(LPARAM)myWnd);
    SendMessage(hWnd,WM_NCPAINT,0,TRUE);
    SendMessage(hWnd,WM_PAINT,0,TRUE);
    return hWnd;
    }
  else {
    
//    if active !!
            
      // in teoria quella attiva in precedenza � l'ultima ossia quella in cima a Z-order...PENULTIMA!
      myWnd=rootWindows;
      while(myWnd) {
        if(myWnd != hWnd && !myWnd->active) {
 				  myWnd->active=1;
          SendMessage(myWnd,WM_ACTIVATE,WA_ACTIVE,(LPARAM)hWnd);
          SendMessage(myWnd,WM_NCPAINT,0,TRUE);
          SendMessage(myWnd,WM_PAINT,0,TRUE);
          temp=hWnd->zOrder;
          hWnd->zOrder=myWnd->zOrder;
          myWnd->zOrder=temp;
          list_bubble_sort(&rootWindows);
          break;
          }
        myWnd=myWnd->next;
        }
// fare?  myWnd->zOrder=HWND_TOP;
  	  hWnd->active=0;
      SendMessage(hWnd,WM_ACTIVATE,WA_INACTIVE,(LPARAM)hWnd);
      SendMessage(hWnd,WM_NCPAINT,0,TRUE);
      SendMessage(hWnd,WM_PAINT,0,TRUE);
      return hWnd;
    }
  
  return NULL;    //NON deve accadere!
	}

int SetScrollPos(HWND hWnd,int nBar,int nPos,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      hWnd->scrollPosX=nPos;
      break;
    case SB_VERT:
      hWnd->scrollPosY=nPos;
      break;
    }
  if(bRedraw)
    return SendMessage(hWnd,WM_PAINT,0,TRUE);
  else
    return 1;
  }

int SetScrollInfo(HWND hWnd,int nBar,SCROLLINFO *lpsi,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      if(lpsi->fMask & SIF_POS)
        hWnd->scrollPosX=lpsi->nPos;
      if(lpsi->fMask & SIF_PAGE)
        ;
      if(lpsi->fMask & SIF_RANGE)
        ;
      break;
    case SB_VERT:
      if(lpsi->fMask & SIF_POS)
        hWnd->scrollPosY=lpsi->nPos;
      if(lpsi->fMask & SIF_PAGE)
        ;
      if(lpsi->fMask & SIF_RANGE)
        ;
      break;
    }
  if(bRedraw)
    return SendMessage(hWnd,WM_PAINT,0,TRUE);
  else
    return 1;
  }

BOOL SetScrollRange(HWND hWnd,int nBar,int nMinPos,int nMaxPos,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      hWnd->scrollPosX=(nMaxPos-nMinPos);   // boh finire..
      break;
    case SB_VERT:
      hWnd->scrollPosY=(nMaxPos-nMinPos);
      break;
    }
  if(bRedraw)
    return SendMessage(hWnd,WM_PAINT,0,TRUE);
  else
    return 1;
  }

BOOL SetWindowText(HWND hWnd,const char *title) {
  
  strncpy(hWnd->caption,title,sizeof(hWnd->caption)-1);
  hWnd->caption[sizeof(hWnd->caption)-1]=0;
  return SendMessage(hWnd,WM_PAINT,0,TRUE);
  }

int PaintBackground(void) {
  // PUO CONFLUIRE IN INVALIDARE, SE SI CREA LA WINDOW-DESKTOP
  
  switch(videoMode) {
    case MODE_LCD:
      fillRectLCD(0,0,_width,_height,desktopColor);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectangleFilled(0,0,_width,_height,desktopColor);
      break;
    }
  }

int DrawIcon8(HWND hWnd,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const BYTE icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const BYTE *p2=icon;
  
  w=8; h=8;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(&hWnd->hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawIcon(HWND hWnd,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const BYTE icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const BYTE *p2=icon;
  
  w=16; h=16;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(&hWnd->hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawCaret(HWND hWnd,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const BYTE icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const BYTE *p2=icon;
  
  w=8; h=8;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(&hWnd->hDC,x1+i, y1+j, *p2++);
      }
    }
  }

BOOL TextOut(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const char *s) {
  char c;
  
  setCursor(x1,y1);
  
  while(*s) {
    c=*s;
    
#ifdef USE_CUSTOM_FONTS 
  if(!gfxFont) { // 'Classic' built-in font
#endif

    switch(c) {
      case '\n':
        cursor_y += (hDC->fontSimple)*8;
        cursor_x  = 0;
        break;
      case '\r':
        // skip em
        break; 
      default:
        if(wrap && ((cursor_x + (hDC->fontSimple) * 6) >= hDC->area.right)) { 	// Heading off edge?
          // TENDENZIALMENTE QUA NON CI INTERESSA! textout fa una sola riga
//          cursor_x  = hDC->area.left;            // Reset x 
//          cursor_y += (hDC->fontSimple) * 8; // Advance y one line
          }
        DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, (hDC->fontSimple));
        cursor_x += (hDC->fontSimple) * 6;
        break; 
    	}

#ifdef USE_CUSTOM_FONTS 
  	} 
	else { // Custom font

    if(c == '\n') {
      cursor_x  = 0;
      cursor_y += (GRAPH_COORD_T)textsize *
                  (UINT8)pgm_read_byte(&gfxFont->yAdvance);
  	  } 
		else if(c != '\r') {
      UINT8 first = pgm_read_byte(&gfxFont->first);
      if((c >= first) && (c <= (UINT8)pgm_read_byte(&gfxFont->last))) {
        UINT8   c2    = c - pgm_read_byte(&gfxFont->first);
        GFXglyph *glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c2]);
        UINT8   w     = pgm_read_byte(&glyph->width),
                  h     = pgm_read_byte(&glyph->height);
        if((w > 0) && (h > 0)) { // Is there an associated bitmap?
          GRAPH_COORD_T xo = (INT8)pgm_read_byte(&glyph->xOffset); // sic
          if(wrap && ((cursor_x + textsize * (xo + w)) >= _width)) {
            // Drawing character would go off right edge; wrap to new line
            cursor_x  = 0;
            cursor_y += (GRAPH_COORD_T)textsize *
                        (UINT8)pgm_read_byte(&gfxFont->yAdvance);
          	}
          drawChar(cursor_x, cursor_y, c, textcolor, textbgcolor, textsize);
        	}
        cursor_x += pgm_read_byte(&glyph->xAdvance) * (GRAPH_COORD_T)textsize;
      	}
    	}

  	}
#endif

    s++;
    }
  }

void SetWindowTextCursor(HDC *hDC,BYTE col,BYTE row) {
  
  setTextCursor(col,row);
  }

BOOL MoveToEx(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,POINT *lppt) {
  
  if(lppt) {
    lppt->x=hDC->cursorX;
    lppt->y=hDC->cursorY;
    }
  hDC->cursorX=x;
  hDC->cursorY=y;
  }

BOOL LineTo(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  DrawLineWindow(hDC,hDC->cursorX, hDC->cursorY, x, y, hDC->foreColor);
  hDC->cursorX=x;
  hDC->cursorY=y;
  return 1;
  }

GFX_COLOR SetPixel(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,GFX_COLOR color) {

  DrawPixelWindow(hDC,x,y,color);
  return color;   // forse vuole il colore precedente, finire quando ci spostiamo in RAM
  }
  
BOOL Rectangle(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  
  return DrawRectangleWindow(hDC, left, top, right, bottom, hDC->foreColor);
  }

BOOL RectangleFilled(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  
  return FillRectangleWindow(hDC, left, top, right, bottom, hDC->foreColor);
  }

BOOL Ellipse(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  return DrawCircleWindow(hDC, left, top, right, bottom, hDC->foreColor);
  }

BOOL Arc(HDC *hDC,UGRAPH_COORD_T x1,UGRAPH_COORD_T y1,UGRAPH_COORD_T x2,UGRAPH_COORD_T y2,
  UGRAPH_COORD_T x3,UGRAPH_COORD_T y3,UGRAPH_COORD_T x4,UGRAPH_COORD_T y4) {
  }

GFX_COLOR SetTextColor(HDC *hDC,GFX_COLOR color) {
  
  hDC->foreColor=color;
  }
GFX_COLOR SetBkColor(HDC *hDC,GFX_COLOR color) {
  
  hDC->backColor=color;
  }

static void DrawCharWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size) {
	INT8 i,j;
	const BYTE *fontPtr;

#ifdef USE_CUSTOM_FONTS 
  if(!gfxFont) { // 'Classic' built-in font
#endif

    if(!_cp437 && (c >= 176)) 
			c++; // Handle 'classic' charset behavior
#ifndef USE_256_CHAR_FONT 
		if(c>=128)
			return;
#endif

    switch(videoMode) {
      case MODE_LCD:
      case MODE_VGA:
      case MODE_COMPOSITE:
        // per ora gestiti tutti da pixel line ecc, poi magari potrebbe cambiare
    
        fontPtr=font+((UINT16)c)*5;
        for(i=0; i<6; i++) {
          UINT8 line;
          if(i<5) 
            line = pgm_read_byte(fontPtr+i);
          else  
            line = 0x0;
          for(j=0; j<8; j++, line >>= 1) {
            if(line & 0x1) {
              if(size == 1) 
                DrawPixelWindow(hDC,x+i,y+j,color);
              else
                FillRectangleWindow(hDC,x+(i*size),y+(j*size),size,size,color);
              } 
            else if(bg != color) {
              if(size == 1) 
                DrawPixelWindow(hDC,x+i,y+j,bg);
              else          
                FillRectangleWindow(hDC,x+(i*size),y+(j*size),size,size,bg);
              }
            }
          }

    #ifdef USE_CUSTOM_FONTS 
        } 
      else { // Custom font
        GFXglyph *glyph;
        UINT8  *bitmap;
        UINT16 bo;
        UINT8  w, h, xa;
        INT8   xo, yo;
        UINT8  xx, yy, bits, bit = 0;
        GRAPH_COORD_T  xo16, yo16;

        // Character is assumed previously filtered by write() to eliminate
        // newlines, returns, non-printable characters, etc.  Calling drawChar()
        // directly with 'bad' characters of font may cause mayhem!

        c -= pgm_read_byte(&gfxFont->first);
        glyph  = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
        bitmap = (UINT8 *)pgm_read_pointer(&gfxFont->bitmap);

        bo = pgm_read_word(&glyph->bitmapOffset);
        w  = pgm_read_byte(&glyph->width),
                 h  = pgm_read_byte(&glyph->height),
                 xa = pgm_read_byte(&glyph->xAdvance);
        xo = pgm_read_byte(&glyph->xOffset),
                 yo = pgm_read_byte(&glyph->yOffset);
        xx, yy, bits, bit = 0;
        xo16, yo16;

        if(size > 1) {
          xo16 = xo;
          yo16 = yo;
          }

        // Todo: Add character clipping here

        // NOTE: THERE IS NO 'BACKGROUND' COLOR OPTION ON CUSTOM FONTS.
        // THIS IS ON PURPOSE AND BY DESIGN.  The background color feature
        // has typically been used with the 'classic' font to overwrite old
        // screen contents with new data.  This ONLY works because the
        // characters are a uniform size; it's not a sensible thing to do with
        // proportionally-spaced fonts with glyphs of varying sizes (and that
        // may overlap).  To replace previously-drawn text when using a custom
        // font, use the getTextBounds() function to determine the smallest
        // rectangle encompassing a string, erase the area with fillRect(),
        // then draw new text.  This WILL unfortunately 'blink' the text, but
        // is unavoidable.  Drawing 'background' pixels will NOT fix this,
        // only creates a new set of problems.  Have an idea to work around
        // this (a canvas object type for MCUs that can afford the RAM and
        // displays supporting setAddrWindow() and pushColors()), but haven't
        // implemented this yet.

        for(yy=0; yy<h; yy++) {
          for(xx=0; xx<w; xx++) {
            if(!(bit++ & 7)) {
              bits = pgm_read_byte(&bitmap[bo++]);
              }
            if(bits & 0x80) {
              if(size == 1) {
                drawPixel(x+xo+xx, y+yo+yy, color);
                } 
              else {
                fillRect(x+(xo16+xx)*size, y+(yo16+yy)*size, size, size, color);
                }
              }
            bits <<= 1;
            }
          }

        } // End classic vs custom font
  #endif
        break;
  	}

	}

static void __attribute__((always_inline)) Pixel(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {

  START_WRITE();
	setAddrWindow(x, y, 1, 1);
	writedata16(color);
  END_WRITE();
	}

static void DrawPixelWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {
  
  x+=hDC->area.left;
  y+=hDC->area.top;
  // mancherebbe il < 0...
  if(BoundaryCheckWindow(hDC,x,y))
    return;
  if(ZCheckWindow(hDC,x,y))
    return;
  
  switch(videoMode) {
    case MODE_LCD:
//      drawPixelLCD(x,y,color);
    	Pixel(x, y, color);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawPixel(x,y,color);
      break;
    }
  }

static void DrawLineWindow(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
 	BOOL steep;
	GRAPH_COORD_T dx,dy;
	GRAPH_COORD_T err;
	GRAPH_COORD_T ystep;
	GRAPH_COORD_T xbegin;
  
  x1+=hDC->area.left;
  y1+=hDC->area.top;
  x2+=hDC->area.left;
  y2+=hDC->area.top;
  if(BoundaryCheckWindow(hDC,x1,y1))
    return;
	if(x2 > hDC->area.right)  
  	x2 = hDC->area.right;
	if(y2 > hDC->area.bottom)  
  	y2 = hDC->area.bottom;
  
  switch(videoMode) {
    case MODE_LCD:
      drawLineLCD(x1,y1,x2,y2,c);
#if 0

	steep = abs(y2-y1) > abs(x2-x1);
	if(steep) {
		_swap(&x1, &y1);
		_swap(&x2, &y2);
		}
	if(x0>x1) {
		_swap(&x1, &x2);
		_swap(&y1, &y2);
		}

	dx = x2-x1;
	dy = abs(y2-y1);

	err = dx/2;

	if(y1<y2) {
		ystep = 1;
		} 
	else {
		ystep = -1;
		}

	xbegin = x1;
	if(steep) {
		for(; x1<=x2; x1++) {
			err -= dy;
			if(err < 0) {
				INT16 len = x1-xbegin;
				if(len) {
					VLine(y1, xbegin, len + 1, color);
					} 
				else {
					DrawPixelWindow(hDC,y1,x1,color);
					}
				xbegin = x1+1;
				y1 += ystep;
				err += dx;
				}
			}
		if(x1 > xbegin + 1) {
			VLine(y1, xbegin, x1 - xbegin, color);
			}
		} 
	else {
		for(; x1<=x2; x1++) {
			err -= dy;
			if(err < 0) {
				INT16 len = x1-xbegin;
				if(len) {
					HLine(xbegin, y1, len+1, color);
					} 
				else {
					DrawPixelWindow(hDC,x1,y1,color);
					}
				xbegin = x1+1;
				y1 += ystep;
				err += dx;
				}
			}
		if(x1 > xbegin+1) {
			HLine(xbegin, y1, x1-xbegin, color);
			}
		}
#endif
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawLine(x1,y1,x2,y2,c);
      break;
    }

  }

static int DrawRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  
  x1+=hDC->area.left;
  y1+=hDC->area.top;
  x2+=hDC->area.left;
  y2+=hDC->area.top;
  if(BoundaryCheckWindow(hDC,x1,y1))
    return;
  if(x2<=x1 || y2<=y1)
    return;
	if(x2 > hDC->area.right)  
  	x2 = hDC->area.right;
	if(y2 > hDC->area.bottom)  
  	y2 = hDC->area.bottom;
  
  switch(videoMode) {
    case MODE_LCD:
      drawRectLCD(x1,y1,x2-x1+1,y2-y1+1,c);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectangle(x1,y1,x2,y2,c);
      break;
    }
  }

static int FillRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, 
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  
  switch(videoMode) {
    case MODE_LCD:
//      fillRectLCD(x1,y1,x2-x1+1,y2-y1+1,c);
      while(y1<y2) {
        while(x1<x2) {
					DrawPixelWindow(hDC,x1,y1,c);
          x1++;
          }
        y1++;
        }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectangleFilled(x1,y1,x2,y2,c);
      break;
    }
  }

static int DrawCircleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  
  x1+=hDC->area.left;
  y1+=hDC->area.top;
  x2+=hDC->area.left;
  y2+=hDC->area.top;
  if(BoundaryCheckWindow(hDC,x1,y1))
    return;
  if(x2<=x1 || y2<=y1)
    return;
	if(x2 > hDC->area.right)  
  	x2 = hDC->area.right;
	if(y2 > hDC->area.bottom)  
  	y2 = hDC->area.bottom;
  
  switch(videoMode) {
    case MODE_LCD:
      drawCircleLCD((x1+x2)/2,(y1+y2)/2,(x2-x1+y2-y1)/(2*2),c); // bah finire, adattare!
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawCircle((x1+x2)/2,(y1+y2)/2,(x2-x1+y2-y1)/(2*2),c); // bah finire, adattare!
      break;
    }
  }

static BOOL BoundaryCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {

	if((x > hDC->area.right) || (y > hDC->area.bottom)) 
		return TRUE;
	return FALSE;
	}

static BOOL ZCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  HWND hWnd,myWnd;
  POINT pt;
  
  hWnd=HWND_FROM_HDC(hDC);
//  hWnd=container_of(hDC,struct _WINDOW,hDC);
  pt.x=x; pt.y=y;
  myWnd=hWnd->next;   // inizio da quella subito sopra di me
  while(myWnd) {
    if(myWnd->zOrder < hWnd->zOrder) {    // in teoria questo test � inutile, dato il sort
      if(PtInRect(&myWnd->nonClientArea,pt)) {
        return 1;
        }
      }
    myWnd=myWnd->next;
    }
  return 0;
  }

void SortLinkedListValue(struct _WINDOW *node) {   //https://stackoverflow.com/questions/35914574/sorting-linked-list-simplest-way
  struct _WINDOW *temp;
  int tempvar,j;  //temp variable to store node data
    
  temp = node->next;//temp node to hold node data and next link
  while(node && node->next) {
    for(j=0; j<maxWindows; j++) {   //[value 5 because I am taking only 5 nodes]
      if(node->zOrder > temp->zOrder) {   //swap node data
        tempvar = node->zOrder;
        node->zOrder= temp->zOrder;
        temp->zOrder = tempvar;
        }
      temp = temp->next;
      }
    node = node->next;
    }
  }
 
static void SortLinkedList(struct _WINDOW *head) {     // https://www.javatpoint.com/program-to-sort-the-elements-of-the-singly-linked-list
  struct _WINDOW *node = head, *i, *j;
  struct _WINDOW *temp;
  
#if 0
  //Node current will point to head  
  struct _WINDOW *current = head, *index = NULL;  
  int temp;  

  if(!head) {  
    return;  
    } 
  else {  
    while(current) {  
      //Node index will point to node next to current  
      index = current->next;  

      while(index ) {  
        //If current node's data is greater than index's node data, swap the data between them  
        if(current->zOrder > index->zOrder) {  
          temp = current->zOrder;  
          current->zOrder = index->zOrder;  
          index->zOrder = temp;  
          }  
        index = index->next;  
        }  
      current = current->next;  
      }      
    }  
#endif
  
  // https://stackoverflow.com/questions/8981823/bubble-sort-algorithm-for-a-linked-list
  i = node;
  while(i) {
    j = node->next;
    while(j) {
      if(i->zOrder > j->zOrder) {
        temp = i->next;
        i->next = j->next;
        j->next = temp;
        }
      j = j->next;
      }
    i = i->next;
    }
  }

void list_bubble_sort(struct _WINDOW **head) {    //https://stackoverflow.com/questions/21388916/bubble-sort-singly-linked-list-in-c-with-pointers
  int done = 0;         // True if no swaps were made in a pass

  // Don't try to sort empty or single-node lists
  if(!*head || !((*head)->next))
    return;

  while(!done) {
    struct _WINDOW **pv = head;         // "source" of the pointer to the current node in the list struct
    struct _WINDOW *nd = *head;            // local iterator pointer
    struct _WINDOW *nx = (*head)->next;  // local next pointer

    done = 1;

    while(nx) {
      if(nd->zOrder < nx->zOrder) {
        nd->next = nx->next;
        nx->next = nd;
        *pv = nx;
        done = 0;
        }
      pv = &nd->next;
      nd = nx;
      nx = nx->next;
      }
    }
  }