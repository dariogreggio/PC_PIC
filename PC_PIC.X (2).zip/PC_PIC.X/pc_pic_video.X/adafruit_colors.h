#ifndef ADAFRUIT_COLORS_H
#define ADAFRUIT_COLORS_H

typedef WORD /*unsigned int*/ GFX_COLOR;
#define Color565(red, green, blue)    (GFX_COLOR) ((((GFX_COLOR)(red) & 0xF8) << 8) | (((GFX_COLOR)(green) & 0xFC) << 3) | (((GFX_COLOR)(blue) & 0xF8) >> 3))
#define ColorBGR(color)    (DWORD) ( ((color & 0xf800) >> 11) | ((color & 0x07e0) << 5) | ((((DWORD)color) & 0x001f) << 16) )
#define ColorRGB(color)    (DWORD) ( ((((DWORD)color) & 0xf800) << 8) | ((((DWORD)color) & 0x07e0) << 5) | ((((DWORD)color) & 0x001f) << 3) )
// in adaf/ili era una funzione ma io faccio macro!
#define Color24To565(color)    ((((color >> 16) & 0xFF) / 8) << 11) | ((((color >> 8) & 0xFF) / 4) << 5) | (((color) &  0xFF) / 8)
  //convert 24bit color into packet 16 bit one (credits for this are all mine) GD made a macro!

#ifndef BLACK
			#define BLACK           Color565(0, 0, 0)
#endif	
			#define BRIGHTBLUE      Color565(0, 0, 255)
			#define BRIGHTGREEN     Color565(0, 255, 0)
			#define BRIGHTCYAN      Color565(0, 255, 255)
			#define BRIGHTRED       Color565(255, 0, 0)
			#define BRIGHTMAGENTA   Color565(255, 0, 255)
			#define YELLOW          Color565(128, 128, 0)
			#define BRIGHTYELLOW    Color565(255, 255, 0)
			#define LIGHTYELLOW     Color565(255, 255, 150)
			#define GOLD            Color565(255, 215, 0)
			#define BLUE            Color565(0, 0, 128)
			#define GREEN           Color565(0, 128, 0)
			#define CYAN            Color565(0, 128, 128)
			#define RED             Color565(128, 0, 0)
			#define MAGENTA         Color565(128, 0, 128)
			#define BROWN           Color565(255, 128, 0)
			#define LIGHTGRAY       Color565(128, 128, 128)
			#define DARKGRAY        Color565(64, 64, 64)
			#define LIGHTBLUE       Color565(128, 128, 255)
			#define LIGHTGREEN      Color565(128, 255, 128)
			#define LIGHTCYAN       Color565(128, 255, 255)
			#define LIGHTRED        Color565(255, 128, 128)
			#define LIGHTMAGENTA    Color565(255, 128, 255)
			#define WHITE           Color565(255, 255, 255)
			#define SADDLEBROWN 	Color565(139, 69, 19)
			#define SIENNA      	Color565(160, 82, 45)
			#define PERU        	Color565(205, 133, 63)
			#define BURLYWOOD  	 	Color565(222, 184, 135)
			#define WHEAT       	Color565(245, 245, 220)
			#define DARKBLUE        Color565(0, 0, 64)
// v. TAN in basic.. !!			#define TAN         	Color565(210, 180, 140)
			#define ORANGE         	Color565(255, 187, 76)
			#define DARKORANGE      Color565(255, 140, 0)
			#define LIGHTORANGE     Color565(255, 200, 0)
			#define GRAY242      	Color565(242, 242, 242)    
			#define GRAY229      	Color565(229, 229, 229)    
			#define GRAY224         Color565(224, 224, 224)
			#define GRAY204      	Color565(204, 204, 204)    
			#define GRAY192         Color565(192, 192, 192)
			#define GRAY160         Color565(160, 160, 160)
			#define GRAY128         Color565(128, 128, 128)
			#define GRAY096          Color565(96, 96, 96)
			#define GRAY032          Color565(32, 32, 32)
			#define GRAY010          Color565(10, 10, 10)
		
			#define GRAY95      	Color565(242, 242, 242)
			#define GRAY90      	Color565(229, 229, 229)
			#define GRAY0           Color565(224, 224, 224)
			#define GRAY80      	Color565(204, 204, 204)
			#define GRAY1           Color565(192, 192, 192)
			#define GRAY2           Color565(160, 160, 160)
			#define GRAY3           Color565(128, 128, 128)
			#define GRAY4           Color565(96, 96, 96)
			#define GRAY5           Color565(64, 64, 64)
			#define GRAY6           Color565(32, 32, 32)

#define CLR_INVALID 0xffffffff


BOOL PtInRect(const RECT *lprc,POINT pt);
BOOL IsRectEmpty(const RECT *lprc);
POINT MAKEPOINT(UGRAPH_COORD_T x,UGRAPH_COORD_T y);

#endif

