/*
 * BREAKTHROUGH 2.0
 * (C) G.Dar 1987-2021 :) !
 * (portions inspired by Windows, since 1990)
 * 
 * http://nano-x.org/ ahah siete morti :D https://github.com/moovel/microwindows
 */
 
#include <xc.h>
#include "pc_pic_video.h"
#include "Adafruit_ST7735.h"

extern BYTE DMA_READY videoRAM[800L*600];  

extern enum VIDEO_MODE videoMode;


#define Color565(red, green, blue)    (GFX_COLOR) ((((GFX_COLOR)(red) & 0xF8) << 8) | (((GFX_COLOR)(green) & 0xFC) << 3) | (((GFX_COLOR)(blue) & 0xF8) >> 3))
#define ColorRGB(color)    (DWORD) ( ((color & 0xf800) >> 11) | ((color & 0x07e0) << 3) | ((((DWORD)color) & 0x001f) << 16) )
#define ColorR(color)    ((color & 0xf800) >> 8)        // left-justified, diciamo..
#define ColorG(color)    ((color & 0x07e0) >> 3)
#define ColorB(color)    ((color & 0x001f) << 3)
#define Color565To332(color)    (BYTE) ((WORD)( ((color & 0xe000) >> 8) | ((color & 0x0700) >> 6) | ((color & 0x0018) >> 3) ))
#define Color565To222(color)    (BYTE) ((WORD)( ((color & 0xc000) >> 10) | ((color & 0x0600) >> 7) | ((color & 0x0018) >> 3) ))
#define Color24To565(color)    ((((color >> 16) & 0xFF) / 8) << 11) | ((((color >> 8) & 0xFF) / 4) << 5) | (((color) &  0xFF) / 8)
  //convert 24bit color into packet 16 bit one (credits for this are all mine) GD made a macro!

#include "breakthrough.h"

GFX_COLOR windowForeColor, windowInactiveForeColor, windowBackColor, desktopColor;
extern const unsigned char font[] PROGMEM;
HWND rootWindows=NULL,desktopWindow,shellWindow;
WORD maxWindows=1;
WNDCLASS *rootClasses=NULL;
UGRAPH_COORD_T mouseX,mouseY;
CURSOR mouseCursor;
  

const GFX_COLOR standardIcon[]={
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  WHITE,LIGHTRED,WHITE,RED,WHITE,RED,WHITE,LIGHTRED,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  LIGHTGREEN,BLACK,LIGHTGREEN,BLACK,LIGHTGREEN,BLACK,LIGHTGREEN,BLACK,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  WHITE,LIGHTBLUE,WHITE,LIGHTBLUE,WHITE,LIGHTBLUE,WHITE,LIGHTBLUE,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  };
const GFX_COLOR standardCursor[]={
  WHITE,WHITE,WHITE,WHITE,BLACK,BLACK,BLACK,BLACK,
  WHITE,WHITE,BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,
  WHITE,BLACK,WHITE,BLACK,BLACK,BLACK,BLACK,BLACK,
  WHITE,BLACK,BLACK,WHITE,BLACK,BLACK,BLACK,BLACK,
  BLACK,BLACK,BLACK,BLACK,WHITE,BLACK,BLACK,BLACK,
  BLACK,BLACK,BLACK,BLACK,BLACK,WHITE,BLACK,BLACK,
  BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,WHITE,BLACK,
  BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,WHITE
  };
const GFX_COLOR standardCaret[]={
  WHITE,WHITE,WHITE,WHITE,
  BLACK,BLACK,BLACK,WHITE,
  WHITE,BLACK,WHITE,WHITE,
  WHITE,BLACK,WHITE,WHITE,
  WHITE,BLACK,WHITE,WHITE,
  WHITE,BLACK,WHITE,WHITE,
  BLACK,BLACK,BLACK,WHITE,
  WHITE,WHITE,WHITE,WHITE,
  };
const GFX_COLOR redBallIcon[]={   //https://www.digole.com/tools/PicturetoC_Hex_converter.php
  0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
  0x0000,0x2110,0xa989,0xa9b8,0xa8b8,0xa989,0x2110,0x0000,
  0x0000,0xa989,0x6ae8,0x4ef9,0x09f0,0x47c0,0x8879,0x0000,
  0x0000,0xa9b8,0x8bf8,0xd4fa,0x28d8,0x05a0,0x0360,0x0000,
  0x0000,0xa8b0,0x07d0,0x06c0,0x0598,0x0468,0x0350,0x0000,
  0x0000,0xa981,0x4698,0x0480,0x0360,0x2350,0xe550,0x0000,
  0x0000,0x2110,0x8871,0x0350,0x0348,0xe550,0x0008,0x0000,
  0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000
  };
const GFX_COLOR recyclerIcon[]={
  BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,BLACK,
  BLACK,LIGHTBLUE,LIGHTBLUE,LIGHTBLUE,LIGHTBLUE,LIGHTBLUE,LIGHTBLUE,BLACK,
  BLACK,LIGHTBLUE,BLACK,BLACK,BLACK,BLACK,LIGHTBLUE,BLACK,
  BLACK,LIGHTBLUE,BLACK,BLACK,BLACK,BLACK,LIGHTBLUE,BLACK,
  BLACK,BLACK,LIGHTBLUE,BLACK,BLACK,LIGHTBLUE,BLACK,BLACK,
  BLACK,BLACK,LIGHTBLUE,BLACK,BLACK,LIGHTBLUE,BLACK,BLACK,
  BLACK,BLACK,BLACK,LIGHTBLUE,LIGHTBLUE,BLACK,BLACK,BLACK,
  BLACK,BLACK,BLACK,LIGHTBLUE,LIGHTBLUE,BLACK,BLACK,BLACK
  };
const GFX_COLOR folderIcon[]={
  0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,
  0xad73,0xb2bd,0x30ad,0x0c63,0x0c63,0x0c63,0x0c63,0x0c63,
  0x92b5,0x15ef,0xf3ee,0xb3e6,0x92de,0xb3e6,0x51de,0xa339,
  0xd4bd,0x31ff,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0x499c,
  0x91bd,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0xa662,
  0x4dbd,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0xe220,
  0x11ad,0xb2bd,0xb2bd,0xb2bd,0xb2bd,0xb2bd,0x92bd,0x0c63,
  0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7
  };
const GFX_COLOR windowIcon[]={
  0x1ebe,0x3ebe,0xddb5,0xdcb5,0xdcb5,0x1ebe,0x1ebe,0xfdb5,
  0xdfd6,0x1fdf,0x1fdf,0x1fdf,0x1fdf,0x1fdf,0x1fdf,0xbfd6,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9995,0x988d,0x9995,0x988d,0x9995,0x988d,0x9995,0x798d
  };

#define MAX_TIMERS 4
TIMER_DATA timerData[MAX_TIMERS];    // diciamo 4

static void DrawCharWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size);
static void DrawPixelWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color);
static void DrawLineWindow(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static void DrawHorizLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,UGRAPH_COORD_T x2,GFX_COLOR c);
static void DrawVertLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,UGRAPH_COORD_T y2,GFX_COLOR c);
static void DrawRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static void FillRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static void DrawCircleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static BOOL inline BoundaryCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y);
static BOOL inline ZCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y);
static BOOL nonClientPaint(HWND hWnd,const RECT *rc);
static BOOL clientPaint(HWND hWnd,const RECT *rc);
static void calculateClientArea(HWND hWnd,RECT *rc);
static void calculateNonClientArea(HWND hWnd,RECT *rc);
static void activateChildren(HWND hWnd);

static BOOL addHeadWindow(HWND);
static BOOL addTailWindow(HWND);
static BOOL insertWindow(HWND,HWND);
static BOOL removeWindow(HWND);
static void SortLinkedList(struct _WINDOW *head);
static void list_bubble_sort(struct _WINDOW **head);
LRESULT DefWindowProc(HWND,uint16_t,WPARAM ,LPARAM);
LRESULT SendMessage(HWND,uint16_t,WPARAM ,LPARAM);
static HWND setActive(HWND hWnd,BOOL state);


//-------------------------windows----------------------------------------------
void InitWindows(GFX_COLOR bgcolor /*DARKBLUE*/) {
  char buf[16];
  
  windowForeColor=BRIGHTCYAN;
  windowInactiveForeColor=GRAY160;
  windowBackColor=DARKGRAY;
  desktopColor=bgcolor;
  rootWindows=NULL;
  maxWindows=1;
  // oppure 
  // rootWindows=CreateWindow("desktop","",WS_ACTIVE | WS_VISIBLE,0,0,_width,_height,NULL,NULL,0);
  // e anche
  // CreateWindow("taskbar","",WS_ACTIVE | WS_VISIBLE,0,_height-_height/16,_width,_height/16,NULL,NULL,0);
  
  switch(videoMode) {
    case MODE_VGA:
      screenCLS(BLACK);
      writeStringXY(4,4,"BREAKTHROUGH 2.0",WHITE);
      break;
    case MODE_COMPOSITE:
      screenCLS(BLACK);
      writeStringXY(4,4,"BREAKTHROUGH 2.0",WHITE);
      break;
    case MODE_LCD:
      clearScreenLCD();
      goto lcd_normale;
    case MODE_LCD_DMA:
      screenCLS(BLACK);
      displayDMA();
lcd_normale:
#ifndef USING_SIMULATOR
      setColors(WHITE,desktopColor);    // ok cos�, magari fare un rettangoletto
      setTextSize(2);
      setCursor((_width-12*6*2)/2,_height/2-30);
      gfx_print("BREAKTHROUGH");
      setCursor((_width-4*6*2)/2,_height/2-5);
      sprintf(buf,"%u.%02u",BREAKTHROUGH_VERSION_H,BREAKTHROUGH_VERSION_L);
      gfx_print(buf);
      setTextSize(1);
      setColors(LIGHTGRAY,desktopColor);
      setCursor((_width-13*6)/2,_height/2+36);
      gfx_print("(C) 1988-2021");
#endif
      break;
    }
  
  __delay_ms(1000);
  ClrWdt();
  mouseX=_width/2; mouseY=_height/2;
  mouseCursor=standardCursor;

#ifndef USING_SIMULATOR
  PaintDesktop(NULL);
#endif
  ClrWdt();
  // oppure 
  // rootWindows=desktopWindow=CreateWindow(WC_DESKTOPCLASS,NULL,WS_ACTIVE | WS_VISIBLE,0,0,_width,_height,NULL,NULL,0);
  // e anche
  // shellWindow=CreateWindow("taskbar","",WS_ACTIVE | WS_VISIBLE,0,_height-_height/16,_width,_height/16,NULL,NULL,0);
  }

GFX_COLOR GetSysColor(int nIndex) {
  
  switch(nIndex) {
    case COLOR_ACTIVECAPTION:
    case COLOR_ACTIVEBORDER:
    case COLOR_BTNFACE:
    case COLOR_CAPTIONTEXT:
    case COLOR_BTNTEXT:
    case COLOR_MENU:
    case COLOR_MENUBAR:
    case COLOR_SCROLLBAR:
    case COLOR_WINDOWFRAME:
    case COLOR_WINDOWTEXT:
      return windowForeColor;
      break;
    case COLOR_GRAYTEXT:
    case COLOR_INACTIVEBORDER:
    case COLOR_INACTIVECAPTION:
    case COLOR_INACTIVECAPTIONTEXT:
      return windowInactiveForeColor;
      break;
    case COLOR_WINDOW:
      return windowBackColor;
      break;
//    case COLOR_BACKGROUND:
    case COLOR_DESKTOP:
      return desktopColor;
      break;
    }
  }

GFX_COLOR GetSystemMetrics(int nIndex) {
  
  switch(nIndex) {
    case SM_CXSCREEN:
      return _width;
      break;
    case SM_CYSCREEN:
      return _height;
    case SM_CXVSCROLL:
      return SCROLL_SIZE;
      break;
    case SM_CYHSCROLL:
      return SCROLL_SIZE;
      break;
    case SM_CYCAPTION:
      return TITLE_HEIGHT;
      break;
    case SM_CXBORDER:
      return 1;
      break;
    case SM_CYBORDER:
      return 1;
      break;
    case SM_CYVTHUMB:
      break;
    case SM_CXHTHUMB:
      break;
    case SM_CXICON:
      return 8;
      break;
    case SM_CYICON:
      return 8;
      break;
    case SM_CXCURSOR:
      return 8;
      break;
    case SM_CYCURSOR:
      return 8;
      break;
    case SM_CYMENU:
      return MENU_HEIGHT;
      break;
    case SM_CXFULLSCREEN:
      return _width;
      break;
    case SM_CYFULLSCREEN:
      return _width;
      break;
    case SM_CYKANJIWINDOW:
      return FALSE;
      break;
    case SM_MOUSEPRESENT:
      return TRUE;
      break;
    case SM_CYVSCROLL:
      break;
    case SM_CXHSCROLL:
      break;
    case SM_DEBUG:
#ifdef _DEBUG
      return TRUE;
#else
      return FALSE;
#endif
      break;
    case SM_SWAPBUTTON:
      return FALSE;
      break;
    case SM_RESERVED1:
      return 0;
      break;
    case SM_RESERVED2:
      return 0;
      break;
    case SM_RESERVED3:
      return 0;
      break;
    case SM_RESERVED4:
      return 0;
      break;
    case SM_CXMIN:
      break;
    case SM_CYMIN:
      break;
    case SM_CXSIZE:
      break;
    case SM_CYSIZE:
      break;
//    case SM_CXDLGFRAME:
//    case SM_CXSIZEFRAME:
    case SM_CXFRAME:
      return 2;
      break;
//    case SM_CYDLGFRAME:
//    case SM_CYSIZEFRAME:
    case SM_CYFRAME:
      return 2;
      break;
    case SM_CXMINTRACK:
      break;
    case SM_CYMINTRACK:
      break;
    case SM_CXDOUBLECLK:
      break;
    case SM_CYDOUBLECLK:
      break;
    case SM_CXICONSPACING:
      break;
    case SM_CYICONSPACING:
      break;
    case SM_MENUDROPALIGNMENT:
      break;
    case SM_PENWINDOWS:
    case SM_TABLETPC:
      return FALSE;
      break;
    case SM_DBCSENABLED:
      return FALSE;
      break;
    case SM_CMOUSEBUTTONS:
      return 2;
      break;
    case SM_CXFIXEDFRAME:
      break;
    case SM_CYFIXEDFRAME:
      break;
    case SM_SECURE:
      return FALSE;
      break;
    case SM_CXEDGE:
      break;
    case SM_CYEDGE:
      break;
    case SM_CXMINSPACING:
      break;
    case SM_CYMINSPACING:
      break;
    case SM_CXSMICON:
      break;
    case SM_CYSMICON:
      break;
    case SM_CYSMCAPTION:
      break;
    case SM_CXSMSIZE:
      break;
    case SM_CYSMSIZE:
      break;
    case SM_CXMENUSIZE:
      break;
    case SM_CYMENUSIZE:
      break;
    case SM_ARRANGE:
      break;
    case SM_CXMINIMIZED:
      break;
    case SM_CYMINIMIZED:
      break;
    case SM_CXMAXTRACK:
      break;
    case SM_CYMAXTRACK:
      break;
    case SM_CXMAXIMIZED:
      break;
    case SM_CYMAXIMIZED:
      break;
    case SM_NETWORK:
      return TRUE;
      return FALSE;
      break;
    case SM_CLEANBOOT:
#ifdef _DEBUG
      return TRUE;
#else
      return FALSE;
#endif
      break;
    case SM_CXDRAG:
      break;
    case SM_CYDRAG:
      break;
    case SM_SHOWSOUNDS:
      return FALSE;
      break;
    case SM_CXMENUCHECK:
      break;
    case SM_CYMENUCHECK:
      break;
    case SM_SLOWMACHINE:
      return FALSE; //:D suca
      break;
    case SM_MIDEASTENABLED:
      return FALSE;   // porcoallah :D :D
      break;
    case SM_MOUSEWHEELPRESENT:
      return FALSE;
      break;
    case SM_XVIRTUALSCREEN:
      return FALSE;
      break;
    case SM_YVIRTUALSCREEN:
      return FALSE;
      break;
    case SM_CXVIRTUALSCREEN:
      return FALSE;
      break;
    case SM_CYVIRTUALSCREEN:
      return FALSE;
      break;
    case SM_CMONITORS:
      return 1;
      break;
    case SM_SAMEDISPLAYFORMAT:
      return FALSE;
      break;
    case SM_CMETRICS:
      return ;
      break;
    }
  }

HWND GetDesktopWindow(void) { return rootWindows; }	// forse :)
HWND GetShellWindow(void) { return shellWindow; }

int GetDeviceCaps(HDC hDC,int index) {
  
  switch(index) {
    case DRIVERVERSION:
      return MAKEWORD(BREAKTHROUGH_VERSION_L,BREAKTHROUGH_VERSION_H);
      break;
    case TECHNOLOGY:
      break;
    case HORZSIZE:
    case HORZRES:
      return _height;
      break;
    case VERTRES:
    case VERTSIZE:
      return _width;
      break;
    case BITSPIXEL:
      switch(videoMode) {
        case MODE_LCD:
        case MODE_LCD_DMA:
          return 16;
          break;
        case MODE_VGA:
          return 8;
          break;
        case MODE_COMPOSITE:
          return 8;
          break;
        }
      break;
    case PLANES:
      return 3;
      break;
    case NUMBRUSHES:
      return 1;
      break;
    case NUMPENS:
      return 1;
      break;
    case NUMMARKERS:
      return 0;
      break;
    case NUMFONTS:
//      #ifdef USE_CUSTOM_FONTS 
        return 3;
      break;
    case NUMCOLORS:
      switch(videoMode) {
        case MODE_LCD:
        case MODE_LCD_DMA:
          return 65536;
          break;
        case MODE_VGA:
          return 256;
          break;
        case MODE_COMPOSITE:
          return 256;
          break;
        }
      break;
    case CURVECAPS:
      return 1;
      break;
    case LINECAPS:
      return 1;
      break;
    case POLYGONALCAPS:
      return 1;
      break;
    case TEXTCAPS:
      return 1;
      break;
    case CLIPCAPS:
      return 1;
      break;
    case RASTERCAPS:
      return 1;
      break;
    case VREFRESH:
      switch(videoMode) {
        case MODE_LCD:
        case MODE_LCD_DMA:
          return 50;
          break;
        case MODE_VGA:
          return 60;
          break;
        case MODE_COMPOSITE:
          return 50;
          break;
        }
      break;
      
    default:
      break;
    }
  }

BOOL SetCursorPos(int X,int Y) {

  mouseX=X; mouseY=Y;
  }
BOOL GetCursorPos(POINT *lpPoint) {
  
  lpPoint->x=mouseX; lpPoint->y=mouseY;
  }
CURSOR SetCursor(CURSOR hCursor) {
  
  mouseCursor=hCursor;
  }
BOOL SetCaretPos(int X,int Y) {
  }
BOOL SetCaretBlinkTime(UINT uMSeconds) {
  }
BOOL HideCaret(HWND hWnd) {
  }

HWND CreateWindow(CLASS Class,const char *lpWindowName,
  DWORD dwStyle,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,UGRAPH_COORD_T nWidth,UGRAPH_COORD_T nHeight,
  HWND hWndParent,HMENU hMenu,void *lpParam) {
  HWND hWnd;
  WNDCLASS *wndClass;

  if(!GetClassInfo(0,Class,&wndClass))
    return NULL;
  
  hWnd=malloc(sizeof(struct _WINDOW)+wndClass->cbWndExtra);
  if(!hWnd)
    return NULL;
  hWnd->class=Class;
  hWnd->next=NULL;
  hWnd->status=0;
  hWnd->nonClientArea.top=Y;
  hWnd->nonClientArea.left=X;
  hWnd->nonClientArea.bottom=Y+nHeight;
  hWnd->nonClientArea.right=X+nWidth;
  hWnd->cursorX=hWnd->cursorY=0;
  hWnd->foreColor=WHITE;    // CONTRARIO di windows, almeno per ora :)
  hWnd->backColor=BLACK;
  hWnd->hDC.font=/*(FONT)GetStockObject(SYSTEM_FIXED_FONT)*/ CreateFont(8,6,0,0,100,0,0,0,0,0,0,
    0,0,NULL);
  hWnd->hDC.pen=CreatePen(PS_SOLID,1,WHITE);
  hWnd->hDC.brush=GetSysColorBrush(COLOR_WINDOW) /*CreateSolidBrush(BLACK)*/;
  hWnd->icon=wndClass->icon;
  hWnd->cursor=wndClass->cursor;
  hWnd->windowProc=wndClass->lpfnWndProc;
  if(lpWindowName) {
    strncpy(hWnd->caption,lpWindowName,sizeof(hWnd->caption)-1);
    hWnd->caption[sizeof(hWnd->caption)-1]=0;
    }
  else
    hWnd->caption[0]=0;
  hWnd->style=dwStyle;    // e wndClass->style ?
//  hWnd->styleEx=0;
  hWnd->tag=lpParam;
  hWnd->menu=hMenu;
  if(dwStyle & WS_CHILD)    // safety
    hWnd->parent=hWndParent;
  else
    hWnd->parent=NULL;
  
  { CREATESTRUCT cs;
  cs.x=hWnd->nonClientArea.left;
  cs.y=hWnd->nonClientArea.top;
  cs.cx=hWnd->nonClientArea.right-hWnd->nonClientArea.left;
  cs.cy=hWnd->nonClientArea.bottom-hWnd->nonClientArea.top;
  cs.class=Class;
  cs.lpszName=hWnd->caption;
  cs.style=hWnd->style;
//  cs.dwExStyle=hWnd->styleEx;
  if(!SendMessage(hWnd,WM_NCCREATE,0,(LPARAM)&cs))
    goto no_creata;
  if(SendMessage(hWnd,WM_CREATE,0,(LPARAM)&cs) < 0) {
no_creata:
    free(hWnd);
    return NULL;
    }
  else {
    hWnd->style=cs.style;
    hWnd->nonClientArea.left=cs.x;
    hWnd->nonClientArea.top=cs.y;
    hWnd->nonClientArea.right=hWnd->nonClientArea.left+cs.cx;
    hWnd->nonClientArea.bottom=hWnd->nonClientArea.top+cs.cy;
    }
  }
  calculateClientArea(hWnd,&hWnd->clientArea);
  hWnd->scrollPosX=hWnd->scrollPosY=0;
  calculateNonClientArea(hWnd,&hWnd->nonClientArea);
  hWnd->enabled=hWnd->style & WS_DISABLED ? 0 : 1;
  if(hWnd->enabled && !(hWnd->style & WS_CHILD)) {
    hWnd->zOrder=maxWindows;
//che fare con le Child? mah le metto cmq in coda
    addTailWindow(hWnd);
    }
  else {
    hWnd->zOrder=1;
    addHeadWindow(hWnd);    // cos� rispettiamo lo Z-order subito!
    }
  if(!(hWnd->style & WS_CHILD))   // direi
    setActive(hWnd,hWnd->style & WS_ACTIVE ? 1 : 0);
  
  if(hWnd->style & WS_VISIBLE) {
    hWnd->visible=1;
#ifndef USING_SIMULATOR
    if(!(hWnd->style & WS_CHILD)) {
      SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
      SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
      SendMessage(hWnd,WM_PAINT,0,0);
      }
    else {
      SendMessage(hWnd->parent,WM_PAINT,0,0);   // direi cos�
      }
#endif
    }

#ifdef USING_SIMULATOR
  {
  extern HWND rootWindows;
    HWND myWnd=rootWindows;
  while(myWnd)
    myWnd=myWnd->next;
  }
#endif

  return hWnd;
  }

static BOOL addTailWindow(HWND hWnd) {   // per insertSorted: https://www.geeksforgeeks.org/given-a-linked-list-which-is-sorted-how-will-you-insert-in-sorted-way/
  HWND myWnd;
  
  maxWindows++;
  if(!rootWindows)
    rootWindows=hWnd;
  else {
    myWnd=rootWindows;
    while(myWnd && myWnd->next) {
      myWnd=myWnd->next;
      }
    myWnd->next=hWnd;
    }
  return 1;
  }
static BOOL addHeadWindow(HWND hWnd) {
  HWND myWnd;
  
  maxWindows++;
  if(!rootWindows)
    rootWindows=hWnd;
  else {
    myWnd=hWnd->next=rootWindows;
    rootWindows=hWnd;
    rootWindows->zOrder=1;    // questa diventa la pi� indietro...
    while(myWnd) {
      myWnd->zOrder++;    // ...e le scrollo tutte avanti di uno
      myWnd=myWnd->next;
      }
    }
  return 1;
  }
static BOOL insertWindow(HWND hWnd,HWND hWndAfter) {
  HWND myWnd,myWnd2;
  
  removeWindow(hWnd);
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd == hWndAfter) {
      myWnd2=hWndAfter->next;
      hWndAfter->next=hWnd;
      hWnd->next=myWnd2;
      maxWindows++;
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;
  }
static BOOL removeWindow(HWND hWnd) {
  HWND myWnd=rootWindows,myWnd2;
  
  while(myWnd) {
    myWnd2=myWnd;
    if(myWnd==hWnd) {
      if(myWnd==rootWindows)
        rootWindows=myWnd->next;
      else
        myWnd2->next=myWnd->next;
      maxWindows--;
      myWnd=myWnd->next;
      while(myWnd) {
        myWnd->zOrder--;
        myWnd=myWnd->next;
        }
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;
  }

LRESULT SendMessage(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  HWND myWnd;

	if(hWnd==HWND_BROADCAST) {
    myWnd=rootWindows;
    while(myWnd) {
			if(!(myWnd->style & WS_CHILD) /*myWnd->parent*/)
				myWnd->windowProc(myWnd,message,wParam,lParam);
      myWnd=myWnd->next;
      }
    }
	else
		return hWnd->windowProc(hWnd,message,wParam,lParam);   // per ora cos� :)
  }
LRESULT DefWindowProc(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_NCPAINT:
      //wParam = region
      return nonClientPaint(hWnd,(RECT *)wParam);
      break;
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_SYNCPAINT:
      SendMessage(hWnd,WM_NCPAINT,0,0);
      SendMessage(hWnd,WM_ERASEBKGND,0,0);
      break;
    case WM_SETREDRAW:
      if(wParam)      // gestire blocco/sblocco redraw...
        ;
      break;
    case WM_CTLCOLOR:   // � deprecated ma per ora lo uso!
      return 0xffffffff;   // 
      break;
    case WM_SETICON:
      hWnd->icon=(const GFX_COLOR *)lParam;
      break;
    case WM_SETFONT:
      hWnd->font.font=((BYTE *)wParam);
      if(LOWORD(lParam))
        InvalidateRect(hWnd,NULL,TRUE);
      break;
    case WM_GETFONT:
      return (LRESULT)hWnd->font.font;
      break;
    case WM_ERASEBKGND: // If hbrBackground is NULL, the application should process the WM_ERASEBKGND 
      return 0;
      break;
    case WM_CHAR:
    { char buf[8];    // TOGLIERE POI! :D
      buf[0]=wParam; buf[1]=0;
      TextOut(&hWnd->hDC,hWnd->hDC.cursorX,hWnd->hDC.cursorY,buf);
    }
      break;
    case WM_MOUSEMOVE:
      break;
    case WM_LBUTTONDOWN:
      break;
    case WM_SETCURSOR:
      // wparam=handle to window, L-lparam=hittest H-lparam=wm_mousemove o altro
      // impostare cursore a class-cursor se in client area
      break;
    case WM_TIMER:
      break;
    case WM_HSCROLL:
      break;
    case WM_VSCROLL:
      break;
    case WM_GETMINMAXINFO:
      // lParam = MINMAXINFO structure
      break;
    case WM_NCCALCSIZE:
      if(wParam) {
        struct NCCALCSIZE_PARAMS *ncp=(struct NCCALCSIZE_PARAMS *)lParam;
        }
      else {
        RECT *rc=(RECT *)lParam;
        calculateNonClientArea(hWnd,rc);
        calculateClientArea(hWnd,rc);
        }
      break;
    case WM_NCHITTEST:    //https://docs.microsoft.com/en-us/windows/win32/inputdev/wm-nchittest
      {POINT pt;
      pt.x=LOWORD(lParam); pt.y=HIWORD(lParam);
      if(pt.x>=hWnd->nonClientArea.left && pt.y>=hWnd->nonClientArea.top) {
        if(pt.y==hWnd->nonClientArea.top) {
          if(pt.x==hWnd->nonClientArea.left)
            return HTTOPLEFT;
          else if(pt.x==hWnd->nonClientArea.right)
            return HTTOPRIGHT;
          else
            return HTTOP;
          }
        else if(pt.y<hWnd->nonClientArea.bottom) {
          if(pt.x<=hWnd->nonClientArea.left+BORDER_SIZE) {  // gestire thick
            return hWnd->style & WS_THICKFRAME ? HTLEFT : HTBORDER;   // solo se resizable...
            }
          else if(pt.x>=hWnd->nonClientArea.right-BORDER_SIZE) {  // gestire thick
            return hWnd->style & WS_THICKFRAME ? HTRIGHT : HTBORDER;   // solo se resizable...
            }
          else if(pt.y<=hWnd->nonClientArea.top+TITLE_HEIGHT) {
            if(pt.x>=hWnd->nonClientArea.left+TITLE_ICON_WIDTH) {
              return hWnd->style & WS_SYSMENU ? HTSYSMENU : HTCAPTION;
              }
            else if(pt.x>=hWnd->nonClientArea.right-TITLE_ICON_WIDTH) {
              if(hWnd->style & WS_SYSMENU)
                return HTCLOSE;
              else if(hWnd->style & WS_MAXIMIZEBOX)
                return HTMAXBUTTON;
              else
                return HTCAPTION;
              }
            else if(pt.x>=(hWnd->nonClientArea.right-TITLE_ICON_WIDTH*2+2)) {
              if(hWnd->style & WS_MAXIMIZEBOX)
                return HTMAXBUTTON;
              else if(hWnd->style & WS_MINIMIZEBOX)
                return HTMINBUTTON;
              else
                return HTCAPTION;
              }
            else if(pt.x>=(hWnd->nonClientArea.right-TITLE_ICON_WIDTH*3+4)) {
              if(hWnd->style & WS_MINIMIZEBOX)
                return HTMINBUTTON;
              else
                return HTCAPTION;
              }
            else {
              return HTCAPTION;
              }
            }
          else if(hWnd->menu && pt.y<=hWnd->nonClientArea.top+MENU_HEIGHT) {
//            if(pt.x>=hWnd->nonClientArea.left+TITLE_ICON_WIDTH) {
            return HTMENU ;     // FINIRE!
            }
          else if(pt.y<=hWnd->nonClientArea.bottom-SCROLL_SIZE) {
            if(pt.x>=hWnd->nonClientArea.right-SCROLL_SIZE)
              return hWnd->style & WS_HSCROLL ? HTHSCROLL : HTCLIENT;
            }
          else if(pt.y<=hWnd->nonClientArea.bottom-BORDER_SIZE) {
            if(hWnd->style & WS_SIZEBOX) {
              if(pt.x>=hWnd->nonClientArea.right-SCROLL_SIZE)
                return HTSIZE;
              else
                return hWnd->style & WS_HSCROLL ? HTHSCROLL : HTCLIENT;
              }
            else {
              return hWnd->style & WS_VSCROLL ? HTVSCROLL : HTCLIENT;
              }
            }
          else if(pt.x<hWnd->nonClientArea.right-BORDER_SIZE) {
            return HTCLIENT;
            }
          }
        else if(pt.y==hWnd->nonClientArea.bottom) {
          if(pt.x==hWnd->nonClientArea.left+BORDER_SIZE) {  // gestire thick
            return hWnd->style & WS_THICKFRAME ? HTBOTTOMLEFT : HTBOTTOM;   // solo se resizable...
            }
          else if(pt.x==hWnd->nonClientArea.right-BORDER_SIZE) {  // gestire thick
            return hWnd->style & WS_THICKFRAME ? HTBOTTOMRIGHT : HTBOTTOM;   // solo se resizable...
            }
          else {
            return hWnd->style & WS_THICKFRAME ? HTBOTTOM : HTBORDER;   // solo se resizable...
            }
          }
        }
      else {
        return HTNOWHERE;
        }
/*      
HTBORDER 18 //	In the border of a window that does not have a sizing border.
HTBOTTOM 15 //	In the lower-horizontal border of a resizable window (the user can click the mouse to resize the window vertically).
HTBOTTOMLEFT 16 //	In the lower-left corner of a border of a resizable window (the user can click the mouse to resize the window diagonally).
HTBOTTOMRIGHT 17 //	In the lower-right corner of a border of a resizable window (the user can click the mouse to resize the window diagonally).
HTCAPTION 2	//In a title bar.
HTCLIENT 1 //	In a client area.
HTCLOSE 20 //In a Close button.
HTERROR -2 //	On the screen background or on a dividing line between windows (same as HTNOWHERE, except that the DefWindowProc function produces a system beep to indicate an error).
HTGROWBOX 4 //	In a size box (same as HTSIZE).
HTHELP 21 //	In a Help button.
HTHSCROLL 6 //	In a horizontal scroll bar.
HTLEFT 10 //	In the left border of a resizable window (the user can click the mouse to resize the window horizontally).
HTMENU 5 //	In a menu.
HTMAXBUTTON 9 //	In a Maximize button.
HTMINBUTTON 8 //	In a Minimize button.
HTNOWHERE 0 //	On the screen background or on a dividing line between windows.
HTREDUCE 8 //	In a Minimize button.
HTRIGHT 11 //	In the right border of a resizable window (the user can click the mouse to resize the window horizontally).
HTSIZE 4 //	In a size box (same as HTGROWBOX).
HTSYSMENU 3 //	In a window menu or in a Close button in a child window.
HTTOP 12 //	In the upper-horizontal border of a window.
HTTOPLEFT 13 //	In the upper-left corner of a window border.
HTTOPRIGHT 14 //	In the upper-right corner of a window border.
HTTRANSPARENT -1 //	In a window currently covered by another window in the same thread (the message will be sent to underlying windows in the same thread until one of them returns a code that is not HTTRANSPARENT).
HTVSCROLL 7 //	In the vertical scroll bar.
HTZOOM 9 //	In a Maximize button
 * */
      return HTNOWHERE;
      }
      break;
    case WM_NCCREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 0;
      break;
    case WM_NCDESTROY:
      return 0;
      break;
    case WM_DESTROY:
      return 0;
      break;
    case WM_MOVE:
      //xPos = (int)(short) LOWORD(lParam);   // horizontal position 
      //yPos = (int)(short) HIWORD(lParam);   // vertical position 
      activateChildren(hWnd);
      return 0;
      break;
//    case WM_MOVING:
//      break;
    case WM_SIZE:
      switch(wParam) {
        case SIZE_MAXHIDE:
          break;
        case SIZE_MAXIMIZED:
          break;
        case SIZE_MAXSHOW:
          break;
        case SIZE_MINIMIZED:
          break;
        case SIZE_RESTORED:
          break;
        }
      //UINT width = LOWORD(lParam);
      //UINT height = HIWORD(lParam);
      activateChildren(hWnd);
      return 0;
      break;
//    case WM_SIZING:
//      break;
    case WM_CLOSE:
      DestroyWindow(hWnd);
      break;
    case WM_NCACTIVATE:
      // https://docs.microsoft.com/en-us/windows/win32/winmsg/wm-ncactivate
      return 1;   // per ora cos�
      break;
    case WM_ACTIVATE:
//   		setActive(hWnd,wParam == WA_ACTIVE);
//   	  hWnd->active=wParam == WA_ACTIVE;
      return 0;
      break;
    case WM_MOUSEACTIVATE:
//MA_ACTIVATE 1 //	Activates the window, and does not discard the mouse message.
//MA_ACTIVATEANDEAT 2 //	Activates the window, and discards the mouse message.
//MA_NOACTIVATE 3 //	Does not activate the window, and does not discard the mouse message.
//MA_NOACTIVATEANDEAT //4
      break;
    case WM_CHILDACTIVATE:
      return 0;
      break;
    case WM_DISPLAYCHANGE:
      break;
    case WM_PAINTICON:    // solo windows 3.x :)
      break;
    case WM_QUERYOPEN:
			return 1;
      break;
    case WM_SHOWWINDOW:
			return 0;
      break;
    case WM_WINDOWPOSCHANGING:
      return 0;
      break;
    case WM_WINDOWPOSCHANGED:
      return 0;
      break;
    case WM_SETFOCUS:
      break;
    case WM_KILLFOCUS:
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      nonClientPaint(hWnd,NULL /*area titolo...*/);
      return 1;
      break;
    case WM_GETTEXT:
      {
      int i=min(sizeof(hWnd->caption),wParam);
      strncpy((char *)lParam,hWnd->caption,i-1);
      ((char *)lParam)[i]=0;
      return i;
      }
      break;
    case WM_GETTEXTLENGTH:
      return strlen(hWnd->caption);
      break;
    case WM_ENABLE:
      hWnd->enabled=wParam;
      // c'entra con active? https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-enablewindow
      if(!hWnd->enabled) {
    		setActive(hWnd,FALSE);
        SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
        SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
        SendMessage(hWnd,WM_PAINT,0,0);
				}
      break;
    case WM_STYLECHANGED:
      break;
    case WM_STYLECHANGING:
      break;
      
    case WM_INITDIALOG:
      break;
    case WM_INITMENU:
      break;
    case WM_COMMAND:
      break;
    case WM_SYSCOMMAND:
      break;

    case WM_ENDSESSION:
      return 0;
      break;
    case WM_QUERYENDSESSION:
      return TRUE;
      break;
    case WM_QUIT:
      break;

    }
  return 0;
  }

LRESULT DefWindowProcStaticWC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      int i;
      GetClientRect(hWnd,&rc);
#ifndef USING_SIMULATOR
      FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
      // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_BUTTON,GetWindowByte(hWnd,1));
      switch(hWnd->style & 0xff) {
        case SS_LEFT:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
          TextOut(&hWnd->hDC,0,0,hWnd->caption);
          break;
        case SS_CENTER:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
          i=strlen(hWnd->caption)*6*hWnd->font.size;
          if(i>=rc.right)
            i=rc.right;
          TextOut(&hWnd->hDC,(rc.right-i)/2,0,hWnd->caption);
          break;
        case SS_RIGHT:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
          i=strlen(hWnd->caption)*6*hWnd->font.size;
          if(i>=rc.right)
            i=rc.right;
          TextOut(&hWnd->hDC,rc.right-i,0,hWnd->caption);
          break;
        case SS_ICON:
          DrawIcon8(&hWnd->hDC,0,0,hWnd->icon);
          break;
        case SS_BITMAP:
//          DrawIcon(&hWnd->hDC,0,0,hWnd->icon);
          break;
        case SS_BLACKFRAME:
          SetTextColor(&hWnd->hDC,BLACK);
          Rectangle(&hWnd->hDC,rc.left,rc.top,rc.right,rc.bottom);
          break;
        case SS_GRAYFRAME:
          SetTextColor(&hWnd->hDC,LIGHTGRAY);
          Rectangle(&hWnd->hDC,rc.left,rc.top,rc.right,rc.bottom);
          break;
        case SS_WHITEFRAME:
          SetTextColor(&hWnd->hDC,WHITE);
          Rectangle(&hWnd->hDC,rc.left,rc.top,rc.right,rc.bottom);
          break;
        case SS_BLACKRECT:
          FillRect(&hWnd->hDC,&rc,GetStockObject(BLACK_BRUSH).myBrush);
          break;
        case SS_GRAYRECT:
          FillRect(&hWnd->hDC,&rc,(BRUSH)GetStockObject(GRAY_BRUSH).myBrush);
          break;
        case SS_WHITERECT:
          FillRect(&hWnd->hDC,&rc,(BRUSH)GetStockObject(WHITE_BRUSH).myBrush);
          break;
        case SS_SUNKEN:
          break;
        }
#endif
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      cs->style |= WS_DISABLED;   // direi
      cs->style &= ~WS_ACTIVE;   // direi
      if((cs->style & 0xff) == SS_ICON)
        cs->cx=cs->cy=8 + (hWnd->style & WS_BORDER ? 2 : 0); // type ecc..
      else
        cs->cy=hWnd->font.size*8 + (hWnd->style & WS_BORDER ? 2 : 0); // 
      }
      return 0;
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      clientPaint(hWnd,NULL);
      return 1;
      break;

    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcEditWC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      char *s;
      BYTE x,startSel,endSel;
      GetClientRect(hWnd,&rc);
//      SetTextColor(&hWnd->hDC,hWnd->active ? GRAY224 : GRAY128);
      FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
      // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_BUTTON,GetWindowByte(hWnd,1));
      
      s=hWnd->caption;
      startSel=GetWindowByte(hWnd,1);
      endSel=GetWindowByte(hWnd,2);
      x=0;
      while(*s) {
        if(startSel || endSel) {
          if(x>=startSel && x<=endSel)
            SetTextColor(&hWnd->hDC,BLACK);
          else
            SetTextColor(&hWnd->hDC,WHITE);
          }
        else
          SetTextColor(&hWnd->hDC,WHITE);
        DrawCharWindow(&hWnd->hDC,x*6*hWnd->hDC.font.size,rc.top+1,*s++,
          hWnd->hDC.foreColor,hWnd->hDC.backColor,hWnd->hDC.font.size);
        x++;
        s++;
        }
      }
      return 1;
      break;
    case WM_LBUTTONDOWN:
      //startsel ecc
      break;
    case WM_CHAR:
    { char buf[8];
      int i;
      buf[0]=wParam; buf[1]=0;
      TextOut(&hWnd->hDC,hWnd->hDC.cursorX,hWnd->hDC.cursorY,buf);
      i=GetWindowByte(hWnd,0);   // curpos
      if(i<32   )
        i++;
      SetWindowByte(hWnd,0,i);   // 
      
      if(hWnd->enabled)
        SendMessage(hWnd->parent,WM_COMMAND,MAKELONG((DWORD)hWnd->tag,EN_CHANGE),(LPARAM)hWnd);
    }
      break;
    case WM_SETFOCUS:
      {RECT rc;
      int i;
      GetClientRect(hWnd,&rc);
      i=GetWindowByte(hWnd,0) * 6;   // curpos
      i=rc.left+i;
      if(i>=rc.right)
        i=rc.right;
      DrawCaret(&hWnd->hDC,i,rc.top+1,standardCaret);
      }
      break;
    case WM_KILLFOCUS:
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      SetWindowByte(hWnd,0,0);   // curpos ecc
      SetWindowByte(hWnd,1,0);   // curpos ecc
      SetWindowByte(hWnd,2,0);   // curpos ecc
      clientPaint(hWnd,NULL);
      return 1;
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcDlgWC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
//      SetTextColor(&hWnd->hDC,hWnd->active ? GRAY224 : GRAY128);
      FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
      
      SetTextColor(&hWnd->hDC,WHITE);
      TextOut(&hWnd->hDC,0,0,hWnd->caption);    // ovviamente finire :)
      }
      return 1;
      break;
    case WM_CHAR:
    { switch(wParam) {
        case VK_RETURN:
          break;
        case VK_ESCAPE:
          break;
        default:
          break;
        }
    }
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcListboxWC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
//      SetTextColor(&hWnd->hDC,hWnd->active ? GRAY224 : GRAY128);
      FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
      
      SetTextColor(&hWnd->hDC,WHITE);
      TextOut(&hWnd->hDC,0,0,hWnd->caption);    // ovviamente finire :)
      }
      return 1;
      break;
    case WM_CHAR:
    { char buf[8];
      buf[0]=wParam; buf[1]=0;
      TextOut(&hWnd->hDC,hWnd->hDC.cursorX,hWnd->hDC.cursorY,buf);
    }
      break;
    case WM_SETFOCUS:
      break;
    case WM_KILLFOCUS:
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcButtonWC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      int i;
      GetClientRect(hWnd,&rc);
      switch(GetWindowByte(hWnd,0)) {
        case BS_PUSHBUTTON:   // BUTTON FINIRE ECC
        case BS_DEFPUSHBUTTON:   // BUTTON FINIRE ECC
          FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
          // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_BUTTON,GetWindowByte(hWnd,1));
          if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
            SetTextColor(&hWnd->hDC,WHITE);
            SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
            }
          else {
            SetTextColor(&hWnd->hDC,BLACK);
            SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
            }
          switch(hWnd->style & 0x0ff0) {
            case BS_LEFTTEXT:
              //boh
            case BS_LEFT:
              TextOut(&hWnd->hDC,0,0,hWnd->caption);
              break;
            case BS_TEXT:
              //boh
            case BS_CENTER:
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,(rc.right-i)/2,0,hWnd->caption);
              break;
            case BS_RIGHT:
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,rc.right-i,0,hWnd->caption);
              break;
            case BS_TOP:
              TextOut(&hWnd->hDC,(rc.right-i)/2,0,hWnd->caption);
              break;
            case BS_BOTTOM:
              TextOut(&hWnd->hDC,(rc.right-i)/2,rc.bottom-hWnd->font.size*8,hWnd->caption);
              break;
            case BS_VCENTER:
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,(rc.right-i)/2,(rc.bottom-hWnd->font.size*8)/2,hWnd->caption);
              break;
            case BS_ICON:
              DrawIcon8(&hWnd->hDC,0,0,hWnd->icon);
              break;
            }
          break;
        case BS_CHECKBOX:   // BUTTON FINIRE ECC
        case BS_AUTOCHECKBOX:   // BUTTON FINIRE ECC
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
          i=rc.bottom-rc.top-2;
          DrawRectangleWindow(&hWnd->hDC,rc.left,rc.top,rc.left+i,rc.top+i,hWnd->active ? WHITE : GRAY192);
          // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_BUTTON,GetWindowByte(hWnd,1));
          switch(hWnd->style & 0x0ff0) {
            case BS_LEFTTEXT:
              //boh
            case BS_LEFT:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawLineWindow(&hWnd->hDC,rc.left,rc.top,rc.left+i,rc.top+i,hWnd->active ? WHITE : GRAY192);
                DrawLineWindow(&hWnd->hDC,rc.left+i,rc.top,rc.left,rc.top+i,hWnd->active ? WHITE : GRAY192);
                }
              TextOut(&hWnd->hDC,i+1,0,hWnd->caption);
              break;
            case BS_TEXT:
              //boh
            case BS_CENTER:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawLineWindow(&hWnd->hDC,rc.left,rc.top,rc.left+i,rc.top+i,hWnd->active ? WHITE : GRAY192);
                DrawLineWindow(&hWnd->hDC,rc.left+i,rc.top,rc.left,rc.top+i,hWnd->active ? WHITE : GRAY192);
                }
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,0,hWnd->caption);
              break;
            case BS_RIGHT:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawLineWindow(&hWnd->hDC,rc.left,rc.top,rc.left+i,rc.top+i,hWnd->active ? WHITE : GRAY192);
                DrawLineWindow(&hWnd->hDC,rc.left+i,rc.top,rc.left,rc.top+i,hWnd->active ? WHITE : GRAY192);
                }
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,rc.right-strlen(hWnd->caption)*6*hWnd->font.size,0,hWnd->caption);
              break;
            case BS_TOP:
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,0,hWnd->caption);
              break;
            case BS_BOTTOM:
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,rc.bottom-hWnd->font.size*8,hWnd->caption);
              break;
            case BS_VCENTER:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawLineWindow(&hWnd->hDC,rc.left,rc.top,rc.left+i,rc.top+i,hWnd->active ? WHITE : GRAY192);
                DrawLineWindow(&hWnd->hDC,rc.left+i,rc.top,rc.left,rc.top+i,hWnd->active ? WHITE : GRAY192);
                }
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,(rc.bottom-hWnd->font.size*8)/2,hWnd->caption);
              break;
            case BS_ICON:
              DrawIcon8(&hWnd->hDC,0,0,hWnd->icon);
              break;
            }
          break;
        case BS_RADIOBUTTON:   // BUTTON FINIRE ECC
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
          DrawCircleWindow(&hWnd->hDC,rc.left,rc.top,rc.left+i,rc.top+i,hWnd->active ? WHITE : GRAY192);
          // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_BUTTON,GetWindowByte(hWnd,1));
          switch(hWnd->style & 0x0ff0) {
            case BS_LEFTTEXT:
              //boh
            case BS_LEFT:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawCircleWindow(&hWnd->hDC,rc.left+1,rc.top+1,rc.left+i-1,rc.top+i-1,hWnd->active ? WHITE : GRAY192);
                // FILLED!
                }
              TextOut(&hWnd->hDC,0,0,hWnd->caption);
              break;
            case BS_TEXT:
              //boh
            case BS_CENTER:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawCircleWindow(&hWnd->hDC,rc.left+1,rc.top+1,rc.left+i-1,rc.top+i-1,hWnd->active ? WHITE : GRAY192);
                // FILLED!
                }
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,0,hWnd->caption);
              break;
            case BS_RIGHT:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawCircleWindow(&hWnd->hDC,rc.left+1,rc.top+1,rc.left+i-1,rc.top+i-1,hWnd->active ? WHITE : GRAY192);
                // FILLED!
                }
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,rc.right-strlen(hWnd->caption)*6*hWnd->font.size,0,hWnd->caption);
              break;
            case BS_TOP:
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,0,hWnd->caption);
              break;
            case BS_BOTTOM:
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,rc.bottom-hWnd->font.size*8,hWnd->caption);
              break;
            case BS_VCENTER:
              if(GetWindowByte(hWnd,1)) {   // il secondo byte � lo stato
                DrawCircleWindow(&hWnd->hDC,rc.left+1,rc.top+1,rc.left+i-1,rc.top+i-1,hWnd->active ? WHITE : GRAY192);
                // FILLED!
                }
              i=strlen(hWnd->caption)*6*hWnd->font.size;
              if(i>=rc.right)
                i=rc.right;
              TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.size)/2,(rc.bottom-hWnd->font.size*8)/2,hWnd->caption);
              break;
            case BS_ICON:
              DrawIcon8(&hWnd->hDC,0,0,hWnd->icon);
              break;
            }
          break;
        }
      }
      return 1;
      break;
    case WM_LBUTTONDOWN:
      if(hWnd->enabled)
        SendMessage(hWnd->parent,WM_COMMAND,MAKELONG((DWORD)hWnd->tag,BN_CLICKED),(LPARAM)hWnd);
      break;
    case WM_CHAR:
    { char buf[8];
      if(wParam)    // hot key??
        ;
      if(GetWindowByte(hWnd,2)) {   // il terzo byte � hotkey
        if(hWnd->enabled)
          SendMessage(hWnd->parent,WM_COMMAND,MAKELONG((DWORD)hWnd->tag,BN_CLICKED),(LPARAM)hWnd);
        }
    }
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      SetWindowByte(hWnd,0,cs->style & 0x0f);   // salvo il tipo, anche se in effetti sarebbe anche in style..
      }
      return 0;
      break;
    case WM_SETTEXT:
      clientPaint(hWnd,NULL);
      return 1;
      break;

    case BM_SETSTATE:
      switch(GetWindowByte(hWnd,0)) {
        case BS_PUSHBUTTON:   // BUTTON FINIRE ECC
        case BS_DEFPUSHBUTTON:   // BUTTON FINIRE ECC
          SetWindowByte(hWnd,1,wParam);
          SendMessage(hWnd,WM_PAINT,0,0);
          if(hWnd->enabled)
            SendMessage(hWnd->parent,WM_COMMAND,MAKELONG((DWORD)hWnd->tag,BN_CLICKED),(LPARAM)hWnd);
      // hmmm bah s�
          break;
        case BS_CHECKBOX:   // BUTTON FINIRE ECC
        case BS_AUTOCHECKBOX:   // BUTTON FINIRE ECC
          SendMessage(hWnd,WM_PAINT,0,0);
          break;
        case BS_RADIOBUTTON:   // BUTTON FINIRE ECC
          SendMessage(hWnd,WM_PAINT,0,0);
          break;
        }
      return 0;
      break;
    case BM_GETSTATE:
      switch(GetWindowByte(hWnd,0)) {
        case BS_PUSHBUTTON:   // BUTTON FINIRE ECC
        case BS_DEFPUSHBUTTON:   // BUTTON FINIRE ECC
          return GetWindowByte(hWnd,1) ? BST_PUSHED : 0;
          break;
        case BS_CHECKBOX:   // BUTTON FINIRE ECC
        case BS_AUTOCHECKBOX:   // BUTTON FINIRE ECC
          break;
          break;
        case BS_RADIOBUTTON:   // BUTTON FINIRE ECC
          break;
        }
      break;
    case BM_SETCHECK:   // questo � per radiobutton e checkbox...
      switch(GetWindowByte(hWnd,0)) {
        case BS_PUSHBUTTON:   // BUTTON FINIRE ECC
        case BS_DEFPUSHBUTTON:   // BUTTON FINIRE ECC
          SendMessage(hWnd,WM_PAINT,0,0);
          break;
        case BS_CHECKBOX:   // BUTTON FINIRE ECC
        case BS_AUTOCHECKBOX:   // BUTTON FINIRE ECC
          switch(wParam) {
            case BST_CHECKED:
              break;
            case BST_UNCHECKED:
              break;
            case BST_INDETERMINATE:
              break;
            }
          SendMessage(hWnd,WM_PAINT,0,0);
          break;
        case BS_RADIOBUTTON:   // BUTTON FINIRE ECC
          SendMessage(hWnd,WM_PAINT,0,0);
          break;
        }
      break;
    case BM_GETCHECK:   // questo � per radiobutton e checkbox...
      switch(GetWindowByte(hWnd,0)) {
        case BS_PUSHBUTTON:   // BUTTON FINIRE ECC
        case BS_DEFPUSHBUTTON:   // BUTTON FINIRE ECC
          break;
        case BS_CHECKBOX:   // BUTTON FINIRE ECC
        case BS_AUTOCHECKBOX:   // BUTTON FINIRE ECC
          break;
        case BS_RADIOBUTTON:   // BUTTON FINIRE ECC
          break;
        }
      break;

    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

BOOL DrawFrameControl(HDC *hDC,RECT *rc,UINT type,UINT state) {
  
  switch(type) {
    case DFC_BUTTON:
      switch(state) {
        case DFCS_PUSHED:
          SetTextColor(hDC,DFCS_PUSHED ? WHITE : GRAY192);
          break;
        }
      break;
    }
  // finire, usare
  FillRect(hDC,rc,hDC->brush);
  
  }

LRESULT DefWindowProcDirDlgWC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
#if 0
//      InvalidateRect(hWnd,(RECT *)wParam,lParam);
      //clientPaint(hWnd,(RECT *)wParam);
      {
      SearchRec rec;
      int i; UGRAPH_COORD_T x,y;
      BYTE tipoVis;
      RECT rc;
      
      GetClientRect(hWnd,&rc);
      if(!SDcardOK)
        return 0;
      if(!FindFirst("*.*", ATTR_VOLUME, &rec)) {
        sp("\tVolume is "); sp(rec.filename); speol();
        }
      if(*nome)
        i=FindFirst(nome, ATTR_MASK ^ ATTR_VOLUME, &rec);
      else
        i=FindFirst("*.*", ATTR_MASK ^ ATTR_VOLUME, &rec);
      if(!i) {
        x=0; y=0;
        do {
          switch(tipoVis) {
            case 0:     // icone
              TextOut(&hWnd->hDC,x+4,y+4+8+2,rec.filename); 
              if(rec.attributes & ATTR_DIRECTORY) {
                DrawIcon8(&hWnd->hDC,x+4,y+4,folderIcon);
                sp("DIR"); 
                }
              else {
                printInteger(rec.filesize,9,' '); spb(9);
                printInteger((rec.timestamp >> 16) & 31, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (5+16)) & 15, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (9+16)) + 1980, 4, '0');
                spb(' ');
                printInteger((rec.timestamp >> 11) & 31, 2, '0');
                spb(':');
                printInteger((rec.timestamp >> 5) & 63, 2, '0');
                spb(':');
                printInteger(rec.timestamp & 63, 2, '0');
                }
              x+=32;
              if(x>rc.right) {
                x=0;
                y+=8;
                if(y>rc.bottom)
                }
              break;
            case 1:
              TextOut(&hWnd->hDC,x+2,y+2,rec.filename); 
              if(rec.attributes & ATTR_DIRECTORY) {
                DrawIcon8(&hWnd->hDC,x+20+2,y+2,folderIcon);
                TextOut(&hWnd->hDC,x+2,y+2,"DIR");
                }
              else {
                printInteger(rec.filesize,9,' '); spb(9);
                TextOut(&hWnd->hDC,x+2,y+2,buf);
                printInteger((rec.timestamp >> 16) & 31, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (5+16)) & 15, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (9+16)) + 1980, 4, '0');
                spb(' ');
                printInteger((rec.timestamp >> 11) & 31, 2, '0');
                spb(':');
                printInteger((rec.timestamp >> 5) & 63, 2, '0');
                spb(':');
                printInteger(rec.timestamp & 63, 2, '0');
                TextOut(&hWnd->hDC,x+2,y+2,buf);
                y+=8;
                if(y>rc.bottom)
                  break;
                }
              break;
            }
          } while(!FindNext(&rec));
        do {
          FSGetDiskProperties(&disk_properties);
          ClrWdt();
          } while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
          if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS) {
            printInteger(disk_properties.results.free_clusters*disk_properties.results.sectors_per_cluster*disk_properties.results.sector_size/1024,12,' '); 
            TextOut(&hWnd->hDC,x+4,y+8+2,rec.filename); 
            }
          else
            TextOut(&hWnd->hDC,x+4,y+8+2,"?"); 
          TextOut(&hWnd->hDC,x+4,y+8+2," Kbytes free");
          }
        }
#endif
      return 1;
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
      
      
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
          TextOut(&hWnd->hDC,0,0,"DIR");
          
          DrawIcon8(&hWnd->hDC,0,16,folderIcon);
          
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 0;
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcDC(HWND hWnd,uint16_t message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      {
      HWND myWnd;
  
      myWnd=rootWindows;
      while(myWnd) {
        if(myWnd->visible) {
          DrawIcon8(&hWnd->hDC,4+(maxWindows-myWnd->zOrder)*10 /* :) */,_height-16,myWnd->icon);
          }
        myWnd=myWnd->next;
        }
      }
      return 1;
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      FillRect(&hWnd->hDC,&rc,hWnd->hDC.brush);
      
      
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,hWnd->hDC.brush.color);
          TextOut(&hWnd->hDC,0,0,"BREAKTHROUGH");
          
//          DrawBitmap(&hWnd->hDC,0,16,   logl);
          
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 0;
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

static void calculateClientArea(HWND hWnd,RECT *rc) {
  
  *rc=hWnd->nonClientArea;
  if(hWnd->style & WS_BORDER) {
    rc->top++;
    rc->bottom--;
    rc->left++;
    rc->right--;
    if(hWnd->style & WS_THICKFRAME) {
      rc->top++;
      rc->bottom--;
      rc->left++;
      rc->right--;
      }
    }
  if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
    rc->top+=TITLE_HEIGHT;
    }
  if(hWnd->style & WS_HSCROLL) {
    rc->bottom-= hWnd->style & WS_BORDER ? SCROLL_SIZE-1 : SCROLL_SIZE; // se c'� bordo, lo scroll usa il bordo, se no no!
    }
//  else
  rc->bottom--;    // strana patch... verificare!
  if(hWnd->style & WS_VSCROLL) {
    rc->right-= hWnd->style & WS_BORDER ? SCROLL_SIZE-1 : SCROLL_SIZE;
    }
//  else
  rc->right--;    // strana patch... verificare!
  }

static void calculateNonClientArea(HWND hWnd,RECT *rc) {

  if(hWnd->style & (WS_HSCROLL | WS_VSCROLL)) {
    hWnd->scrollSizeX= rc->right-rc->left - (hWnd->style & WS_VSCROLL ? SCROLL_SIZE : 0);
    // forse pure -border...
    hWnd->scrollSizeX /= 3;   // test..
    hWnd->scrollSizeY=rc->bottom-rc->top  - (hWnd->style & WS_HSCROLL ? SCROLL_SIZE : 0)
      - (hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION) ? TITLE_HEIGHT : 0);
    hWnd->scrollSizeY /= 3;   // test..
    }
  else {
    hWnd->scrollSizeX=hWnd->scrollSizeY=0;
    }
  }

BOOL GetWindowInfo(HWND hWnd,WINDOWINFO *pwi) {
  
  pwi->wCreatorVersion=MAKEWORD(BREAKTHROUGH_VERSION_L,BREAKTHROUGH_VERSION_H);
  pwi->atomWindowType=0;
  pwi->rcWindow=hWnd->nonClientArea;
  pwi->rcClient=hWnd->clientArea;
  pwi->dwStyle=hWnd->style;
//  pwi->dwExStyle=hWnd->styleEx;
  pwi->dwWindowStatus=hWnd->status;
  pwi->cxWindowBorders=BORDER_SIZE;
  pwi->cyWindowBorders=BORDER_SIZE;
  
  return TRUE;
  }

// ----------------------------------------------------------------------------
int RegisterClass(const WNDCLASS *lpWndClass) {
  WNDCLASS *myClass;
  
  if(GetClassInfo(0,lpWndClass->class,&myClass))    // controllo che non ci sia gi�...
    return 0;
  if(!rootClasses)
    rootClasses=(WNDCLASS *)lpWndClass;
  else {
    myClass=rootClasses;
    while(myClass && myClass->next) {
      myClass=myClass->next;
      }
    myClass->next=(WNDCLASS *)lpWndClass;
    }
  return 1;
  }

BOOL UnregisterClass(CLASS Class, HINSTANCE hInstance) {
  WNDCLASS *myClass,*myClass2,*theClass;
  
  if(GetClassInfo(0,Class,&theClass)) {    // DOVREBBE SALTARE quelle predefinite!
    myClass=rootClasses;
    while(myClass) {
      myClass2=myClass;
      if(myClass==theClass) {
        if(myClass==rootClasses)
          rootClasses=myClass->next;
        else
          myClass2->next=myClass->next;
        return 1;
        }
      myClass=myClass->next;
      }
    }
  return 0;
  }

HWND FindWindow(CLASS Class, char *lpWindowName) {
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
//    if(myWnd->visible && myWnd->enabled && PtInRect(&myWnd->nonClientArea,pt)) {
//      return myWnd;
//      }
    myWnd=myWnd->next;
    }
  }

int GetClassName(HWND hWnd,CLASS *Class) {
  
  *Class=hWnd->class;
  }

DWORD GetClassLong(HWND hWnd,int nIndex) {
  WNDCLASS *wc;
  GetClassInfo(0,hWnd->class,&wc);
  return *((DWORD *)(((unsigned char *)wc)+sizeof(WNDCLASS)+nIndex));
  }

WORD GetClassWORD(HWND hWnd,int nIndex) {
  WNDCLASS *wc;
  GetClassInfo(0,hWnd->class,&wc);
  return MAKEWORD(*(((unsigned char *)wc)+sizeof(WNDCLASS)+nIndex),*(((unsigned char *)wc)+sizeof(WNDCLASS)+nIndex+1));
  }

DWORD GetWindowLong(HWND hWnd,int nIndex) {
  
  return *((DWORD *)(((unsigned char *)hWnd)+sizeof(struct _WINDOW)+nIndex));
  }

void SetClassLong(HWND hWnd,int nIndex,DWORD value) {
  WNDCLASS *wc;
  GetClassInfo(0,hWnd->class,&wc);
  *((DWORD *)(((unsigned char *)wc)+sizeof(WNDCLASS)+nIndex))=value;
  }

void SetWindowLong(HWND hWnd,int nIndex,DWORD value) {
  
  *((DWORD *)(((unsigned char *)hWnd)+sizeof(struct _WINDOW)+nIndex))=value;
  }

BYTE GetClassByte(HWND hWnd,int nIndex) {
  WNDCLASS *wc;
  GetClassInfo(0,hWnd->class,&wc);
  return *((BYTE *)(((unsigned char *)wc)+sizeof(WNDCLASS)+nIndex));
  }

BYTE GetWindowByte(HWND hWnd,int nIndex) {
  
  return *((BYTE *)(((unsigned char *)hWnd)+sizeof(struct _WINDOW)+nIndex));
  }

void SetClassByte(HWND hWnd,int nIndex,BYTE value) {
  WNDCLASS *wc;
  GetClassInfo(0,hWnd->class,&wc);
  *((BYTE *)(((unsigned char *)wc)+sizeof(WNDCLASS)+nIndex))=value;
  }

void SetWindowByte(HWND hWnd,int nIndex,BYTE value) {
  
  *((BYTE *)(((unsigned char *)hWnd)+sizeof(struct _WINDOW)+nIndex))=value;
  }


static BOOL nonClientPaint(HWND hWnd,const RECT *rc) {
  WORD newtop,newbottom,newleft,newright;
  GFX_COLOR itemsColor;
//  HDC myHDC;
          
 
#ifndef USING_SIMULATOR
  if(!(hWnd->style & WS_VISIBLE))
    return 0;

  if(rc) {    // per ora non usato... ridisegnamo sempre tutta la window
    newtop=rc->top;
    newbottom=rc->bottom;
    newleft=rc->left;
    newright=rc->right;
    }
  else {
    newtop=hWnd->nonClientArea.top;
    newbottom=hWnd->nonClientArea.bottom;
    newleft=hWnd->nonClientArea.left;
    newright=hWnd->nonClientArea.right;
    }

  //simulo un HDC per l'intera finestra MA NON FUNZIONA perch� poi mi serve l'HWND da HDC... :(
  //faccio cos�:
  hWnd->hDC.paintArea.top=hWnd->hDC.paintArea.left=0;   // serve questo=0 come offset che si aggiunge...
  hWnd->hDC.paintArea.right=newright;    // ..e questo = VERO valore per boundary (porcata...)
  hWnd->hDC.paintArea.bottom=newbottom;
  
  if(hWnd->minimized) {
    // FINIRE! disegnare icona dove??
    DrawIcon8(&hWnd->hDC,4+(maxWindows-hWnd->zOrder)*10 /* :) */,_height-16,hWnd->icon);
    // v. anche desktopclass
//    hWnd->hDC.area=myHDC.area;
    return;
    }
  if(hWnd->maximized) {
    // FINIRE! o forse non serve altro, una volta cambiate le dimensioni..
    }
  itemsColor=hWnd->active ? windowForeColor : windowInactiveForeColor;
  // e hWnd->enabled ??
  switch(videoMode) {
    case MODE_LCD:
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        fillRectLCD(newleft,newtop,newright-newleft,newbottom-newtop,windowBackColor);
      // ev. provare writeFillRectPreclipped
        }
      else {
        UGRAPH_COORD_T y1=newtop,y2=newbottom;
        while(y1<y2) {
          DrawHorizLineWindow(&hWnd->hDC,newleft,y1,newright-1,windowBackColor);
          y1++;
          }
        }
      if(hWnd->style & WS_BORDER) {
        
        if(hWnd->active /* o zOrder*/) {   
          // forse inutile quando andremo in RAM
          drawRectLCD(newleft,newtop,newright-newleft,newbottom-newtop,itemsColor);
          }
        else {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newtop,newright-1,itemsColor);
          DrawHorizLineWindow(&hWnd->hDC,newleft,newbottom-1,newright-1,itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newleft,newtop,newbottom-1,itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-1,newtop,newbottom-1,itemsColor);
          }

        if(hWnd->style & WS_THICKFRAME) {
          if(hWnd->active /* o zOrder*/) { 
            // forse inutile quando andremo in RAM
            drawRectLCD(newleft+1,newtop+1,newright-1-newleft-1,newbottom-1-newtop-1,
              itemsColor);
            }
          else {
            DrawHorizLineWindow(&hWnd->hDC,newleft+1,newtop+1,newright-1-1,itemsColor);
            DrawHorizLineWindow(&hWnd->hDC,newleft+1,newbottom-1-1,newright-1-1,itemsColor);
            DrawVertLineWindow(&hWnd->hDC,newleft+1,newtop+1,newbottom-1-1,itemsColor);
            DrawVertLineWindow(&hWnd->hDC,newright-1-1,newtop+1,newbottom-1-1,itemsColor);
            }
          }
        }
      if(hWnd->style & WS_THICKFRAME) {
        newtop++;
        newbottom--;
        newleft++;
        newright--;
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        if(hWnd->active) {
          drawLineLCD(newleft+TITLE_ICON_WIDTH+2,newtop,newleft+TITLE_ICON_WIDTH+2,newtop+TITLE_HEIGHT,
            itemsColor);
          }
        else {
          DrawVertLineWindow(&hWnd->hDC,newleft+TITLE_ICON_WIDTH+2,newtop,newtop+TITLE_HEIGHT,itemsColor);
          }
        }
      if(hWnd->style & WS_SYSMENU) {
        if(hWnd->active) {
          fillRectLCD(newleft+2,newtop+2,TITLE_ICON_WIDTH-1,TITLE_ICON_WIDTH-1,itemsColor);
          newleft=newleft+TITLE_ICON_WIDTH+2;
        // metto anche closebox, fisso, a dx? insieme a sysmenu?
          drawLineLCD(newright-3,newtop+3,newright-TITLE_ICON_WIDTH+1,newtop+TITLE_ICON_WIDTH-1,
            itemsColor);
          drawLineLCD(newright-TITLE_ICON_WIDTH+1,newtop+3,newright-3,newtop+TITLE_ICON_WIDTH-1,
            itemsColor);
          drawLineLCD(newright-(TITLE_ICON_WIDTH+1),newtop,newright-(TITLE_ICON_WIDTH+1),newtop+TITLE_HEIGHT,
            itemsColor);
          }
        else {
          UGRAPH_COORD_T y1=newtop+2,y2=TITLE_ICON_WIDTH-1;
          while(y2--) {
            DrawHorizLineWindow(&hWnd->hDC,newleft+2,y1,newleft+2+TITLE_ICON_WIDTH-1-1,itemsColor);
            y1++;
            }
          newleft=newleft+TITLE_ICON_WIDTH+2;
          DrawLineWindow(&hWnd->hDC,newright-3,newtop+3,newright-TITLE_ICON_WIDTH+1,newtop+TITLE_ICON_WIDTH-1,
            itemsColor);
          DrawLineWindow(&hWnd->hDC,newright-TITLE_ICON_WIDTH+1,newtop+3,newright-3,newtop+TITLE_ICON_WIDTH-1,
            itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-(TITLE_ICON_WIDTH+1),newtop,newtop+TITLE_HEIGHT,
            itemsColor);
          }
        newright -= TITLE_ICON_WIDTH+1;
        }
      if(hWnd->style & WS_MAXIMIZEBOX) {
        if(hWnd->active) {
          drawLineLCD(newright-2,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,
            itemsColor);
          drawLineLCD(newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,newright-(TITLE_ICON_WIDTH-1)+1,newtop+TITLE_ICON_WIDTH/2+2,
            itemsColor);
          drawLineLCD(newright-TITLE_ICON_WIDTH,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_HEIGHT,
            itemsColor);
          }
        else {
          DrawLineWindow(&hWnd->hDC,newright-2,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,
            itemsColor);
          DrawLineWindow(&hWnd->hDC,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,newright-(TITLE_ICON_WIDTH-1)+1,newtop+TITLE_ICON_WIDTH/2+2,
            itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-TITLE_ICON_WIDTH,newtop,newtop+TITLE_HEIGHT,
            itemsColor);
          }
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->style & WS_MINIMIZEBOX) {
        if(hWnd->active) {
          drawLineLCD(newright-2,newtop+3,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,
            itemsColor);
          drawLineLCD(newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)+1,newtop+3,
            itemsColor);
          drawLineLCD(newright-TITLE_ICON_WIDTH,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_HEIGHT,
            itemsColor);
          }
        else {
          DrawLineWindow(&hWnd->hDC,newright-2,newtop+3,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,
            itemsColor);
          DrawLineWindow(&hWnd->hDC,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)+1,newtop+3,
            itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-TITLE_ICON_WIDTH,newtop,newtop+TITLE_HEIGHT,
            itemsColor);
          }
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->style & WS_CAPTION) {
        // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_CAPTION,GetWindowByte(hWnd,1));
        char *s=hWnd->caption;
        if(hWnd->active) {
          setColors(itemsColor, windowBackColor);
          cursor_x=newleft+2; cursor_y=newtop+1;
          while(*s) {   // nonclient area, non uso TextOut...
            cwrite(*s++);
            if(cursor_x>=(newright-6) || cursor_y>(newtop+1))   // 1 sola riga, trim a dx
              break;
            }
          }
        else {
          char *s=hWnd->caption;
          cursor_x=newleft+2; cursor_y=newtop+1;
          while(*s) {   // nonclient area, non uso TextOut...
            DrawCharWindow(&hWnd->hDC,cursor_x,cursor_y,*s++,itemsColor,windowBackColor,1);
            cursor_x += 6;
            if(cursor_x>=(newright-6))   // 1 sola riga, trim a dx
              break;
            }
          }
        }
      if(rc) {    // ripristino
        newleft=rc->left;
        newright=rc->right;
        }
      else {
        newleft=hWnd->nonClientArea.left;
        newright=hWnd->nonClientArea.right;
        if(hWnd->style & WS_THICKFRAME) {
          newleft++;
          newright--;
          }
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        if(hWnd->active) {
          drawLineLCD(newleft,newtop+TITLE_HEIGHT,newright-1,newtop+TITLE_HEIGHT,itemsColor);
          }
        else {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newtop+TITLE_HEIGHT,newright-1,itemsColor);
          }
        newtop=newtop+TITLE_HEIGHT;
        }
      if(hWnd->menu) {
        if(hWnd->active) {
          drawLineLCD(newleft,newtop+MENU_HEIGHT,newright-1,newtop+MENU_HEIGHT,itemsColor);
          }
        else {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newtop+MENU_HEIGHT,newright-1,itemsColor);
          }
//        TextOut(1,newtop,"menu");
        // fare...
        newtop=newtop+MENU_HEIGHT;
        }
      if(hWnd->style & WS_HSCROLL) {
        if(hWnd->active) {
          drawLineLCD(newleft,newbottom-SCROLL_SIZE,newright-1,newbottom-SCROLL_SIZE,itemsColor);
          fillRectLCD(newleft+2+hWnd->scrollPosX,newbottom-SCROLL_SIZE+2,hWnd->scrollPosX+hWnd->scrollSizeX,SCROLL_SIZE-4,
                  itemsColor);
          }
        else {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newbottom-SCROLL_SIZE,newright-1,itemsColor);
          UGRAPH_COORD_T y1=newbottom-SCROLL_SIZE+2,y2=SCROLL_SIZE-4;
          while(y2--) {
            DrawHorizLineWindow(&hWnd->hDC,newleft+2+hWnd->scrollPosX,y1,newleft+2+hWnd->scrollPosX+hWnd->scrollPosX+hWnd->scrollSizeX-1,itemsColor);
            y1++;
            }
          }
        }
      if(hWnd->style & WS_VSCROLL) {
        if(hWnd->active) {
          drawLineLCD(newright-SCROLL_SIZE,newtop,newright-SCROLL_SIZE,newbottom-1,itemsColor);
          fillRectLCD(newright-SCROLL_SIZE+2,newtop+2+hWnd->scrollPosY,SCROLL_SIZE-4,hWnd->scrollPosY+hWnd->scrollSizeY,
                itemsColor);
          }
        else {
          DrawVertLineWindow(&hWnd->hDC,newright-SCROLL_SIZE,newtop,newbottom-1,itemsColor);
          UGRAPH_COORD_T x1=newright-SCROLL_SIZE+2,x2=SCROLL_SIZE-4;
          while(x2--) {
            DrawVertLineWindow(&hWnd->hDC,x1,newtop+2+hWnd->scrollPosY,newtop+2+hWnd->scrollPosY+hWnd->scrollSizeY-1,itemsColor);
            x1++;
            }
          }
        }
      if(hWnd->style & WS_SIZEBOX) {
        if(hWnd->active) {
          drawLineLCD(newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom-1,itemsColor);
          }
        else {
          DrawLineWindow(&hWnd->hDC,newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom-1,
            itemsColor);
          }
        }

      break;
      
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      {
      UGRAPH_COORD_T y1=newtop,y2=newbottom;
      while(y1<y2) {
        DrawHorizLineWindow(&hWnd->hDC,newleft,y1,newright-1,windowBackColor);
        y1++;
        }
      }
      if(hWnd->style & WS_BORDER) {
        
          DrawHorizLineWindow(&hWnd->hDC,newleft,newtop,newright-1,itemsColor);
          DrawHorizLineWindow(&hWnd->hDC,newleft,newbottom-1,newright-1,itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newleft,newtop,newbottom-1,itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-1,newtop,newbottom-1,itemsColor);

        if(hWnd->style & WS_THICKFRAME) {
            DrawHorizLineWindow(&hWnd->hDC,newleft+1,newtop+1,newright-1-1,itemsColor);
            DrawHorizLineWindow(&hWnd->hDC,newleft+1,newbottom-1-1,newright-1-1,itemsColor);
            DrawVertLineWindow(&hWnd->hDC,newleft+1,newtop+1,newbottom-1-1,itemsColor);
            DrawVertLineWindow(&hWnd->hDC,newright-1-1,newtop+1,newbottom-1-1,itemsColor);
          }
        }
      if(hWnd->style & WS_THICKFRAME) {
        newtop++;
        newbottom--;
        newleft++;
        newright--;
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
          DrawVertLineWindow(&hWnd->hDC,newleft+TITLE_ICON_WIDTH+2,newtop,newtop+TITLE_HEIGHT,itemsColor);
        }
      if(hWnd->style & WS_SYSMENU) {
          UGRAPH_COORD_T y1=newtop+2,y2=TITLE_ICON_WIDTH-1;
          while(y2--) {
            DrawHorizLineWindow(&hWnd->hDC,newleft+2,y1,newleft+2+TITLE_ICON_WIDTH-1-1,itemsColor);
            y1++;
            }
          newleft=newleft+TITLE_ICON_WIDTH+2;
          DrawLineWindow(&hWnd->hDC,newright-3,newtop+3,newright-TITLE_ICON_WIDTH+1,newtop+TITLE_ICON_WIDTH-1,
            itemsColor);
          DrawLineWindow(&hWnd->hDC,newright-TITLE_ICON_WIDTH+1,newtop+3,newright-3,newtop+TITLE_ICON_WIDTH-1,
            itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-(TITLE_ICON_WIDTH+1),newtop,newtop+TITLE_HEIGHT,
            itemsColor);
        newright -= TITLE_ICON_WIDTH+1;
        }
      if(hWnd->style & WS_MAXIMIZEBOX) {
          DrawLineWindow(&hWnd->hDC,newright-2,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,
            itemsColor);
          DrawLineWindow(&hWnd->hDC,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,newright-(TITLE_ICON_WIDTH-1)+1,newtop+TITLE_ICON_WIDTH/2+2,
            itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-TITLE_ICON_WIDTH,newtop,newtop+TITLE_HEIGHT,
            itemsColor);
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->style & WS_MINIMIZEBOX) {
          DrawLineWindow(&hWnd->hDC,newright-2,newtop+3,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,
            itemsColor);
          DrawLineWindow(&hWnd->hDC,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)+1,newtop+3,
            itemsColor);
          DrawVertLineWindow(&hWnd->hDC,newright-TITLE_ICON_WIDTH,newtop,newtop+TITLE_HEIGHT,
            itemsColor);
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->style & WS_CAPTION) {
        // USARE DrawFrameControl(&hWnd->hDC,&rc,DFC_CAPTION,GetWindowByte(hWnd,1));
          char *s=hWnd->caption;
          cursor_x=newleft+2; cursor_y=newtop+1;
          while(*s) {   // nonclient area, non uso TextOut...
            DrawCharWindow(&hWnd->hDC,cursor_x,cursor_y,*s++,itemsColor,windowBackColor,1);
            cursor_x += 6;
            if(cursor_x>=(newright-6))   // 1 sola riga, trim a dx
              break;
            }
        }
      if(rc) {    // ripristino
        newleft=rc->left;
        newright=rc->right;
        }
      else {
        newleft=hWnd->nonClientArea.left;
        newright=hWnd->nonClientArea.right;
        if(hWnd->style & WS_THICKFRAME) {
          newleft++;
          newright--;
          }
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newtop+TITLE_HEIGHT,newright-1,itemsColor);
        newtop=newtop+TITLE_HEIGHT;
        }
      if(hWnd->menu) {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newtop+MENU_HEIGHT,newright-1,itemsColor);
//        TextOut(1,newtop,"menu");
        // fare...
        newtop=newtop+MENU_HEIGHT;
        }
      if(hWnd->style & WS_HSCROLL) {
          DrawHorizLineWindow(&hWnd->hDC,newleft,newbottom-SCROLL_SIZE,newright-1,itemsColor);
          UGRAPH_COORD_T y1=newbottom-SCROLL_SIZE+2,y2=SCROLL_SIZE-4;
          while(y2--) {
            DrawHorizLineWindow(&hWnd->hDC,newleft+2+hWnd->scrollPosX,y1,newleft+2+hWnd->scrollPosX+hWnd->scrollPosX+hWnd->scrollSizeX-1,itemsColor);
            y1++;
            }
        }
      if(hWnd->style & WS_VSCROLL) {
          DrawVertLineWindow(&hWnd->hDC,newright-SCROLL_SIZE,newtop,newbottom-1,itemsColor);
          UGRAPH_COORD_T x1=newright-SCROLL_SIZE+2,x2=SCROLL_SIZE-4;
          while(x2--) {
            DrawVertLineWindow(&hWnd->hDC,x1,newtop+2+hWnd->scrollPosY,newtop+2+hWnd->scrollPosY+hWnd->scrollSizeY-1,itemsColor);
            x1++;
            }
        }
      if(hWnd->style & WS_SIZEBOX) {
          DrawLineWindow(&hWnd->hDC,newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom-1,
            itemsColor);
        }

      break;
      
    }

#endif
  
  
  return 1;
  }

static BOOL clientPaint(HWND hWnd,const RECT *rc) {
  HWND myWnd;
  
  if(!(hWnd->style & WS_VISIBLE))
    return;
  if(!rc)
    rc=&hWnd->clientArea;
  
  // ora ridisegno tutte le child
  myWnd=rootWindows;
  while(myWnd) {
    
    WS_CLIPSIBLINGS; //gestire
    
    if(myWnd->parent == hWnd /* WS_CHILD*/) {
      SendMessage(myWnd,WM_NCPAINT,(WPARAM)NULL /*upd region*/,0);
  		InvalidateRect(myWnd,rc,TRUE);    // o usare ERASE/PAINT??
      }
    myWnd=myWnd->next;
    }

  return 1;
  }

BOOL InvalidateRect(HWND hWnd,const RECT *rc,BOOL bErase) {

  if(!hWnd) {   // https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
    PaintDesktop(NULL);
    SendMessage(HWND_BROADCAST,WM_NCPAINT,(WPARAM)NULL /*upd region*/,0);
    SendMessage(HWND_BROADCAST,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    SendMessage(HWND_BROADCAST,WM_PAINT,0,0);
    }
  else {
    if(bErase) {    // banalmente, per ora facciam cos�
      int c;
      if(!rc)
        rc=&hWnd->clientArea;
// forse?    hWnd->hDC.paintArea=*rc;
      if(hWnd->style & WS_CHILD) {
        if((c=SendMessage(hWnd->parent,WM_CTLCOLOR,(WPARAM)&hWnd->hDC,(LPARAM)hWnd)) != 0xffffffff) {
          FillRectangleWindow(&hWnd->hDC,rc->left,rc->top,rc->right-rc->left,rc->bottom-rc->top,
            c);
          }
        else
          goto paint_bk;
        }
      else {
paint_bk:
        if(!SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0)) {
#ifndef USING_SIMULATOR
          FillRectangleWindow(&hWnd->hDC,rc->left,rc->top,rc->right-rc->left,rc->bottom-rc->top,
            hWnd->hDC.brush.color);
#endif
;
          }
        }
      }
    // accumulare le aree paint...
    if(!rc)
      rc=&hWnd->clientArea;
    hWnd->hDC.paintArea=*rc;
    SendMessage(hWnd,WM_PAINT,0,0);
    }
  
  return 1;
  }

WORD SetTimer(HWND hWnd,WORD nIDEvent,WORD uElapse,TIMERPROC *lpTimerFunc) {
  int i;
  
  for(i=0; i<MAX_TIMERS; i++) {
    if(!timerData[i].uEvent) {
      timerData[i].hWnd=hWnd;
      timerData[i].uEvent=nIDEvent;
      timerData[i].time_cnt=timerData[i].timeout=uElapse;
      timerData[i].tproc=lpTimerFunc;
      return i+1;
      }
    }
  return 0;
  }

BOOL KillTimer(HWND hWnd,WORD uIDEvent) {
  int i;
  
  for(i=0; i<MAX_TIMERS; i++) {
    if(timerData[i].uEvent == uIDEvent) {
      timerData[i].uEvent=0;
      timerData[i].hWnd=0;
      timerData[i].timeout=0;
      timerData[i].tproc=NULL;
      timerData[i].time_cnt=0;
      return TRUE;
      }
    }
  return FALSE;
  }

BOOL EnableWindow(HWND hWnd,BOOL bEnable) {
  
  SendMessage(hWnd,WM_ENABLE,bEnable,0);
  }

BOOL IsWindowVisible(HWND hWnd) {
  
  return hWnd->visible;
  }

BOOL DestroyWindow(HWND hWnd) {

  SendMessage(hWnd,WM_DESTROY,0,0);
  SendMessage(hWnd,WM_NCDESTROY,0,0);
  removeWindow(hWnd);
  list_bubble_sort(&rootWindows);
  free(hWnd);
  }

BOOL CloseWindow(HWND hWnd) {
  
  hWnd->minimized=1;
  SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  SendMessage(hWnd,WM_PAINT,0,0);
  }

BOOL RedrawWindow(HWND hWnd,const RECT *lprcUpdate,int /*HRGN*/ hrgnUpdate,UINT flags) {
  
  if(flags & RDW_ERASE) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    }
  if(flags & RDW_INVALIDATE) {
    SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    SendMessage(hWnd,WM_PAINT,0,0);
    }
  }

BOOL UpdateWindow(HWND hWnd) {
  
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  return SendMessage(hWnd,WM_PAINT,0,0);
  }
  
BOOL SetWindowPos(HWND hWnd,HWND hWndInsertAfter,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,
  UGRAPH_COORD_T cx,UGRAPH_COORD_T cy, DWORD uFlags) {
  RECT oldNCarea,oldArea;
  int temp;
  
  if(uFlags) {    // bah, controllare
    WINDOWPOS wpos;
    wpos.hwnd=hWnd;
    wpos.hwndInsertAfter=hWndInsertAfter;
    wpos.x=X;
    wpos.y=Y;
    wpos.cx=cx;
    wpos.cy=cy;
    wpos.flags=uFlags;
    SendMessage(hWnd,WM_WINDOWPOSCHANGING,0,(LPARAM)&wpos);
    }
  if(!(uFlags & SWP_NOACTIVATE)) {
    if(hWnd->enabled && !(hWnd->style & WS_CHILD))
  		setActive(hWnd,TRUE);
		}
  if(uFlags & SWP_HIDEWINDOW)
    hWnd->visible=0;
  if(uFlags & SWP_SHOWWINDOW)   // bah :) cmq vince questo
    hWnd->visible=1;
  if(!(uFlags & SWP_NOREPOSITION)) {
    oldNCarea=hWnd->nonClientArea;
    oldArea=hWnd->clientArea;
    if(!(uFlags & SWP_NOMOVE)) {
      hWnd->nonClientArea.left=X;
      hWnd->nonClientArea.top=Y;
      hWnd->clientArea.left+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->clientArea.top+=hWnd->nonClientArea.top-oldNCarea.top;
      SendMessage(hWnd,WM_MOVE,0,MAKEWORD(hWnd->clientArea.left,hWnd->clientArea.top));
      }
    if(!(uFlags & SWP_NOSIZE)) {
      hWnd->nonClientArea.right=hWnd->nonClientArea.left+cx;
      hWnd->nonClientArea.bottom=hWnd->nonClientArea.top+cy;
      hWnd->clientArea.right+=hWnd->nonClientArea.right-oldNCarea.right;
      hWnd->clientArea.bottom+=hWnd->nonClientArea.bottom-oldNCarea.bottom;
      SendMessage(hWnd,WM_SIZE,SIZE_RESTORED,MAKEWORD(hWnd->clientArea.right-hWnd->clientArea.left,hWnd->clientArea.bottom-hWnd->clientArea.top));
      }
    else {
      hWnd->nonClientArea.right+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->nonClientArea.bottom+=hWnd->nonClientArea.top-oldNCarea.top;
      hWnd->clientArea.right+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->clientArea.bottom+=hWnd->nonClientArea.top-oldNCarea.top;
      }
    }
  if(!(uFlags & SWP_NOZORDER /* SWP_NOOWNERZORDER che �? */)) {
    switch((int)hWndInsertAfter) {
      case (int)HWND_BOTTOM:
        hWnd->topmost=0;
        temp=rootWindows->zOrder;
        rootWindows->zOrder=hWnd->zOrder;
        hWnd->zOrder=temp;
        break;
      case (int)HWND_NOTOPMOST:
        hWnd->topmost=0;
        break;
      case (int)HWND_TOP:
        hWnd->topmost=0;
hwnd_top:
        {
        HWND myWnd=rootWindows;
        while(myWnd)
          myWnd=myWnd->next;
        temp=myWnd->zOrder;
        myWnd->zOrder=hWnd->zOrder;
        }
        hWnd->zOrder=temp;
        break;
      case (int)HWND_TOPMOST:
        hWnd->topmost=1;
        goto hwnd_top;
        break;
      default:
        insertWindow(hWnd,hWndInsertAfter);
        break;
      }
    list_bubble_sort(&rootWindows);
    }
  {
  WINDOWPOS wpos;
  wpos.hwnd=hWnd;
  wpos.hwndInsertAfter=NULL /*boh*/;
  wpos.x=hWnd->nonClientArea.left;
  wpos.y=hWnd->nonClientArea.top;
  wpos.cx=hWnd->nonClientArea.right-hWnd->nonClientArea.left;
  wpos.cy=hWnd->nonClientArea.bottom-hWnd->nonClientArea.top;
  wpos.flags=hWnd->style;
  SendMessage(hWnd,WM_WINDOWPOSCHANGED,0,(LPARAM)&wpos);    // boh sempre
  }
  
  if(!(uFlags & SWP_NOREDRAW)) {
    SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    SendMessage(hWnd,WM_PAINT,0,0);
    }
  return 1;
  }

BOOL GetWindowPlacement(HWND hWnd,WINDOWPLACEMENT *lpwndpl) {
  
  if(hWnd->maximized)
    lpwndpl->rcNormalPosition=hWnd->savedArea;
  else
    lpwndpl->rcNormalPosition=hWnd->nonClientArea;
  lpwndpl->ptMaxPosition=MAKEPOINT(0,0);
  lpwndpl->ptMinPosition=MAKEPOINT(4+(maxWindows-hWnd->zOrder)*10 ,_height-16);    // v. desktopclass
  if(hWnd->maximized)
    lpwndpl->showCmd=SW_SHOWMAXIMIZED;
  else if(hWnd->minimized)
    lpwndpl->showCmd=SW_SHOWMINIMIZED;
  else
    lpwndpl->showCmd=SW_SHOWNORMAL;
  lpwndpl->flags=0;   // bah finire
  }

BOOL MoveWindow(HWND hWnd,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,UGRAPH_COORD_T nWidth,UGRAPH_COORD_T nHeight,BOOL bRepaint) {
  
  return SetWindowPos(hWnd,NULL,X,Y,nWidth,nHeight,
    SWP_NOSENDCHANGING | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_NOACTIVATE
    | (bRepaint ? 0 : SWP_NOREDRAW)
    );
  }

BOOL OpenIcon(HWND hWnd) {
  
  return ShowWindow(hWnd,SW_SHOWNORMAL);
  }

BOOL ShowWindow(HWND hWnd,BYTE nCmdShow) {
  
  switch(nCmdShow) {
    case SW_HIDE:
      hWnd->visible=0;
			setActive(hWnd,FALSE);
      break;
    case SW_SHOWNORMAL:
//    case SW_NORMAL:
      if(hWnd->maximized) {
        hWnd->nonClientArea=hWnd->savedArea;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
				SendMessage(HWND_BROADCAST,WM_SHOWWINDOW,TRUE,SW_OTHERUNZOOM);		// mandare a TUTTI!
        InvalidateRect(NULL,NULL,TRUE);
        }
      hWnd->maximized=0;
      hWnd->minimized=0;
      // prosegue
    case SW_SHOW:
      hWnd->visible=1;
      if(hWnd->enabled && !(hWnd->style & WS_CHILD))
        setActive(hWnd,TRUE);
      break;
    case SW_SHOWMINIMIZED:
      hWnd->visible=1;
      if(hWnd->enabled && !(hWnd->style & WS_CHILD))
  			setActive(hWnd,TRUE);
    case SW_MINIMIZE:
      hWnd->minimized=1;
      if(hWnd->maximized) {
        hWnd->nonClientArea=hWnd->savedArea;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
        nonClientPaint(NULL,NULL);
        }
      hWnd->maximized=0;
      break;
    case SW_SHOWMAXIMIZED:
//    case SW_MAXIMIZE:
      if(!hWnd->maximized) {
        hWnd->savedArea=hWnd->nonClientArea;
        hWnd->nonClientArea.top=0;
        hWnd->nonClientArea.left=0;
        hWnd->nonClientArea.bottom=_height;
        hWnd->nonClientArea.right=_width;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
				SendMessage(HWND_BROADCAST,WM_SHOWWINDOW,FALSE,SW_OTHERZOOM);		// mandare a TUTTI!
        }
      hWnd->maximized=1;
      hWnd->minimized=0;
      hWnd->visible=1;
      if(hWnd->enabled && !(hWnd->style & WS_CHILD))
  			setActive(hWnd,TRUE);
      break;
    case SW_SHOWNOACTIVATE:
    case SW_SHOWNA:
      hWnd->visible=1;
      hWnd->maximized=hWnd->minimized=0;
      break;
    case SW_SHOWMINNOACTIVE:
      hWnd->visible=1;
      if(hWnd->enabled)
  			setActive(hWnd,FALSE);
      hWnd->minimized=1;
      hWnd->maximized=0;
      break;
    case SW_RESTORE:
      if(hWnd->maximized) {
        hWnd->nonClientArea=hWnd->savedArea;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
        nonClientPaint(NULL,NULL);
        }
      hWnd->maximized=hWnd->minimized=0;
      break;
    default:
      break;
    }
  SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  return SendMessage(hWnd,WM_PAINT,0,0);
  }

BOOL BringWindowToTop(HWND hWnd) {
  HWND myWnd;
  BYTE temp;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd->zOrder==maxWindows) {   // ovvero andare al fondo della lista
      temp=hWnd->zOrder;
      hWnd->zOrder=myWnd->zOrder;
      myWnd->zOrder=temp;
      list_bubble_sort(&rootWindows);
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;   //NON deve accadere
  }

HWND GetTopWindow(HWND hWnd) {
  HWND myWnd,myWnd2;
//  BYTE minZorder=255;
  
  if(hWnd) {    // child windows...
    }
  else {
    myWnd=rootWindows;
    while(myWnd) {
      myWnd2=myWnd;
      myWnd=myWnd->next;
      }
    return myWnd2;
    }
  }

BOOL SetForegroundWindow(HWND hWnd) {
  HWND myWnd;
  BYTE temp;

  // basterebbe setActive? o no??
  myWnd=rootWindows;
  while(myWnd && myWnd->next) {   // vado al fondo
    myWnd=myWnd->next;
    }
  temp=myWnd->zOrder;
  myWnd->zOrder=hWnd->zOrder;
  hWnd->zOrder=temp;
  list_bubble_sort(&rootWindows);
  }

HWND SetActiveWindow(HWND hWnd) {
  HWND oWnd=NULL;

// idem come sopra...  
  if(!(hWnd->style & WS_CHILD)) {
    oWnd=setActive(hWnd,TRUE);
    activateChildren(hWnd);
    }
  return oWnd;
  }

HWND GetForegroundWindow(void) {
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd && myWnd->next) {   // vado al fondo
    myWnd=myWnd->next;
    }
  return myWnd;
  }

HWND SetParent(HWND hWndChild,HWND hWndNewParent) {
  HWND hWnd=hWndChild->parent;
  
  if(hWndChild->style & WS_CHILD && hWndNewParent!=hWndChild /* frocio :D */)
    hWndChild->parent=hWndNewParent;
  return hWnd;
  }

HWND GetParent(HWND hWnd) {
  
  return hWnd->parent;
  }

BOOL GetClientRect(HWND hWnd,RECT *lpRect) {
  
  lpRect->left=lpRect->top=0;
  lpRect->right=hWnd->clientArea.right-hWnd->clientArea.left;
  lpRect->bottom=hWnd->clientArea.bottom-hWnd->clientArea.top;
  }

BOOL GetWindowRect(HWND hWnd,RECT *lpRect) {
  
  *lpRect=hWnd->nonClientArea;
  }

BOOL SetIcon(HWND hWnd,const GFX_COLOR *icon,BYTE type) {

  return SendMessage(hWnd,WM_SETICON,type,(LPARAM)icon);
  }

BOOL SetFont(HWND hWnd,FONT font) { // questa in effetti non esiste, si userebbero i SelectObject...

  SendMessage(hWnd,WM_SETFONT,(WPARAM)font.font,TRUE);
  }

BOOL IsWindow(HWND hWnd) {
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd == hWnd)
      return TRUE;
    myWnd=myWnd->next;
    }
  return FALSE;
  }

BOOL IsZoomed(HWND hWnd) { 
  return hWnd->maximized;
  }

HWND setActive(HWND hWnd,BOOL state) {
  HWND myWnd;
  BYTE temp;
  
  if(state) {
    myWnd=rootWindows;
    while(myWnd) {
      if(myWnd != hWnd && !myWnd->parent && myWnd->active) {  // tendenzialmente dovrebbe essere sempre l'ultima, quella attiva...
        SendMessage(myWnd,WM_ACTIVATE,WA_INACTIVE,(LPARAM)hWnd);
        myWnd->active=0;
        SendMessage(myWnd,WM_NCPAINT,(WPARAM)NULL,0);
        SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
        SendMessage(myWnd,WM_PAINT,0,0);
        if(hWnd->zOrder < myWnd->zOrder) {
          temp=hWnd->zOrder;
          hWnd->zOrder=myWnd->zOrder;
          myWnd->zOrder=temp;
          list_bubble_sort(&rootWindows);
          }
        break;
        }
      myWnd=myWnd->next;
      }
    hWnd->active=1;
//    SendMessage(hWnd,WM_ACTIVATE,WA_ACTIVE,(LPARAM)myWnd);
    
    activateChildren(hWnd);
    
//    SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
//  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
//    SendMessage(hWnd,WM_PAINT,0,0);
    // c'� gi� nel/nei chiamante, forse togliere..
    return hWnd;
    }
  else {
    if(hWnd->active) {
      // in teoria quella attiva in precedenza � l'ultima ossia quella in cima a Z-order...PENULTIMA!
      myWnd=rootWindows;
      while(myWnd) {
        if(myWnd != hWnd && !myWnd->parent && !myWnd->active) {
 				  myWnd->active=1;
          SendMessage(myWnd,WM_ACTIVATE,WA_ACTIVE,(LPARAM)hWnd);
          myWnd->active=1;
          SendMessage(myWnd,WM_NCPAINT,(WPARAM)NULL,0);
          SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
          SendMessage(myWnd,WM_PAINT,0,0);
          temp=hWnd->zOrder;
          hWnd->zOrder=myWnd->zOrder;
          myWnd->zOrder=temp;
          list_bubble_sort(&rootWindows);
          break;
          }
        myWnd=myWnd->next;
        }
  	  hWnd->active=0;
//      SendMessage(hWnd,WM_ACTIVATE,WA_INACTIVE,(LPARAM)hWnd);
      
//      SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
//  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
//      SendMessage(hWnd,WM_PAINT,0,0);
      // c'� gi� nel/nei chiamante, forse togliere..
      return hWnd;
      }
    }
  
  return NULL;    //NON deve accadere!
	}

    
void activateChildren(HWND hWnd) {
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd->parent == hWnd /* WS_CHILD*/) {
      SendMessage(myWnd,WM_CHILDACTIVATE,0,0);
      }
    myWnd=myWnd->next;
    }
  }

int SetScrollPos(HWND hWnd,int nBar,int nPos,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      hWnd->scrollPosX=nPos;
      break;
    case SB_VERT:
      hWnd->scrollPosY=nPos;
      break;
    }
  if(bRedraw) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    return SendMessage(hWnd,WM_PAINT,0,0);
    }
  else
    return 1;
  }

int SetScrollInfo(HWND hWnd,int nBar,SCROLLINFO *lpsi,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      if(lpsi->fMask & SIF_POS)
        hWnd->scrollPosX=lpsi->nPos;
      if(lpsi->fMask & SIF_PAGE)
        ;
      if(lpsi->fMask & SIF_RANGE)
        ;
      break;
    case SB_VERT:
      if(lpsi->fMask & SIF_POS)
        hWnd->scrollPosY=lpsi->nPos;
      if(lpsi->fMask & SIF_PAGE)
        ;
      if(lpsi->fMask & SIF_RANGE)
        ;
      break;
    }
  if(bRedraw) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    return SendMessage(hWnd,WM_PAINT,0,0);
    }
  else
    return 1;
  }

BOOL SetScrollRange(HWND hWnd,int nBar,int nMinPos,int nMaxPos,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      hWnd->scrollPosX=(nMaxPos-nMinPos);   // boh finire..
      break;
    case SB_VERT:
      hWnd->scrollPosY=(nMaxPos-nMinPos);
      break;
    }
  if(bRedraw) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    return SendMessage(hWnd,WM_PAINT,0,0);
    }
  else
    return 1;
  }

BOOL SetWindowText(HWND hWnd,const char *title) {

  SendMessage(hWnd,WM_SETTEXT,0,TRUE);
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  return SendMessage(hWnd,WM_PAINT,0,0);
  }

int GetWindowText(HWND hWnd,char *lpString,int nMaxCount) {
  
  return SendMessage(hWnd,WM_GETTEXT,nMaxCount,(LPARAM)lpString);
  }

BOOL GetTitleBarInfo(HWND hWnd,TITLEBARINFO *pti) {
  
  // if(pti->cbSize=
  pti->rcTitleBar.top=hWnd->nonClientArea.top;
  pti->rcTitleBar.left=hWnd->nonClientArea.left;
  pti->rcTitleBar.right=hWnd->nonClientArea.right;
  if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION))
    pti->rcTitleBar.bottom=pti->rcTitleBar.top+=TITLE_HEIGHT;
  else
    pti->rcTitleBar.bottom=pti->rcTitleBar.top;

  pti->rgstate[0]=hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION) ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[2]=hWnd->style & WS_MINIMIZEBOX ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[3]=hWnd->style & WS_MAXIMIZEBOX  ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[4]=hWnd->style & 0 /*WS_HELP*/ ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[5]=hWnd->style & WS_SYSMENU ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  }


int PaintDesktop(HDC *hDC) {
  // PUO CONFLUIRE IN INVALIDATE, SE SI CREA LA WINDOW-DESKTOP
  
  switch(videoMode) {
    case MODE_LCD:
      fillRectLCD(0,0,_width,_height,desktopColor);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      drawRectangleFilled(0,0,_width,_height,desktopColor);
      break;
    }
  return 1;
  }

BOOL MessageBeep(BYTE uType) {
	beep();
	}	
int MessageBox(HWND hWnd,const char *lpText,const char *lpCaption,BYTE uType) {
	}

int DrawIcon8(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=icon;
  
  w=8; h=8;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawIcon(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=icon;
  
  w=16; h=16;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawBitmap(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR bitmap[],UGRAPH_COORD_T xs, UGRAPH_COORD_T ys) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=bitmap;
  
  w=xs; h=ys;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawCaret(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR caret[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=caret;
  
  w=4; h=8;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i, y1+j, *p2++);
      }
    }
  }

BOOL TextOut(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const char *s) {
  char c;
  
#ifdef USING_SIMULATOR
  return;
#endif  
  
  setCursor(x1,y1);
  
  while(c=*s++) {
    
    if(!gfxFont) { // 'Classic' built-in font

      switch(c) {
        case '\n':
          cursor_y += (hDC->font.size)*8;
          cursor_x  = 0;
          break;
        case '\r':
          // skip em
          break; 
        default:
          if(wrap && ((cursor_x + (hDC->font.size) * 6) >= hDC->area.right)) { 	// Heading off edge?
            // TENDENZIALMENTE QUA NON CI INTERESSA! textout fa una sola riga
  //          cursor_x  = hDC->area.left;            // Reset x 
  //          cursor_y += (hDC->fontSimple) * 8; // Advance y one line
            }
          DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, hDC->font.size);
          cursor_x += (hDC->font.size) * 6;
          break; 
        }

      } 
    else { // Custom font

      if(c == '\n') {
        cursor_x  = 0;
        cursor_y += (GRAPH_COORD_T)textsize *
                    (UINT8)pgm_read_byte(&gfxFont->yAdvance);
        } 
      else if(c != '\r') {
        UINT8 first = pgm_read_byte(&gfxFont->first);
        if((c >= first) && (c <= (UINT8)pgm_read_byte(&gfxFont->last))) {
          UINT8   c2    = c - pgm_read_byte(&gfxFont->first);
          GFXglyph *glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c2]);
          UINT8   w     = pgm_read_byte(&glyph->width),
                    h     = pgm_read_byte(&glyph->height);
          if((w > 0) && (h > 0)) { // Is there an associated bitmap?
            GRAPH_COORD_T xo = (INT8)pgm_read_byte(&glyph->xOffset); // sic
            if(wrap && ((cursor_x + textsize * (xo + w)) >= _width)) {
              // Drawing character would go off right edge; wrap to new line
              cursor_x  = 0;
              cursor_y += (GRAPH_COORD_T)textsize *
                          (UINT8)pgm_read_byte(&gfxFont->yAdvance);
              }
            DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, hDC->font.size);
            }
          cursor_x += pgm_read_byte(&glyph->xAdvance) * (GRAPH_COORD_T)textsize;
          }
        }

      }

    }
  return 1;
  }

BOOL ExtTextOut(HDC *hDC,int x1,int y1,UINT options,const RECT *lpRect,const char *s,UINT n,const INT *lpDx) {
  char c;
  UINT cnt;
  
  setCursor(x1,y1);
  
  while(cnt<n) {
    c=*s++;
    
  if(!gfxFont) { // 'Classic' built-in font

    switch(c) {
      case '\n':
        cursor_y += (hDC->font.size)*8;
        cursor_x  = 0;
        break;
      case '\r':
        // skip em
        break; 
      default:
        if(wrap && ((cursor_x + (hDC->font.size) * 6) >= hDC->area.right)) { 	// Heading off edge?
          // TENDENZIALMENTE QUA NON CI INTERESSA! textout fa una sola riga
//          cursor_x  = hDC->area.left;            // Reset x 
//          cursor_y += (hDC->fontSimple) * 8; // Advance y one line
          }
        if(lpRect)
          ;
        DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, (hDC->font.size));
        cursor_x += (hDC->font.size) * 6;
        if(lpDx)
          cursor_x+=lpDx[cnt];
        break; 
    	}

  	} 
	else { // Custom font

    if(c == '\n') {
      cursor_x  = 0;
      cursor_y += (GRAPH_COORD_T)textsize *
                  (UINT8)pgm_read_byte(&gfxFont->yAdvance);
  	  } 
		else if(c != '\r') {
      UINT8 first = pgm_read_byte(&gfxFont->first);
      if((c >= first) && (c <= (UINT8)pgm_read_byte(&gfxFont->last))) {
        UINT8   c2    = c - pgm_read_byte(&gfxFont->first);
        GFXglyph *glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c2]);
        UINT8   w     = pgm_read_byte(&glyph->width),
                  h     = pgm_read_byte(&glyph->height);
        if((w > 0) && (h > 0)) { // Is there an associated bitmap?
          GRAPH_COORD_T xo = (INT8)pgm_read_byte(&glyph->xOffset); // sic
          if(wrap && ((cursor_x + textsize * (xo + w)) >= _width)) {
            // Drawing character would go off right edge; wrap to new line
            cursor_x  = 0;
            cursor_y += (GRAPH_COORD_T)textsize *
                        (UINT8)pgm_read_byte(&gfxFont->yAdvance);
          	}
          DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, hDC->font.size);
        	}
        cursor_x += pgm_read_byte(&glyph->xAdvance) * (GRAPH_COORD_T)textsize;
      	}
    	}

  	}

    cnt++;
    }
  return 1;
  }

int DrawText(HDC *hDC,const char *lpchText,int cchText,RECT *lprc,UINT format) {

  return ExtTextOut(hDC,lprc->left,lprc->top,format /*CONTROLLARE!*/,NULL,lpchText,cchText,NULL);
  }

void SetWindowTextCursor(HDC *hDC,BYTE col,BYTE row) {
  
  setTextCursor(col*hDC->font.size*6,row*hDC->font.size*8);
  }

BOOL MoveToEx(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,POINT *lppt) {
  
  if(lppt) {
    lppt->x=hDC->cursorX;
    lppt->y=hDC->cursorY;
    }
  hDC->cursorX=x;
  hDC->cursorY=y;
  }

BOOL LineTo(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  DrawLineWindow(hDC,hDC->cursorX, hDC->cursorY, x, y, hDC->pen.color);
  hDC->cursorX=x;
  hDC->cursorY=y;
  return 1;
  }

GFX_COLOR SetPixel(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,GFX_COLOR color) {

  DrawPixelWindow(hDC,x,y,color);
  if(videoMode==MODE_LCD)
    return color;   // forse vuole il colore precedente, finire quando ci spostiamo in RAM
  else {
  	DWORD i;
    y+=hDC->area.top;
    x+=hDC->area.left;
    if(y>=_height || x>=_width)
      return (GFX_COLOR)CLR_INVALID;
    else {
      i=(DWORD)_width*y+x;
      return (GFX_COLOR)MAKEWORD(videoRAM[i+1],videoRAM[i]);
      }
    }
  }
  
GFX_COLOR GetPixel(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  if(videoMode==MODE_LCD)
    return (GFX_COLOR)CLR_INVALID;   // FINIRE in ram ecc
  else {
  	DWORD i;
    y+=hDC->area.top;
    x+=hDC->area.left;
    if(y>=_height || x>=_width)
      return (GFX_COLOR)CLR_INVALID;
    else {
      i=(DWORD)_width*y+x;
      return (GFX_COLOR)MAKEWORD(videoRAM[i+1],videoRAM[i]);
      }
    }
  }
  
BOOL Rectangle(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  
  DrawRectangleWindow(hDC, left, top, right, bottom, hDC->pen.color);
  return 1;
  }

BOOL FillRect(HDC *hDC,const RECT *rc,BRUSH hbr) {
  
  FillRectangleWindow(hDC, rc->left, rc->top, rc->right, rc->bottom, hbr.color);
  return 1;
  }

BOOL Ellipse(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  
  DrawCircleWindow(hDC, left, top, right, bottom, hDC->pen.color);
  return 1;
  }

BOOL Arc(HDC *hDC,UGRAPH_COORD_T x1,UGRAPH_COORD_T y1,UGRAPH_COORD_T x2,UGRAPH_COORD_T y2,
  UGRAPH_COORD_T x3,UGRAPH_COORD_T y3,UGRAPH_COORD_T x4,UGRAPH_COORD_T y4) {
  
//  DrawCircleWindow(hDC, left, top, right, bottom, hDC->pen.color);
  }

BOOL FillPath(HDC *hDC) {
  }

BOOL FloodFill(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,GFX_COLOR color) {
  }

PEN CreatePen(BYTE iStyle,BYTE cWidth,GFX_COLOR color) {
  PEN myPen;
  
  myPen.style=iStyle;
  myPen.size=cWidth;
  myPen.color=color;
  return myPen;
	}

GFX_COLOR SetDCPenColor(HDC *hDC,GFX_COLOR color) {
  GFX_COLOR c=hDC->pen.color;
  
  hDC->pen.color=color;
  // pure style?
  return c;
  }
  
BRUSH CreateSolidBrush(GFX_COLOR color) {
  BRUSH myBrush;
  
  myBrush.style=BS_SOLID;
  myBrush.size=1;
  myBrush.color=color;
  return myBrush;
	}

BRUSH CreateHatchBrush(BYTE iHatch,GFX_COLOR color) {
  BRUSH myBrush;
  
  myBrush.style=iHatch;
  myBrush.size=1;
  myBrush.color=color;
  return myBrush;
	}

BRUSH CreatePatternBrush(BITMAP *hbm) {
  BRUSH myBrush;
  
  myBrush.style=BS_NULL;
  myBrush.size=1;
  myBrush.color=0;
  return myBrush;
	}

BRUSH GetSysColorBrush(int nIndex) {
  
  return CreateSolidBrush(GetSysColor(nIndex));
  }

GFX_COLOR SetDCBrushColor(HDC *hDC,GFX_COLOR color) {
  GFX_COLOR c=hDC->brush.color;
  
  hDC->brush.color=color;
  // pure style?
  return c;
  }

GDIOBJ GetStockObject(int i) {
  GDIOBJ g;
  
  switch(i) {
    case WHITE_BRUSH:
      g.myBrush=CreateSolidBrush(WHITE);
      return g;
      break;
    case LTGRAY_BRUSH:
      g.myBrush=CreateSolidBrush(LIGHTGRAY);
      return g;
      break;
    case GRAY_BRUSH:
      g.myBrush=CreateSolidBrush(GRAY192);
      return g;
      break;
    case DKGRAY_BRUSH:
      g.myBrush=CreateSolidBrush(DARKGRAY);
      return g;
      break;
    case BLACK_BRUSH:
      g.myBrush=CreateSolidBrush(BLACK);
      return g;
      break;
    case NULL_BRUSH:
//    case HOLLOW_BRUSH:
      g.myBrush=CreateSolidBrush(0);
      g.myBrush.style=0;
      return g;
      break;
    case WHITE_PEN:
      g.myPen=CreatePen(PS_SOLID,1,WHITE);
      return g;
      break;
    case BLACK_PEN:
      g.myPen=CreatePen(PS_SOLID,1,BLACK);
      return g;
      break;
    case NULL_PEN:
      g.myPen=CreatePen(PS_SOLID,0,0);
      return g;
      break;
    case DC_BRUSH:
      g.myBrush=CreateSolidBrush(BLACK);    // CONTRARIO DI WINDOWS :)
      return g;
      break;
    case DC_PEN:
      g.myPen=CreatePen(PS_SOLID,1,WHITE);    // contrario di windows !
      return g;
      break;
    case SYSTEM_FIXED_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,NULL);
      return g;
      break;
    case SYSTEM_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,NULL);
      return g;
      break;
    case OEM_FIXED_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,NULL);
      return g;
      break;
    case ANSI_FIXED_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,NULL);
      return g;
      break;
    case ANSI_VAR_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,"gfx");
      return g;
      break;
    case DEVICE_DEFAULT_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,NULL);
      return g;
      break;
    case DEFAULT_GUI_FONT:
      g.myFont=CreateFont(8,6,0,0,100,0,0,0,0,0,0,0,0,"gfx");
      return g;
      break;
    case DEFAULT_PALETTE:
      break;
    }
  }
  
FONT CreateFont(BYTE cHeight,BYTE cWidth,BYTE cEscapement,BYTE cOrientation,BYTE cWeight,
  BYTE bItalic,BYTE bUnderline,BYTE bStrikeOut,BYTE iCharSet,BYTE iOutPrecision,
  BYTE iClipPrecision, WORD iQuality, BYTE iPitchAndFamily,const char *pszFaceName) {
  FONT myFont;
  
  myFont.font=pszFaceName ? (void *)gfxFont : NULL;     // per ora cos� :)
  myFont.size=1; 
  myFont.inclination=0; 
  myFont.weight=100; 
  myFont.attributes=0;
  return myFont;
	}

BOOL SelectObject(HDC *hDC,BYTE type,void *h) {

	switch(type) {
		case OBJ_PEN:
			hDC->pen=*(PEN *)h;
			return TRUE;
			break;
		case OBJ_BRUSH:
			hDC->brush=*(BRUSH *)h;
			return TRUE;
			break;
		case OBJ_FONT:
			hDC->font=*(FONT *)h;
			return TRUE;
			break;
		case OBJ_BITMAP:
			break;
		case OBJ_REGION:
			break;
		}
	return FALSE;
	}

GFX_COLOR SetTextColor(HDC *hDC,GFX_COLOR color) {
  GFX_COLOR c=hDC->foreColor;
  
  hDC->foreColor=color;
  return c;
  }

GFX_COLOR GetTextColor(HDC *hDC) {
  
  return hDC->foreColor;
  }

GFX_COLOR SetBkColor(HDC *hDC,GFX_COLOR color) {
  GFX_COLOR c=hDC->backColor;
  
  hDC->backColor=color;
  return c;
  }

GFX_COLOR GetBkColor(HDC *hDC) {
  
  return hDC->backColor;
  }

int GetBkMode(HDC *hDC) {
  
  return 0 /*OPAQUE, TRANSPARENT*/;
  }

UINT SetTextAlign(HDC *hDC,UINT align) {
  // return prec
  }

UINT GetTextAlign(HDC *hDC) {
  
//  return TA_BASELINE;   // finire ecc
  }

BOOL GetCharWidth(HDC *hDC,UINT iFirst,UINT iLast,INT *lpBuffer) {
  
  return 6;   // boh :)
  }

BOOL GetTextExtentPoint32(HDC *hDC,const char *lpString,int n,SIZE *psizl) {
  
  psizl->cx= 6 * n;
  psizl->cy= hDC->font.size * 8;
// v. void getTextBounds(char *str, UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T *x1, UGRAPH_COORD_T *y1, UGRAPH_COORD_T *w, UGRAPH_COORD_T *h) {

  return TRUE;
  }

static void DrawCharWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size) {
	INT8 i,j;
	const BYTE *fontPtr;

  switch(videoMode) {
    case MODE_LCD:
    case MODE_LCD_DMA:
    case MODE_VGA:
    case MODE_COMPOSITE:
      // per ora gestiti tutti da pixel line ecc, poi magari potrebbe cambiare

      if(!gfxFont) { // 'Classic' built-in font

        if(!_cp437 && (c >= 176)) 
          c++; // Handle 'classic' charset behavior
#ifndef USE_256_CHAR_FONT 
        if(c>=128)
          return;
#endif
        fontPtr=font+((UINT16)c)*5;
        for(i=0; i<6; i++) {
          UINT8 line;
          if(i<5) 
            line = pgm_read_byte(fontPtr+i);
          else  
            line = 0x0;
          for(j=0; j<8; j++, line >>= 1) {
            if(line & 0x1) {
              if(size == 1) 
                DrawPixelWindow(hDC,x+i,y+j,color);
              else
                FillRectangleWindow(hDC,x+(i*size),y+(j*size),size,size,color);
              } 
            else if(bg != color) {
              if(size == 1) 
                DrawPixelWindow(hDC,x+i,y+j,bg);
              else          
                FillRectangleWindow(hDC,x+(i*size),y+(j*size),size,size,bg);
              }
            }
          }
        }

      else { // Custom font
        GFXglyph *glyph;
        UINT8  *bitmap;
        UINT16 bo;
        UINT8  w, h, xa;
        INT8   xo, yo;
        UINT8  xx, yy, bits, bit = 0;
        GRAPH_COORD_T  xo16, yo16;

        // Character is assumed previously filtered by write() to eliminate
        // newlines, returns, non-printable characters, etc.  Calling drawChar()
        // directly with 'bad' characters of font may cause mayhem!

        c -= pgm_read_byte(&gfxFont->first);
        glyph  = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
        bitmap = (UINT8 *)pgm_read_pointer(&gfxFont->bitmap);

        bo = pgm_read_word(&glyph->bitmapOffset);
        w  = pgm_read_byte(&glyph->width),
                 h  = pgm_read_byte(&glyph->height),
                 xa = pgm_read_byte(&glyph->xAdvance);
        xo = pgm_read_byte(&glyph->xOffset),
                 yo = pgm_read_byte(&glyph->yOffset);
        xx, yy, bits, bit = 0;
        xo16, yo16;

        if(size > 1) {
          xo16 = xo;
          yo16 = yo;
          }

        // Todo: Add character clipping here

        // NOTE: THERE IS NO 'BACKGROUND' COLOR OPTION ON CUSTOM FONTS.
        // THIS IS ON PURPOSE AND BY DESIGN.  The background color feature
        // has typically been used with the 'classic' font to overwrite old
        // screen contents with new data.  This ONLY works because the
        // characters are a uniform size; it's not a sensible thing to do with
        // proportionally-spaced fonts with glyphs of varying sizes (and that
        // may overlap).  To replace previously-drawn text when using a custom
        // font, use the getTextBounds() function to determine the smallest
        // rectangle encompassing a string, erase the area with fillRect(),
        // then draw new text.  This WILL unfortunately 'blink' the text, but
        // is unavoidable.  Drawing 'background' pixels will NOT fix this,
        // only creates a new set of problems.  Have an idea to work around
        // this (a canvas object type for MCUs that can afford the RAM and
        // displays supporting setAddrWindow() and pushColors()), but haven't
        // implemented this yet.

        for(yy=0; yy<h; yy++) {
          for(xx=0; xx<w; xx++) {
            if(!(bit++ & 7)) {
              bits = pgm_read_byte(&bitmap[bo++]);
              }
            if(bits & 0x80) {
              if(size == 1) {
                DrawPixelWindow(hDC,x+xo+xx, y+yo+yy, color);
                } 
              else {
                FillRectangleWindow(hDC,x+(xo16+xx)*size, y+(yo16+yy)*size, size, size, color);
                }
              }
            bits <<= 1;
            }
          }

        } // End classic vs custom font
      break;
  	}

	}

static void __attribute__((always_inline)) Pixel(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {

  START_WRITE();
	setAddrWindow(x, y, 1, 1);
	writedata16(color);
  END_WRITE();
	}

static void DrawPixelWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {
  HWND hWnd;
  
  x+=hDC->area.left;
  y+=hDC->area.top;
  hWnd=WindowFromDC(hDC);
  if(BoundaryCheckWindow(hDC,x,y))
    return;
  if(hWnd->style & WS_CHILD) {  // DOPO per motivi vari
    x+=hWnd->parent->hDC.area.left;
    y+=hWnd->parent->hDC.area.top;
    }
  // mancherebbe il < 0... ma non dovrebbe servire
  if(ZCheckWindow(hDC,x,y))
    return;
  
  switch(videoMode) {
    case MODE_LCD:
//      drawPixelLCD(x,y,color);
    	Pixel(x,y,color);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      drawPixel(x,y,color);
      break;
    }
  }

static void DrawHorizLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y,UGRAPH_COORD_T x2,GFX_COLOR c) {

  while(x1<=x2) {
    DrawPixelWindow(hDC,x1,y,c);
    x1++;
    }
  }

static void DrawVertLineWindow(HDC *hDC, UGRAPH_COORD_T x, UGRAPH_COORD_T y1,UGRAPH_COORD_T y2,GFX_COLOR c) {
  
  while(y1<=y2) {
    DrawPixelWindow(hDC,x,y1,c);
    y1++;
    }
  }

static void DrawLineWindow(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
 	BOOL steep;
	GRAPH_COORD_T dx,dy;
	GRAPH_COORD_T err;
	GRAPH_COORD_T ystep;
	GRAPH_COORD_T xbegin;
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
//        e qua credo sia in fondo del tutto inutile
//      drawLineLCD(x1,y1,x2,y2,c);
        // e CMQ non andrebbe per le child/clipchildren!
        }
      else {
        }

      steep = abs(y2-y1) > abs(x2-x1);
      if(steep) {
        _swap(&x1, &y1);
        _swap(&x2, &y2);
        }
      if(x1>x2) {
        _swap(&x1, &x2);
        _swap(&y1, &y2);
        }

      dx = x2-x1;
      dy = abs(y2-y1);
      err = dx/2;
      ystep = y1<y2 ? 1 : -1;

      xbegin = x1;
      if(steep) {
        for(; x1<=x2; x1++) {
          err -= dy;
          if(err < 0) {
            INT16 len = x1-xbegin;
            if(len)
              DrawVertLineWindow(hDC,y1,xbegin,xbegin+len,c);
            else
              DrawPixelWindow(hDC,y1,x1,c);
            xbegin = x1+1;
            y1 += ystep;
            err += dx;
            }
          }
        if(x1 > xbegin+1)
          DrawVertLineWindow(hDC,y1,xbegin,x1,c);
        } 
      else {
        for(; x1<=x2; x1++) {
          err -= dy;
          if(err < 0) {
            INT16 len = x1-xbegin;
            if(len)
              DrawHorizLineWindow(hDC,xbegin,y1,xbegin+len,c);
            else
              DrawPixelWindow(hDC,x1,y1,c);
            xbegin = x1+1;
            y1 += ystep;
            err += dx;
            }
          }
        if(x1 > xbegin+1)
          DrawHorizLineWindow(hDC,xbegin,y1,x1,c);
        }
      break;
      
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      drawLine(x1,y1,x2,y2,c);
      break;
    }

  }

static void DrawRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
        x1+=hDC->area.left;
        y1+=hDC->area.top;
        x2+=hDC->area.left;
        y2+=hDC->area.top;
        if(BoundaryCheckWindow(hDC,x1,y1))
          return;
        if(x2<=x1 || y2<=y1)
          return;
        if(x2 > hDC->area.right)  
          x2 = hDC->area.right;
        if(y2 > hDC->area.bottom)
          y2 = hDC->area.bottom;
        drawRectLCD(x1,y1,x2-x1+1,y2-y1+1,c);
      // OCCHIO cmq a child/clipchildren!
        }
      else {
        DrawHorizLineWindow(hDC,x1,y1,x2,c);
        DrawHorizLineWindow(hDC,x1,y2,x2,c);
        DrawVertLineWindow(hDC,x1,y1,y2,c);
        DrawVertLineWindow(hDC,x2,y1,y2,c);
        }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      drawRectangle(x1,y1,x2,y2,c);
      break;
    }
  }

static void FillRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, 
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
        x1+=hDC->area.left;
        y1+=hDC->area.top;
        x2+=hDC->area.left;
        y2+=hDC->area.top;
        if(BoundaryCheckWindow(hDC,x1,y1))
          return;
        if(x2<=x1 || y2<=y1)
          return;
        if(x2 > hDC->area.right)  
          x2 = hDC->area.right;
        if(y2 > hDC->area.bottom)  
          y2 = hDC->area.bottom;
        fillRectLCD(x1,y1,x2-x1+1,y2-y1+1,c);
      // OCCHIO cmq a child/clipchildren!
        }
      else {
        while(y1<=y2) {
          DrawHorizLineWindow(hDC,x1,y1,x2,c);
          y1++;
          }
        }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      drawRectangleFilled(x1,y1,x2,y2,c);
      break;
    }
  }

static void DrawCircleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  UGRAPH_COORD_T r=(x2-x1+y2-y1)/(2*2);
  GRAPH_COORD_T f = 1 - r;
  GRAPH_COORD_T ddF_x = 1;
  GRAPH_COORD_T ddF_y = -2 * r;
  GRAPH_COORD_T x = 0;
  GRAPH_COORD_T y = r;
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
        x1+=hDC->area.left;
        y1+=hDC->area.top;
        x2+=hDC->area.left;
        y2+=hDC->area.top;
        if(BoundaryCheckWindow(hDC,x1,y1))
          return;
        if(x2<=x1 || y2<=y1)
          return;
        if(x2 > hDC->area.right)  
          x2 = hDC->area.right;
        if(y2 > hDC->area.bottom)  
          y2 = hDC->area.bottom;
        drawCircleLCD((x1+x2)/2,(y1+y2)/2,(x2-x1+y2-y1)/(2*2),c); // bah finire, adattare!
      // OCCHIO cmq a child/clipchildren!
        }
      else {

      DrawPixelWindow(hDC,x1  , y1+r, c);
      DrawPixelWindow(hDC,x1  , y1-r, c);
      DrawPixelWindow(hDC,x1+r, y1  , c);
      DrawPixelWindow(hDC,x1-r, y1  , c);

      while(x<y) {
        if(f >= 0) {
          y--;
          ddF_y += 2;
          f += ddF_y;
          }
        x++;
        ddF_x += 2;
        f += ddF_x;

        DrawPixelWindow(hDC,x1 + x, y1 + y, c);
        DrawPixelWindow(hDC,x1 - x, y1 + y, c);
        DrawPixelWindow(hDC,x1 + x, y1 - y, c);
        DrawPixelWindow(hDC,x1 - x, y1 - y, c);
        DrawPixelWindow(hDC,x1 + y, y1 + x, c);
        DrawPixelWindow(hDC,x1 - y, y1 + x, c);
        DrawPixelWindow(hDC,x1 + y, y1 - x, c);
        DrawPixelWindow(hDC,x1 - y, y1 - x, c);
        }
      }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      drawCircle((x1+x2)/2,(y1+y2)/2,(x2-x1+y2-y1)/(2*2),c); // bah finire, adattare!
      break;
    }
  }

static BOOL BoundaryCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  HWND hWnd=WindowFromDC(hDC);

  if(hWnd->style & WS_CHILD) {   // if(hWnd->parent) ..
  	if(((x < hDC->paintArea.left) || (y < hDC->paintArea.top)) ||
      ((x > hDC->paintArea.right) || (y > hDC->paintArea.bottom)))
     	return TRUE;
    x+=hWnd->parent->hDC.area.left;   // v. sopra...
    y+=hWnd->parent->hDC.area.top;
  	if((x > hWnd->parent->hDC.area.right) || (y > hWnd->parent->hDC.area.bottom)) // bah direi di s�, per sicurezza
    	return TRUE;
    }
  else {
  	if(((x < hDC->paintArea.left) || (y < hDC->paintArea.top)) ||
      ((x > hDC->paintArea.right) || (y > hDC->paintArea.bottom)))
    	return TRUE;
    }
	return FALSE;
	}

HWND WindowFromPoint(POINT pt) { //not retrieve a handle to a hidden or disabled
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd->visible && myWnd->enabled && PtInRect(&myWnd->nonClientArea,pt)) {
      return myWnd;
      }
    myWnd=myWnd->next;
    }
  return NULL;
  }

HWND GetWindow(HWND hWnd,UINT uCmd) {
  HWND myWnd;
  
  switch(uCmd) {
    case GW_CHILD:
      // occhio anche a zorder cmq
      break;

    case GW_ENABLEDPOPUP:
      break;

    case GW_HWNDFIRST:
      // finire...
      break;

    case GW_HWNDLAST:
      break;

    case GW_HWNDNEXT:
      break;

    case GW_HWNDPREV:
      break;
    case GW_OWNER:
      return hWnd->parent;
      break;
    }
  }

BOOL EnumChildWindows(HWND hWndParent,WNDENUMPROC lpEnumFunc,LPARAM lParam) {
  //fare!
  }


static BOOL ZCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  HWND hWnd,myWnd;
  POINT pt;
  
  hWnd=WindowFromDC(hDC);
//  if(hWnd->active /* o zOrder*/)    // diciamo :) magari solo se non child ma le child NON DOVREBBERO MAI essere attive!
//    return 0;
//  hWnd=container_of(hDC,struct _WINDOW,hDC);
  pt.x=x; pt.y=y;
  if(hWnd->style & WS_CHILD) {
    myWnd=rootWindows;   // le guardo tutte
    while(myWnd) {
      
      if(hWnd->style & WS_CLIPSIBLINGS) { //gestire
        if((myWnd != hWnd) && ((myWnd != hWnd->parent && myWnd->zOrder > hWnd->parent->zOrder) ||
          (myWnd->parent == hWnd->parent))) {    //
          if(PtInRect(&myWnd->nonClientArea,pt)) {
            return 1;
            }
          }
        }
      else {
        if((myWnd != hWnd) && (myWnd != hWnd->parent && myWnd->zOrder > hWnd->parent->zOrder)) {    // in teoria il test Zorder � inutile, dato il sort
          if(PtInRect(&myWnd->nonClientArea,pt)) {
            return 1;
            }
          }
        }
      myWnd=myWnd->next;
      }
    }
  else {
    if(!(hWnd->style & WS_CLIPCHILDREN)) {
#warning	USARE la cliparea!
//magari da sopra quando aggiorniamo le child

      if(hWnd->active /* o zOrder*/)    // diciamo :) 
        return 0;
      myWnd=hWnd->next;   // inizio da quella subito sopra di me
      while(myWnd) {
        if(myWnd->zOrder > hWnd->zOrder) {    // in teoria questo test � inutile, dato il sort
          if(PtInRect(&myWnd->nonClientArea,pt)) {
            return 1;
            }
          }
        myWnd=myWnd->next;
        }
      }
    else {
      myWnd=rootWindows;
      while(myWnd) {
        if(myWnd != hWnd) {
          if(myWnd->parent == hWnd) {
            RECT rc;
            rc.left=myWnd->nonClientArea.left+hWnd->clientArea.left;
            rc.right=myWnd->nonClientArea.right+hWnd->clientArea.left;
            rc.top=myWnd->nonClientArea.top+hWnd->clientArea.top;
            rc.bottom=myWnd->nonClientArea.bottom+hWnd->clientArea.top;
            if(PtInRect(&rc,pt)) {
              return 1;
              }
            }
          else {
            if(myWnd->zOrder > hWnd->zOrder) {
              if(PtInRect(&myWnd->nonClientArea,pt)) {
                return 1;
                }
              }
            }
          }
        myWnd=myWnd->next;
        }
      }
    }
  return 0;
  }

BOOL SetRect(RECT *lprc,UGRAPH_COORD_T xLeft,UGRAPH_COORD_T yTop,UGRAPH_COORD_T xRight,UGRAPH_COORD_T yBottom) {
  
  lprc->left=xLeft;
  lprc->right=xRight;
  lprc->top=yTop;
  lprc->bottom=yBottom;
  }

BOOL SetRectEmpty(RECT *lprc) {
  
  lprc->left=lprc->right=lprc->top=lprc->bottom=0;
  }

BOOL UnionRect(RECT *rcDst,const RECT *rcSrc1,const RECT *rcSrc2) {
  
  rcDst->top=min(rcSrc1->top,rcSrc2->top);
  rcDst->left=min(rcSrc1->left,rcSrc2->left);
  rcDst->right=max(rcSrc1->right,rcSrc2->right);
  rcDst->bottom=max(rcSrc1->bottom,rcSrc2->bottom);
  
  return !IsRectEmpty(rcDst);
  }

// -------------------------------------------------------------------------------
WNDCLASS baseClass= {
  MAKECLASS(WC_DEFAULTCLASS),
  0,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProc,
  0,
  0,
  NULL,
  {0,0,DARKGRAY}
  };
struct WNDCLASS_STATIC {
  WNDCLASS baseClass;
  } staticClass = { {
  MAKECLASS(WC_STATIC),
  SS_CENTER,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcStaticWC,
  0,
  32,    // testo esteso, se si usa
  NULL,
  {0,0,DARKGRAY}
  }
  };
struct WNDCLASS_BUTTON {
  WNDCLASS baseClass;
  } buttonClass = { {
  MAKECLASS(WC_BUTTON),
  BS_CENTER,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcButtonWC,
  0,
  4, // BYTE type;  BYTE state;	BYTE hotkey;
  NULL,
  {0,0,GRAY204}
  }
  };
struct WNDCLASS_EDIT {
  WNDCLASS baseClass;
  } editClass = { {
  MAKECLASS(WC_EDIT),
  WS_BORDER,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcEditWC,
  0,
  36,  //	BYTE caretPos;	BYTE selStart,selEnd;  BYTE content[32];
  NULL,
  {0,0,GRAY224}
  }
  };
struct WNDCLASS_DIALOG {
  WNDCLASS baseClass;
  } dialogClass = { {
  MAKECLASS(WC_DIALOG),
  WS_BORDER,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcDlgWC,
  0,
  0,		// fare
  NULL,
  {0,0,GRAY224}
  }
  };
struct WNDCLASS_LISTBOX {
  WNDCLASS baseClass;
  } listboxClass = { {
  MAKECLASS(WC_LISTBOX),
  WS_BORDER,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcListboxWC,
  0,
  8, //   BYTE *data; 	BYTE selectedLine;
  NULL,
  {0,0,GRAY224}
  }   
  };
struct WNDCLASS_DESKTOP {
  WNDCLASS baseClass;
  } desktopClass = { {
  MAKECLASS(WC_DESKTOPCLASS),
  0,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcDC,
  0,
  32,    //  POINT iconPosition[16];
  NULL,
  {0,0,DARKBLUE}
  }
  };
struct WNDCLASS_DIRDLG {
  WNDCLASS baseClass;
  } fileDialogClass= { {
  MAKECLASS(WC_DIRDLG),
  WS_BORDER,
  standardIcon,
  standardCursor,
  (WINDOWPROC *)DefWindowProcDirDlgWC,
  0,
  sizeof(OPENFILENAME),   //   OPENFILENAME ofn;
  NULL,
  {0,0,LIGHTGRAY}
  }
  };

BOOL GetClassInfo(HINSTANCE hInstance, CLASS Class, WNDCLASS **lpWndClass) {
  
  switch(Class.class) {
    case WC_STATIC:
      *lpWndClass=(WNDCLASS *)&staticClass;
      break;
    case WC_BUTTON:
      *lpWndClass=(WNDCLASS *)&buttonClass;
      break;
    case WC_COMBOBOX:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_EDIT:
      *lpWndClass=(WNDCLASS *)&editClass;
      break;
    case WC_DIALOG:
      *lpWndClass=(WNDCLASS *)&dialogClass;
      break;
    case WC_LISTBOX:
      *lpWndClass=(WNDCLASS *)&listboxClass;
      break;
    case WC_SCROLLBAR:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_HOTKEY:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_PROGRESS:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_STATUS:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_TRACKBAR:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_UPDOWN:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
    case WC_DIRDLG:
      *lpWndClass=(WNDCLASS *)&fileDialogClass;
      break;

    case WC_DESKTOPCLASS:
      *lpWndClass=(WNDCLASS *)&desktopClass;
      break;

    case WC_DEFAULTCLASS:
      *lpWndClass=(WNDCLASS *)&baseClass;
      break;
      
    default:
    {
      WNDCLASS *myClass=rootClasses;
//      *lpWndClass=NULL;
      while(myClass) {
        if(myClass->class.class==Class.class) {
          *lpWndClass=myClass;
          return TRUE;
          break;
          }
        myClass=myClass->next;
        }
      return FALSE;
    }

      break;
    }
  return TRUE;
  }


// -------------------------------------------------------------------------------
void SortLinkedListValue(struct _WINDOW *node) {   //https://stackoverflow.com/questions/35914574/sorting-linked-list-simplest-way
  struct _WINDOW *temp;
  int tempvar,j;  //temp variable to store node data
    
  temp = node->next;//temp node to hold node data and next link
  while(node && node->next) {
    for(j=0; j<maxWindows; j++) {   //[value 5 because I am taking only 5 nodes]
      if(node->zOrder > temp->zOrder) {   //swap node data
        tempvar = node->zOrder;
        node->zOrder= temp->zOrder;
        temp->zOrder = tempvar;
        }
      temp = temp->next;
      }
    node = node->next;
    }
  }
 
static void SortLinkedList(struct _WINDOW *head) {     // https://www.javatpoint.com/program-to-sort-the-elements-of-the-singly-linked-list
  struct _WINDOW *node = head, *i, *j;
  struct _WINDOW *temp;
  
#if 0
  //Node current will point to head  
  struct _WINDOW *current = head, *index = NULL;  
  int temp;  

  if(!head) {  
    return;  
    } 
  else {  
    while(current) {  
      //Node index will point to node next to current  
      index = current->next;  

      while(index ) {  
        //If current node's data is greater than index's node data, swap the data between them  
        if(current->zOrder > index->zOrder) {  
          temp = current->zOrder;  
          current->zOrder = index->zOrder;  
          index->zOrder = temp;  
          }  
        index = index->next;  
        }  
      current = current->next;  
      }      
    }  
#endif
  
  // https://stackoverflow.com/questions/8981823/bubble-sort-algorithm-for-a-linked-list
  i = node;
  while(i) {
    j = node->next;
    while(j) {
      if(i->zOrder > j->zOrder) {
        temp = i->next;
        i->next = j->next;
        j->next = temp;
        }
      j = j->next;
      }
    i = i->next;
    }
  }

void list_bubble_sort(struct _WINDOW **head) {    //https://stackoverflow.com/questions/21388916/bubble-sort-singly-linked-list-in-c-with-pointers
  int done = 0;         // True if no swaps were made in a pass

  // Don't try to sort empty or single-node lists
  if(!*head || !((*head)->next))
    return;

  while(!done) {
    struct _WINDOW **pv = head;         // "source" of the pointer to the current node in the list struct
    struct _WINDOW *nd = *head;            // local iterator pointer
    struct _WINDOW *nx = (*head)->next;  // local next pointer

    done = 1;

    while(nx) {
      if(nd->zOrder > nx->zOrder) {   // ordino da pi� basso a pi� alto (v. anche ZCheckWindow e HWND_TOP ecc)
        nd->next = nx->next;
        nx->next = nd;
        *pv = nx;
        done = 0;
        }
      pv = &nd->next;
      nd = nx;
      nx = nx->next;
      }
    }
  }

void handleWinTimers(void) {
  int i;
  
  for(i=0; i<MAX_TIMERS; i++) {
    if(timerData[i].uEvent) {
      if(timerData[i].time_cnt) {
        timerData[i].time_cnt--;
        if(!timerData[i].time_cnt) {
          if(timerData[i].hWnd)
            SendMessage(timerData[i].hWnd,WM_TIMER,timerData[i].uEvent,(LPARAM)timerData[i].tproc);
          else if(timerData[i].tproc)
            timerData[i].tproc(timerData[i].hWnd,0,0,0);
          timerData[i].time_cnt=timerData[i].timeout;
          }
        }
      }
    }
  }
