/*
 * BREAKTHROUGH 2.0
 * (C) G.Dar 1987-2021 :) !
 * (portions inspired by Windows, since 1990)
 * 
 * 
 */
 
#include <xc.h>
#include "pc_pic_video.h"
#include "Adafruit_ST7735.h"

extern BYTE DMA_READY videoRAM[800L*600];  

extern enum VIDEO_MODE videoMode;


#define Color565(red, green, blue)    (GFX_COLOR) ((((GFX_COLOR)(red) & 0xF8) << 8) | (((GFX_COLOR)(green) & 0xFC) << 3) | (((GFX_COLOR)(blue) & 0xF8) >> 3))
#define ColorRGB(color)    (DWORD) ( ((color & 0xf800) >> 11) | ((color & 0x07e0) << 3) | ((((DWORD)color) & 0x001f) << 16) )
#define ColorR(color)    ((color & 0xf800) >> 8)        // left-justified, diciamo..
#define ColorG(color)    ((color & 0x07e0) >> 3)
#define ColorB(color)    ((color & 0x001f) << 3)
#define Color565To332(color)    (BYTE) ((WORD)( ((color & 0xe000) >> 8) | ((color & 0x0700) >> 6) | ((color & 0x0018) >> 3) ))
#define Color565To222(color)    (BYTE) ((WORD)( ((color & 0xc000) >> 10) | ((color & 0x0600) >> 7) | ((color & 0x0018) >> 3) ))
#define Color24To565(color)    ((((color >> 16) & 0xFF) / 8) << 11) | ((((color >> 8) & 0xFF) / 4) << 5) | (((color) &  0xFF) / 8)
  //convert 24bit color into packet 16 bit one (credits for this are all mine) GD made a macro!

#include "breakthrough.h"

GFX_COLOR windowForeColor, windowInactiveForeColor, windowBackColor, desktopColor;
extern const unsigned char font[] PROGMEM;
HWND rootWindows=NULL;
WORD maxWindows=1;

const GFX_COLOR standardIcon[]={
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  WHITE,RED,WHITE,RED,WHITE,RED,WHITE,RED,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  LIGHTGREEN,BLACK,LIGHTGREEN,BLACK,LIGHTGREEN,BLACK,LIGHTGREEN,BLACK,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  WHITE,LIGHTBLUE,WHITE,LIGHTBLUE,WHITE,LIGHTBLUE,WHITE,LIGHTBLUE,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,WHITE,BLACK,
  };
const GFX_COLOR redBallIcon[]={   //https://www.digole.com/tools/PicturetoC_Hex_converter.php
  0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
  0x0000,0x2110,0xa989,0xa9b8,0xa8b8,0xa989,0x2110,0x0000,
  0x0000,0xa989,0x6ae8,0x4ef9,0x09f0,0x47c0,0x8879,0x0000,
  0x0000,0xa9b8,0x8bf8,0xd4fa,0x28d8,0x05a0,0x0360,0x0000,
  0x0000,0xa8b0,0x07d0,0x06c0,0x0598,0x0468,0x0350,0x0000,
  0x0000,0xa981,0x4698,0x0480,0x0360,0x2350,0xe550,0x0000,
  0x0000,0x2110,0x8871,0x0350,0x0348,0xe550,0x0008,0x0000,
  0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000
  };
const GFX_COLOR folderIcon[]={
  0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,
  0xad73,0xb2bd,0x30ad,0x0c63,0x0c63,0x0c63,0x0c63,0x0c63,
  0x92b5,0x15ef,0xf3ee,0xb3e6,0x92de,0xb3e6,0x51de,0xa339,
  0xd4bd,0x31ff,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0x499c,
  0x91bd,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0xa662,
  0x4dbd,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0x30ff,0xe220,
  0x11ad,0xb2bd,0xb2bd,0xb2bd,0xb2bd,0xb2bd,0x92bd,0x0c63,
  0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7,0xbef7
  };
const GFX_COLOR windowIcon[]={
  0x1ebe,0x3ebe,0xddb5,0xdcb5,0xdcb5,0x1ebe,0x1ebe,0xfdb5,
  0xdfd6,0x1fdf,0x1fdf,0x1fdf,0x1fdf,0x1fdf,0x1fdf,0xbfd6,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9fef,0xffff,0xffff,0xffff,0xffff,0xffff,0xffff,0x7eef,
  0x9995,0x988d,0x9995,0x988d,0x9995,0x988d,0x9995,0x798d
  };

#define MAX_TIMERS 4
TIMER_DATA timerData[MAX_TIMERS];    // diciamo 4

static void DrawCharWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size);
static void DrawPixelWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color);
static void DrawLineWindow(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static void DrawHorizLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,UGRAPH_COORD_T x2,GFX_COLOR c);
static void DrawVertLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,UGRAPH_COORD_T y2,GFX_COLOR c);
static void DrawRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static void FillRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static void DrawCircleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);
static BOOL inline BoundaryCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y);
static BOOL inline ZCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y);
static BOOL nonClientPaint(HWND hWnd,const RECT *rc);
static BOOL clientPaint(HWND hWnd,const RECT *rc);
static void calculateClientArea(HWND hWnd,RECT *rc);
static void calculateNonClientArea(HWND hWnd,RECT *rc);
static void readClassInfo(CLASS className,WINDOWPROC **wproc,DWORD *flags,GFX_COLOR **picon,WNDCLASS *ci);

static BOOL addHeadWindow(HWND);
static BOOL addTailWindow(HWND);
static BOOL insertWindow(HWND,HWND);
static BOOL removeWindow(HWND);
static void SortLinkedList(struct _WINDOW *head);
void list_bubble_sort(struct _WINDOW **head);
LRESULT DefWindowProc(HWND ,unsigned int ,WPARAM ,LPARAM);
LRESULT SendMessage(HWND ,unsigned int ,WPARAM ,LPARAM);
static HWND setActive(HWND hWnd,BOOL state);


//-------------------------windows----------------------------------------------
void InitWindows(GFX_COLOR bgcolor /*DARKBLUE*/) {
  char buf[16];
  
  windowForeColor=BRIGHTCYAN;
  windowInactiveForeColor=GRAY160;
  windowBackColor=DARKGRAY;
  desktopColor=bgcolor;
  rootWindows=NULL;
  maxWindows=1;
  // oppure 
  // rootWindows=CreateWindow("desktop","",WS_ACTIVE | WS_VISIBLE,0,0,_width,_height,NULL,NULL,0);
  // e anche
  // CreateWindow("taskbar","",WS_ACTIVE | WS_VISIBLE,0,_height-_height/16,_width,_height/16,NULL,NULL,0);
  
  switch(videoMode) {
    case MODE_VGA:
      screenCLS(BLACK);
      writeStringXY(4,4,"BREAKTHROUGH 2.0",WHITE);
      break;
    case MODE_COMPOSITE:
      screenCLS(BLACK);
      writeStringXY(4,4,"BREAKTHROUGH 2.0",WHITE);
      break;
    case MODE_LCD:
#ifndef USING_SIMULATOR
      clearScreenLCD();
      setColors(WHITE,desktopColor);    // ok cos�, magari fare un rettangoletto
      setTextSize(2);
      setTextCursor(2,6);
      gfx_print("BREAKTHROUGH");
      setTextCursor(10,8);
      sprintf(buf,"%u.%02u",BREAKTHROUGH_VERSION_H,BREAKTHROUGH_VERSION_L);
      gfx_print(buf);
      setTextSize(1);
      setColors(LIGHTGRAY,desktopColor);
      setTextCursor(7,12);
      gfx_print("(C) 1988-2021");
#endif
      break;
    }
  
  __delay_ms(1000);
  ClrWdt();
#ifndef USING_SIMULATOR
  PaintDesktop(NULL);
#endif
  ClrWdt();
  // oppure 
  // rootWindows=CreateWindow(WC_DESKTOPCLASS,NULL,WS_ACTIVE | WS_VISIBLE,0,0,_width,_height,NULL,NULL,0);
  // e anche
  // CreateWindow("taskbar","",WS_ACTIVE | WS_VISIBLE,0,_height-_height/16,_width,_height/16,NULL,NULL,0);
  }

GFX_COLOR GetSysColor(int nIndex) {
  
  switch(nIndex) {
    case 0:   // mettere quelli di windows...
      return windowForeColor;
      break;
    case 1:
      return windowInactiveForeColor;
      break;
    case 2:
      return windowBackColor;
      break;
    case 3:
      return desktopColor;
      break;
    }
  }

HWND GetDesktopWindow(void) { return rootWindows; }	// forse :)
int GetDeviceCaps(HDC hDC,int index) {
  
  switch(index) {
    case DRIVERVERSION:
      return MAKEWORD(BREAKTHROUGH_VERSION_L,BREAKTHROUGH_VERSION_H);
      break;
    case TECHNOLOGY:
      break;
    case HORZSIZE:
    case HORZRES:
      return _height;
      break;
    case VERTRES:
    case VERTSIZE:
      return _width;
      break;
    case BITSPIXEL:
      switch(videoMode) {
        case MODE_LCD:
          return 16;
          break;
        case MODE_VGA:
          return 8;
          break;
        case MODE_COMPOSITE:
          return 8;
          break;
        }
      break;
    case PLANES:
      return 3;
      break;
    case NUMBRUSHES:
      return 1;
      break;
    case NUMPENS:
      return 1;
      break;
    case NUMMARKERS:
      return 0;
      break;
    case NUMFONTS:
      #ifdef USE_CUSTOM_FONTS 
        return 3;
      #else
        return 2;
      #endif
      break;
    case NUMCOLORS:
      switch(videoMode) {
        case MODE_LCD:
          return 65536;
          break;
        case MODE_VGA:
          return 256;
          break;
        case MODE_COMPOSITE:
          return 256;
          break;
        }
      break;
    case CURVECAPS:
      return 1;
      break;
    case LINECAPS:
      return 1;
      break;
    case POLYGONALCAPS:
      return 1;
      break;
    case TEXTCAPS:
      return 1;
      break;
    case CLIPCAPS:
      return 1;
      break;
    case RASTERCAPS:
      return 1;
      break;
    case VREFRESH:
      switch(videoMode) {
        case MODE_LCD:
          return 50;
          break;
        case MODE_VGA:
          return 60;
          break;
        case MODE_COMPOSITE:
          return 50;
          break;
        }
      break;
      
    default:
      break;
    }
  }

HWND CreateWindow(CLASS Class,const char *lpWindowName,
  DWORD dwStyle,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,UGRAPH_COORD_T nWidth,UGRAPH_COORD_T nHeight,
  HWND hWndParent,HMENU hMenu,void *lpParam) {
  HWND hWnd;

  hWnd=malloc(sizeof(struct _WINDOW));
  if(!hWnd)
    return NULL;
  hWnd->next=NULL;
  hWnd->flags=0;
  hWnd->nonClientArea.top=Y;
  hWnd->nonClientArea.left=X;
  hWnd->nonClientArea.bottom=Y+nHeight;
  hWnd->nonClientArea.right=X+nWidth;
  hWnd->cursorX=hWnd->cursorY=0;
  hWnd->foreColor=WHITE;    // CONTRARIO di windows, almeno per ora :)
  hWnd->backColor=BLACK;
  hWnd->font.font=NULL; hWnd->font.fontSimple=1;
  hWnd->icon=windowIcon;
  hWnd->class.class=Class.class;
  {
  WINDOWPROC *wproc;DWORD flags;GFX_COLOR *picon;WNDCLASS ci;
  readClassInfo(hWnd->class,&wproc,&flags,&picon,&ci);
  hWnd->windowProc=(WINDOWPROC *)wproc;
  }
  if(lpWindowName) {
    strncpy(hWnd->caption,lpWindowName,sizeof(hWnd->caption)-1);
    hWnd->caption[sizeof(hWnd->caption)-1]=0;
    }
  else
    hWnd->caption[0]=0;
  hWnd->style=dwStyle;
//  hWnd->styleEx=0;
  hWnd->tag=lpParam;
  hWnd->menu=hMenu;
  hWnd->parent=hWndParent;
  
  { CREATESTRUCT cs;
  cs.x=hWnd->nonClientArea.left;
  cs.y=hWnd->nonClientArea.top;
  cs.cx=hWnd->nonClientArea.right-hWnd->nonClientArea.left;
  cs.cy=hWnd->nonClientArea.bottom-hWnd->nonClientArea.top;
  cs.class=Class;
  cs.lpszName=hWnd->caption;
  cs.style=hWnd->style;
//  cs.dwExStyle=hWnd->styleEx;
  if(!SendMessage(hWnd,WM_NCCREATE,0,(LPARAM)&cs))
    goto no_creata;
  if(SendMessage(hWnd,WM_CREATE,0,(LPARAM)&cs) < 0) {
no_creata:
    free(hWnd);
    return NULL;
    }
  else {
    hWnd->style=cs.style;
    hWnd->nonClientArea.left=cs.x;
    hWnd->nonClientArea.top=cs.y;
    hWnd->nonClientArea.right=hWnd->nonClientArea.left+cs.cx;
    hWnd->nonClientArea.bottom=hWnd->nonClientArea.top+cs.cy;
    }
  }
  calculateClientArea(hWnd,&hWnd->clientArea);
  hWnd->scrollPosX=hWnd->scrollPosY=0;
  calculateNonClientArea(hWnd,&hWnd->nonClientArea);
  hWnd->enabled=hWnd->style & WS_DISABLED ? 0 : 1;
  if(hWnd->enabled && !(hWnd->style & WS_CHILD)) {
    hWnd->zOrder=maxWindows;
//che fare con le Child? mah le metto cmq in coda
    addTailWindow(hWnd);
    }
  else {
    hWnd->zOrder=1;
    addHeadWindow(hWnd);    // cos� rispettiamo lo Z-order subito!
    }
  if(!(hWnd->style & WS_CHILD))   // direi
    setActive(hWnd,hWnd->style & WS_ACTIVE ? 1 : 0);
  
  if(hWnd->style & WS_VISIBLE) {
    hWnd->visible=1;
#ifndef USING_SIMULATOR
    if(!(hWnd->style & WS_CHILD)) {
      SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
      SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
      SendMessage(hWnd,WM_PAINT,0,0);
      }
#endif
    }

#ifdef USING_SIMULATOR
  {
  extern HWND rootWindows;
    HWND myWnd=rootWindows;
  while(myWnd)
    myWnd=myWnd->next;
  }
#endif

  return hWnd;
  }

static BOOL addTailWindow(HWND hWnd) {   // per insertSorted: https://www.geeksforgeeks.org/given-a-linked-list-which-is-sorted-how-will-you-insert-in-sorted-way/
  HWND myWnd;
  
  maxWindows++;
  if(!rootWindows)
    rootWindows=hWnd;
  else {
    myWnd=rootWindows;
    while(myWnd && myWnd->next) {
      myWnd=myWnd->next;
      }
    myWnd->next=hWnd;
    }
  return 1;
  }
static BOOL addHeadWindow(HWND hWnd) {
  HWND myWnd;
  
  maxWindows++;
  if(!rootWindows)
    rootWindows=hWnd;
  else {
    myWnd=hWnd->next=rootWindows;
    rootWindows=hWnd;
    rootWindows->zOrder=1;    // questa diventa la pi� indietro...
    while(myWnd) {
      myWnd->zOrder++;    // ...e le scrollo tutte avanti di uno
      myWnd=myWnd->next;
      }
    }
  return 1;
  }
static BOOL insertWindow(HWND hWnd,HWND hWndAfter) {
  HWND myWnd,myWnd2;
  
  removeWindow(hWnd);
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd == hWndAfter) {
      myWnd2=hWndAfter->next;
      hWndAfter->next=hWnd;
      hWnd->next=myWnd2;
      maxWindows++;
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;
  }
static BOOL removeWindow(HWND hWnd) {
  HWND myWnd=rootWindows,myWnd2;
  
  while(myWnd) {
    myWnd2=myWnd;
    if(myWnd==hWnd) {
      if(myWnd==rootWindows)
        rootWindows=myWnd->next;
      else
        myWnd2->next=myWnd->next;
      maxWindows--;
      myWnd=myWnd->next;
      while(myWnd) {
        myWnd->zOrder--;
        myWnd=myWnd->next;
        }
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;
  }

LRESULT SendMessage(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  HWND myWnd;

	if(hWnd==HWND_BROADCAST) {
    myWnd=rootWindows;
    while(myWnd) {
			if(!(myWnd->style & WS_CHILD) /*myWnd->parent*/)
				myWnd->windowProc(myWnd,message,wParam,lParam);
      myWnd=myWnd->next;
      }
    }
	else
		return hWnd->windowProc(hWnd,message,wParam,lParam);   // per ora cos� :)
  }
LRESULT DefWindowProc(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_NCPAINT:
      //wParam = region
      return nonClientPaint(hWnd,(RECT *)wParam);
      break;
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_SETICON:
      hWnd->icon=(const GFX_COLOR *)lParam;
      break;
    case WM_SETFONT:
      hWnd->font.font=((BYTE *)wParam);
      if(LOWORD(lParam))
        InvalidateRect(hWnd,NULL,TRUE);
      break;
    case WM_GETFONT:
      return (LRESULT)hWnd->font.font;
      break;
    case WM_ERASEBKGND:
      return 0;
      break;
    case WM_CHAR:
    { char buf[8];    // TOGLIERE POI! :D
      buf[0]=wParam; buf[1]=0;
      TextOut(&hWnd->hDC,hWnd->hDC.cursorX,hWnd->hDC.cursorY,buf);
    }
      break;
    case WM_MOUSEMOVE:
      break;
    case WM_LBUTTONDOWN:
      break;
    case WM_TIMER:
      break;
    case WM_HSCROLL:
      break;
    case WM_VSCROLL:
      break;
    case WM_GETMINMAXINFO:
      // lParam = MINMAXINFO structure
      break;
    case WM_NCCALCSIZE:
      if(wParam) {
        struct NCCALCSIZE_PARAMS *ncp=(struct NCCALCSIZE_PARAMS *)lParam;
        }
      else {
        RECT *rc=(RECT *)lParam;
        calculateNonClientArea(hWnd,rc);
        calculateClientArea(hWnd,rc);
        }
      break;
    case WM_NCHITTEST:
      break;
    case WM_NCCREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 0;
      break;
    case WM_NCDESTROY:
      return 0;
      break;
    case WM_DESTROY:
      return 0;
      break;
    case WM_MOVE:
      //xPos = (int)(short) LOWORD(lParam);   // horizontal position 
      //yPos = (int)(short) HIWORD(lParam);   // vertical position 
      return 0;
      break;
//    case WM_MOVING:
//      break;
    case WM_SIZE:
      switch(wParam) {
        case SIZE_MAXHIDE:
          break;
        case SIZE_MAXIMIZED:
          break;
        case SIZE_MAXSHOW:
          break;
        case SIZE_MINIMIZED:
          break;
        case SIZE_RESTORED:
          break;
        }
      //UINT width = LOWORD(lParam);
      //UINT height = HIWORD(lParam);
      return 0;
      break;
//    case WM_SIZING:
//      break;
    case WM_CLOSE:
      DestroyWindow(hWnd);
      break;
    case WM_NCACTIVATE:
      // https://docs.microsoft.com/en-us/windows/win32/winmsg/wm-ncactivate
      return 1;   // per ora cos�
      break;
    case WM_ACTIVATE:
//   		setActive(hWnd,wParam == WA_ACTIVE);
//   	  hWnd->active=wParam == WA_ACTIVE;
      return 0;
      break;
    case WM_CHILDACTIVATE:
      return 0;
      break;
    case WM_DISPLAYCHANGE:
      break;
    case WM_PAINTICON:    // solo windows 3.x :)
      break;
    case WM_QUERYOPEN:
			return 1;
      break;
    case WM_SHOWWINDOW:
			return 0;
      break;
    case WM_WINDOWPOSCHANGING:
      return 0;
      break;
    case WM_WINDOWPOSCHANGED:
      return 0;
      break;
    case WM_SETFOCUS:
      break;
    case WM_KILLFOCUS:
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      nonClientPaint(hWnd,NULL /*area titolo...*/);
      return 1;
      break;
    case WM_GETTEXT:
      {
      int i=min(sizeof(hWnd->caption),wParam);
      strncpy((char *)lParam,hWnd->caption,i-1);
      ((char *)lParam)[i]=0;
      return i;
      }
      break;
    case WM_GETTEXTLENGTH:
      return strlen(hWnd->caption);
      break;
    case WM_ENABLE:
      hWnd->enabled=wParam;
      // c'entra con active? https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-enablewindow
      if(!hWnd->enabled) {
    		setActive(hWnd,FALSE);
        SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
        SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
        SendMessage(hWnd,WM_PAINT,0,0);
				}
      break;
    case WM_STYLECHANGED:
      break;
    case WM_STYLECHANGING:
      break;
      
    case WM_INITDIALOG:
      break;
    case WM_INITMENU:
      break;
    case WM_COMMAND:
      break;
    case WM_SYSCOMMAND:
      break;

    case WM_ENDSESSION:
      return 0;
      break;
    case WM_QUERYENDSESSION:
      return TRUE;
      break;
    case WM_QUIT:
      break;

    }
  return 0;
  }

LRESULT DefWindowProcStaticWC(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      SetTextColor(&hWnd->hDC /* ovvero (HDC *)wParam */,windowBackColor);
      FillRect(&hWnd->hDC,&rc);
      switch(hWnd->style & 0xff) {
        case SS_LEFT:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,0,0,hWnd->caption);
          break;
        case SS_CENTER:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple)/2,0,hWnd->caption);
          break;
        case SS_RIGHT:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple,0,hWnd->caption);
          break;
        case SS_ICON:
          DrawIcon8(&hWnd->hDC,0,0,hWnd->icon);
          break;
        case SS_BITMAP:
//          DrawIcon(&hWnd->hDC,0,0,hWnd->icon);
          break;
        case SS_BLACKFRAME:
          SetTextColor(&hWnd->hDC,BLACK);
          Rectangle(&hWnd->hDC,rc.left,rc.top,rc.right,rc.bottom);
          break;
        case SS_GRAYFRAME:
          SetTextColor(&hWnd->hDC,LIGHTGRAY);
          Rectangle(&hWnd->hDC,rc.left,rc.top,rc.right,rc.bottom);
          break;
        case SS_WHITEFRAME:
          SetTextColor(&hWnd->hDC,WHITE);
          Rectangle(&hWnd->hDC,rc.left,rc.top,rc.right,rc.bottom);
          break;
        case SS_BLACKRECT:
          SetTextColor(&hWnd->hDC,BLACK);
          SetBkColor(&hWnd->hDC,windowBackColor);
          FillRect(&hWnd->hDC,&rc);
          break;
        case SS_GRAYRECT:
          SetTextColor(&hWnd->hDC,LIGHTGRAY);
          SetBkColor(&hWnd->hDC,windowBackColor);
          FillRect(&hWnd->hDC,&rc);
          break;
        case SS_WHITERECT:
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,windowBackColor);
          FillRect(&hWnd->hDC,&rc);
          break;
        case SS_SUNKEN:
          break;
        }
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      cs->style |= WS_DISABLED;   // direi
      cs->style &= ~WS_ACTIVE;   // direi
      if((cs->style & 0xff) == SS_ICON)
        cs->cx=cs->cy=8 + (hWnd->style & WS_BORDER ? 2 : 0); // type ecc..
      else
        cs->cy=hWnd->font.fontSimple*8 + (hWnd->style & WS_BORDER ? 2 : 0); // 
      }
      return 0;
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      nonClientPaint(hWnd,NULL /*area titolo...*/);
      return 1;
      break;

    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcEditWC(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_NCPAINT:
      return nonClientPaint(hWnd,(RECT *)wParam);
      break;
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      SetTextColor(&hWnd->hDC,hWnd->active ? GRAY224 : GRAY128);
      FillRect(&hWnd->hDC,&rc);
      
      SetTextColor(&hWnd->hDC,WHITE);
      TextOut(&hWnd->hDC,0,0,hWnd->caption);    // ovviamente finire :)
      }
      return 1;
      break;
    case WM_CHAR:
    { char buf[8];
      buf[0]=wParam; buf[1]=0;
      TextOut(&hWnd->hDC,hWnd->hDC.cursorX,hWnd->hDC.cursorY,buf);
    }
      break;
    case WM_SETFOCUS:
      // caret..
      break;
    case WM_KILLFOCUS:
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      nonClientPaint(hWnd,NULL /*area titolo...*/);
      return 1;
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcButtonWC(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_NCPAINT:
      return nonClientPaint(hWnd,(RECT *)wParam);
      break;
    case WM_PAINT:
      return clientPaint(hWnd,NULL /*sarebbe l'area accumulata da invalidate...*/);
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      SetTextColor(&hWnd->hDC,GRAY128);
      FillRect(&hWnd->hDC,&rc);
      switch(hWnd->style & 0x0ff0) {
        case BS_LEFTTEXT:
          //boh
        case BS_LEFT:
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,0,0,hWnd->caption);
          break;
        case BS_TEXT:
          //boh
        case BS_CENTER:
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple)/2,0,hWnd->caption);
          break;
        case BS_RIGHT:
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple,0,hWnd->caption);
          break;
        case BS_TOP:
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple)/2,0,hWnd->caption);
          break;
        case BS_BOTTOM:
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple)/2,rc.bottom-hWnd->font.fontSimple*8,hWnd->caption);
          break;
        case BS_VCENTER:
          SetTextColor(&hWnd->hDC,hWnd->active ? WHITE : GRAY192);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,(rc.right-strlen(hWnd->caption)*6*hWnd->font.fontSimple)/2,(rc.bottom-hWnd->font.fontSimple*8)/2,hWnd->caption);
          break;
        case BS_ICON:
          DrawIcon8(&hWnd->hDC,0,0,hWnd->icon);
          break;
        }
      }
      return 1;
      break;
    case WM_CHAR:
    { char buf[8];
      if(wParam)    // hot key??
        ;
    }
      break;
    case WM_SETTEXT:
      strncpy(hWnd->caption,(const char *)lParam,sizeof(hWnd->caption)-1);
      hWnd->caption[sizeof(hWnd->caption)-1]=0;
      nonClientPaint(hWnd,NULL /*area titolo...*/);
      return 1;
      break;

    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcDirDlgWC(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
#if 0
//      InvalidateRect(hWnd,(RECT *)wParam,lParam);
      //clientPaint(hWnd,(RECT *)wParam);
      {
      SearchRec rec;
      int i; UGRAPH_COORD x,y;
      BYTE tipoVis;
      RECT rc;
      
      GetClientRect(hWnd,&rc);
      if(!SDcardOK)
        return 0;
      if(!FindFirst("*.*", ATTR_VOLUME, &rec)) {
        sp("\tVolume is "); sp(rec.filename); speol();
        }
      if(*nome)
        i=FindFirst(nome, ATTR_MASK ^ ATTR_VOLUME, &rec);
      else
        i=FindFirst("*.*", ATTR_MASK ^ ATTR_VOLUME, &rec);
      if(!i) {
        x=0; y=0;
        do {
          switch(tipoVis) {
            case 0:     // icone
              TextOut(&hWnd->hDC,x+4,y+4+8+2,rec.filename); 
              if(rec.attributes & ATTR_DIRECTORY) {
                DrawIcon8(&hWnd->hDC,x+4,y+4,folderIcon);
                sp("DIR"); 
                }
              else {
                printInteger(rec.filesize,9,' '); spb(9);
                printInteger((rec.timestamp >> 16) & 31, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (5+16)) & 15, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (9+16)) + 1980, 4, '0');
                spb(' ');
                printInteger((rec.timestamp >> 11) & 31, 2, '0');
                spb(':');
                printInteger((rec.timestamp >> 5) & 63, 2, '0');
                spb(':');
                printInteger(rec.timestamp & 63, 2, '0');
                }
              x+=32;
              if(x>rc.right) {
                x=0;
                y+=8;
                if(y>rc.bottom)
                }
              break;
            case 1:
              TextOut(&hWnd->hDC,x+2,y+2,rec.filename); 
              if(rec.attributes & ATTR_DIRECTORY) {
                DrawIcon8(&hWnd->hDC,x+20+2,y+2,folderIcon);
                TextOut(&hWnd->hDC,x+2,y+2,"DIR");
                }
              else {
                printInteger(rec.filesize,9,' '); spb(9);
                TextOut(&hWnd->hDC,x+2,y+2,buf);
                printInteger((rec.timestamp >> 16) & 31, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (5+16)) & 15, 2, '0');
                spb('/');
                printInteger((rec.timestamp >> (9+16)) + 1980, 4, '0');
                spb(' ');
                printInteger((rec.timestamp >> 11) & 31, 2, '0');
                spb(':');
                printInteger((rec.timestamp >> 5) & 63, 2, '0');
                spb(':');
                printInteger(rec.timestamp & 63, 2, '0');
                TextOut(&hWnd->hDC,x+2,y+2,buf);
                y+=8;
                if(y>rc.bottom)
                  break;
                }
              break;
            }
          } while(!FindNext(&rec));
        do {
          FSGetDiskProperties(&disk_properties);
          ClrWdt();
          } while(disk_properties.properties_status == FS_GET_PROPERTIES_STILL_WORKING);
          if(disk_properties.properties_status == FS_GET_PROPERTIES_NO_ERRORS) {
            printInteger(disk_properties.results.free_clusters*disk_properties.results.sectors_per_cluster*disk_properties.results.sector_size/1024,12,' '); 
            TextOut(&hWnd->hDC,x+4,y+8+2,rec.filename); 
            }
          else
            TextOut(&hWnd->hDC,x+4,y+8+2,"?"); 
          TextOut(&hWnd->hDC,x+4,y+8+2," Kbytes free");
          }
        }
#endif
      return 1;
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      SetTextColor(&hWnd->hDC,windowBackColor);
      FillRect(&hWnd->hDC,&rc);
      
      
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,0,0,"DIR");
          
          DrawIcon8(&hWnd->hDC,0,16,folderIcon);
          
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 0;
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

LRESULT DefWindowProcDC(HWND hWnd,unsigned int message,WPARAM wParam,LPARAM lParam) {
  
  switch(message) {
    case WM_PAINT:
      {
      HWND myWnd;
  
      myWnd=rootWindows;
      while(myWnd) {
        if(myWnd->visible) {
          DrawIcon8(&hWnd->hDC,4+(maxWindows-myWnd->zOrder)*10 /* :) */,_height-16,myWnd->icon);
          }
        myWnd=myWnd->next;
        }
      }
      return 1;
      break;
    case WM_ERASEBKGND:
      {RECT rc;
      GetClientRect(hWnd,&rc);
      SetTextColor(&hWnd->hDC,windowBackColor);
      FillRect(&hWnd->hDC,&rc);
      
      
          SetTextColor(&hWnd->hDC,WHITE);
          SetBkColor(&hWnd->hDC,windowBackColor);
          TextOut(&hWnd->hDC,0,0,"BREAKTHROUGH");
          
//          DrawBitmap(&hWnd->hDC,0,16,   logl);
          
      }
      return 1;
      break;
    case WM_CREATE:
      {CREATESTRUCT *cs=(CREATESTRUCT *)lParam;
      }
      return 0;
      break;
      
    default:
      return DefWindowProc(hWnd,message,wParam,lParam);
      break;
    }
  return 0;
  }

static void calculateClientArea(HWND hWnd,RECT *rc) {
  
  *rc=hWnd->nonClientArea;
  if(hWnd->style & WS_BORDER) {
    rc->top++;
    rc->bottom--;
    rc->left++;
    rc->right--;
    if(hWnd->style & WS_THICKFRAME) {
      rc->top++;
      rc->bottom--;
      rc->left++;
      rc->right--;
      }
    }
  if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
    rc->top+=TITLE_HEIGHT;
    }
  if(hWnd->style & WS_HSCROLL) {
    rc->bottom-= hWnd->style & WS_BORDER ? SCROLL_SIZE-1 : SCROLL_SIZE; // se c'� bordo, lo scroll usa il bordo, se no no!
    }
//  else
  rc->bottom--;    // strana patch... verificare!
  if(hWnd->style & WS_VSCROLL) {
    rc->right-= hWnd->style & WS_BORDER ? SCROLL_SIZE-1 : SCROLL_SIZE;
    }
//  else
  rc->right--;    // strana patch... verificare!
  }

static void calculateNonClientArea(HWND hWnd,RECT *rc) {

  if(hWnd->style & (WS_HSCROLL | WS_VSCROLL)) {
    hWnd->scrollSizeX= rc->right-rc->left - (hWnd->style & WS_VSCROLL ? SCROLL_SIZE : 0);
    // forse pure -border...
    hWnd->scrollSizeX /= 3;   // test..
    hWnd->scrollSizeY=rc->bottom-rc->top  - (hWnd->style & WS_HSCROLL ? SCROLL_SIZE : 0)
      - (hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION) ? TITLE_HEIGHT : 0);
    hWnd->scrollSizeY /= 3;   // test..
    }
  else {
    hWnd->scrollSizeX=hWnd->scrollSizeY=0;
    }
  }

static void readClassInfo(CLASS className,WINDOWPROC **wproc,DWORD *flags,GFX_COLOR **picon,WNDCLASS *ci) {
  
  switch(className.class) {
    case WC_BUTTON:
      *wproc=(WINDOWPROC *)DefWindowProcButtonWC;
      break;
    case WC_COMBOBOX:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_EDIT:
      *wproc=(WINDOWPROC *)DefWindowProcEditWC;
      break;
    case WC_LISTBOX:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_SCROLLBAR:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_STATIC:
      *wproc=(WINDOWPROC *)DefWindowProcStaticWC;
      break;
    case WC_HOTKEY:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_PROGRESS:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_STATUS :
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_TRACKBAR:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_UPDOWN:
      *wproc=(WINDOWPROC *)DefWindowProc;
      break;
    case WC_DIRDLG:
      *wproc=(WINDOWPROC *)DefWindowProcDirDlgWC;
      break;

    case WC_DESKTOPCLASS:
      *wproc=(WINDOWPROC *)DefWindowProcDC;
      break;

    case WC_DEFAULTCLASS:
    default:
      *wproc=(WINDOWPROC *)DefWindowProc;
      // e poi le altre da RegisterClass 
      break;
    }
  }

int RegisterClassA(const WNDCLASS *lpWndClass) {
  }

BOOL UnregisterClassA(CLASS Class, HINSTANCE hInstance) {
  }

HWND FindWindowA(CLASS Class, char *lpWindowName) {
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
//    if(myWnd->visible && myWnd->enabled && PtInRect(&myWnd->nonClientArea,pt)) {
//      return myWnd;
//      }
    myWnd=myWnd->next;
    }
  }

BOOL GetClassInfo(HINSTANCE hInstance, CLASS Class, WNDCLASS *lpWndClass) {
  }

int GetClassName(HWND hWnd,CLASS *Class) {
  
  *Class=hWnd->class;
  }

static BOOL nonClientPaint(HWND hWnd,const RECT *rc) {
  WORD newtop,newbottom,newleft,newright;
  GFX_COLOR itemsColor;
  
//#ifndef USING_SIMULATOR
  if(!(hWnd->style & WS_VISIBLE))
    return 0;

  if(rc) {    // per ora non usato... ridisegnamo sempre tutta la window
    newtop=rc->top;
    newbottom=rc->bottom;
    newleft=rc->left;
    newright=rc->right;
    }
  else {
    newtop=hWnd->nonClientArea.top;
    newbottom=hWnd->nonClientArea.bottom;
    newleft=hWnd->nonClientArea.left;
    newright=hWnd->nonClientArea.right;
    }

  if(hWnd->minimized) {
    // FINIRE! disegnare icona dove??
    DrawIcon8(&hWnd->hDC,4+(maxWindows-hWnd->zOrder)*10 /* :) */,_height-16,hWnd->icon);
    // v. anche desktopclass
    return;
    }
  if(hWnd->maximized) {
    // FINIRE! o forse non serve altro, una volta cambiate le dimensioni..
    }
  itemsColor=hWnd->active ? windowForeColor : windowInactiveForeColor;
  // e hWnd->enabled ??
  switch(videoMode) {
    case MODE_LCD:
      fillRectLCD(newleft,newtop,newright-newleft,newbottom-newtop,windowBackColor);
      // ev. provare writeFillRectPreclipped
      if(hWnd->style & WS_BORDER) {
#warning USARE funzioni con CLIP :) ovviamente
        
        if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
          // forse inutile quando andremo in RAM
          drawRectLCD(newleft,newtop,newright-newleft,newbottom-newtop,itemsColor);
          }
        else {
          HDC myHDC;
          
          myHDC.area.top=myHDC.area.left=0;
          myHDC.area.right=hWnd->nonClientArea.right-hWnd->nonClientArea.left;
          myHDC.area.bottom=hWnd->nonClientArea.bottom-hWnd->nonClientArea.top;
          DrawHorizLineWindow(&myHDC,newleft,newtop,newright,itemsColor);
          DrawHorizLineWindow(&myHDC,newleft,newbottom,newright,itemsColor);
          DrawVertLineWindow(&myHDC,newleft,newtop,newbottom,itemsColor);
          DrawVertLineWindow(&myHDC,newright,newtop,newbottom,itemsColor);
          }

        if(hWnd->style & WS_THICKFRAME) {
          
          if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
            // forse inutile quando andremo in RAM
            drawRectLCD(newleft+1,newtop+1,newright-1-newleft-1,newbottom-1-newtop-1,
              itemsColor);
            }
          else {
          HDC myHDC;
          
          myHDC.area=hWnd->nonClientArea;
            DrawHorizLineWindow(&myHDC,newleft+1,newtop+1,newright-1,itemsColor);
            DrawHorizLineWindow(&myHDC,newleft+1,newbottom-1,newright-1,itemsColor);
            DrawVertLineWindow(&myHDC,newleft+1,newtop+1,newbottom-1,itemsColor);
            DrawVertLineWindow(&myHDC,newright-1,newtop+1,newbottom-1,itemsColor);
            }
          
          }
        }
      if(hWnd->style & WS_THICKFRAME) {
        newtop++;
        newbottom--;
        newleft++;
        newright--;
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLineLCD(newleft+TITLE_ICON_WIDTH+2,newtop,newleft+TITLE_ICON_WIDTH+2,newtop+TITLE_HEIGHT,
          itemsColor);
        }
      if(hWnd->style & WS_SYSMENU) {
        fillRectLCD(newleft+2,newtop+2,TITLE_ICON_WIDTH-1,TITLE_ICON_WIDTH-1,itemsColor);
        newleft=newleft+TITLE_ICON_WIDTH+2;
      // metto anche closebox, fisso, a dx? insieme a sysmenu?
        drawLineLCD(newright-3,newtop+3,newright-TITLE_ICON_WIDTH+1,newtop+TITLE_ICON_WIDTH-1,
          itemsColor);
        drawLineLCD(newright-TITLE_ICON_WIDTH+1,newtop+3,newright-3,newtop+TITLE_ICON_WIDTH-1,
          itemsColor);
        drawLineLCD(newright-(TITLE_ICON_WIDTH+1),newtop,newright-(TITLE_ICON_WIDTH+1),newtop+TITLE_HEIGHT,
          itemsColor);
        newright -= TITLE_ICON_WIDTH+1;
        }
      if(hWnd->style & WS_MAXIMIZEBOX) {
        drawLineLCD(newright-2,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,
          itemsColor);
        drawLineLCD(newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+3,newright-(TITLE_ICON_WIDTH-1)+1,newtop+TITLE_ICON_WIDTH/2+2,
          itemsColor);
        drawLineLCD(newright-TITLE_ICON_WIDTH,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_HEIGHT,
          itemsColor);
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->style & WS_MINIMIZEBOX) {
        drawLineLCD(newright-2,newtop+3,newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,
          itemsColor);
        drawLineLCD(newright-(TITLE_ICON_WIDTH-1)/2-1,newtop+TITLE_ICON_WIDTH/2+2,newright-(TITLE_ICON_WIDTH-1)+1,newtop+3,
          itemsColor);
        drawLineLCD(newright-TITLE_ICON_WIDTH,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_HEIGHT,
          itemsColor);
        newright -= TITLE_ICON_WIDTH;
        }
      if(hWnd->style & WS_CAPTION) {
        char *s=hWnd->caption;
        setColors(itemsColor, windowBackColor);
        cursor_x=newleft+2; cursor_y=newtop+1;
        while(*s) {   // nonclient area, non uso TextOut...
          cwrite(*s++);
          if(cursor_x>=(newright-6) || cursor_y>(newtop+1))   // 1 sola riga, trim a dx
            break;
          }
        }
      if(rc) {    // ripristino
        newleft=rc->left;
        newright=rc->right;
        }
      else {
        newleft=hWnd->nonClientArea.left;
        newright=hWnd->nonClientArea.right;
        if(hWnd->style & WS_THICKFRAME) {
          newleft++;
          newright--;
          }
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLineLCD(newleft,newtop+TITLE_HEIGHT,newright-1,newtop+TITLE_HEIGHT,itemsColor);
        newtop=newtop+TITLE_HEIGHT;
        }
      if(hWnd->menu) {
        drawLineLCD(newleft,newtop+TITLE_HEIGHT,newright-1,newtop+MENU_HEIGHT,itemsColor);
//        TextOut(1,newtop,"menu");
        // fare...
        newtop=newtop+MENU_HEIGHT;
        }
      if(hWnd->style & WS_HSCROLL) {
        drawLineLCD(newleft,newbottom-SCROLL_SIZE,newright-1,newbottom-SCROLL_SIZE,
                itemsColor);
        fillRectLCD(newleft+2+hWnd->scrollPosX,newbottom-SCROLL_SIZE+2,hWnd->scrollPosX+hWnd->scrollSizeX,SCROLL_SIZE-4,
                itemsColor);
        }
      if(hWnd->style & WS_VSCROLL) {
        drawLineLCD(newright-SCROLL_SIZE,newtop,newright-SCROLL_SIZE,newbottom-1,
                itemsColor);
        fillRectLCD(newright-SCROLL_SIZE+2,newtop+2+hWnd->scrollPosY,SCROLL_SIZE-4,hWnd->scrollPosY+hWnd->scrollSizeY,
                itemsColor);
        }
      if(hWnd->style & WS_SIZEBOX) {
        drawLineLCD(newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom-1,
          itemsColor);
        }

      break;
      
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectFilled(rc,windowBackColor);
      if(hWnd->style & WS_BORDER) {
        drawRect(rc,itemsColor);
        if(hWnd->style & WS_THICKFRAME) {
          drawRectangle(newleft+1,newtop+1,newright-1,newbottom-1,itemsColor);
          }
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLine(newleft+TITLE_ICON_WIDTH+2,newtop,newleft+TITLE_ICON_WIDTH+2,newtop+TITLE_HEIGHT,
          itemsColor);
        }
      if(hWnd->style & WS_SYSMENU) {
        drawRectangleFilled(newleft+2,newtop+2,newleft+2+TITLE_ICON_WIDTH,newtop+2+TITLE_ICON_WIDTH,
                itemsColor);
        newleft=newleft+TITLE_ICON_WIDTH+2;
        drawLine(newright-1,newtop,newright-TITLE_ICON_WIDTH,newtop+TITLE_ICON_WIDTH+1,
          itemsColor);
        drawLine(newright-TITLE_ICON_WIDTH,newtop,newright-1,newtop+TITLE_ICON_WIDTH+1,
          itemsColor);
        }
      if(hWnd->style & WS_MAXIMIZEBOX) {
        newright=newright-(TITLE_ICON_WIDTH+2);
        }
      if(hWnd->style & WS_MINIMIZEBOX) {
        newright=newright-(TITLE_ICON_WIDTH+2);
        }
      // mettere anche closebox, fisso, a dx? o va insieme a sysmenu?
      if(hWnd->style & WS_CAPTION) {
        char *s=hWnd->caption;
       
        cursor_x=newleft+1; cursor_y=newtop+1;
        while(*s) {   // nonclient area, non uso TextOut...
          writeChar(cursor_x,cursor_y,*s,itemsColor); //
   				cursor_x+=8;
          if(cursor_x>=(newright-8) || cursor_y>(newtop+1))   // 1 sola riga, trim a dx
            break;
          s++;
          }
        }
      if(rc) {
        newleft=rc->left;
        newright=rc->right;
        }
      else {
        newleft=hWnd->nonClientArea.left;
        newright=hWnd->nonClientArea.right;
        }
      if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION)) {
        drawLineLCD(newleft,newtop+TITLE_HEIGHT,newright,newtop+TITLE_HEIGHT,
          itemsColor);
        newtop=newtop+TITLE_HEIGHT;
        }
      if(hWnd->style & WS_HSCROLL) {
        drawLine(newleft,newbottom-SCROLL_SIZE,newright,newbottom-SCROLL_SIZE,
                itemsColor);
        drawRectangleFilled(newleft+hWnd->scrollPosX+1,newbottom-SCROLL_SIZE+1,newleft+1+hWnd->scrollPosX+hWnd->scrollSizeX,newbottom-1,
                itemsColor);
        }
      if(hWnd->style & WS_VSCROLL) {
        drawLine(newright-SCROLL_SIZE,newtop,newright-SCROLL_SIZE,newbottom,
                itemsColor);
        drawRectangleFilled(newright-SCROLL_SIZE+1,newtop+hWnd->scrollPosY+1,newright-1,newtop+1+hWnd->scrollPosY+hWnd->scrollSizeY,
                itemsColor);
        }
      if(hWnd->style & WS_SIZEBOX) {
        drawLine(newright-1,newbottom-TITLE_ICON_WIDTH,newright-TITLE_ICON_WIDTH,newbottom+1,
          itemsColor);
        }

      break;
    }
//#endif
  
  return 1;
  }

static BOOL clientPaint(HWND hWnd,const RECT *rc) {
  HWND myWnd;
  
  if(!(hWnd->style & WS_VISIBLE))
    return;
  if(!rc)
    rc=&hWnd->clientArea;
  
  // ora ridisegno tutte le child
  myWnd=rootWindows;
  while(myWnd) {
    
    WS_CLIPSIBLINGS; //gestire
    
    if(myWnd->parent == hWnd /* WS_CHILD*/) {
      SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL /*upd region*/,0);
  		InvalidateRect(myWnd,NULL,TRUE);    // o usare ERASE/PAINT??
      }
    myWnd=myWnd->next;
    }

  return 1;
  }

BOOL InvalidateRect(HWND hWnd,const RECT *rc,BOOL bErase) {

  if(!hWnd) {   // https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
    PaintDesktop(NULL);
    SendMessage(HWND_BROADCAST,WM_NCPAINT,(WPARAM)NULL /*upd region*/,0);
    SendMessage(HWND_BROADCAST,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    SendMessage(HWND_BROADCAST,WM_PAINT,0,0);
    }
  else {
    if(bErase) {    // banalmente, per ora facciam cos�
      if(!SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0)) {
#ifndef USING_SIMULATOR
        FillRectangleWindow(&hWnd->hDC,rc->left,rc->top,rc->right-rc->left,rc->bottom-rc->top,
          windowBackColor);
#endif
        }
      }
    // accumulare le aree paint...
    SendMessage(hWnd,WM_PAINT,0,0);
    }
  
  return 1;
  }

UINT SetTimer(HWND hWnd,UINT nIDEvent,UINT uElapse,TIMERPROC lpTimerFunc) {
  int i;
  
  for(i=0; i<MAX_TIMERS; i++) {
    if(!timerData[i].uEvent) {
      timerData[i].hWnd=hWnd;
      timerData[i].uEvent=nIDEvent;
      timerData[i].timeout=uElapse;
      timerData[i].tproc=lpTimerFunc;
      timerData[i].time_cnt=0;
      return i+1;
      }
    }
  return 0;
  }

BOOL KillTimer(HWND hWnd,UINT uIDEvent) {
  int i;
  
  for(i=0; i<MAX_TIMERS; i++) {
    if(timerData[i].uEvent == uIDEvent) {
      timerData[i].uEvent=0;
      timerData[i].hWnd=0;
      timerData[i].timeout=0;
      timerData[i].tproc=NULL;
      timerData[i].time_cnt=0;
      return TRUE;
      }
    }
  return FALSE;
  }

BOOL EnableWindow(HWND hWnd,BOOL bEnable) {
  
  SendMessage(hWnd,WM_ENABLE,bEnable,0);
  }

BOOL DestroyWindow(HWND hWnd) {

  SendMessage(hWnd,WM_DESTROY,0,0);
  SendMessage(hWnd,WM_NCDESTROY,0,0);
  removeWindow(hWnd);
  list_bubble_sort(&rootWindows);
  free(hWnd);
  }

BOOL CloseWindow(HWND hWnd) {
  
  hWnd->minimized=1;
  SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  SendMessage(hWnd,WM_PAINT,0,0);
  }

BOOL RedrawWindow(HWND hWnd,const RECT *lprcUpdate,int /*HRGN*/ hrgnUpdate,UINT flags) {
  
  if(flags & RDW_ERASE) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    }
  if(flags & RDW_INVALIDATE) {
    SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    SendMessage(hWnd,WM_PAINT,0,0);
    }
  }

BOOL UpdateWindow(HWND hWnd) {
  
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  SendMessage(hWnd,WM_PAINT,0,0);
  }
  
BOOL SetWindowPos(HWND hWnd,HWND hWndInsertAfter,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,
  UGRAPH_COORD_T cx,UGRAPH_COORD_T cy, DWORD uFlags) {
  RECT oldNCarea,oldArea;
  int temp;
  
  if(uFlags) {    // bah, controllare
    WINDOWPOS wpos;
    wpos.hwnd=hWnd;
    wpos.hwndInsertAfter=hWndInsertAfter;
    wpos.x=X;
    wpos.y=Y;
    wpos.cx=cx;
    wpos.cy=cy;
    wpos.flags=uFlags;
    SendMessage(hWnd,WM_WINDOWPOSCHANGING,0,(LPARAM)&wpos);
    }
  if(!(uFlags & SWP_NOACTIVATE)) {
    if(hWnd->enabled)
  		setActive(hWnd,TRUE);
		}
  if(uFlags & SWP_HIDEWINDOW)
    hWnd->visible=0;
  if(uFlags & SWP_SHOWWINDOW)   // bah :) cmq vince questo
    hWnd->visible=1;
  if(!(uFlags & SWP_NOREPOSITION)) {
    oldNCarea=hWnd->nonClientArea;
    oldArea=hWnd->clientArea;
    if(!(uFlags & SWP_NOMOVE)) {
      hWnd->nonClientArea.left=X;
      hWnd->nonClientArea.top=Y;
      hWnd->clientArea.left+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->clientArea.top+=hWnd->nonClientArea.top-oldNCarea.top;
      SendMessage(hWnd,WM_MOVE,0,MAKEWORD(hWnd->clientArea.left,hWnd->clientArea.top));
      }
    if(!(uFlags & SWP_NOSIZE)) {
      hWnd->nonClientArea.right=hWnd->nonClientArea.left+cx;
      hWnd->nonClientArea.bottom=hWnd->nonClientArea.top+cy;
      hWnd->clientArea.right+=hWnd->nonClientArea.right-oldNCarea.right;
      hWnd->clientArea.bottom+=hWnd->nonClientArea.bottom-oldNCarea.bottom;
      SendMessage(hWnd,WM_SIZE,SIZE_RESTORED,MAKEWORD(hWnd->clientArea.right-hWnd->clientArea.left,hWnd->clientArea.bottom-hWnd->clientArea.top));
      }
    else {
      hWnd->nonClientArea.right+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->nonClientArea.bottom+=hWnd->nonClientArea.top-oldNCarea.top;
      hWnd->clientArea.right+=hWnd->nonClientArea.left-oldNCarea.left;
      hWnd->clientArea.bottom+=hWnd->nonClientArea.top-oldNCarea.top;
      }
    }
  if(!(uFlags & SWP_NOZORDER /* SWP_NOOWNERZORDER che �? */)) {
    switch((int)hWndInsertAfter) {
      case (int)HWND_BOTTOM:
        hWnd->topmost=0;
        temp=rootWindows->zOrder;
        rootWindows->zOrder=hWnd->zOrder;
        hWnd->zOrder=temp;
        break;
      case (int)HWND_NOTOPMOST:
        hWnd->topmost=0;
        break;
      case (int)HWND_TOP:
        hWnd->topmost=0;
hwnd_top:
        {
        HWND myWnd=rootWindows;
        while(myWnd)
          myWnd=myWnd->next;
        temp=myWnd->zOrder;
        myWnd->zOrder=hWnd->zOrder;
        }
        hWnd->zOrder=temp;
        break;
      case (int)HWND_TOPMOST:
        hWnd->topmost=1;
        goto hwnd_top;
        break;
      default:
        insertWindow(hWnd,hWndInsertAfter);
        break;
      }
    list_bubble_sort(&rootWindows);
    }
  {
  WINDOWPOS wpos;
  wpos.hwnd=hWnd;
  wpos.hwndInsertAfter=NULL /*boh*/;
  wpos.x=hWnd->nonClientArea.left;
  wpos.y=hWnd->nonClientArea.top;
  wpos.cx=hWnd->nonClientArea.right-hWnd->nonClientArea.left;
  wpos.cy=hWnd->nonClientArea.bottom-hWnd->nonClientArea.top;
  wpos.flags=hWnd->style;
  SendMessage(hWnd,WM_WINDOWPOSCHANGED,0,(LPARAM)&wpos);    // boh sempre
  }
  
  if(!(uFlags & SWP_NOREDRAW)) {
    SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    SendMessage(hWnd,WM_PAINT,0,0);
    }
  return 1;
  }

BOOL MoveWindow(HWND hWnd,UGRAPH_COORD_T X,UGRAPH_COORD_T Y,UGRAPH_COORD_T nWidth,UGRAPH_COORD_T nHeight,BOOL bRepaint) {
  
  return SetWindowPos(hWnd,NULL,X,Y,nWidth,nHeight,
    SWP_NOSENDCHANGING | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_NOACTIVATE
    | (bRepaint ? 0 : SWP_NOREDRAW)
    );
  }

BOOL OpenIcon(HWND hWnd) {
  
  return ShowWindow(hWnd,SW_SHOWNORMAL);
  }

BOOL ShowWindow(HWND hWnd,BYTE nCmdShow) {
  
  switch(nCmdShow) {
    case SW_HIDE:
      hWnd->visible=0;
			setActive(hWnd,FALSE);
      break;
    case SW_SHOWNORMAL:
//    case SW_NORMAL:
      if(hWnd->maximized) {
        hWnd->nonClientArea=hWnd->savedArea;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
				SendMessage(HWND_BROADCAST,WM_SHOWWINDOW,TRUE,SW_OTHERUNZOOM);		// mandare a TUTTI!
        InvalidateRect(NULL,NULL,TRUE);
        }
      hWnd->maximized=0;
      hWnd->minimized=0;
      // prosegue
    case SW_SHOW:
      hWnd->visible=1;
      if(hWnd->enabled)
        setActive(hWnd,TRUE);
      break;
    case SW_SHOWMINIMIZED:
      hWnd->visible=1;
      if(hWnd->enabled)
  			setActive(hWnd,TRUE);
    case SW_MINIMIZE:
      hWnd->minimized=1;
      if(hWnd->maximized) {
        hWnd->nonClientArea=hWnd->savedArea;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
        nonClientPaint(NULL,NULL);
        }
      hWnd->maximized=0;
      break;
    case SW_SHOWMAXIMIZED:
//    case SW_MAXIMIZE:
      if(!hWnd->maximized) {
        hWnd->savedArea=hWnd->nonClientArea;
        hWnd->nonClientArea.top=0;
        hWnd->nonClientArea.left=0;
        hWnd->nonClientArea.bottom=_height;
        hWnd->nonClientArea.right=_width;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
				SendMessage(HWND_BROADCAST,WM_SHOWWINDOW,FALSE,SW_OTHERZOOM);		// mandare a TUTTI!
        }
      hWnd->maximized=1;
      hWnd->minimized=0;
      hWnd->visible=1;
      if(hWnd->enabled)
  			setActive(hWnd,TRUE);
      break;
    case SW_SHOWNOACTIVATE:
    case SW_SHOWNA:
      hWnd->visible=1;
      hWnd->maximized=hWnd->minimized=0;
      break;
    case SW_SHOWMINNOACTIVE:
      hWnd->visible=1;
      if(hWnd->enabled)
  			setActive(hWnd,FALSE);
      hWnd->minimized=1;
      hWnd->maximized=0;
      break;
    case SW_RESTORE:
      if(hWnd->maximized) {
        hWnd->nonClientArea=hWnd->savedArea;
        calculateClientArea(hWnd,&hWnd->clientArea);
        calculateNonClientArea(hWnd,&hWnd->nonClientArea);
        nonClientPaint(NULL,NULL);
        }
      hWnd->maximized=hWnd->minimized=0;
      break;
    default:
      break;
    }
  SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  return SendMessage(hWnd,WM_PAINT,0,0);
  }

BOOL BringWindowToTop(HWND hWnd) {
  HWND myWnd;
  BYTE temp;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd->zOrder==maxWindows) {   // ovvero andare al fondo della lista
      temp=hWnd->zOrder;
      hWnd->zOrder=myWnd->zOrder;
      myWnd->zOrder=temp;
      list_bubble_sort(&rootWindows);
      return 1;
      }
    myWnd=myWnd->next;
    }
  return 0;   //NON deve accadere
  }

HWND GetTopWindow(HWND hWnd) {
  HWND myWnd,myWnd2;
//  BYTE minZorder=255;
  
  if(hWnd) {    // child windows...
    }
  else {
    myWnd=rootWindows;
    while(myWnd) {
      myWnd2=myWnd;
      myWnd=myWnd->next;
      }
    return myWnd2;
    }
  }

BOOL SetForegroundWindow(HWND hWnd) {
  HWND myWnd;
  BYTE temp;

  // basterebbe setActive? o no??
  myWnd=rootWindows;
  while(myWnd && myWnd->next) {   // vado al fondo
    myWnd=myWnd->next;
    }
  temp=myWnd->zOrder;
  myWnd->zOrder=hWnd->zOrder;
  hWnd->zOrder=temp;
  list_bubble_sort(&rootWindows);
  }

HWND SetParent(HWND hWndChild,HWND hWndNewParent) {
  HWND hWnd=hWndChild->parent;
  
  if(hWndChild->style & WS_CHILD)
    hWndChild->parent=hWndNewParent;
  return hWnd;
  }

HWND GetParent(HWND hWnd) {
  return hWnd->parent;
  }

BOOL GetClientRect(HWND hWnd,RECT *lpRect) {
  
  lpRect->left=lpRect->top=0;
  lpRect->right=hWnd->clientArea.right-hWnd->clientArea.left;
  lpRect->bottom=hWnd->clientArea.bottom-hWnd->clientArea.top;
  }

BOOL GetWindowRect(HWND hWnd,RECT *lpRect) {
  
  *lpRect=hWnd->nonClientArea;
  }

BOOL SetIcon(HWND hWnd,const GFX_COLOR *icon,BYTE type) {

  return SendMessage(hWnd,WM_SETICON,type,(LPARAM)icon);
  }

BOOL SetFont(HWND hWnd,FONT font) { // questa in effetti non esiste, si userebbero i SelectObject...

  SendMessage(hWnd,WM_SETFONT,(WPARAM)font.font,TRUE);
  }

BOOL IsWindow(HWND hWnd) {
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd == hWnd)
      return TRUE;
    myWnd=myWnd->next;
    }
  return FALSE;
  }

BOOL IsZoomed(HWND hWnd) { 
  return hWnd->maximized;
  }

HWND setActive(HWND hWnd,BOOL state) {
  HWND myWnd;
  BYTE temp;
  
  if(state) {
    myWnd=rootWindows;
    while(myWnd) {
      if(myWnd != hWnd && myWnd->active) {  // tendenzialmente dovrebbe essere sempre l'ultima, quella attiva...
        SendMessage(myWnd,WM_ACTIVATE,WA_INACTIVE,(LPARAM)hWnd);
        myWnd->active=0;
        SendMessage(myWnd,WM_NCPAINT,(WPARAM)NULL,0);
        SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
        SendMessage(myWnd,WM_PAINT,0,0);
        if(hWnd->zOrder < myWnd->zOrder) {
          temp=hWnd->zOrder;
          hWnd->zOrder=myWnd->zOrder;
          myWnd->zOrder=temp;
          list_bubble_sort(&rootWindows);
          }
        break;
        }
      myWnd=myWnd->next;
      }
    hWnd->active=1;
//    SendMessage(hWnd,WM_ACTIVATE,WA_ACTIVE,(LPARAM)myWnd);
    
//    SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
//  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
//    SendMessage(hWnd,WM_PAINT,0,0);
    // c'� gi� nel/nei chiamante, forse togliere..
    return hWnd;
    }
  else {
    if(hWnd->active) {
      // in teoria quella attiva in precedenza � l'ultima ossia quella in cima a Z-order...PENULTIMA!
      myWnd=rootWindows;
      while(myWnd) {
        if(myWnd != hWnd && !myWnd->active) {
 				  myWnd->active=1;
          SendMessage(myWnd,WM_ACTIVATE,WA_ACTIVE,(LPARAM)hWnd);
          myWnd->active=1;
          SendMessage(myWnd,WM_NCPAINT,(WPARAM)NULL,0);
          SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
          SendMessage(myWnd,WM_PAINT,0,0);
          temp=hWnd->zOrder;
          hWnd->zOrder=myWnd->zOrder;
          myWnd->zOrder=temp;
          list_bubble_sort(&rootWindows);
          break;
          }
        myWnd=myWnd->next;
        }
  	  hWnd->active=0;
//      SendMessage(hWnd,WM_ACTIVATE,WA_INACTIVE,(LPARAM)hWnd);
      
//      SendMessage(hWnd,WM_NCPAINT,(WPARAM)NULL,0);
//  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
//      SendMessage(hWnd,WM_PAINT,0,0);
      // c'� gi� nel/nei chiamante, forse togliere..
      return hWnd;
      }
    }
  
  return NULL;    //NON deve accadere!
	}

int SetScrollPos(HWND hWnd,int nBar,int nPos,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      hWnd->scrollPosX=nPos;
      break;
    case SB_VERT:
      hWnd->scrollPosY=nPos;
      break;
    }
  if(bRedraw) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    return SendMessage(hWnd,WM_PAINT,0,0);
    }
  else
    return 1;
  }

int SetScrollInfo(HWND hWnd,int nBar,SCROLLINFO *lpsi,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      if(lpsi->fMask & SIF_POS)
        hWnd->scrollPosX=lpsi->nPos;
      if(lpsi->fMask & SIF_PAGE)
        ;
      if(lpsi->fMask & SIF_RANGE)
        ;
      break;
    case SB_VERT:
      if(lpsi->fMask & SIF_POS)
        hWnd->scrollPosY=lpsi->nPos;
      if(lpsi->fMask & SIF_PAGE)
        ;
      if(lpsi->fMask & SIF_RANGE)
        ;
      break;
    }
  if(bRedraw) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    return SendMessage(hWnd,WM_PAINT,0,0);
    }
  else
    return 1;
  }

BOOL SetScrollRange(HWND hWnd,int nBar,int nMinPos,int nMaxPos,BOOL bRedraw) {
  
  switch(nBar) {
    case SB_CTL:
      break;
    case SB_HORZ:
      hWnd->scrollPosX=(nMaxPos-nMinPos);   // boh finire..
      break;
    case SB_VERT:
      hWnd->scrollPosY=(nMaxPos-nMinPos);
      break;
    }
  if(bRedraw) {
    SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
    return SendMessage(hWnd,WM_PAINT,0,0);
    }
  else
    return 1;
  }

BOOL SetWindowText(HWND hWnd,const char *title) {

  SendMessage(hWnd,WM_SETTEXT,0,TRUE);
  SendMessage(hWnd,WM_ERASEBKGND,(WPARAM)&hWnd->hDC,0);
  return SendMessage(hWnd,WM_PAINT,0,0);
  }

int GetWindowText(HWND hWnd,char *lpString,int nMaxCount) {
  
  return SendMessage(hWnd,WM_GETTEXT,nMaxCount,(LPARAM)lpString);
  }

BOOL GetTitleBarInfo(HWND hWnd,TITLEBARINFO *pti) {
  
  // if(pti->cbSize=
  pti->rcTitleBar.top=hWnd->nonClientArea.top;
  pti->rcTitleBar.left=hWnd->nonClientArea.left;
  pti->rcTitleBar.right=hWnd->nonClientArea.right;
  if(hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION))
    pti->rcTitleBar.bottom=pti->rcTitleBar.top+=TITLE_HEIGHT;
  else
    pti->rcTitleBar.bottom=pti->rcTitleBar.top;

  pti->rgstate[0]=hWnd->style & (WS_SYSMENU | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_CAPTION) ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[2]=hWnd->style & WS_MINIMIZEBOX ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[3]=hWnd->style & WS_MAXIMIZEBOX  ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[4]=hWnd->style & 0 /*WS_HELP*/ ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  pti->rgstate[5]=hWnd->style & WS_SYSMENU ? STATE_SYSTEM_FOCUSABLE : STATE_SYSTEM_UNAVAILABLE;
  }


int PaintDesktop(HDC *hDC) {
  // PUO CONFLUIRE IN INVALIDATE, SE SI CREA LA WINDOW-DESKTOP
  
  switch(videoMode) {
    case MODE_LCD:
      fillRectLCD(0,0,_width,_height,desktopColor);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectangleFilled(0,0,_width,_height,desktopColor);
      break;
    }
  return 1;
  }

int DrawIcon8(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=icon;
  
  w=8; h=8;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawIcon(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR icon[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=icon;
  
  w=16; h=16;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawBitmap(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR bitmap[],UGRAPH_COORD_T xs, UGRAPH_COORD_T ys) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=bitmap;
  
  w=xs; h=ys;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i,y1+j,*p2++);
      }
    }
  }

int DrawCaret(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const GFX_COLOR caret[]) {
  UGRAPH_COORD_T w,h;
  GRAPH_COORD_T i, j;
  const GFX_COLOR *p2=caret;
  
  w=8; h=8;
  for(j=0; j<h; j++) {
    for(i=0; i<w; i++) {
      DrawPixelWindow(hDC,x1+i, y1+j, *p2++);
      }
    }
  }

BOOL TextOut(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const char *s) {
  char c;
  
#ifdef USING_SIMULATOR
  return;
#endif  
  
  setCursor(x1,y1);
  
  while(c=*s++) {
    
#ifdef USE_CUSTOM_FONTS 
  if(!gfxFont) { // 'Classic' built-in font
#endif

    switch(c) {
      case '\n':
        cursor_y += (hDC->font.fontSimple)*8;
        cursor_x  = 0;
        break;
      case '\r':
        // skip em
        break; 
      default:
        if(wrap && ((cursor_x + (hDC->font.fontSimple) * 6) >= hDC->area.right)) { 	// Heading off edge?
          // TENDENZIALMENTE QUA NON CI INTERESSA! textout fa una sola riga
//          cursor_x  = hDC->area.left;            // Reset x 
//          cursor_y += (hDC->fontSimple) * 8; // Advance y one line
          }
        DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, (hDC->font.fontSimple));
        cursor_x += (hDC->font.fontSimple) * 6;
        break; 
    	}

#ifdef USE_CUSTOM_FONTS 
  	} 
	else { // Custom font

    if(c == '\n') {
      cursor_x  = 0;
      cursor_y += (GRAPH_COORD_T)textsize *
                  (UINT8)pgm_read_byte(&gfxFont->yAdvance);
  	  } 
		else if(c != '\r') {
      UINT8 first = pgm_read_byte(&gfxFont->first);
      if((c >= first) && (c <= (UINT8)pgm_read_byte(&gfxFont->last))) {
        UINT8   c2    = c - pgm_read_byte(&gfxFont->first);
        GFXglyph *glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c2]);
        UINT8   w     = pgm_read_byte(&glyph->width),
                  h     = pgm_read_byte(&glyph->height);
        if((w > 0) && (h > 0)) { // Is there an associated bitmap?
          GRAPH_COORD_T xo = (INT8)pgm_read_byte(&glyph->xOffset); // sic
          if(wrap && ((cursor_x + textsize * (xo + w)) >= _width)) {
            // Drawing character would go off right edge; wrap to new line
            cursor_x  = 0;
            cursor_y += (GRAPH_COORD_T)textsize *
                        (UINT8)pgm_read_byte(&gfxFont->yAdvance);
          	}
          drawChar(cursor_x, cursor_y, c, textcolor, textbgcolor, textsize);
        	}
        cursor_x += pgm_read_byte(&glyph->xAdvance) * (GRAPH_COORD_T)textsize;
      	}
    	}

  	}
#endif

    }
  return 1;
  }

BOOL ExtTextOut(HDC *hDC,int x1,int y1,UINT options,const RECT *lpRect,const char *s,UINT n,const INT *lpDx) {
  char c;
  UINT cnt;
  
  setCursor(x1,y1);
  
  while(cnt<n) {
    c=*s++;
    
#ifdef USE_CUSTOM_FONTS 
  if(!gfxFont) { // 'Classic' built-in font
#endif

    switch(c) {
      case '\n':
        cursor_y += (hDC->font.fontSimple)*8;
        cursor_x  = 0;
        break;
      case '\r':
        // skip em
        break; 
      default:
        if(wrap && ((cursor_x + (hDC->font.fontSimple) * 6) >= hDC->area.right)) { 	// Heading off edge?
          // TENDENZIALMENTE QUA NON CI INTERESSA! textout fa una sola riga
//          cursor_x  = hDC->area.left;            // Reset x 
//          cursor_y += (hDC->fontSimple) * 8; // Advance y one line
          }
        if(lpRect)
          ;
        DrawCharWindow(hDC,cursor_x, cursor_y, c, hDC->foreColor, hDC->backColor, (hDC->font.fontSimple));
        cursor_x += (hDC->font.fontSimple) * 6;
        if(lpDx)
          cursor_x+=lpDx[cnt];
        break; 
    	}

#ifdef USE_CUSTOM_FONTS 
  	} 
	else { // Custom font

    if(c == '\n') {
      cursor_x  = 0;
      cursor_y += (GRAPH_COORD_T)textsize *
                  (UINT8)pgm_read_byte(&gfxFont->yAdvance);
  	  } 
		else if(c != '\r') {
      UINT8 first = pgm_read_byte(&gfxFont->first);
      if((c >= first) && (c <= (UINT8)pgm_read_byte(&gfxFont->last))) {
        UINT8   c2    = c - pgm_read_byte(&gfxFont->first);
        GFXglyph *glyph = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c2]);
        UINT8   w     = pgm_read_byte(&glyph->width),
                  h     = pgm_read_byte(&glyph->height);
        if((w > 0) && (h > 0)) { // Is there an associated bitmap?
          GRAPH_COORD_T xo = (INT8)pgm_read_byte(&glyph->xOffset); // sic
          if(wrap && ((cursor_x + textsize * (xo + w)) >= _width)) {
            // Drawing character would go off right edge; wrap to new line
            cursor_x  = 0;
            cursor_y += (GRAPH_COORD_T)textsize *
                        (UINT8)pgm_read_byte(&gfxFont->yAdvance);
          	}
          drawChar(cursor_x, cursor_y, c, textcolor, textbgcolor, textsize);
        	}
        cursor_x += pgm_read_byte(&glyph->xAdvance) * (GRAPH_COORD_T)textsize;
      	}
    	}

  	}
#endif

    cnt++;
    }
  return 1;
  }

int DrawText(HDC *hDC,const char *lpchText,int cchText,RECT *lprc,UINT format) {

  return ExtTextOut(hDC,lprc->left,lprc->top,format /*CONTROLLARE!*/,NULL,lpchText,cchText,NULL);
  }

void SetWindowTextCursor(HDC *hDC,BYTE col,BYTE row) {
  
  setTextCursor(col*hDC->font.fontSimple*6,row*hDC->font.fontSimple*8);
  }

BOOL MoveToEx(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,POINT *lppt) {
  
  if(lppt) {
    lppt->x=hDC->cursorX;
    lppt->y=hDC->cursorY;
    }
  hDC->cursorX=x;
  hDC->cursorY=y;
  }

BOOL LineTo(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  DrawLineWindow(hDC,hDC->cursorX, hDC->cursorY, x, y, hDC->foreColor);
  hDC->cursorX=x;
  hDC->cursorY=y;
  return 1;
  }

GFX_COLOR SetPixel(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y,GFX_COLOR color) {

  DrawPixelWindow(hDC,x,y,color);
  return color;   // forse vuole il colore precedente, finire quando ci spostiamo in RAM
  }
  
GFX_COLOR GetPixel(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  return (GFX_COLOR)CLR_INVALID;   // FINIRE in ram ecc
  }
  
BOOL Rectangle(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  
  DrawRectangleWindow(hDC, left, top, right, bottom, hDC->foreColor);
  return 1;
  }

BOOL FillRect(HDC *hDC,const RECT *rc) {
  
  FillRectangleWindow(hDC, rc->left, rc->top, rc->right, rc->bottom, hDC->foreColor);
  return 1;
  }

BOOL Ellipse(HDC *hDC,UGRAPH_COORD_T left,UGRAPH_COORD_T top,UGRAPH_COORD_T right,UGRAPH_COORD_T bottom) {
  
  DrawCircleWindow(hDC, left, top, right, bottom, hDC->foreColor);
  return 1;
  }

BOOL Arc(HDC *hDC,UGRAPH_COORD_T x1,UGRAPH_COORD_T y1,UGRAPH_COORD_T x2,UGRAPH_COORD_T y2,
  UGRAPH_COORD_T x3,UGRAPH_COORD_T y3,UGRAPH_COORD_T x4,UGRAPH_COORD_T y4) {
  
//  DrawCircleWindow(hDC, left, top, right, bottom, hDC->foreColor);
  }

BOOL FillPath(HDC *hDC) {
  }

BOOL FloodFill(HDC *hDC,int x,int y,GFX_COLOR color) {
  }

GFX_COLOR SetTextColor(HDC *hDC,GFX_COLOR color) {
  GFX_COLOR c=hDC->foreColor;
  
  hDC->foreColor=color;
  return c;
  }

GFX_COLOR GetTextColor(HDC *hDC) {
  
  return hDC->foreColor;
  }

GFX_COLOR SetBkColor(HDC *hDC,GFX_COLOR color) {
  GFX_COLOR c=hDC->backColor;
  
  hDC->backColor=color;
  return c;
  }

GFX_COLOR GetBkColor(HDC *hDC) {
  
  return hDC->backColor;
  }

int GetBkMode(HDC *hDC) {
  
  return 0 /*OPAQUE, TRANSPARENT*/;
  }

UINT SetTextAlign(HDC *hDC,UINT align) {
  // return prec
  }

UINT GetTextAlign(HDC *hDC) {
  
//  return TA_LEFT;     // finire ecc
  }

BOOL GetCharWidth(HDC *hDC,UINT iFirst,UINT iLast,INT *lpBuffer) {
  
  return 6;   // boh :)
  }

BOOL GetTextExtentPoint32(HDC *hDC,const char *lpString,int n,SIZE *psizl) {
  
  psizl->cx= 6 * n;
  psizl->cy= hDC->font.fontSimple * 8;
  return TRUE;
  }

static void DrawCharWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, unsigned char c, GFX_COLOR color, GFX_COLOR bg, UINT8 size) {
	INT8 i,j;
	const BYTE *fontPtr;

#ifdef USE_CUSTOM_FONTS 
  if(!gfxFont) { // 'Classic' built-in font
#endif

    if(!_cp437 && (c >= 176)) 
			c++; // Handle 'classic' charset behavior
#ifndef USE_256_CHAR_FONT 
		if(c>=128)
			return;
#endif

    switch(videoMode) {
      case MODE_LCD:
      case MODE_VGA:
      case MODE_COMPOSITE:
        // per ora gestiti tutti da pixel line ecc, poi magari potrebbe cambiare
    
        fontPtr=font+((UINT16)c)*5;
        for(i=0; i<6; i++) {
          UINT8 line;
          if(i<5) 
            line = pgm_read_byte(fontPtr+i);
          else  
            line = 0x0;
          for(j=0; j<8; j++, line >>= 1) {
            if(line & 0x1) {
              if(size == 1) 
                DrawPixelWindow(hDC,x+i,y+j,color);
              else
                FillRectangleWindow(hDC,x+(i*size),y+(j*size),size,size,color);
              } 
            else if(bg != color) {
              if(size == 1) 
                DrawPixelWindow(hDC,x+i,y+j,bg);
              else          
                FillRectangleWindow(hDC,x+(i*size),y+(j*size),size,size,bg);
              }
            }
          }

    #ifdef USE_CUSTOM_FONTS 
        } 
      else { // Custom font
        GFXglyph *glyph;
        UINT8  *bitmap;
        UINT16 bo;
        UINT8  w, h, xa;
        INT8   xo, yo;
        UINT8  xx, yy, bits, bit = 0;
        GRAPH_COORD_T  xo16, yo16;

        // Character is assumed previously filtered by write() to eliminate
        // newlines, returns, non-printable characters, etc.  Calling drawChar()
        // directly with 'bad' characters of font may cause mayhem!

        c -= pgm_read_byte(&gfxFont->first);
        glyph  = &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
        bitmap = (UINT8 *)pgm_read_pointer(&gfxFont->bitmap);

        bo = pgm_read_word(&glyph->bitmapOffset);
        w  = pgm_read_byte(&glyph->width),
                 h  = pgm_read_byte(&glyph->height),
                 xa = pgm_read_byte(&glyph->xAdvance);
        xo = pgm_read_byte(&glyph->xOffset),
                 yo = pgm_read_byte(&glyph->yOffset);
        xx, yy, bits, bit = 0;
        xo16, yo16;

        if(size > 1) {
          xo16 = xo;
          yo16 = yo;
          }

        // Todo: Add character clipping here

        // NOTE: THERE IS NO 'BACKGROUND' COLOR OPTION ON CUSTOM FONTS.
        // THIS IS ON PURPOSE AND BY DESIGN.  The background color feature
        // has typically been used with the 'classic' font to overwrite old
        // screen contents with new data.  This ONLY works because the
        // characters are a uniform size; it's not a sensible thing to do with
        // proportionally-spaced fonts with glyphs of varying sizes (and that
        // may overlap).  To replace previously-drawn text when using a custom
        // font, use the getTextBounds() function to determine the smallest
        // rectangle encompassing a string, erase the area with fillRect(),
        // then draw new text.  This WILL unfortunately 'blink' the text, but
        // is unavoidable.  Drawing 'background' pixels will NOT fix this,
        // only creates a new set of problems.  Have an idea to work around
        // this (a canvas object type for MCUs that can afford the RAM and
        // displays supporting setAddrWindow() and pushColors()), but haven't
        // implemented this yet.

        for(yy=0; yy<h; yy++) {
          for(xx=0; xx<w; xx++) {
            if(!(bit++ & 7)) {
              bits = pgm_read_byte(&bitmap[bo++]);
              }
            if(bits & 0x80) {
              if(size == 1) {
                drawPixel(x+xo+xx, y+yo+yy, color);
                } 
              else {
                fillRect(x+(xo16+xx)*size, y+(yo16+yy)*size, size, size, color);
                }
              }
            bits <<= 1;
            }
          }

        } // End classic vs custom font
  #endif
        break;
  	}

	}

static void __attribute__((always_inline)) Pixel(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {

  START_WRITE();
	setAddrWindow(x, y, 1, 1);
	writedata16(color);
  END_WRITE();
	}

static void DrawPixelWindow(HDC *hDC,UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color) {
  HWND hWnd;
  
  x+=hDC->area.left;
  y+=hDC->area.top;
  hWnd=WindowFromDC(hDC);
  if(hWnd->style & WS_CHILD) {
    x+=hWnd->parent->hDC.area.left;
    y+=hWnd->parent->hDC.area.top;
    }
  // mancherebbe il < 0...
  if(BoundaryCheckWindow(hDC,x,y))
    return;
  if(ZCheckWindow(hDC,x,y))
    return;
  
  switch(videoMode) {
    case MODE_LCD:
//      drawPixelLCD(x,y,color);
    	Pixel(x,y,color);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawPixel(x,y,color);
      break;
    }
  }

static void DrawHorizLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,UGRAPH_COORD_T x2,GFX_COLOR c) {

  while(x1<=x2) {
    DrawPixelWindow(hDC,x1,y1,c);
    x1++;
    }
  }

static void DrawVertLineWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,UGRAPH_COORD_T y2,GFX_COLOR c) {
  
  while(y1<=y2) {
    DrawPixelWindow(hDC,x1,y1,c);
    y1++;
    }
  }

static void DrawLineWindow(HDC *hDC,UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
 	BOOL steep;
	GRAPH_COORD_T dx,dy;
	GRAPH_COORD_T err;
	GRAPH_COORD_T ystep;
	GRAPH_COORD_T xbegin;
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
//        e qua credo sia in fondo del tutto inutile
//      drawLineLCD(x1,y1,x2,y2,c);
        }
      else {
        }

      steep = abs(y2-y1) > abs(x2-x1);
      if(steep) {
        _swap(&x1, &y1);
        _swap(&x2, &y2);
        }
      if(x1>x2) {
        _swap(&x1, &x2);
        _swap(&y1, &y2);
        }

      dx = x2-x1;
      dy = abs(y2-y1);
      err = dx/2;
      ystep = y1<y2 ? 1 : -1;

      xbegin = x1;
      if(steep) {
        for(; x1<=x2; x1++) {
          err -= dy;
          if(err < 0) {
            INT16 len = x1-xbegin;
            if(len)
              DrawVertLineWindow(hDC,y1,xbegin,xbegin+len,c);
            else
              DrawPixelWindow(hDC,y1,x1,c);
            xbegin = x1+1;
            y1 += ystep;
            err += dx;
            }
          }
        if(x1 > xbegin+1)
          DrawVertLineWindow(hDC,y1,xbegin,x1,c);
        } 
      else {
        for(; x1<=x2; x1++) {
          err -= dy;
          if(err < 0) {
            INT16 len = x1-xbegin;
            if(len)
              DrawHorizLineWindow(hDC,xbegin,y1,xbegin+len,c);
            else
              DrawPixelWindow(hDC,x1,y1,c);
            xbegin = x1+1;
            y1 += ystep;
            err += dx;
            }
          }
        if(x1 > xbegin+1)
          DrawHorizLineWindow(hDC,xbegin,y1,x1,c);
        }
      break;
      
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawLine(x1,y1,x2,y2,c);
      break;
    }

  }

static void DrawRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
        x1+=hDC->area.left;
        y1+=hDC->area.top;
        x2+=hDC->area.left;
        y2+=hDC->area.top;
        if(BoundaryCheckWindow(hDC,x1,y1))
          return;
        if(x2<=x1 || y2<=y1)
          return;
        if(x2 > hDC->area.right)  
          x2 = hDC->area.right;
        if(y2 > hDC->area.bottom)
          y2 = hDC->area.bottom;
        drawRectLCD(x1,y1,x2-x1+1,y2-y1+1,c);
        }
      else {
        DrawHorizLineWindow(hDC,x1,y1,x2,c);
        DrawHorizLineWindow(hDC,x1,y2,x2,c);
        DrawVertLineWindow(hDC,x1,y1,y2,c);
        DrawVertLineWindow(hDC,x2,y1,y2,c);
        }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectangle(x1,y1,x2,y2,c);
      break;
    }
  }

static void FillRectangleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, 
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
        x1+=hDC->area.left;
        y1+=hDC->area.top;
        x2+=hDC->area.left;
        y2+=hDC->area.top;
        if(BoundaryCheckWindow(hDC,x1,y1))
          return;
        if(x2<=x1 || y2<=y1)
          return;
        if(x2 > hDC->area.right)  
          x2 = hDC->area.right;
        if(y2 > hDC->area.bottom)  
          y2 = hDC->area.bottom;
        fillRectLCD(x1,y1,x2-x1+1,y2-y1+1,c);
        }
      else {
        while(y1<=y2) {
          DrawHorizLineWindow(hDC,x1,y1,x2,c);
          y1++;
          }
        }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawRectangleFilled(x1,y1,x2,y2,c);
      break;
    }
  }

static void DrawCircleWindow(HDC *hDC, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,
  UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
  UGRAPH_COORD_T r=(x2-x1+y2-y1)/(2*2);
  GRAPH_COORD_T f = 1 - r;
  GRAPH_COORD_T ddF_x = 1;
  GRAPH_COORD_T ddF_y = -2 * r;
  GRAPH_COORD_T x = 0;
  GRAPH_COORD_T y = r;
  HWND hWnd;
  
  switch(videoMode) {
    case MODE_LCD:
      hWnd=WindowFromDC(hDC);
      if(hWnd->active /* o zOrder*/) {   // diciamo - velocizzo se siamo al Top
        // forse inutile quando andremo in RAM
        x1+=hDC->area.left;
        y1+=hDC->area.top;
        x2+=hDC->area.left;
        y2+=hDC->area.top;
        if(BoundaryCheckWindow(hDC,x1,y1))
          return;
        if(x2<=x1 || y2<=y1)
          return;
        if(x2 > hDC->area.right)  
          x2 = hDC->area.right;
        if(y2 > hDC->area.bottom)  
          y2 = hDC->area.bottom;
        drawCircleLCD((x1+x2)/2,(y1+y2)/2,(x2-x1+y2-y1)/(2*2),c); // bah finire, adattare!
        }
      else {

      DrawPixelWindow(hDC,x1  , y1+r, c);
      DrawPixelWindow(hDC,x1  , y1-r, c);
      DrawPixelWindow(hDC,x1+r, y1  , c);
      DrawPixelWindow(hDC,x1-r, y1  , c);

      while(x<y) {
        if(f >= 0) {
          y--;
          ddF_y += 2;
          f += ddF_y;
          }
        x++;
        ddF_x += 2;
        f += ddF_x;

        DrawPixelWindow(hDC,x1 + x, y1 + y, c);
        DrawPixelWindow(hDC,x1 - x, y1 + y, c);
        DrawPixelWindow(hDC,x1 + x, y1 - y, c);
        DrawPixelWindow(hDC,x1 - x, y1 - y, c);
        DrawPixelWindow(hDC,x1 + y, y1 + x, c);
        DrawPixelWindow(hDC,x1 - y, y1 + x, c);
        DrawPixelWindow(hDC,x1 + y, y1 - x, c);
        DrawPixelWindow(hDC,x1 - y, y1 - x, c);
        }
      }
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      drawCircle((x1+x2)/2,(y1+y2)/2,(x2-x1+y2-y1)/(2*2),c); // bah finire, adattare!
      break;
    }
  }

static BOOL BoundaryCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  HWND hWnd=WindowFromDC(hDC);

  if(hWnd->style & WS_CHILD) {   // if(hWnd->parent) ..
//  	if((x > hWnd->parent->hDC.area.right) || (y > hWnd->parent->hDC.area.bottom)) 
// non so se � giusto...    	return TRUE;
    }
  else {
  	if((x > hDC->area.right) || (y > hDC->area.bottom)) 
    	return TRUE;
    }
	return FALSE;
	}

HWND WindowFromPoint(POINT pt) { //not retrieve a handle to a hidden or disabled
  HWND myWnd;
  
  myWnd=rootWindows;
  while(myWnd) {
    if(myWnd->visible && myWnd->enabled && PtInRect(&myWnd->nonClientArea,pt)) {
      return myWnd;
      }
    myWnd=myWnd->next;
    }
  return NULL;
  }


static BOOL ZCheckWindow(HDC *hDC,UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  HWND hWnd,myWnd;
  POINT pt;
  
  hWnd=WindowFromDC(hDC);
  if(hWnd->active /* o zOrder*/)    // diciamo :)
    return 0;
//  hWnd=container_of(hDC,struct _WINDOW,hDC);
  pt.x=x; pt.y=y;
  myWnd=hWnd->next;   // inizio da quella subito sopra di me
  while(myWnd) {
    if(hWnd->style & WS_CHILD) {
      
        WS_CLIPSIBLINGS; //gestire
        
      if(myWnd != hWnd->parent && myWnd->zOrder > hWnd->zOrder) {    // in teoria il test Zorder � inutile, dato il sort
        if(PtInRect(&myWnd->nonClientArea,pt)) {
          return 1;
          }
        }
      }
    else {
      if(myWnd->zOrder > hWnd->zOrder) {    // in teoria questo test � inutile, dato il sort
        if(PtInRect(&myWnd->nonClientArea,pt)) {
          return 1;
          }
        }
      }
    myWnd=myWnd->next;
    }
  return 0;
  }

BOOL SetRect(RECT *lprc,UGRAPH_COORD_T xLeft,UGRAPH_COORD_T yTop,UGRAPH_COORD_T xRight,UGRAPH_COORD_T yBottom) {
  
  lprc->left=xLeft;
  lprc->right=xRight;
  lprc->top=yTop;
  lprc->bottom=yBottom;
  }

BOOL SetRectEmpty(RECT *lprc) {
  
  lprc->left=lprc->right=lprc->top=lprc->bottom=0;
  }

// -------------------------------------------------------------------------------
WNDCLASS baseClass;


// -------------------------------------------------------------------------------
void SortLinkedListValue(struct _WINDOW *node) {   //https://stackoverflow.com/questions/35914574/sorting-linked-list-simplest-way
  struct _WINDOW *temp;
  int tempvar,j;  //temp variable to store node data
    
  temp = node->next;//temp node to hold node data and next link
  while(node && node->next) {
    for(j=0; j<maxWindows; j++) {   //[value 5 because I am taking only 5 nodes]
      if(node->zOrder > temp->zOrder) {   //swap node data
        tempvar = node->zOrder;
        node->zOrder= temp->zOrder;
        temp->zOrder = tempvar;
        }
      temp = temp->next;
      }
    node = node->next;
    }
  }
 
static void SortLinkedList(struct _WINDOW *head) {     // https://www.javatpoint.com/program-to-sort-the-elements-of-the-singly-linked-list
  struct _WINDOW *node = head, *i, *j;
  struct _WINDOW *temp;
  
#if 0
  //Node current will point to head  
  struct _WINDOW *current = head, *index = NULL;  
  int temp;  

  if(!head) {  
    return;  
    } 
  else {  
    while(current) {  
      //Node index will point to node next to current  
      index = current->next;  

      while(index ) {  
        //If current node's data is greater than index's node data, swap the data between them  
        if(current->zOrder > index->zOrder) {  
          temp = current->zOrder;  
          current->zOrder = index->zOrder;  
          index->zOrder = temp;  
          }  
        index = index->next;  
        }  
      current = current->next;  
      }      
    }  
#endif
  
  // https://stackoverflow.com/questions/8981823/bubble-sort-algorithm-for-a-linked-list
  i = node;
  while(i) {
    j = node->next;
    while(j) {
      if(i->zOrder > j->zOrder) {
        temp = i->next;
        i->next = j->next;
        j->next = temp;
        }
      j = j->next;
      }
    i = i->next;
    }
  }

void list_bubble_sort(struct _WINDOW **head) {    //https://stackoverflow.com/questions/21388916/bubble-sort-singly-linked-list-in-c-with-pointers
  int done = 0;         // True if no swaps were made in a pass

  // Don't try to sort empty or single-node lists
  if(!*head || !((*head)->next))
    return;

  while(!done) {
    struct _WINDOW **pv = head;         // "source" of the pointer to the current node in the list struct
    struct _WINDOW *nd = *head;            // local iterator pointer
    struct _WINDOW *nx = (*head)->next;  // local next pointer

    done = 1;

    while(nx) {
      if(nd->zOrder > nx->zOrder) {   // ordino da pi� basso a pi� alto (v. anche ZCheckWindow e HWND_TOP ecc)
        nd->next = nx->next;
        nx->next = nd;
        *pv = nx;
        done = 0;
        }
      pv = &nd->next;
      nd = nx;
      nx = nx->next;
      }
    }
  }


