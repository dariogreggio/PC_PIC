/***************************************************
  STM32 Support added by Jaret Burkett at OSHlab.com

  This is our library for the Adafruit  ILI9488 Breakout and Shield
  ----> http://www.adafruit.com/products/1651

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution

	Adapted by GD on 6/6/2022
 ****************************************************/

#ifndef _ILI9488H_
#define _ILI9488H_


#define ILI9488_TFTWIDTH  480
#define ILI9488_TFTHEIGHT 320

#define ILI9488_NOP     0x00
#define ILI9488_SWRESET 0x01
#define ILI9488_RDDID   0x04        // RDDIDIF
#define ILI9488_RDUMED  0x05
#define ILI9488_RDDST   0x09        // RDDPM

#define ILI9488_RDMODE  0x0A        // RDDPM
#define ILI9488_RDMADCTL  0x0B      // RDDMADCTL
#define ILI9488_RDPIXFMT  0x0C      // RDDCOLMOD
#define ILI9488_RDIMGFMT  0x0D      // RDDIM
#define ILI9488_RDDSM     0x0E
#define ILI9488_RDSELFDIAG  0x0F        // RDDSDR

#define ILI9488_SLPIN   0x10
#define ILI9488_SLPOUT  0x11
#define ILI9488_PTLON   0x12
#define ILI9488_NORON   0x13

#define ILI9488_INVOFF  0x20
#define ILI9488_INVON   0x21
#define ILI9488_ALLPOFF 0x22
#define ILI9488_GAMMASET 0x26       // non c'� nel doc...
#define ILI9488_DISPOFF 0x28        // DISOFF
#define ILI9488_DISPON  0x29        // DISON

#define ILI9488_CASET   0x2A
#define ILI9488_PASET   0x2B
#define ILI9488_RAMWR   0x2C
#define ILI9488_RAMRD   0x2E

#define ILI9488_PTLAR   0x30        // PLTAR
#define ILI9488_VSCRDEF 0x33
#define ILI9488_TEOFF   0x34
#define ILI9488_TEON    0x35
#define ILI9488_MADCTL  0x36
#define ILI9488_VSCRSADD 0x37
#define ILI9488_IDMON   0x39
#define ILI9488_PIXFMT  0x3A        // COLMOD
#define ILI9488_RAMRDRC 0x3E

#define ILI9488_TESLWR  0x44
#define ILI9488_TESLRD  0x45

#define ILI9488_WRDISBV 0x51
#define ILI9488_RDDISBV 0x52
#define ILI9488_WRCTRLD 0x53
#define ILI9488_RDCTRLD 0x54
#define ILI9488_WRCABC  0x55
#define ILI9488_RDCABC  0x56
#define ILI9488_WRCABCMB 0x5e
#define ILI9488_RDCABCMB 0x5f

#define ILI9488_RDABCSDR 0x68

#define ILI9488_IFMODE  0xB0

#define ILI9488_FRMCTR1 0xB1
#define ILI9488_FRMCTR2 0xB2
#define ILI9488_FRMCTR3 0xB3
#define ILI9488_INVCTR  0xB4
#define ILI9488_DFUNCTR 0xB6        // DISCTRL

#define ILI9488_ETMOD   0xB7
#define ILI9488_CECTRL1 0xB9
#define ILI9488_CECTRL2 0xBA
#define ILI9488_HSLCTRL 0xBE

#define ILI9488_PWCTR1  0xC0        // PWCTRL1
#define ILI9488_PWCTR2  0xC1
#define ILI9488_PWCTR3  0xC2
#define ILI9488_PWCTR4  0xC3
#define ILI9488_PWCTR5  0xC4
#define ILI9488_VMCTR1  0xC5        // VMCTRL
#define ILI9488_CABCCTRL1 0xC6
#define ILI9488_VMCTR2  0xC7
#define ILI9488_CABCCTRL2 0xC8
#define ILI9488_CABCCTRL3 0xC9
#define ILI9488_CABCCTRL4 0xCA
#define ILI9488_CABCCTRL5 0xCB
#define ILI9488_CABCCTRL6 0xCC
#define ILI9488_CABCCTRL7 0xCD
#define ILI9488_CABCCTRL8 0xCE
#define ILI9488_CABCCTRL9 0xCF

#define ILI9488_NVMWR    0xD0
#define ILI9488_NVMPKEY  0xD1
#define ILI9488_DISON    0xD2

#define ILI9488_RDID4   0xD3
#define ILI9488_ADJCTRL 0xD7
#define ILI9488_RDIDV   0xD8
//0xD9 � usato ma non risulta... "sekret command" ;)

#define ILI9488_RDID1   0xDA        // questi non ci sono nel doc! v. sopra
#define ILI9488_RDID2   0xDB
#define ILI9488_RDID3   0xDC
#define ILI9488_RDID4   0xDD

#define ILI9488_GMCTRP1 0xE0        // PGAMCTRL
#define ILI9488_GMCTRN1 0xE1        // NGAMCTRL
#define ILI9488_DMCTRN1 0xE2        // DGAMCTRL1
#define ILI9488_DMCTRN2 0xE3        // DGAMCTRL2

#define ILI9488_SETIMAGE 0xE9

#define ILI9488_ADJCTRL2 0xF2
#define ILI9488_ADJCTRL3 0xF7
#define ILI9488_ADJCTRL4 0xF8
#define ILI9488_ADJCTRL5 0xF9

#define ILI9488_SPIREAD  0xFB
#define ILI9488_ADJCTRL6 0xFC
#define ILI9488_ADJCTRL7 0xFF

/*
#define ILI9488_PWCTR6  0xFC
*/

#define MADCTL_MY  0x80
#define MADCTL_MX  0x40
#define MADCTL_MV  0x20
#define MADCTL_ML  0x10
#define MADCTL_RGB 0x00
#define MADCTL_BGR 0x08
#define MADCTL_MH  0x04


// Color definitions
#define ILI9488_BLACK       0x0000      /*   0,   0,   0 */
#define ILI9488_NAVY        0x000F      /*   0,   0, 128 */
#define ILI9488_DARKGREEN   0x03E0      /*   0, 128,   0 */
#define ILI9488_DARKCYAN    0x03EF      /*   0, 128, 128 */
#define ILI9488_MAROON      0x7800      /* 128,   0,   0 */
#define ILI9488_PURPLE      0x780F      /* 128,   0, 128 */
#define ILI9488_OLIVE       0x7BE0      /* 128, 128,   0 */
#define ILI9488_LIGHTGREY   0xC618      /* 192, 192, 192 */
#define ILI9488_DARKGREY    0x7BEF      /* 128, 128, 128 */
#define ILI9488_BLUE        0x001F      /*   0,   0, 255 */
#define ILI9488_GREEN       0x07E0      /*   0, 255,   0 */
#define ILI9488_CYAN        0x07FF      /*   0, 255, 255 */
#define ILI9488_RED         0xF800      /* 255,   0,   0 */
#define ILI9488_MAGENTA     0xF81F      /* 255,   0, 255 */
#define ILI9488_YELLOW      0xFFE0      /* 255, 255,   0 */
#define ILI9488_WHITE       0xFFFF      /* 255, 255, 255 */
#define ILI9488_ORANGE      0xFD20      /* 255, 165,   0 */
#define ILI9488_GREENYELLOW 0xAFE5      /* 173, 255,  47 */
#define ILI9488_PINK        0xF81F


int Adafruit_ILI9488_SW(int8_t _CS, int8_t _DC, int8_t _MOSI, int8_t _SCLK,
		   int8_t _RST, int8_t _MISO);
int Adafruit_ILI9488_HW(int8_t _CS, int8_t _DC, int8_t _RST);

  void Adafruit_ili9488_begin(uint32_t);
  void displayInit_ili9488(void);
    void setAddrWindow_ili9488(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T x1, UGRAPH_COORD_T y1);
    void setScrollArea(UGRAPH_COORD_T topFixedArea, UGRAPH_COORD_T bottomFixedArea);
    void scroll(uint16_t pixels);
    void pushColor(GFX_COLOR color);
    void pushColors(uint16_t *data, uint8_t len, BOOL first);
    int drawImage(const uint16_t* img, UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h);
    void fillScreen(GFX_COLOR color);
    int drawPixel(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR color);

    void drawFastVLine_ili9488(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T h, GFX_COLOR color);
    void drawFastHLine_ili9488(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, GFX_COLOR color);
    void fillRect(UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h,
      GFX_COLOR color);
    void setRotation_ili9488(uint8_t r);
    void invertDisplay(BOOL i);

  /* These are not for current use, 8-bit protocol only! */
  uint8_t  readdata(void);
uint8_t    readcommand8(uint8_t reg, uint8_t index);
  /*
  uint16_t readcommand16(uint8_t);
  uint32_t readcommand32(uint8_t);
  void     dummyclock(void);
  */

  void   spiwrite(uint8_t);
    void writeCommand(uint8_t c);
    void write16BitColor(GFX_COLOR color);
    void writeData(uint8_t);
    void writeData32(uint32_t);
    void commandList(uint8_t *addr);
  uint8_t  spiRead(void);

 
extern   uint8_t  tabcolor;



extern   BOOL  hwSPI;

extern     int8_t  _cs, _dc, _rst, _mosi, _miso, _sclk;


#endif
