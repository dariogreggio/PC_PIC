#include <xc.h>
#include "pc_pic_video.h"
#include "Adafruit_ST7735.h"
#include "Adafruit_ILI9488.h"
#include <sys/kmem.h>

extern BYTE DMA_READY videoRAM[800L*600];  
BYTE DMA_READY videoLCDBuffer[640*3];
extern BYTE videoTextRAM[80*25];
extern volatile DWORD vLine;

extern enum VIDEO_MODE videoMode;
extern BYTE cursorMode,oldCursorState;
extern BYTE savedCursorArea[16*16];

extern volatile BYTE commandReceived;


#define Color565(red, green, blue)    (GFX_COLOR) ((((GFX_COLOR)(red) & 0xF8) << 8) | (((GFX_COLOR)(green) & 0xFC) << 3) | (((GFX_COLOR)(blue) & 0xF8) >> 3))
#define ColorRGB(color)    (DWORD) ( ((((DWORD)color) & 0xf800) << 8) | ((((DWORD)color) & 0x07e0) << 5) | ((((DWORD)color) & 0x001f) << 3) )
#define ColorBGR(color)    (DWORD) ( ((color & 0xf800) >> 11) | ((color & 0x07e0) << 5) | ((((DWORD)color) & 0x001f) << 16) )
#define ColorR(color)    ((color & 0xf800) >> 8)        // left-justified, diciamo..
#define ColorG(color)    ((color & 0x07e0) >> 3)
#define ColorB(color)    ((color & 0x001f) << 3)
#define Color565To332(color)    (BYTE) ((WORD)( ((color & 0xe000) >> 8) | ((color & 0x0700) >> 6) | ((color & 0x0018) >> 3) ))
#define Color565To332R(color)   (BYTE) ((WORD)( ((color & 0xe000) >> 13) | ((color & 0x0700) >> 5) | ((color & 0x0018) << 3) ))
#define Color565To222(color)    (BYTE) ((WORD)( ((color & 0xc000) >> 10) | ((color & 0x0600) >> 7) | ((color & 0x0018) >> 3) ))
#define Color24To565(color)    ((((color >> 16) & 0xFF) / 8) << 11) | ((((color >> 8) & 0xFF) / 4) << 5) | (((color) &  0xFF) / 8)
  //convert 24bit color into packet 16 bit one (credits for this are all mine) GD made a macro!
#define Color565ToRGB(color)    ((DWORD)( ((color & 0xf800) >> 8) | ((DWORD)(color & 0x07e0) << 5) | ((DWORD)(color & 0x001f) << 19) ))
  // per ILI...

volatile BYTE lcd_dirty;
void DMA_Init2(void);    // per SPI -> display

int drawRectangleFilled(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c);

void putCursor(UGRAPH_COORD_T x,UGRAPH_COORD_T y,BYTE *from,BYTE *to);


int drawPixel(UGRAPH_COORD_T x, UGRAPH_COORD_T y, GFX_COLOR c) {
	DWORD i;

	ClrWdt();

#ifdef PATCH_VGA
  if(videoMode==MODE_VGA /* && width>=640 */) {
    x /= 2;
    }
	if(y>=_height || x>=_width)
		return 0;

	i=(DWORD)_width*y+x;
	videoRAM[i] = Color565To332R(c);

#else
	if(y>=_height || x>=_width)
		return 0;

  switch(videoMode) {
    case MODE_LCD_DMA:
      i=((DWORD)_width*2)*y+(x*2);
      videoRAM[i] = LOBYTE(c);
      videoRAM[i+1] = HIBYTE(c);
      break;
    case MODE_VGA:
      i=((DWORD)_width  +HORIZ_PORCH_VGA)*y+x   +HORIZ_PORCH_VGA;
      videoRAM[i] = Color565To332R(c);
      break;
    case MODE_COMPOSITE:
      i=((DWORD)_width  +HORIZ_PORCH_COMP)*y+x   +HORIZ_PORCH_COMP;
      videoRAM[i] = Color565To332R(c);
      break;
    case MODE_LCD:
      i=((DWORD)_width)*y+x;
      videoRAM[i] = Color565To332R(c);
      break;
    }
#endif
  
  return 1;
	}

int drawPixelPoint(POINT pt, GFX_COLOR c) {
  
  drawPixel(pt.x,pt.y,c);
  }

static void drawHorizLine(UGRAPH_COORD_T x1, UGRAPH_COORD_T y,UGRAPH_COORD_T x2,GFX_COLOR c) {

  while(x1<=x2)
    drawPixel(x1++,y,c);
  }

static void drawVertLine(UGRAPH_COORD_T x, UGRAPH_COORD_T y1,UGRAPH_COORD_T y2,GFX_COLOR c) {
  
  while(y1<=y2)
    drawPixel(x,y1++,c);
  }
// � ancora da verificare la cosa che le linee hor/ver sforano di uno... ma poi pu� succedere che le oblique siano incomplete... 28/6/22
void drawLine(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
 	BOOL steep;
	GRAPH_COORD_T dx,dy;
	GRAPH_COORD_T err;
	GRAPH_COORD_T ystep;
	GRAPH_COORD_T xbegin;

  steep = abs(y2-y1) > abs(x2-x1);
  if(steep) {
    _swap(&x1, &y1);
    _swap(&x2, &y2);
    }
  if(x1>x2) {
    _swap(&x1, &x2);
    _swap(&y1, &y2);
    }

  dx = x2-x1;
  dy = abs(y2-y1);
  err = dx/2;
  ystep = y1<y2 ? 1 : -1;

  xbegin = x1;
  if(steep) {
    for(; x1<x2; x1++) {
      err -= dy;
      if(err < 0) {
        INT16 len = x1-xbegin;
        if(len) {
          if(textsize==1)
            drawVertLine(y1,xbegin,xbegin+len,c);
          else {
            while(len--) {
              drawRectangleFilled(y1,xbegin,y1+textsize,xbegin+textsize,c);
              xbegin++;
              }
            }
          }
        else {
          if(textsize==1)   // usare ALTRA size...
            drawPixel(y1,x1,c);
          else
            drawRectangleFilled(y1,x1,y1+textsize,x1+textsize,c);
          }
        xbegin = x1+1;
        y1 += ystep;
        err += dx;
        }
      }
    if(x1 > xbegin+1) {
      if(textsize==1)
        drawVertLine(y1,xbegin,x1,c);
      else {
        while(xbegin<=x1) {
          drawRectangleFilled(y1,xbegin,y1+textsize,xbegin+textsize,c);
          xbegin++;
          }
        }
      }
    } 
  else {
    for(; x1<x2; x1++) {
      err -= dy;
      if(err < 0) {
        INT16 len = x1-xbegin;
        if(len) {
          if(textsize==1)
            drawHorizLine(xbegin,y1,xbegin+len,c);
          else {
            while(len--) {
              drawRectangleFilled(xbegin,y1,xbegin+textsize,y1+textsize,c);
              xbegin++;
              }
            }
          }
        else {
          if(textsize==1)
            drawPixel(x1,y1,c);
          else
            drawRectangleFilled(x1,y1,x1+textsize,y1+textsize,c);
          }
        xbegin = x1+1;
        y1 += ystep;
        err += dx;
        }
      }
    if(x1 > xbegin+1) {
      if(textsize==1)
        drawHorizLine(xbegin,y1,x1,c);
      else {
        while(xbegin<=x1) {
          drawRectangleFilled(xbegin,y1,xbegin+textsize,y1+textsize,c);
          xbegin++;
          }
        }
      }
    }

	}

int drawRectangle(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
	UGRAPH_COORD_T x,y;

	if(x1>x2 || y1>y2)
		return 0;
	drawHorizLine(x1,y1,x2,c);
	drawVertLine(x1,y1,y2,c);
	drawVertLine(x2,y1,y2,c);
	drawHorizLine(x1,y2,x2,c);
  
  return 1;
	}

int drawRect(const RECT *rc, GFX_COLOR c) {
	UGRAPH_COORD_T x,y;

	if(rc->left>rc->right || rc->top>rc->bottom)
		return 0;
	drawHorizLine(rc->left,rc->top,rc->right,c);
	drawVertLine(rc->left,rc->top,rc->bottom,c);
	drawVertLine(rc->right,rc->top,rc->bottom,c);
	drawHorizLine(rc->left,rc->bottom,rc->right,c);

  return 1;
	}

int drawRectangleFilled(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, GFX_COLOR c) {
	UGRAPH_COORD_T y;

	if(x1>x2 || y1>y2)
		return 0;
	for(y=y1; y<y2; y++) {
		drawHorizLine(x1,y,x2,c);
		}

  return 1;
	}

int drawRectFilled(RECT *rc, GFX_COLOR c) {
	UGRAPH_COORD_T y;

	if(rc->left>rc->right || rc->top>rc->bottom)
		return 0;
	for(y=rc->top; y<rc->bottom; y++)
		drawHorizLine(rc->left,y,rc->right,c);

  return 1;
	}


void screenCLS(GFX_COLOR c) {
	DWORD i;

  switch(videoMode) {
    case MODE_LCD:
      clearScreenLCD();
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      for(i=0; i<(((DWORD)_height)*_width); i++) {
        videoRAM[i]=Color565To332R(c);
        ClrWdt();
        }
      break;
    case MODE_LCD_DMA:
      for(i=0; i<(((DWORD)_height)*_width*2); i+=2) {
        videoRAM[i] = HIBYTE(c);
        videoRAM[i+1] = LOBYTE(c);
        ClrWdt();
        }
      break;
    }

	}

void scrollArea(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1, UGRAPH_COORD_T x2, UGRAPH_COORD_T y2, int16_t dx, int16_t dy) {
  int x,y;
  
  if(cursorMode & 0b10000000 && oldCursorState & 0b10000000) {
    putCursor(cursor_x,cursor_y,savedCursorArea,NULL);
    oldCursorState &= ~0b10000000;
    }

  switch(videoMode) {
    case MODE_LCD:
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
      for(y=y1; y<y2; y++) {
        BYTE *p1,*p2;
        p1=((BYTE *)videoRAM)+y*(x2-x1);
        p2=((BYTE *)videoRAM)+(y+dy)*(x2-x1);
        // per ora solo dy e su righe intere...
        for(x=x1; x<x2; x++) {
          *(p2+x)=*(p1+x);
          }
        ClrWdt();
        }
      break;
    case MODE_LCD_DMA:
      if(dy<0) {
        for(y=y1; y<y2; y++) {
          WORD *p1,*p2;
          p1=((WORD *)videoRAM)+y*(x2-x1);
          p2=((WORD *)videoRAM)+(y+dy)*(x2-x1);
          // per ora solo dy e su righe intere...
          // e ovviamente occhio alle sovrascritture!
          for(x=x1; x<x2; x++) {
            *(p2+x)=*(p1+x);
            }
          ClrWdt();
          }
        }
      else {
        for(y=y2-1; y>=y1; y--) {
          WORD *p1,*p2;
          p1=((WORD *)videoRAM)+y*(x2-x1);
          p2=((WORD *)videoRAM)+(y+dy)*(x2-x1);
          // per ora solo dy e su righe intere...
          // e ovviamente occhio alle sovrascritture!
          for(x=x1; x<x2; x++) {
            *(p2+x)=*(p1+x);
            }
          ClrWdt();
          }
        }
      for(y=y2+dy; y<_height; y++) {// PULISCO COS� sempre! v. fillrect sotto...
        WORD *p1;
        p1=((WORD *)videoRAM)+y*(x2-x1);
        for(x=x1; x<x2; x++) {
          *(p1+x)=0;
          }
        ClrWdt();
        }
      break;
		}
  
  }


void drawCircle(UGRAPH_COORD_T x0, UGRAPH_COORD_T y0, UGRAPH_COORD_T r, GFX_COLOR color) {
  GRAPH_COORD_T f = 1 - r;
  GRAPH_COORD_T ddF_x = 1;
  GRAPH_COORD_T ddF_y = -2 * r;
  GRAPH_COORD_T x = 0;
  GRAPH_COORD_T y = r;

  drawPixel(x0  , y0+r, color);
  drawPixel(x0  , y0-r, color);
  drawPixel(x0+r, y0  , color);
  drawPixel(x0-r, y0  , color);

  while(x<y) {
    if(f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
      }
    x++;
    ddF_x += 2;
    f += ddF_x;

    drawPixel(x0 + x, y0 + y, color);
    drawPixel(x0 - x, y0 + y, color);
    drawPixel(x0 + x, y0 - y, color);
    drawPixel(x0 - x, y0 - y, color);
    drawPixel(x0 + y, y0 + x, color);
    drawPixel(x0 - y, y0 + x, color);
    drawPixel(x0 + y, y0 - x, color);
    drawPixel(x0 - y, y0 - x, color);
		}
	}

extern const BYTE font8x8_basic[256][8];    //8*8
extern const BYTE font6x8_basic[256][8];   //6*8
void writeChar(char ch) {
	uint32_t /*WORD*/ xc,yc;
	const BYTE *p;
	BYTE cmask;

	if(textsize_x==6)
    p=(BYTE *)&font6x8_basic[(BYTE)ch];
  else
    p=(BYTE *)&font8x8_basic[(BYTE)ch];
  switch(ch) {
    case '\n':
			if(cursorMode & 0b10000000 && oldCursorState & 0b10000000) {
        oldCursorState &= ~0b10000000;
				putCursor(cursor_x,cursor_y,savedCursorArea,NULL);
				}
			// mah direi che serve!

      cursor_x = 0;
      cursor_y += textsize_y;
      if(cursor_y>=_height) {
        scrollArea(0, textsize_y, _width, _height, 0, - textsize_y);
//non va.. credo le line        drawRectangleFilled(0, _height-textsize*8, _width, textsize*8, BLACK);
        cursor_y -= textsize_y;
        }
      break;
    case '\t':    // TAB= 8spazi
      if(cursor_x < ((_width - 1) & -(((int16_t)textsize_x)*8))) {
        if(cursorMode & 0b10000000 && oldCursorState & 0b10000000) {
          putCursor(cursor_x,cursor_y,savedCursorArea,NULL);
          }
        // mah direi che serve!

#warning BUG TAB pos. 0!
        xc=cursor_x / textsize_x;
        while(++xc % 8) {
          cursor_x += textsize_x;
          }
        }
      break;
    case '\r':        // skip em
      break;
    case '\x8':
      if(cursor_x >= textsize_x) {
        if(cursorMode & 0b10000000 && oldCursorState & 0b10000000) {
          putCursor(cursor_x,cursor_y,savedCursorArea,NULL);
          }
        // forse metterli tutti insieme :)
        
        cursor_x -= textsize_x;
        writeChar(' ');   // non � il massimo ma ok
        cursor_x -= textsize_x;
        }
      break;
    default:
      if(wrap && ((cursor_x + textsize_x) > _width)) { 	// Heading off edge?
        cursor_x = 0;             // Reset x to zero
        cursor_y += textsize_y; // Advance y one line
        if(cursor_y>=_height) {
          scrollArea(0, textsize_y, _width, _height, 0, - textsize_y);
//non va          drawRectangleFilled(0, _height-textsize*8, _width, textsize*8, BLACK);
          cursor_y -= textsize_y;
          }
        }
drawchar:
      for(yc=0; yc<8; yc++,p++) {
        cmask = 0b10000000;
        for(xc=0; xc<textsize_x; xc++, cmask >>= 1) {
          if(*p & cmask)
            drawPixel(xc+cursor_x,yc+cursor_y,textcolor);
          else
            drawPixel(xc+cursor_x,yc+cursor_y,textbgcolor);
          }
        }

      xc=cursor_x / textsize_x;
      yc=cursor_y / textsize_y;
      videoTextRAM[yc*(_width/textsize_x) +xc]=ch;

      cursor_x += textsize_x;
      break;
    }
	}
void writeCharXY(UGRAPH_COORD_T x, UGRAPH_COORD_T y, char ch, GFX_COLOR c) {
	uint32_t /*WORD*/ xc,yc;
	const BYTE *p;
	BYTE cmask;

	if(textsize_x==6)
    p=(BYTE *)&font6x8_basic[(BYTE)ch];
  else
    p=(BYTE *)&font8x8_basic[(BYTE)ch];
	for(yc=0; yc<8; yc++,p++) {
		cmask = 0b10000000;
		for(xc=0; xc<textsize_x; xc++, cmask >>= 1) {
			if(*p & cmask)
				drawPixel(xc+x,yc+y,c);
			else
				drawPixel(xc+x,yc+y,0);
// gestire colore di sfondo?
			}
		}
	}

int writeStringXY(UGRAPH_COORD_T x, UGRAPH_COORD_T y, const char *s, GFX_COLOR c) {
  
  x*=textsize_x;
  y*=textsize_y;

	while(*s) {
// gestire CR,LF ecc; limiti schermo...
		switch(*s) {
			case CR:
				x=0;
				break;
			case 9:
				x+=textsize_y;    // fare/finire! 
				break;
			case LF:
				y+=textsize_y;
				break;
			default:
				writeCharXY(x,y,*s,c);
				x+=textsize_x;
				break;
			}
		s++;
		}
	return 1;	
	}

int writeString(const char *s) {
// bah in pratica usiamo printf...
	while(*s) {
    writeChar(*s++);
		}
	return 1;	
	}

int drawImage(const WORD b[],UGRAPH_COORD_T x, UGRAPH_COORD_T y, UGRAPH_COORD_T w, UGRAPH_COORD_T h) {
	WORD i;

	for(i=0; i<(((DWORD)_height)*_width); i++) {
		videoRAM[i]=  Color565To332R(b[i]);
		ClrWdt();
		}
	
	}

int drawIcon8(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const WORD icon[]) {
  int x,y;
  BYTE *p;
  const WORD *p2=icon;
  
	for(y=0; y<8; y++) {
    p=((BYTE *)videoRAM)+((y1+y)*_width)+x1;
    for(x=0; x<8; x++) {
      *p=Color565To332R(*p2);
      p2++;
      ClrWdt();
  		}
		}
  }

int drawIcon(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const WORD icon[]) {
  int x,y;
  BYTE *p;
  const WORD *p2=icon;
  
	for(y=0; y<16; y++) {
    p=((BYTE *)videoRAM)+((y1+y)*_width)+x1;
    for(x=0; x<16; x++) {
      *p=Color565To332R(*p2);
      p2++;
      ClrWdt();
  		}
		}
  }

int drawPointer(UGRAPH_COORD_T x1, UGRAPH_COORD_T y1,const WORD icon[]) {
  int x,y;
  BYTE *p;
  const WORD *p2=icon;
  
	for(y=0; y<16; y++) {
    p=((BYTE *)videoRAM)+((y1+y)*_width)+x1;
    for(x=0; x<16; x++) {
      *p=Color565To332R(*p2);
      p2++;
      ClrWdt();
  		}
		}
  }

void setCursor(UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  switch(videoMode) {
    case MODE_LCD:
      setCursorLCD(x,y);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      cursor_x = x;
      cursor_y = y;
      break;
    }
  }

void putCursor(UGRAPH_COORD_T x,UGRAPH_COORD_T y,BYTE *from,BYTE *to) {
  GFX_COLOR *p1,*from1,*to1;
  BYTE *p2,*from2,*to2;
  int x1,y1,ySize;
  
	if(y>=_height || x>=_width)
		return;
  
  if(cursorMode & 2) {
    ySize=8;    // occhio font..
    }
  else {
    ySize=2;    // occhio font..
    y+=6;
    }

  switch(videoMode) {
    case MODE_LCD_DMA:
      p1=(GFX_COLOR*)&videoRAM[((DWORD)_width*2)*y+(x*2)];
      from1=(GFX_COLOR*)from;
      to1=(GFX_COLOR*)to;
      break;
    case MODE_VGA:
      p2=&videoRAM[((DWORD)_width  +HORIZ_PORCH_VGA)*y+x   +HORIZ_PORCH_VGA];
      from2=(BYTE*)from;
      to2=(BYTE*)to;
      break;
    case MODE_COMPOSITE:
      p2=&videoRAM[((DWORD)_width  +HORIZ_PORCH_COMP)*y+x   +HORIZ_PORCH_COMP];
      from2=(BYTE*)from;
      to2=(BYTE*)to;
      break;
    case MODE_LCD:
      break;
    }
  
  for(y1=0; y1<ySize; y1++) {   // parametrizzare font..
    for(x1=0; x1<textsize_x; x1++) {
      if(from) {
        switch(videoMode) {
          case MODE_LCD_DMA:
            *p1++=*from1++;     // recupera area prec
            break;
          case MODE_VGA:
          case MODE_COMPOSITE:
            *p2++=*from2++;     // recupera area prec
            break;
          case MODE_LCD:    // bah per ora cos�.. plotto e basta, tanto tendenzialmente sono OLTRE l'ultimo char!
            writeCharXY(cursor_x,cursor_y,' ', WHITE);    // 
            break;
          }
        }
      else {
        switch(videoMode) {   // poi plotto cursore
          case MODE_LCD_DMA:
            if(to) {
              *to1++=*p1;     // se devo salvare area sottostante, lo faccio
              }
            *p1++=WHITE;
            break;
          case MODE_VGA:
            if(to) {
              *to2++=*p2;     // se devo salvare area sottostante, lo faccio
              }
            *p2++=Color565To332R(WHITE);
            break;
          case MODE_COMPOSITE:
            if(to) {
              *to2++=*p2;     // se devo salvare area sottostante, lo faccio
              }
            *p2++=Color565To332R(WHITE);
            break;
          case MODE_LCD:    // bah per ora cos�.. plotto e basta, tanto tendenzialmente sono OLTRE l'ultimo char!
            writeCharXY(cursor_x,cursor_y,cursorMode & 2 ? '\x7f' : '_', WHITE);    // bianco fisso! :)
            break;
          }
        }
      }
    p1+=_width-x1;
    p2+=_width-x1;
    }
  
  }

void setTextCursor(UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  
  if(cursorMode & 0b10000000 && oldCursorState & 0b10000000) {
    oldCursorState &= ~0b10000000;
    putCursor(cursor_x,cursor_y,savedCursorArea,NULL);
    }
  switch(videoMode) {
    case MODE_LCD:
      setCursor(x*textsize_x,y*textsize_y);
      break;
    case MODE_VGA:
    case MODE_COMPOSITE:
    case MODE_LCD_DMA:
      setCursor(x*textsize_x,y*textsize_y);
      break;
    }
  }

void setColors(GFX_COLOR c,GFX_COLOR bg) {
  
  textcolor=c;
  textbgcolor=bg;
  }

BOOL PtInRect(const RECT *lprc,POINT pt) {
  
  if(pt.x>=lprc->left && pt.x<lprc->right &&
          pt.y>=lprc->top && pt.y<lprc->bottom)
    return TRUE;
  else
    return FALSE;
  }

POINT MAKEPOINT(UGRAPH_COORD_T x,UGRAPH_COORD_T y) {
  POINT pt;
  
  pt.x=x; pt.y=y;
  return pt;
  }

BOOL IsRectEmpty(const RECT *lprc) {
  
  if(lprc->bottom<=lprc->top || lprc->right<=lprc->left)
    return 1;
  else
    return 0;
  }

void displayDMA(void) {
	WORD i;
   
    
  if(!m_SPICSBit)     // non deve rientrare o si schianta ossia butta fuori merda!
    return;
  //(poi nel caso fare qualcosa anche per i2c...))
  
  if(!IS_ILI()) {
    START_WRITE();
    uint32_t xa = ((uint32_t)0 << 16) | (_width-1);
    uint32_t ya = ((uint32_t)0 << 16) | (_height-1); 

    writeCommand(ST77XX_CASET); // Column addr set
    SPI_WRITE32(xa);

    writeCommand(ST77XX_RASET); // Row addr set
    SPI_WRITE32(ya);

    writeCommand(ST77XX_RAMWR); // write to RAM
    }
  else {
    START_WRITE();
    uint32_t xa = ((uint32_t)0 << 16) | (_width-1);
    uint32_t ya = ((uint32_t)0 << 16) | (_height-1); 

    writeCommand(ILI9488_CASET); // Column addr set
//    writeData(0 >> 8);
//    writeData(0 & 0xFF);     // XSTART
//    writeData((_width-1) >> 8);
//    writeData((_width-1) & 0xFF);     // XEND
    SPI_WRITE32(xa);

    writeCommand(ILI9488_PASET); // Row addr set
//    writeData(0>>8);
//    writeData(0 & 0xff);     // YSTART
//    writeData((_height-1)>>8);
//    writeData((_height-1) & 0xff);     // YEND
    SPI_WRITE32(ya);

    writeCommand(ILI9488_RAMWR); // write to RAM
    }

	ClrWdt();

//  if(sid != -1) {
    // SPI
  
  m_SPICSBit = 1;   // ergo inutile :)
  m_LCDDCBit = 1;
  if(!IS_ILI()) {
    SPI1CONbits.MODE16=1;
    }
  else {
    SPI1CONbits.MODE16=0;
    }
  
  if(!commandReceived)
    LATDCLR=VIRQ_MASK;
  
  DMA_Init2();
   

	lcd_dirty=2;    // o farlo fare all'IRQ? o metto 2 per indicare
	}

void DMA_Init2(void) {    // per SPI -> display
// si pu� usare lo 0 anche qua o no??
  
  IEC3CLR = _IEC3_SPI1TXIE_MASK; //Make sure SPI TX interrupt is disabled
  IFS3CLR = _IFS3_SPI1TXIF_MASK;
  
  IFS4CLR=_IFS4_DMA1IF_MASK; //clear any pending DMA channel 1 interrupt
  
  DCH1CON = 0x0002;   // channel off, priority 2, no chaining, one shot
  DCH1ECON = 0;    // no start or stop IRQs, no pattern match
#ifndef USING_SIMULATOR
  DCH1SSA = KVA_TO_PA(&videoLCDBuffer[0]);  //s transfer source physical address
#else
  DCH1SSA = &videoRAM;  //s transfer source physical address
#endif
  if(!IS_ILI()) {
    DCH1SSIZ = _width*2;       // source size (un/tot di righe a 16bit)
    DCH1DSIZ = 2;    // destination size 
    DCH1CSIZ = 2;                   // 2 bytes transferred per event
    }
  else {
    DCH1SSIZ = _width*3;       // source size (un/tot di righe a 24bit)
    DCH1DSIZ = 1;    // destination size 
    DCH1CSIZ = 1;                   // 3 bytes transferred per event
    }

#ifndef USING_SIMULATOR
  DCH1DSA = KVA_TO_PA(&SPI1BUF);   // transfer destination physical address
#else
  DCH1DSA = &SPI1BUF;   // transfer destination physical address
#endif
  DCH1INT = 0;                    // clear all interrupts
  //DCH1ECONSET = _ADC_DATA4_VECTOR << _DCH0ECON_CHSIRQ_POSITION;
  //DCH1ECONSET = _DCH0ECON_SIRQEN_MASK;
  DCH1ECONbits.CHSIRQ = /*_TIMER_1_VECTOR*/ _SPI1_TX_VECTOR;
  DCH1ECONbits.SIRQEN = 1;  // enable DMA 1 for IRQ trigger
  
  DCH1INTbits.CHBCIE = 1;  // Interrupt when block transfer complete [the fill is done].

  m_SPICSBit=0;   // un pizzico prima di far partire la cosa!

  vLine=0;
  
  {int i;
  if(!IS_ILI()) {
    WORD *p1,*p2;
    p1=(WORD *)&videoLCDBuffer[0];
    p2=(WORD *)&videoRAM[0]+vLine*_width;
    for(i=0; i<_width; i++) {
      *p1++=*p2++;
      }
    }
  else {
    BYTE *p1;
    WORD *p2;
    p1=&videoLCDBuffer[0];
    p2=(WORD *)&videoRAM[0]+vLine*_width;
    for(i=0; i<_width; i++) {
/*        *p1++ = *p2 & 0xf8;          // 80uS
      *p1 = (*p2++ & 0x7) << 5;
      *p1++ |= (*p2 & 0xe0) >> 5;
      *p1++ = *p2++ << 3;*/
      *p1++ = (*p2 & 0x001f) << 3;    // 70uS
      *p1++ = (*p2 & 0x07e0) >> 3;
      *p1++ = (*p2++ & 0xf800) >> 8;
      }
    }
  }
  
  
  DMACONbits.ON = 1;  // enable global DMA controller  
  
  IPC33bits.DMA1IP=2;            // set IPL 2, sub-priority 2 (v. timer2)
  IPC33bits.DMA1IS=2;
//  IPC33SET = 2 << _IPC33_DMA1IP_POSITION; // 
//  IPC33SET = 0 << _IPC33_DMA1IS_POSITION; // 
  IEC4bits.DMA1IE=1;             // enable DMA channel 1 interrupt
  //IEC4SET = _IEC4_DMA1IE_MASK; // enable DMA channel 1 interrupts
  
  DCH1CONbits.CHEN = 1; // turn on DMA channel 1/start

  }

